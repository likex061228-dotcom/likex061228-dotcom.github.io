import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {TransformControls} from 'three/addons/controls/TransformControls.js';
export class PhysicsView{
 constructor(host,onSelect,onMove){
  this.host=host;this.onSelect=onSelect;this.onMove=onMove;this.meshes=[];this.editing=false;this.session=null;
  this.renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});this.renderer.setPixelRatio(Math.min(devicePixelRatio,2));this.renderer.setClearColor(0x101d24);this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  const canvas=this.renderer.domElement;canvas.setAttribute('aria-label','由MuJoCo状态驱动的三维机械场景');canvas.setAttribute('role','img');canvas.tabIndex=0;host.append(canvas);
  this.scene=new THREE.Scene();this.scene.fog=new THREE.Fog(0x101d24,9,25);
  this.camera=new THREE.PerspectiveCamera(40,1,.01,100);this.camera.up.set(0,0,1);this.camera.position.set(2.7,-3.4,2.5);
  this.orbit=new OrbitControls(this.camera,canvas);this.orbit.target.set(0,0,.6);this.orbit.enableDamping=true;this.orbit.minDistance=.15;this.orbit.maxDistance=25;
  this.scene.add(new THREE.HemisphereLight(0xd8ece7,0x29434b,2.2));const light=new THREE.DirectionalLight(0xffedcb,3);light.position.set(2,-3,6);light.castShadow=true;light.shadow.mapSize.set(2048,2048);light.shadow.camera.left=-5;light.shadow.camera.right=5;light.shadow.camera.top=5;light.shadow.camera.bottom=-5;this.scene.add(light);
  const grid=new THREE.GridHelper(10,50,0x4a6b65,0x21373c);grid.rotation.x=Math.PI/2;grid.position.z=.001;this.scene.add(grid);
  const axes=new THREE.AxesHelper(.35);axes.position.set(-1,-.7,.005);this.scene.add(axes);
  this.group=new THREE.Group();this.scene.add(this.group);
  this.transform=new TransformControls(this.camera,canvas);this.transform.setMode('translate');this.transform.setSpace('world');this.transform.setSize(.8);this.transform.setTranslationSnap(.01);this.scene.add(this.transform.getHelper());
  this.transform.addEventListener('dragging-changed',e=>{this.orbit.enabled=!e.value;if(e.value){this.dragStart=this.transform.object.position.clone();}else if(this.dragStart&&this.selected!==undefined){const delta=this.transform.object.position.clone().sub(this.dragStart);this.dragStart=null;if(delta.length()>1e-7)this.onMove(this.selected,delta);}});
  this.raycaster=new THREE.Raycaster();let start=null;
  canvas.addEventListener('pointerdown',e=>{start=[e.clientX,e.clientY];});
  canvas.addEventListener('pointerup',e=>{if(!start||this.transform.axis||Math.hypot(e.clientX-start[0],e.clientY-start[1])>5)return;const box=canvas.getBoundingClientRect();this.raycaster.setFromCamera(new THREE.Vector2((e.clientX-box.left)/box.width*2-1,-(e.clientY-box.top)/box.height*2+1),this.camera);const hit=this.raycaster.intersectObjects(this.meshes)[0];if(hit)this.onSelect(hit.object.userData.geom);});
  new ResizeObserver(()=>this.resize()).observe(host);this.resize();
 }
 resize(){const width=this.host.clientWidth,height=this.host.clientHeight;if(!width||!height)return;this.renderer.setSize(width,height);this.camera.aspect=width/height;this.camera.updateProjectionMatrix();}
 load(session){
  this.transform.detach();this.session=session;this.selected=undefined;
  for(const mesh of this.meshes){mesh.geometry.dispose();mesh.material.dispose();}this.group.clear();this.meshes=[];
  const m=session.model;
  for(let i=0;i<m.ngeom;i++){
   const size=Array.from(m.geom_size.slice(i*3,i*3+3)),type=m.geom_type[i];let geometry;
   if(type===0)geometry=new THREE.PlaneGeometry(Math.max(2,size[0]*2),Math.max(2,size[1]*2));
   else if(type===2)geometry=new THREE.SphereGeometry(size[0],32,20);
   else if(type===3){geometry=new THREE.CapsuleGeometry(size[0],2*size[1],8,20);geometry.rotateX(Math.PI/2);}
   else if(type===4){geometry=new THREE.SphereGeometry(1,28,20);geometry.scale(...size);}
   else if(type===5){geometry=new THREE.CylinderGeometry(size[0],size[0],size[1]*2,32);geometry.rotateX(Math.PI/2);}
   else geometry=new THREE.BoxGeometry(size[0]*2,size[1]*2,size[2]*2);
   const rgba=Array.from(m.geom_rgba.slice(i*4,i*4+4)),material=new THREE.MeshStandardMaterial({color:new THREE.Color(rgba[0],rgba[1],rgba[2]),roughness:.55,metalness:.18,transparent:rgba[3]<1,opacity:rgba[3],side:THREE.DoubleSide});
   const mesh=new THREE.Mesh(geometry,material);mesh.userData.geom=i;mesh.castShadow=type!==0;mesh.receiveShadow=true;this.group.add(mesh);this.meshes.push(mesh);
  }
  this.sync();this.home();
 }
 select(id){
  this.selected=id;for(const mesh of this.meshes)mesh.material.emissive.setHex(mesh.userData.geom===id?0x1b4536:0);
  if(this.editing&&this.meshes[id])this.transform.attach(this.meshes[id]);else this.transform.detach();
 }
 setEditing(value){this.editing=value;if(this.selected!==undefined)this.select(this.selected);}
 sync(){
  if(!this.session||this.transform.dragging)return;
  const d=this.session.data;
  for(const mesh of this.meshes){const id=mesh.userData.geom,p=d.geom_xpos.slice(id*3,id*3+3),r=d.geom_xmat.slice(id*9,id*9+9);mesh.position.set(...p);const mat=new THREE.Matrix4();mat.set(r[0],r[1],r[2],0,r[3],r[4],r[5],0,r[6],r[7],r[8],0,0,0,0,1);mesh.quaternion.setFromRotationMatrix(mat);}
 }
 home(){
  const center=new THREE.Vector3(0,0,.5);let max=1;
  if(this.session){const moving=this.meshes.filter(mesh=>this.session.model.geom_bodyid[mesh.userData.geom]>0);if(moving.length){const box=new THREE.Box3();for(const mesh of moving)box.expandByObject(mesh);box.getCenter(center);max=Math.max(.7,box.getSize(new THREE.Vector3()).length());}}
  this.orbit.target.copy(center);this.camera.position.copy(center).add(new THREE.Vector3(1.6,-2.3,1.3).multiplyScalar(max));this.orbit.update();
 }
 angle(mode){const target=this.orbit.target,dist=this.camera.position.distanceTo(target);const delta=mode==='top'?new THREE.Vector3(.001,0,dist):mode==='side'?new THREE.Vector3(0,-dist,.03):new THREE.Vector3(dist*.7,-dist*.7,dist*.5);this.camera.position.copy(target).add(delta);this.orbit.update();}
 render(){this.orbit.update();this.renderer.render(this.scene,this.camera);}
}
