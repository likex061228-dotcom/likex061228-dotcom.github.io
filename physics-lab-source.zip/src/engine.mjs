import {buildXML,validateProject,validateXML} from './models.mjs';
import {SampledController} from './controller.mjs';
export class Session{
 constructor(mj,project){
  this.mj=mj;this.project=validateProject(project);this.xml=validateXML(buildXML(this.project));this.model=null;this.data=null;this.trace=[];this.lastTrace=-Infinity;this.controllers=[];
  try{
   this.model=mj.MjModel.from_xml_string(this.xml);
   const m=this.model;
   if(m.ngeom===0)throw Error('工作台模型至少需要一个可显示的几何体');
   if(m.nbody>65||m.ngeom>128||m.nq>256||m.nu>16||m.nsensor>64)throw Error('模型超出浏览器工作台资源上限');
   const option=m.opt;this.dt=option.timestep;this.gravity=Array.from(option.gravity);this.integrator=option.integrator;option.delete();if(this.dt<.0001||this.dt>.01)throw Error('物理步长必须在0.1～10 ms之间');
   for(const type of m.geom_type)if(![0,2,3,4,5,6].includes(type))throw Error('3D视图当前仅支持平面、球、胶囊、椭球、圆柱与方块');
   this.data=new mj.MjData(m);
   this.joints=Array.from({length:m.njnt},(_,id)=>({id,name:mj.mj_id2name(m,3,id)||`joint_${id}`,type:m.jnt_type[id],q:m.jnt_qposadr[id],v:m.jnt_dofadr[id]}));
   for(const config of this.project.controllers){
    const joint=this.joints.find(j=>j.name===config.joint),actuator=mj.mj_name2id(m,19,config.actuator);
    if(!joint||![2,3].includes(joint.type))throw Error(`控制器关节 ${config.joint} 必须是已存在的单自由度滑动/转动关节`);
    if(actuator<0||m.actuator_trntype[actuator]!==0||m.actuator_trnid[actuator*2]!==joint.id)throw Error(`执行器 ${config.actuator} 必须直接作用于关节 ${config.joint}`);
    if(m.actuator_dyntype[actuator]!==0||m.actuator_gaintype[actuator]!==0||m.actuator_biastype[actuator]!==0||Math.abs(m.actuator_gainprm[actuator*10]-1)>1e-10||Math.abs(m.actuator_gear[actuator*6]-1)>1e-10)throw Error('PID接口仅支持gear=1的无动态motor；不能将位置伺服、电压或带传动比输入冒充力/力矩');
    if(config.samplePeriod<this.dt-1e-12)throw Error('控制采样周期不能小于物理步长');
    const ratio=config.samplePeriod/this.dt;if(Math.abs(ratio-Math.round(ratio))>1e-7)throw Error('控制采样周期必须是物理步长的整数倍');
    const bounds=m.actuator_ctrllimited[actuator]?[m.actuator_ctrlrange[actuator*2],m.actuator_ctrlrange[actuator*2+1]]:[-10000,10000];
    if(m.actuator_forcelimited[actuator]){bounds[0]=Math.max(bounds[0],m.actuator_forcerange[actuator*2]);bounds[1]=Math.min(bounds[1],m.actuator_forcerange[actuator*2+1]);}if(bounds[0]>0||bounds[1]<0)throw Error('当前控制接口要求motor输入范围包含0');
    this.controllers.push({joint,actuator,loop:new SampledController(config,bounds),unit:joint.type===2?'N':'N·m'});
   }
   this.reset();
  }catch(error){this.dispose();throw error;}
 }
 reset(){
  const {mj,model:m,data:d}=this;if(m.nkey>0)mj.mj_resetDataKeyframe(m,d,0);else mj.mj_resetData(m,d);
  this.trace=[];this.lastTrace=-Infinity;this.controllers.forEach(c=>c.loop.reset());mj.mj_forward(m,d);for(const {joint:j,actuator,loop}of this.controllers)d.ctrl[actuator]=loop.update(d.time,d.qpos[j.q],d.qvel[j.v]);mj.mj_forward(m,d);this.record();
 }
 joint(name){const j=this.joints.find(item=>item.name===name);if(!j)throw Error('未知关节');return{position:this.data.qpos[j.q],velocity:this.data.qvel[j.v],type:j.type};}
 step(){
  const {data:d,model:m,mj}=this,time=d.time;
  for(const {joint:j,actuator,loop}of this.controllers)d.ctrl[actuator]=loop.update(time,d.qpos[j.q],d.qvel[j.v]);
  mj.mj_step(m,d);
  if(d.time<=time||!Array.from(d.qpos).every(Number.isFinite)||!Array.from(d.qvel).every(Number.isFinite))throw Error('求解器出现非有限状态或自动重置；已停止，不继续显示旧曲线');
  // Synchronize derived geometry and sensor arrays with the newly integrated qpos.
  mj.mj_forward(m,d);this.record();
 }
 sample(){
  const {data:d}=this,first=this.controllers[0],scalar=this.joints.find(j=>[2,3].includes(j.type));
  const j=first?.joint||scalar;
  const free=this.joints.find(item=>item.type===0);const position=j?d.qpos[j.q]:free?d.qpos[free.q+2]:null,velocity=j?d.qvel[j.v]:free?d.qvel[free.v+2]:null;
  this.mj.mj_energyPos(this.model,d);this.mj.mj_energyVel(this.model,d);return {time:d.time,position,velocity,measured:first?.loop.measured??position,target:first?.loop.reference??0,control:first?d.actuator_force[first.actuator]:0,command:first?d.ctrl[first.actuator]:0,error:first?first.loop.reference-position:0,energyPotential:d.energy[0],energyKinetic:d.energy[1],contacts:d.ncon,saturated:first?.loop.saturated||false,joints:Object.fromEntries(this.joints.filter(j=>[2,3].includes(j.type)).map(j=>[j.name,{position:d.qpos[j.q],velocity:d.qvel[j.v]}])),actuators:Array.from(d.actuator_force),commands:Array.from(d.ctrl),controlStates:Object.fromEntries(this.controllers.map(c=>[c.joint.name,{reference:c.loop.reference,measured:c.loop.measured,command:d.ctrl[c.actuator]}]))};
 }
 record(){if(this.data.time-this.lastTrace<.01-1e-10)return;this.lastTrace=this.data.time;this.trace.push(this.sample());if(this.trace.length>6000)this.trace.shift();}
 sensors(){
  const {model:m,data:d,mj}=this;
  return Array.from({length:m.nsensor},(_,i)=>({name:mj.mj_id2name(m,20,i)||`sensor_${i}`,values:Array.from(d.sensordata.slice(m.sensor_adr[i],m.sensor_adr[i]+m.sensor_dim[i]))}));
 }
 impulse(name,value){
  const j=this.joints.find(j=>j.name===name);if(!j||![2,3].includes(j.type))throw Error('扰动仅支持单自由度关节');
  // A documented velocity kick changes the physical initial state; not a fabricated force measurement.
  this.data.qvel[j.v]+=value;this.mj.mj_forward(this.model,this.data);
 }
 dispose(){if(this.data){this.data.delete();this.data=null;}if(this.model){this.model.delete();this.model=null;}}
}
