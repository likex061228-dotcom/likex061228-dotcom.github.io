const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export class SampledController{
 constructor(config,bounds){this.config={...config};this.bounds=bounds;this.reset();}
 reset(){this.integral=0;this.next=0;this.history=[];this.output=0;this.measured=0;this.reference=0;this.error=0;this.saturated=false;}
 update(time,position,velocity){
  const c=this.config;if(time+1e-9<this.next)return this.output;
  const period=c.samplePeriod;this.next=time+period;
  this.history.push({time,position,velocity});
  const cutoff=time-c.delay;let sample=this.history[0];for(const item of this.history){if(item.time>cutoff+1e-9)break;sample=item;}
  while(this.history.length>2&&this.history[1].time<cutoff-period)this.history.shift();
  this.measured=c.quantization>0?Math.round(sample.position/c.quantization)*c.quantization:sample.position;
  this.reference=c.target+(c.reference==='sine'?c.amplitude*Math.sin(2*Math.PI*c.frequency*time):0);
  this.error=this.reference-this.measured;
  const low=Math.max(-c.limit,this.bounds[0]),high=Math.min(c.limit,this.bounds[1]);
  if(c.mode==='off'){this.output=0;this.integral=0;this.saturated=false;return 0;}
  let raw=c.constant;
  if(c.mode==='pid'){
   const proposed=this.integral+this.error*period;
   raw=c.kp*this.error+c.ki*proposed-c.kd*sample.velocity;
   // Conditional integration: do not accumulate further into actuator saturation.
   if((raw<=high&&raw>=low)||(raw>high&&this.error<0)||(raw<low&&this.error>0))this.integral=proposed;
   raw=c.kp*this.error+c.ki*this.integral-c.kd*sample.velocity;
  }
  this.output=clamp(raw,low,high);this.saturated=Math.abs(raw-this.output)>1e-9;
  return this.output;
 }
}
