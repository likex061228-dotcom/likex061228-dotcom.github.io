import {preset} from './models.mjs';
import {Session} from './engine.mjs';
const simulate=(session,seconds)=>{const steps=Math.round(seconds/session.dt);for(let i=0;i<steps;i++)session.step();};
export function runBenchmarks(mj){
 const results=[];
 const compare=(name,actual,expected,tolerance,unit,reference)=>results.push({name,actual,expected,error:Math.abs(actual-expected),tolerance,unit,pass:Number.isFinite(actual)&&Math.abs(actual-expected)<=tolerance,reference});
 const drop=preset('drop');let s=new Session(mj,drop);simulate(s,.5);const t=s.data.time;
 compare('自由落体高度',s.data.qpos[2],2-.5*9.81*t*t,.006,'m','z=z0−g·t²/2；implicitfast的有限步长误差显式保留');
 compare('自由落体速度',s.data.qvel[2],-9.81*t,1e-9,'m/s','v=−g·t');
 const coarseError=Math.abs(s.data.qpos[2]-(2-.5*9.81*t*t));s.dispose();
 const fine=preset('drop');fine.parameters.dt=.001;s=new Session(mj,fine);simulate(s,.5);const fineError=Math.abs(s.data.qpos[2]-(2-.5*9.81*.25));
 compare('步长减半的误差比',fineError/coarseError,.5,.02,'ratio','平滑无接触自由落体，预期一阶位置误差约减半');s.dispose();
 const slide=preset('slider');slide.parameters.mass=2;slide.parameters.damping=0;slide.parameters.travel=3;slide.controllers[0].mode='constant';slide.controllers[0].constant=2;s=new Session(mj,slide);simulate(s,.5);
 compare('恒力滑台速度',s.joint('slide').velocity,.5,1e-9,'m/s','v=F·t/m，F=2 N、m=2 kg、无阻尼');s.dispose();
 const pendulum=preset('pendulum');Object.assign(pendulum.parameters,{damping:0,angle:.03});pendulum.controllers[0].mode='off';s=new Session(mj,pendulum);
 const p=pendulum.parameters,L=p.length,m=p.mass,r=p.radius,mr=p.rodMass;
 const I=mr*(L*L/3+.03*.03/12)+m*(L*L+.4*r*r),gravityMoment=9.81*(mr*L/2+m*L);
 const expectedPeriod=2*Math.PI*Math.sqrt(I/gravityMoment);const crossings=[];let previous=s.joint('hinge').position,previousTime=0;
 for(let i=0;i<Math.round(6/s.dt);i++){s.step();const q=s.joint('hinge').position;if(previous<0&&q>=0)crossings.push(previousTime+(s.data.time-previousTime)*(-previous)/(q-previous));previous=q;previousTime=s.data.time;}
 compare('复合物理摆周期',crossings.length>1?crossings[1]-crossings[0]:NaN,expectedPeriod,.01,'s','T≈2π√(I支点/(g·Σm·d))；杆+实心球，初角0.03 rad');
 compare('铰接点漂移',Math.hypot(s.data.xpos[3]-0,s.data.xpos[4]-0,s.data.xpos[5]-(L+.6)),0,1e-9,'m','理想铰链的刚体坐标原点保持固定');s.dispose();
 s=new Session(mj,preset('slider'));simulate(s,4);compare('PID滑台稳态位置',s.joint('slide').position,.4,.005,'m','离散PD/PID输出进入真实motor，独立检查目标误差');s.dispose();
 let a=new Session(mj,preset('slider')),b=new Session(mj,preset('slider'));simulate(a,1);simulate(b,1);compare('同引擎同条件重放',Math.max(...a.data.qpos.map((v,i)=>Math.abs(v-b.data.qpos[i]))),0,1e-12,'m','同版本、同平台、同初值与相同步数');a.dispose();b.dispose();
 s=new Session(mj,preset('drop'));simulate(s,2);compare('落球接触静止高度',s.data.qpos[2],drop.parameters.radius,.003,'m','平面上的球心高度应接近球半径；软接触容许压入误差');s.dispose();
 return results;
}
