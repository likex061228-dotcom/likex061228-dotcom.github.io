export const VERSION='3.16.0';
const clone=value=>JSON.parse(JSON.stringify(value));
const finite=(value,min,max,name)=>{if(typeof value!=='number'||!Number.isFinite(value)||value<min||value>max)throw Error(`${name} 无效，范围 ${min}～${max}`);return value;};
const keys=(value,list,name)=>{if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(key=>!list.includes(key)))throw Error(`${name} 含不支持的字段`);};
const control=(joint,actuator,target,kp,kd,limit)=>({joint,actuator,mode:'pid',target,kp,ki:0,kd,limit,samplePeriod:.01,delay:0,quantization:0,reference:'step',amplitude:.1,frequency:.25,constant:0});
export function preset(kind){
 const shared={version:1,name:'',kind,parameters:{},controllers:[],assumptions:[]};
 if(kind==='slider')return {...shared,name:'直线滑台 · 力驱动闭环',parameters:{mass:1,damping:.1,travel:.8,force:20,dt:.002},controllers:[control('slide','motor',.4,40,12,20)],assumptions:['理想直线关节；未模拟丝杠效率、间隙与电机电气过程。','motor 的gear=1，输入为牛顿；未建立电压到推力映射。']};
 if(kind==='pendulum')return {...shared,name:'单关节摆杆 · 力矩控制',parameters:{length:.6,mass:.5,rodMass:.2,radius:.05,damping:.02,angle:.2,torque:3,dt:.002},controllers:[control('hinge','motor',0,6,1.8,3)],assumptions:['均匀矩形杆与实心球组成物理摆，质量与转动惯量由引擎计算。','关节粘性阻尼由MJCF指定；无轴承间隙，力矩源不包含电气模型。']};
 if(kind==='drop')return {...shared,name:'落球 · 重力与接触',parameters:{mass:1,radius:.08,height:2,friction:.5,dt:.002},assumptions:['重力9.81 m/s²，忽略空气阻力。','地面接触使用MuJoCo软接触参数，未把它当作指定恢复系数模型。']};
 if(kind==='custom')return {...preset('slider'),kind:'custom',name:'自定义 MJCF',xml:buildXML(preset('slider')),parameters:{}};
 throw Error('不支持的模型类型');
}
export function validateProject(value){
 keys(value,['version','name','kind','parameters','controllers','assumptions','xml'],'项目');
 if(value.version!==1||!['slider','pendulum','drop','custom'].includes(value.kind))throw Error('不支持的项目版本或类型');
 if(typeof value.name!=='string'||value.name.length>120)throw Error('项目名称无效');
 const limits={slider:{mass:[.001,1000],damping:[0,100],travel:[.01,10],force:[.001,10000],dt:[.0001,.01]},pendulum:{length:[.05,5],mass:[.001,100],rodMass:[.001,100],radius:[.005,.3],damping:[0,100],angle:[-3,3],torque:[.001,1000],dt:[.0001,.01]},drop:{mass:[.001,1000],radius:[.005,1],height:[.01,20],friction:[0,2],dt:[.0001,.01]},custom:{}};
 keys(value.parameters||{},Object.keys(limits[value.kind]),'模型参数');
 for(const [key,range]of Object.entries(limits[value.kind]))finite(value.parameters?.[key],...range,key);
 if(value.kind==='drop'&&value.parameters.height<=value.parameters.radius)throw Error('球心高度必须大于半径');
 if(!Array.isArray(value.controllers)||value.controllers.length>16)throw Error('控制器数量无效');
 for(const c of value.controllers){
  keys(c,['joint','actuator','mode','target','kp','ki','kd','limit','samplePeriod','delay','quantization','reference','amplitude','frequency','constant'],'控制器');
  if(!['pid','constant','off'].includes(c.mode)||!['step','sine'].includes(c.reference))throw Error('控制模式无效');
  if(![c.joint,c.actuator].every(name=>typeof name==='string'&&name.length>0&&name.length<80))throw Error('关节/执行器名称无效');
  for(const key of ['target','constant'])finite(c[key],-10000,10000,key);
  for(const key of ['kp','ki','kd'])finite(c[key],0,100000,key);
  finite(c.limit,0,10000,'输出上限');finite(c.samplePeriod,.001,1,'采样周期');finite(c.delay,0,1,'测量延迟');finite(c.quantization,0,1,'测量量化');finite(c.amplitude,0,10,'参考幅值');finite(c.frequency,.01,10,'参考频率');
 }
 if(new Set(value.controllers.map(c=>c.actuator)).size!==value.controllers.length)throw Error('同一执行器不能同时挂接多个控制器');
 if(value.assumptions!==undefined&&(!Array.isArray(value.assumptions)||value.assumptions.length>30||value.assumptions.some(s=>typeof s!=='string'||s.length>600)))throw Error('假设说明无效');
 if(value.kind==='custom')validateXML(value.xml);
 return {...clone(value),parameters:clone(value.parameters||{}),assumptions:clone(value.assumptions||[])};
}
export function validateXML(xml){
 if(typeof xml!=='string'||xml.length>60000||!xml.includes('<mujoco'))throw Error('MJCF 必须是小于60 KB的完整mujoco文档');
 if(/<!DOCTYPE|<!ENTITY|<include\b|<plugin\b|<extension\b|<composite\b|<replicate\b|<flex\w*\b|<skin\b|<mesh\b|<hfield\b|\bfile\s*=/i.test(xml))throw Error('当前工作台不支持外部文件、插件、网格/柔性体或批量复制；请使用自包含的基础刚体MJCF');
 if((xml.match(/<body\b/g)||[]).length>64||(xml.match(/<geom\b/g)||[]).length>128)throw Error('模型超过64个刚体或128个几何体上限');
 return xml;
}
export function buildXML(project){
 validateProject(project);
 if(project.kind==='custom')return project.xml;
 const p=project.parameters;
 const header=`<mujoco model="like_x_${project.kind}"><compiler angle="radian"/><option timestep="${p.dt}" integrator="implicitfast" gravity="0 0 -9.81"><flag energy="enable"/></option><visual><global offwidth="1280" offheight="720"/></visual><default><geom rgba="0.56 0.82 0.70 1" friction="0.5 0.005 0.0001"/></default>`;
 const floor='<geom name="ground" type="plane" size="3 3 0.1" rgba="0.13 0.19 0.22 1"/>';
 if(project.kind==='slider')return `${header}<worldbody>${floor}<geom name="rail" type="box" pos="0 0 0.1" size="${p.travel+.2} 0.035 0.025" contype="0" conaffinity="0" rgba="0.38 0.44 0.44 1"/><body name="carriage" pos="0 0 0.25"><joint name="slide" type="slide" axis="1 0 0" damping="${p.damping}" limited="true" range="${-p.travel} ${p.travel}"/><geom name="carriage_shape" type="box" size="0.10 0.08 0.06" mass="${p.mass}"/><site name="carriage_site" size="0.01"/></body></worldbody><actuator><motor name="motor" joint="slide" gear="1" ctrllimited="true" ctrlrange="${-p.force} ${p.force}"/></actuator><sensor><jointpos name="encoder" joint="slide"/><jointvel name="velocity" joint="slide"/><actuatorfrc name="motor_force" actuator="motor"/></sensor></mujoco>`;
 if(project.kind==='pendulum')return `${header}<worldbody>${floor}<geom name="stand" type="box" pos="0 0.12 ${p.length+.25}" size="0.04 0.03 ${p.length+.25}" rgba="0.35 0.43 0.44 1"/><body name="arm" pos="0 0 ${p.length+.6}"><joint name="hinge" type="hinge" axis="0 1 0" damping="${p.damping}"/><geom name="rod" type="box" pos="0 0 ${-p.length/2}" size="0.015 0.015 ${p.length/2}" mass="${p.rodMass}" rgba="0.72 0.60 0.41 1"/><geom name="bob" type="sphere" pos="0 0 ${-p.length}" size="${p.radius}" mass="${p.mass}"/></body></worldbody><actuator><motor name="motor" joint="hinge" gear="1" ctrllimited="true" ctrlrange="${-p.torque} ${p.torque}"/></actuator><sensor><jointpos name="encoder" joint="hinge"/><jointvel name="velocity" joint="hinge"/><actuatorfrc name="motor_torque" actuator="motor"/></sensor><keyframe><key name="start" qpos="${p.angle}"/></keyframe></mujoco>`;
 return `${header}<worldbody><geom name="ground" type="plane" size="3 3 0.1" friction="${p.friction} 0.005 0.0001" rgba="0.13 0.19 0.22 1"/><body name="ball" pos="0 0 ${p.height}"><freejoint name="free"/><geom name="ball_shape" type="sphere" size="${p.radius}" mass="${p.mass}" friction="${p.friction} 0.005 0.0001"/><site name="range_site" quat="0 1 0 0" size="0.01"/></body></worldbody><sensor><framepos name="ball_position" objtype="body" objname="ball"/><framelinvel name="ball_velocity" objtype="body" objname="ball"/><rangefinder name="floor_range" site="range_site"/></sensor></mujoco>`;
}
const patterns={mass:/(?:质量|负载|mass)\s*[:=：为是]?\s*([+-]?[\d.]+)\s*(kg|千克|公斤|g|克)(?![A-Za-z])/i,length:/(?:杆长|摆长|长度|length)\s*[:=：为是]?\s*([+-]?[\d.]+)\s*(mm|cm|m|毫米|厘米|米)/i,height:/(?:高度|球心高度|height)\s*[:=：为是]?\s*([+-]?[\d.]+)\s*(mm|cm|m|毫米|厘米|米)/i,target:/(?:目标(?:位置)?|target)\s*[:=：为是]?\s*([+-]?[\d.]+)\s*(mm|cm|m|毫米|厘米|米|deg|rad|度|弧度)/i,force:/(?:最大推力|推力上限|推力|force)\s*[:=：为是]?\s*([+-]?[\d.]+)\s*(N|牛顿|牛)(?![A-Za-z·*])/i,torque:/(?:最大力矩|力矩上限|力矩|转矩|torque)\s*[:=：为是]?\s*([+-]?[\d.]+)\s*(N[·*]?m|牛米)(?![A-Za-z])/i};
export function parseRequirements(text){
 if(typeof text!=='string'||text.length>3000)throw Error('需求长度无效');
 if(/电路|固件|STM32|ESP32|液压|磁场|柔性|机械臂|斜面|轮式|小车|\d\s*(?:V|伏特|安培|Ω)\b/i.test(text))throw Error('该结构/电气或固件要求不在当前文字转换支持范围内；可另行建立机械MJCF，不能用预设模型冒充');
 if(/负\s*\d/.test(text))throw Error('数值无效：请填写带正确单位的正质量/尺寸');
 const kind=/滑台|滑块|直线|slider/i.test(text)?'slider':/单摆|摆杆|单关节|pendulum/i.test(text)?'pendulum':/自由落体|落球|下落|drop/i.test(text)?'drop':null;
 if([/滑台|滑块|直线|slider/i,/单摆|摆杆|单关节|pendulum/i,/自由落体|落球|下落|drop/i].filter(regex=>regex.test(text)).length>1)throw Error('组合机构不能套用单个模板；请建立对应的自定义MJCF模型');if(!kind)throw Error('尚不能识别该结构。当前文字转换支持直线滑台、单摆/摆杆、自由落球；更复杂机构请使用MJCF编辑器。');
 const project=preset(kind),recognized=[],assumptions=[];let remaining=text.replace(/3D|PID/gi,'');
 for(const [key,regex]of Object.entries(patterns)){
  const found=text.match(regex);if(!found)continue;
  if(!(key in project.parameters)&&!(key==='target'&&project.controllers.length))throw Error(`该模型不支持“${found[0]}”，请明确正确的结构/单位`);
  let number=Number(found[1]),unit=found[2];if(key==='target'){const angular=/^(deg|rad|度|弧度)$/i.test(unit);if(angular!==(kind==='pendulum'))throw Error('目标单位与关节类型不符：滑台用m/cm，摆杆用rad/度');if(/^(deg|度)$/i.test(unit))number*=Math.PI/180;}if(/^(cm|厘米)$/i.test(unit))number/=100;if(/^(mm|毫米)$/i.test(unit))number/=1000;if(/^(g|克)$/i.test(unit))number/=1000;
  if(key!=='target')project.parameters[key]=number;if(key==='target'&&project.controllers[0])project.controllers[0].target=number;if(['force','torque'].includes(key)&&project.controllers[0])project.controllers[0].limit=number;
  recognized.push({field:key,text:found[0],value:number});remaining=remaining.replace(found[0],'');
 }
 for(const term of ['kp','ki','kd']){const regex=new RegExp(term+'\\s*[=:：为]?\\s*([\\d.]+)','i'),match=text.match(regex);if(match){if(!project.controllers.length)throw Error('自由落球不包含PID执行器');project.controllers[0][term]=Number(match[1]);recognized.push({field:term,text:match[0],value:Number(match[1])});remaining=remaining.replace(match[0],'');}}
 if(/\d/.test(remaining))throw Error('有带数值的要求未被识别，可能缺少单位或字段不受支持。请使用“质量1 kg、目标40 cm、最大推力20 N”等明确写法。');
 if(/摇摆|往返|正弦/.test(text)&&project.controllers[0]){project.controllers[0].reference='sine';recognized.push({field:'reference',text:'正弦参考',value:'sine'});}
 for(const [key,value]of Object.entries(project.parameters))if(!recognized.some(row=>row.field===key))assumptions.push(`${key} = ${value}（示例假设，可修改，非实物测量）`);
 if(project.controllers[0])for(const [key,value]of Object.entries(project.controllers[0]))if(!['actuator','joint'].includes(key)&&!recognized.some(row=>row.field===key))assumptions.push(`controller.${key} = ${value}（控制器示例假设）`);return {project:validateProject(project),recognized,assumptions,unparsed:remaining,warnings:['这是本地规则转换，未调用AI服务。仅解析列出的字段；其他文字不构成已实现的验收要求。',...project.assumptions]};
}
