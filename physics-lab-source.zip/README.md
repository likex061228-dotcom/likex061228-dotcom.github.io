# Like_x physics workbench

A browser-local mechanical simulation workspace. MuJoCo 3.16.0 calculates dynamics; Three.js 0.186.1 renders native geometry poses. No remote AI or telemetry.

## Reproduce

Use Node.js 22 or later. From this extracted directory:

```
npm ci --ignore-scripts
npm test
node build.mjs dist
python -m http.server 8765 --directory dist
```

Open http://localhost:8765/workbench.html. For standalone hosting, provide your own favicon.svg (or remove its link). The build pins dependencies and emits SHA-256 hashes of the engine and application bundle. The bundled MuJoCo WASM is about 11 MB. Source maps are not published.

## Scope

Self-contained primitive MJCF rigid bodies, joints, contacts, ideal motor force/torque, sampled PID, native sensors, geometry edits and CSV/JSON exports. The text parser supports slider, physical pendulum and falling ball templates only. Unknown numerical requirements are rejected and default assumptions shown. Arbitrary structures require physically correct MJCF supplied by the user or an assistant.

The nine analytic/constraint/replay checks validate example problems and engine integration, not an arbitrary custom model. All real projects require independent parameter measurement and validation. No MCU firmware or electrical circuit execution is implemented. Explicit MJCF inertial definitions take precedence as specified by MuJoCo; graphical geom mass editing is disabled in those cases.

## Third-party licenses

MuJoCo: Apache-2.0, Copyright 2021 DeepMind Technologies Limited. Box collision code includes Copyright 2016 Svetoslav Kolev. See licenses/MUJOCO-LICENSE.txt and https://github.com/google-deepmind/mujoco.

Three.js: MIT, see licenses/THREE-LICENSE.txt and https://github.com/mrdoob/three.js. Build dependencies retain their upstream licenses in installed packages.
