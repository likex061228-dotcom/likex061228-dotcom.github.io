import test from 'node:test';
import assert from 'node:assert/strict';
import load from '@mujoco/mujoco';
import {preset,parseRequirements,validateProject} from '../src/models.mjs';
import {Session} from '../src/engine.mjs';
import {runBenchmarks} from '../src/benchmarks.mjs';
const mj=await load();
test('official WASM engine and independent numerical benchmarks',()=>{
 assert.equal(mj.mj_versionString(),'3.16.0');
 const rows=runBenchmarks(mj);
 console.log(JSON.stringify(rows,null,2));
 assert.ok(rows.length>=6);
 for(const row of rows)assert.ok(row.pass,JSON.stringify(row));
});
test('requirements carry units, assumptions and never silently accept unsupported content',()=>{
 const result=parseRequirements('做一个直线滑台，质量2 kg，目标40 cm，最大推力20 N，用PID控制。');
 assert.equal(result.project.parameters.mass,2);
 assert.equal(result.project.controllers[0].target,.4);
 assert.ok(result.assumptions.length>0);
 assert.throws(()=>parseRequirements('做一个12V电机电路，运行STM32固件'),/支持|固件|电路/);
 assert.throws(()=>parseRequirements('直线滑台，质量负2kg'),/无效|范围|正/);
 assert.throws(()=>parseRequirements('直线滑台，负载2磅'),/识别|单位|支持/);
});
test('actual physics and geometry change together; mass affects acceleration',()=>{
 const a=preset('slider');a.parameters.mass=2;a.parameters.damping=0;a.controllers[0].mode='constant';a.controllers[0].constant=2;
 const session=new Session(mj,a);
 for(let i=0;i<100;i++)session.step();
 assert.ok(Math.abs(session.joint('slide').velocity-.2)<.002);
 session.dispose();
});
test('invalid controller and invalid MJCF cannot masquerade as a valid simulation',()=>{
 const p=preset('slider');p.controllers[0].joint='missing';assert.throws(()=>new Session(mj,p),/关节|joint/);
 const custom={version:1,name:'invalid',kind:'custom',xml:'<mujoco><worldbody><body><geom type="wat"/></body></worldbody></mujoco>',controllers:[]};
 assert.throws(()=>new Session(mj,custom));
 assert.throws(()=>validateProject({...preset('slider'),privateEmail:'x'}),/字段/);
});
test('closed-loop response is computed, saturates and differs from disabled control',()=>{
 const good=new Session(mj,preset('slider'));
 const p=preset('slider');p.controllers[0].mode='off';const off=new Session(mj,p);
 for(let i=0;i<2000;i++){good.step();off.step();}
 assert.ok(Math.abs(good.joint('slide').position-.4)<.005);
 assert.ok(Math.abs(off.joint('slide').position)<1e-10);
 assert.ok(good.trace.every(row=>Math.abs(row.control)<=20+1e-9));
 good.dispose();off.dispose();
});

test('minimal imports normalize optional fields and empty scenes are rejected atomically',()=>{
 const p=preset('custom');delete p.assumptions;delete p.parameters;
 const checked=validateProject(p);assert.deepEqual(checked.assumptions,[]);assert.deepEqual(checked.parameters,{});
 const s=new Session(mj,p);assert.ok(s.model.ngeom>0);s.dispose();
 assert.throws(()=>new Session(mj,{...p,controllers:[],xml:'<mujoco><option timestep="0.002"/><worldbody/></mujoco>'}),/几何体/);
});
test('native explicit inertia takes precedence and historical targets do not change',()=>{
 const p=preset('custom');p.xml=p.xml.replace('<joint name="slide"','<inertial pos="0 0 0" mass="2" diaginertia=".01 .01 .01"/><joint name="slide"').replace('mass="1"','mass="100"');
 const s=new Session(mj,p);assert.equal(s.model.body_mass[1],2);
 const before=s.trace[0].controlStates.slide.reference;s.controllers[0].loop.config.target=.2;
 for(let i=0;i<20;i++)s.step();assert.equal(s.trace[0].controlStates.slide.reference,before);assert.equal(s.trace.at(-1).controlStates.slide.reference,.2);s.dispose();
});
