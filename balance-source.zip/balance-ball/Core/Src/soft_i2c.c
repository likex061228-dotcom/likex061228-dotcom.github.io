#include "soft_i2c.h"

#define IIC_SCL_H() HAL_GPIO_WritePin(SOFT_I2C_PORT, SOFT_I2C_SCL_PIN, GPIO_PIN_SET)
#define IIC_SCL_L() HAL_GPIO_WritePin(SOFT_I2C_PORT, SOFT_I2C_SCL_PIN, GPIO_PIN_RESET)
#define IIC_SDA_H() HAL_GPIO_WritePin(SOFT_I2C_PORT, SOFT_I2C_SDA_PIN, GPIO_PIN_SET)
#define IIC_SDA_L() HAL_GPIO_WritePin(SOFT_I2C_PORT, SOFT_I2C_SDA_PIN, GPIO_PIN_RESET)
#define READ_SDA()  HAL_GPIO_ReadPin(SOFT_I2C_PORT, SOFT_I2C_SDA_PIN)

static void sda_input(void)
{
  SOFT_I2C_PORT->MODER &= ~(3UL << (15U * 2U));
}

static void sda_output(void)
{
  SOFT_I2C_PORT->MODER =
      (SOFT_I2C_PORT->MODER & ~(3UL << (15U * 2U))) | (1UL << (15U * 2U));
}

void delay_us(uint32_t us)
{
  uint32_t start = DWT->CYCCNT;
  uint32_t ticks = us * (SystemCoreClock / 1000000U);
  while ((uint32_t)(DWT->CYCCNT - start) < ticks) {
  }
}

void Soft_I2C_Init(void)
{
  GPIO_InitTypeDef gpio = {0};

  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0U;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

  __HAL_RCC_GPIOA_CLK_ENABLE();
  gpio.Pin = SOFT_I2C_SCL_PIN | SOFT_I2C_SDA_PIN;
  gpio.Mode = GPIO_MODE_OUTPUT_OD;
  gpio.Pull = GPIO_PULLUP;
  gpio.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(SOFT_I2C_PORT, &gpio);
  IIC_SCL_H();
  IIC_SDA_H();
}

void Soft_I2C_Start(void)
{
  sda_output();
  IIC_SDA_H();
  IIC_SCL_H();
  delay_us(4U);
  IIC_SDA_L();
  delay_us(4U);
  IIC_SCL_L();
}

void Soft_I2C_Stop(void)
{
  sda_output();
  IIC_SCL_L();
  IIC_SDA_L();
  delay_us(4U);
  IIC_SCL_H();
  delay_us(4U);
  IIC_SDA_H();
  delay_us(4U);
}

uint8_t Soft_I2C_Wait_Ack(void)
{
  uint16_t timeout = 0U;

  sda_input();
  delay_us(1U);
  IIC_SCL_H();
  while (READ_SDA() == GPIO_PIN_SET) {
    if (++timeout >= 100U) {
      IIC_SCL_L();
      Soft_I2C_Stop();
      return 1U;
    }
    delay_us(1U);
  }
  IIC_SCL_L();
  return 0U;
}

void Soft_I2C_Ack(void)
{
  IIC_SCL_L();
  sda_output();
  IIC_SDA_L();
  delay_us(2U);
  IIC_SCL_H();
  delay_us(2U);
  IIC_SCL_L();
}

void Soft_I2C_NAck(void)
{
  IIC_SCL_L();
  sda_output();
  IIC_SDA_H();
  delay_us(2U);
  IIC_SCL_H();
  delay_us(2U);
  IIC_SCL_L();
}

void Soft_I2C_Send_Byte(uint8_t data)
{
  uint8_t i;

  sda_output();
  for (i = 0U; i < 8U; ++i) {
    if ((data & 0x80U) != 0U) {
      IIC_SDA_H();
    } else {
      IIC_SDA_L();
    }
    data <<= 1;
    delay_us(2U);
    IIC_SCL_H();
    delay_us(2U);
    IIC_SCL_L();
    delay_us(2U);
  }
}

uint8_t Soft_I2C_Read_Byte(uint8_t ack)
{
  uint8_t data = 0U;
  uint8_t i;

  sda_input();
  for (i = 0U; i < 8U; ++i) {
    IIC_SCL_L();
    delay_us(2U);
    IIC_SCL_H();
    data <<= 1;
    if (READ_SDA() == GPIO_PIN_SET) {
      ++data;
    }
    delay_us(2U);
  }
  if (ack != 0U) {
    Soft_I2C_Ack();
  } else {
    Soft_I2C_NAck();
  }
  return data;
}

int Soft_I2C_Write(uint8_t addr, uint8_t reg, uint8_t len, const uint8_t *data)
{
  uint8_t i;

  Soft_I2C_Start();
  Soft_I2C_Send_Byte((uint8_t)(addr << 1));
  if (Soft_I2C_Wait_Ack() != 0U) {
    return 1;
  }
  Soft_I2C_Send_Byte(reg);
  if (Soft_I2C_Wait_Ack() != 0U) {
    return 1;
  }
  for (i = 0U; i < len; ++i) {
    Soft_I2C_Send_Byte(data[i]);
    if (Soft_I2C_Wait_Ack() != 0U) {
      return 1;
    }
  }
  Soft_I2C_Stop();
  return 0;
}

int Soft_I2C_Read(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *buf)
{
  Soft_I2C_Start();
  Soft_I2C_Send_Byte((uint8_t)(addr << 1));
  if (Soft_I2C_Wait_Ack() != 0U) {
    return 1;
  }
  Soft_I2C_Send_Byte(reg);
  if (Soft_I2C_Wait_Ack() != 0U) {
    return 1;
  }
  Soft_I2C_Start();
  Soft_I2C_Send_Byte((uint8_t)((addr << 1) | 1U));
  if (Soft_I2C_Wait_Ack() != 0U) {
    return 1;
  }
  while (len != 0U) {
    *buf++ = Soft_I2C_Read_Byte((uint8_t)(len > 1U));
    --len;
  }
  Soft_I2C_Stop();
  return 0;
}
