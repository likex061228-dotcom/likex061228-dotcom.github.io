/**
 * Emm_V5.c — 张大头 Emm_V5.0 闭环步进串口协议实现
 *
 * 协议格式 (13字节):
 *   [addr] [0xFD] [dir] [vel_H] [vel_L] [acc]
 *   [pulse_3] [pulse_2] [pulse_1] [pulse_0]
 *   [raF] [snF] [checksum]
 *
 * 本项目使用 USART3 (PC10/PC11) 连接步进驱动器
 */

#include "Emm_V5.h"
#include "usart.h"
#include <string.h>
#include <stdlib.h>

/* ---------- 内部发送 ---------- */
static HAL_StatusTypeDef Emm_SendCmd(uint8_t *cmd, uint8_t len)
{
    return HAL_UART_Transmit(&EMM_UART, cmd, len, 50);
}

/* ---------- 位置控制 (13字节) ---------- */
HAL_StatusTypeDef Emm_V5_Pos_Control(uint8_t addr, uint8_t dir, uint16_t vel,
                                     uint8_t acc, uint32_t clk, uint8_t raF, uint8_t snF)
{
    uint8_t cmd[13];

    if (addr == 0 || dir > 1 || clk > 45 || raF > 1 || snF > 1) {
        return HAL_ERROR;
    }

    cmd[0]  = addr;
    cmd[1]  = CMD_POS_CTRL;
    cmd[2]  = dir;
    cmd[3]  = (uint8_t)(vel >> 8);
    cmd[4]  = (uint8_t)(vel & 0xFF);
    cmd[5]  = acc;
    cmd[6]  = (uint8_t)(clk >> 24);
    cmd[7]  = (uint8_t)(clk >> 16);
    cmd[8]  = (uint8_t)(clk >> 8);
    cmd[9]  = (uint8_t)(clk & 0xFF);
    cmd[10] = raF;
    cmd[11] = snF;
    cmd[12] = 0x6B;

    return Emm_SendCmd(cmd, sizeof(cmd));
}

/* ---------- 增量运动 ---------- */
HAL_StatusTypeDef Emm_V5_Move_Relative(int32_t pulses, uint16_t vel, uint8_t acc)
{
    uint8_t dir;
    uint32_t clk;

    if (pulses > EMM_MAX_RELATIVE_PULSES ||
        pulses < -EMM_MAX_RELATIVE_PULSES) {
        Emm_V5_Stop(EMM_ADDR, SYNC_OFF);
        return HAL_ERROR;
    }

    if (pulses > 0) {
        dir = DIR_CW;
        clk = (uint32_t)pulses;
    } else if (pulses < 0) {
        dir = DIR_CCW;
        clk = (uint32_t)(-pulses);
    } else {
        return HAL_OK;
    }

    return Emm_V5_Pos_Control(EMM_ADDR, dir, vel, acc, clk, MODE_RELATIVE, SYNC_OFF);
}

/* ---------- 绝对位置运动 ---------- */
HAL_StatusTypeDef Emm_V5_Move_Absolute(int32_t target_pulses, uint16_t vel, uint8_t acc)
{
    uint8_t dir;
    uint32_t clk;

    if (target_pulses >= 0) {
        dir = DIR_CW;
        clk = (uint32_t)target_pulses;
    } else {
        dir = DIR_CCW;
        clk = (uint32_t)(-target_pulses);
    }

    return Emm_V5_Pos_Control(EMM_ADDR, dir, vel, acc, clk, MODE_ABSOLUTE, SYNC_OFF);
}

/* ---------- 急停 ---------- */
void Emm_V5_Stop(uint8_t addr, uint8_t snF)
{
    uint8_t cmd[5] = {addr, 0xFE, 0x98, snF ? 0x01 : 0x00, 0x6B};
    Emm_SendCmd(cmd, sizeof(cmd));
}

/* ---------- 使能控制 ---------- */
void Emm_V5_Enable(uint8_t addr, uint8_t en, uint8_t snF)
{
    uint8_t cmd[6];
    cmd[0] = addr;
    cmd[1] = 0xF3;
    cmd[2] = 0xAB;
    cmd[3] = en ? 0x01 : 0x00;
    cmd[4] = snF ? 0x01 : 0x00;
    cmd[5] = 0x6B;
    Emm_SendCmd(cmd, 6);
}
