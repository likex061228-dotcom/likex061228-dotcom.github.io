/**
 * maixcam_proto.c — MaixCam 串口协议解析
 *
 * 协议: ASCII "X+03.45\n" / "X-12.50\n", 单位 cm, 精度 0.01cm
 */

#include "maixcam_proto.h"
#include "main.h"
#include <string.h>
#include <stdlib.h>

#define TIMEOUT_MS  500

static uint8_t  rx_buf[RX_BUF_SIZE];
static uint8_t  rx_idx = 0;
static volatile int32_t  position = 0;
static volatile int      fresh    = 0;
static volatile uint32_t last_rx  = 0;
static volatile uint8_t  has_valid = 0;

/* ---------- 内部解析 ---------- */
static int parse_line(void)
{
    if (rx_idx < 3) return 0;
    if (rx_buf[0] != 'X' && rx_buf[0] != 'x') return 0;

    int sign = 1;
    uint8_t start = 1;
    if (rx_buf[1] == '-') { sign = -1; start = 2; }
    else if (rx_buf[1] == '+') { start = 2; }

    int32_t integer = 0;
    int32_t frac = 0;
    int dot_seen = 0;
    int frac_digits = 0;
    int digit_count = 0;

    for (uint8_t i = start; i < rx_idx; i++) {
        uint8_t c = rx_buf[i];
        if (c == '\n' || c == '\r') break;
        if (c == '.') {
            if (dot_seen || digit_count == 0) return 0;
            dot_seen = 1;
            continue;
        }
        if (c >= '0' && c <= '9') {
            digit_count++;
            if (!dot_seen) {
                integer = integer * 10 + (c - '0');
            } else if (frac_digits < 2) {
                frac = frac * 10 + (c - '0');
                frac_digits++;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }

    if (digit_count == 0 || (dot_seen && frac_digits == 0)) return 0;
    if (frac_digits == 1) frac *= 10;

    position = sign * (integer * 100 + frac);
    if (position > 1500 || position < -1500) return 0;

    return 1;
}

/* ---------- 喂字节 ---------- */
int MaixCam_Feed(uint8_t byte)
{
    if (byte == '\n' || byte == '\r') {
        if (rx_idx > 0) {
            int ok = parse_line();
            rx_idx = 0;
            return ok;
        }
        return 0;
    }

    if ((byte == 'X' || byte == 'x') && rx_idx > 0) {
        rx_idx = 0;
    }

    if (rx_idx < RX_BUF_SIZE - 1) {
        rx_buf[rx_idx++] = byte;
    } else {
        rx_idx = 0;
    }

    return 0;
}

/* ---------- 回调接口 ---------- */
void MaixCam_RXCallback(uint8_t byte)
{
    if (MaixCam_Feed(byte)) {
        last_rx = HAL_GetTick();
        has_valid = 1;
        fresh = 1;
    }
}

/* ---------- 读取 ---------- */
int MaixCam_GetPosition(int32_t *pos_out)
{
    if (pos_out) *pos_out = position;
    if (fresh) { fresh = 0; return 1; }
    return 0;
}

int MaixCam_IsFresh(void)
{
    return fresh;
}

/* 不消费 fresh 标志, 仅供显示/调试使用 */
int MaixCam_PeekPosition(int32_t *pos_out)
{
    if (pos_out != NULL) {
        *pos_out = position;
    }
    return has_valid != 0U;
}

/* ---------- 周期性 ---------- */
void MaixCam_Tick(uint32_t now_ms)
{
    (void)now_ms;
    /* ponytail: 自动清零未被消费的旧标志 */
    if (fresh) fresh = 0;
}

int MaixCam_IsTimeout(uint32_t now_ms)
{
    if (!has_valid) return 1;
    return (now_ms - last_rx) > TIMEOUT_MS;
}

void MaixCam_Reset(void)
{
    rx_idx = 0;
    position = 0;
    fresh = 0;
    last_rx = 0;
    has_valid = 0;
    memset(rx_buf, 0, sizeof(rx_buf));
}
