/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "jy901s.h"
#include "motor_drv.h"
#include "oled.h"
#include "soft_i2c.h"
#include "tracking.h"
#include "track_i2c.h"
#include "Emm_V5.h"
#include "pid.h"
#include "maixcam_proto.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/*
 * 循迹算法 —— 八路分段质心 + 自适应滤波 + PD差速
 *
 * 参考: 2026.6.29校赛B题已验证代码 (MSPM0G3507, 5路GPIO红外)
 * 核心逻辑:
 *   deviation = 连续黑线段的加权质心 → 重滤波 → 线性PD → 差速
 *   turn      = KP × deviation + KD × deviation变化
 *   speed     = 基础速度 - 弯道减速, EMA平滑过渡
 *   宽线、边缘命中时保留弯向并快速降速
 *
 * 调参 (一次只改一个):
 *   蛇形震荡 → ↓ KP 或 ↑ KD
 *   弯道冲出 → ↓ SPEED 或 ↑ SLOWDOWN
 *   弯道转不过来 → ↑ KP 或 ↑ MAX_TURN
 *   反应滞后 → 已经10ms控制周期; ↑ KP
 *   丢线转过头 → ↓ SEARCH_TURN
 */

/* ── 循迹参数: 参照 D157B 例程风格, 极简 ── */
#define LINE_DIRECTION          (-1)
#define LINE_SPEED               15     /* 基础速度 % */
#define LINE_MIN_SPEED           10     /* 弯道最低速 % */
#define LINE_MAX_TURN            15     /* 最大转向 % */
#define LINE_KP                   1     /* P增益 */
#define LINE_KD                   3     /* D增益 */
#define LINE_CONTROL_PERIOD_MS   10U
#define LINE_FRAME_TIMEOUT_MS   100U
#define LINE_DISPLAY_MS         500U
#define LINE_KEY_DEBOUNCE_MS     20U
#define USE_ADVANCED_ALGO         0

/* ── A分支兼容宏 (USE_ADVANCED_ALGO=0 运行时不用, 但编译需要) ── */
#define LINE_POS_W0   -10
#define LINE_POS_W1    -7
#define LINE_POS_W2    -4
#define LINE_POS_W3    -1
#define LINE_POS_W4     1
#define LINE_POS_W5     4
#define LINE_POS_W6     7
#define LINE_POS_W7    10
#define LINE_KP_CENTER 55
#define LINE_KP_CURVE  45
#define LINE_D_LIMIT   10
#define LINE_TURN_MAX_STEP      3
#define LINE_SPEED_START        20
#define LINE_CURVE_MIN_SPEED    20
#define LINE_STRAIGHT_SPEED     40
#define LINE_SPEED_ALPHA_UP      3
#define LINE_SPEED_ALPHA_DN      3
#define LINE_SPEED_ALPHA_SHIFT   3
#define LINE_FILTER_FAST_LIMIT   6
#define LINE_URGENT_BRAKE_STEP  12
#define LINE_SEARCH_SPEED       12
#define LINE_SEARCH_TURN        10
#define LINE_LOST_CONFIRM_FRAMES 3U
#define LINE_LOST_HOLD_SPEED    12
#define LINE_LOST_SEARCH_MS   1000U
#define LINE_RIGHT_CURVE_MIN_TURN 34
#define LINE_RIGHT_CURVE_THRESHOLD 6
#define LINE_EDGE_MAX_SPEED      80
#define LINE_GYRO_DIRECTION       1
#define LINE_GYRO_KD           0.30f
#define LINE_GYRO_DEADBAND     1.0f
#define LINE_GYRO_MAX_TURN      20
#define LINE_GYRO_LINE_LIMIT     8
#define LINE_GYRO_TIMEOUT_MS   100U

/* ── 按键定义 ── */
#define KEY1_PORT               GPIOE
#define KEY1_PIN                GPIO_PIN_4
#define KEY2_PORT               GPIOE
#define KEY2_PIN                GPIO_PIN_5
#define KEY_DEBOUNCE_MS          20U

/* ── 任务2: Full Lap 跑一整圈停A ── */
#define T2_SPEED                 15   /* 基础速度 % */
#define T2_MIN_SPEED             10   /* 最低速 % */
#define T2_CRAWL_MS           11300   /* 降速时刻 ms */
#define T2_STOP_MS            13925
/* 刹停时刻 ms */
/* Full Lap 循迹参数 */
#define T2_MAX_TURN              15   /* 最大转向 % */
#define T2_KP                     1   /* P增益 */
#define T2_KD                     3   /* D增益 */
#define T2_KI                     5   /* I增益默认值 */
#define T2_B_W0                 -7   /* 探头0 */
#define T2_B_W1                 -5   /* 探头1 */
#define T2_B_W2                 -3   /* 探头2 */
#define T2_B_W3                 -1   /* 探头3 */
#define T2_B_W4                  1   /* 探头4 */
#define T2_B_W5                  3   /* 探头5 */
#define T2_B_W6                  5   /* 探头6 */
#define T2_B_W7                  7   /* 探头7 */
#define T2_I_THRESHOLD            4   /* I累积触发 */
#define T2_I_LIMIT               50   /* I累积限幅 */
#define T2_KI_DIVISOR            10   /* KI除数 */
#define T2_GYRO_DAMP_THRESHOLD    6   /* 陀螺阻尼触发 */
#define T2_GYRO_DAMP_GAIN     0.10f   /* 陀螺阻尼增益 */

/* ── 任务5: 复用任务4控制，完整一圈并通过A ── */
#define T5_SPEED                  5   /* 全圈留有时间余量，降低半圆入弯/出弯冲击 */
#define T5_MIN_SPEED              4   /* 复用Req4弯道最低速度 */
#define T5_RAMP_START_SPEED       2
#define T5_RAMP_STEP_MS         500U
#define T5_FORWARD_SLEW_Q8        3U
#define T5_TURN_SLEW_Q8           0U  /* 保留已验证的即时循迹响应 */
#define T5_TIMEOUT_MS         30000U  /* 题面要求整圈不超过30s */
#define T5_VISION_ABORT_MS     3500U  /* 全圈短时视觉中断不立即停车 */
#define T5_BALL_SAFETY_CM100    800   /* 全圈调试保护，避免显示偏差在4cm误停 */
#define T6_PHYSICAL_SAFETY_CM100 1300 /* 要求6按物理槽边界保护，不按目标距离误停 */
#define T5_LAP_ENC            25750   /* 实测30s=41397且约1.5圈，一圈约27600 */
#define T5_MIN_LAP_ENC        20000   /* 屏蔽起点横线，约3/4圈后允许识别A */
#define T5_START_LINE_BLACK       5U  /* A横线应同时覆盖至少5个探头 */
#define T5_START_LINE_FRAMES      2U  /* 连续确认，防止噪声误判 */
/* Req5循迹参数与Req4成功版一致 */
#define T5_MAX_TURN              15
#define T5_KP                     1
#define T5_KD                     3
#define T5_KI                     5
#define T5_B_W0                 -7   /* 探头0 */
#define T5_B_W1                 -5   /* 探头1 */
#define T5_B_W2                 -3   /* 探头2 */
#define T5_B_W3                 -1   /* 探头3 */
#define T5_B_W4                  1   /* 探头4 */
#define T5_B_W5                  3   /* 探头5 */
#define T5_B_W6                  5   /* 探头6 */
#define T5_B_W7                  7   /* 探头7 */
#define T5_I_THRESHOLD            4   /* I累积触发 */
#define T5_I_LIMIT               50   /* I累积限幅 */
#define T5_KI_DIVISOR            10   /* KI除数 */
#define T5_GYRO_DAMP_THRESHOLD    6   /* 陀螺阻尼触发 */
#define T5_GYRO_DAMP_GAIN     0.10f   /* 陀螺阻尼增益 */

/* ── 任务4: A→B 慢速循迹 (1.5m直道, 时≤8s) ── */
#define T4_SPEED                  6   /* 基础速度 % (慢速保球稳) */
#define T4_MIN_SPEED              4   /* 最低速 % */
#define T4_RAMP_START_SPEED       2   /* Req4软启动首档 */
#define T4_RAMP_STEP_MS         500U  /* 每0.5s提升1%直到巡航速度 */
#define T4_FORWARD_SLEW_Q8        3U  /* 每10ms约0.012%，连续底盘加速 */
#define T4_TURN_SLEW_Q8           0U  /* 循迹必须即时响应；禁止延迟实际转向 */
#define T4_BAL_PID_KP           14.0f /* Req4中心连续位置增益 */
#define T4_BAL_PID_KD            8.0f /* Req4车体运动速度阻尼，提前卸力抑制折返过冲 */
#define T4_BAL_STEP_PULSES          3
#define T4_BAL_TX_INTERVAL_MS     10U
#define T4_BAL_MOTOR_SPEED         45
#define T4_BAL_MOTOR_ACC           60
#define T4_ENCODER_SIGN            1  /* motor_drv已统一前进编码器为正 */
#define T4_STOP_ENC            25500   /* 1.5m≈6500脉冲，仅作为通过B的判据 */
#define T4_STOP_TIMEOUT_MS     8000   /* PDF要求AB时间≤8s */
#define T4_BALL_LIMIT_CM100     100   /* 评分要求: 全程中心误差≤1.00cm */
#define T4_BALL_SAFETY_CM100    400   /* 调试保护: 球偏差≥4cm立即停车回平 */
#define T4_VISION_GRACE_MS      700   /* 启动后等待MaixCAM首帧 */
#define T4_BRAKE_TARGET_FAST     80   /* 车体启动惯性下的中心高速制动 */
#define T4_BRAKE_TARGET_MID      64
#define T4_BRAKE_TARGET_SLOW     48
#define T4_BRAKE_ENTER_DELTA_CM100 6 /* 球离心速度达到0.06cm/100ms即制动 */
#define T4_BRAKE_MOTOR_POLARITY  (-1) /* 恢复已验证的原制动方向 */
#define T4_FAIL_BALL           0x01U
#define T4_FAIL_TIMEOUT        0x02U
#define T4_FAIL_VISION         0x04U
#define T4_FAIL_SAFETY         0x08U
#define T4_FAIL_MANUAL         0x10U
/* A→B 循迹参数 */
#define T4_MAX_TURN              15   /* 最大转向 % */
#define T4_KP                     1   /* P增益 */
#define T4_KD                     3   /* D增益 */
#define T4_KI                     5   /* I增益默认值 */
#define T4_B_W0                 -7   /* 探头0 */
#define T4_B_W1                 -5   /* 探头1 */
#define T4_B_W2                 -3   /* 探头2 */
#define T4_B_W3                 -1   /* 探头3 */
#define T4_B_W4                  1   /* 探头4 */
#define T4_B_W5                  3   /* 探头5 */
#define T4_B_W6                  5   /* 探头6 */
#define T4_B_W7                  7   /* 探头7 */
#define T4_I_THRESHOLD            4   /* I累积触发 */
#define T4_I_LIMIT               50   /* I累积限幅 */
#define T4_KI_DIVISOR            10   /* KI除数 */
#define T4_GYRO_DAMP_THRESHOLD    6   /* 陀螺阻尼触发 */
#define T4_GYRO_DAMP_GAIN     0.10f   /* 陀螺阻尼增益 */

/* ── 任务3: 摆球平衡 (要求3/4/5/6 共用) ── */
#define T3_MOTOR_SPEED            30   /* 步进电机 RPM */
#define T3_MOTOR_ACC              35   /* 加速度 */
#define T3_MAX_OFFSET_PULSES      80   /* ±80pulse=±2° */
#define T3_MAX_STEP_PULSES         3   /* 单次最多3脉冲 */
#define T3_MIN_STEP_PULSES         1   /* 最小动作 */
#define T3_MOTOR_TX_INTERVAL_MS   20   /* 电机命令最小间隔 */
#define T3_PID_KP              14.0f   /* 起步CMD约80脉冲，克服钢球静摩擦但不提高限角 */
#define T3_PID_KD               1.5f   /* D增益 */
#define T3_MOTOR_POLARITY         (-1)  /* Maix坐标修正后: +误差必须驱动球向物理+方向 */
#define T3_PID_DEADBAND           0   /* 死区 cm×100 */
#define T3_LEVEL_OFFSET_PULSES     0   /* 默认0, 球偏右时用摄像头TRIM校准 */
#define T3_SETPOINT_CM100          0   /* 默认目标位置 (0=中心, ±500=±5cm) */
#define T3_REQ3_TARGET_CM100     500   /* 要求3端点: ±5.00cm */
#define T3_REQ3_RETURN_AIM_CM100 450   /* 回程控制瞄准-4.50cm，将实测-6.44cm静止点前移约0.5cm */
#define T3_REQ3_OUTBOUND_PULSES  180   /* 要求3静止启动倾角；160脉冲仍未克服当前静摩擦 */
#define T3_REQ3_LAUNCH_SPEED_CM100 3   /* 球确实向+5cm运动>0.03cm/帧才退出强启动 */
#define T3_REQ3_LAUNCH_STEP_PULSES  4  /* 驱动层允许上限：快速到倾角以破静摩擦 */
#define T3_REQ3_LAUNCH_TX_INTERVAL_MS 10 /* 去程快速到位/回撤，制动模式已验证该周期 */
#define T3_REQ3_LAUNCH_MIN_PULSES   120 /* 至少建立该倾角后才允许速度触发退出 */
#define T3_REQ3_RETURN_BRAKE_BASE_CM100 700  /* 回程提前一帧制动，抑制冲过-5cm */
#define T3_REQ3_RETURN_BRAKE_V_GAIN       6  /* gain=9仅到-3.30cm；按触发边界延后一帧 */
#define T3_REQ3_RETURN_BRAKE_MAX_CM100 1600  /* 动态制动距离最大16cm */
#define T3_REQ3_RETURN_BRAKE_FAST_PULSES 64 /* 已通过实测的终点高速制动值 */
#define T3_REQ3_RETURN_BRAKE_FAST_DELTA_CM100 60 /* |V|低于0.60cm/帧提前降档回平 */
#define T3_REQ3_TURN_BRAKE_FAST_PULSES   64 /* 140脉冲可靠启动后增强折返制动，抑制冲到+11cm */
#define T3_REQ3_TOL_CM100        100   /* 端点允许最大误差: ±1.00cm */
#define T3_REQ3_CONFIRM_FRAMES      1   /* 保留低速门槛，转折点低速首帧即可捕获 */
#define T3_TIMEOUT_MS           5000   /* 要求3全过程必须≤5s */
#define T3_VELOCITY_REF_MS       100U  /* 球速统一为每100ms位移，消除视觉帧率影响 */

/* 中心捕获迟滞 */
#define T3_CAPTURE_ENTER_CM100    35   /* ±0.35cm 进入保持 */
#define T3_CAPTURE_EXIT_CM100     80   /* >±0.80cm 退出保持 */
#define T3_CAPTURE_SPEED_CM100     8   /* 球速≤0.08cm/帧 才能进入 */

/* 分段倾角限幅 */
#define T3_TILT_FAR_CM100        400   /* >4cm: 远端 */
#define T3_TILT_MID_CM100        150   /* 1.5~4cm: 中段 */
#define T3_TILT_FAR_PULSES        80   /* 远端=±2° */
#define T3_TILT_MID_PULSES        50
#define T3_TILT_NEAR_PULSES       30

/* 渐进静摩擦补偿: 球停滞时缓慢增加倾角 */
#define T3_STICTION_START_CM100   120  /* 偏差>1.20cm才启用 */
#define T3_STICTION_SPEED_CM100     8  /* 每帧移动≤0.08cm认为停滞 */
#define T3_STICTION_MAX_PULSES     12  /* 最多额外增加12脉冲 */
#define T3_STICTION_RAMP_FRAMES     3  /* 每3个视觉帧增加1脉冲 */

/* ── 动态制动：按球速分段反向倾斜 ── */
#define T3_BRAKE_ZONE_CM100            150  /* 仅距当前目标1.5cm内制动，避免起步即反向 */
#define T3_BRAKE_ENTER_DELTA_CM100       6  /* ≥0.06cm/帧进入 */
#define T3_BRAKE_STOP_DELTA_CM100        3  /* ≤0.03cm/帧认为接近停止 */
#define T3_BRAKE_STOP_FRAMES             2  /* 连续2帧低速退出 */

#define T3_BRAKE_TARGET_FAST            36  /* 高速制动 */
#define T3_BRAKE_TARGET_MID             26  /* 中速制动 */
#define T3_BRAKE_TARGET_SLOW            16  /* 低速制动 */

#define T3_BRAKE_STEP_PULSES             4  /* 制动时单次4脉冲 */
#define T3_BRAKE_TX_INTERVAL_MS         10  /* 制动时10ms间隔 */
#define T3_BRAKE_MOTOR_SPEED            45  /* 制动时电机转速 */
#define T3_BRAKE_MOTOR_ACC              60  /* 制动时加速度 */

/* ── 端部救援：只负责克服静摩擦、启动小球 ── */
#define T3_RECOVER_ENTER_CM100          800  /* 距中心超过8cm */
#define T3_RECOVER_EXIT_CM100           700  /* 回到7cm也可退出 */
#define T3_RECOVER_STILL_CM100           10  /* 每帧≤0.10cm认为静止 */
#define T3_RECOVER_CONFIRM_FRAMES         3  /* 连续确认帧数 */

#define T3_RECOVER_MOVE_DELTA_CM100      10  /* ≥0.10cm/帧=已运动 */
#define T3_RECOVER_MOVE_FRAMES            2  /* 连续2帧确认 */

#define T3_RECOVER_TARGET_PULSES         50  /* 启动倾角 */
#define T3_RECOVER_STEP_PULSES            2  /* 救援时单次2脉冲 */
#define T3_RECOVER_TX_INTERVAL_MS        25  /* 救援时25ms间隔 */
#define T3_RECOVER_MOTOR_SPEED           20  /* 救援时电机转速 */
#define T3_RECOVER_MOTOR_ACC             20  /* 救援时加速度 */

/* 调试开关: 置0关闭PID和MOTOR调试串口输出 */
#define BAL_DEBUG                  0

/* 编译期检查: 主程序步进限制不得超过驱动层允许值 */
#if T3_MAX_STEP_PULSES > EMM_MAX_RELATIVE_PULSES
#error "T3_MAX_STEP_PULSES exceeds Emm_V5 relative pulse limit"
#endif
#if T3_BRAKE_STEP_PULSES > EMM_MAX_RELATIVE_PULSES
#error "T3_BRAKE_STEP_PULSES exceeds Emm_V5 relative pulse limit"
#endif
#if T3_RECOVER_STEP_PULSES > EMM_MAX_RELATIVE_PULSES
#error "T3_RECOVER_STEP_PULSES exceeds Emm_V5 relative pulse limit"
#endif
#if T3_REQ3_LAUNCH_STEP_PULSES > EMM_MAX_RELATIVE_PULSES
#error "T3_REQ3_LAUNCH_STEP_PULSES exceeds Emm_V5 relative pulse limit"
#endif

/* ── 共用 ── */
#define STOP_CRAWL_SPEED          10   /* 爬行速度 % */
#define MENU_TOTAL                 6   /* 菜单项数 */
#define LINE_ENC_AVG_DIVISOR       2   /* 左右编码器平均值除数 */

/* Req6 shares the proven Req5 full-lap motion/balance parameters, but keeps
 * its own task id so Req5's zero-centre behaviour cannot be changed. */
#define TASK_IS_FULL_LAP_BALANCE(task) ((task) == 3U || (task) == 4U)
#define TASK_USES_BALANCE(task) \
  ((task) == 0U || (task) == 2U || TASK_IS_FULL_LAP_BALANCE(task))

/* ── 选参宏: 按 active_task 选 T4/T2/T5 参数 ── */
#define TASK_MAX_TURN           ((active_task == 0) ? T4_MAX_TURN : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_MAX_TURN : T2_MAX_TURN)
#define TASK_KP                 ((active_task == 0) ? T4_KP       : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_KP       : T2_KP)
#define TASK_KD                 ((active_task == 0) ? T4_KD       : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_KD       : T2_KD)
#define TASK_KI                 ((active_task == 0) ? T4_KI       : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_KI       : T2_KI)
#define TASK_I_THRESHOLD        ((active_task == 0) ? T4_I_THRESHOLD : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_I_THRESHOLD : T2_I_THRESHOLD)
#define TASK_I_LIMIT            ((active_task == 0) ? T4_I_LIMIT   : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_I_LIMIT   : T2_I_LIMIT)
#define TASK_KI_DIVISOR         ((active_task == 0) ? T4_KI_DIVISOR : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_KI_DIVISOR : T2_KI_DIVISOR)
#define TASK_GYRO_DAMP_THRESHOLD ((active_task == 0) ? T4_GYRO_DAMP_THRESHOLD : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_GYRO_DAMP_THRESHOLD : T2_GYRO_DAMP_THRESHOLD)
#define TASK_GYRO_DAMP_GAIN     ((active_task == 0) ? T4_GYRO_DAMP_GAIN : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_GYRO_DAMP_GAIN : T2_GYRO_DAMP_GAIN)
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
static volatile uint8_t car_running = 0U;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
static uint8_t Line_GetDeviation(uint8_t raw, int16_t previous,
                                 int16_t *dev, uint8_t *edge_detected);
static int16_t Line_FilterDeviation(int16_t raw_dev, uint32_t frame_count);
static void Line_FilterReset(void);
static int16_t Line_PDControl(int16_t deviation, uint32_t frame_count);
static int16_t Line_GyroDampedTurn(int16_t line_turn, uint32_t now);
static int16_t Line_SlewTurn(int16_t current, int16_t target);
static int16_t Line_BlendedSpeed(int16_t current, int16_t target,
                                 uint8_t urgent);
static uint8_t Key3_Pressed(void);
static void Debug_Send(int16_t dev, int16_t turn, int16_t spd, uint8_t state);
static void Tune_ProcessCommand(void);
static void Tune_SendConfig(void);
static void Tune_ApplyTaskDefaults(void);
static void Balance_ApplySerialTuning(void);
static void Balance_SendSerialConfig(void);
static void Balance_SendTelemetry(uint32_t now);
static void Req4_ResetState(uint32_t now);
static void Req4_MarkBPassed(uint32_t now);
static void Req4_SetTerminal(uint32_t now, uint8_t fail_reason);
static void Req4_SendTelemetry(uint32_t now);
static void MX_TIM5_Balance_Init(void);
static void Balance_Start(uint32_t now);
static void Balance_ReturnCenter(void);
static void Balance_Stop(void);
static HAL_StatusTypeDef Balance_ArmVisionOnly(void);
static void Req6_SetTouchSelection(uint8_t enable);
static void Req6_ResetTargetAndSelect(void);
static void MaixControl_ParseByte(uint8_t byte);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

static int32_t line_filter_q8 = 0;
static uint32_t line_filter_frame = 0U;
static uint8_t line_filter_valid = 0U;
static int16_t line_pd_previous = 0;
static int16_t line_pd_output = 0;
static uint32_t line_pd_frame = 0U;
static uint8_t line_pd_valid = 0U;
static int16_t line_dev_prev_b = 0;          /* B分支 PD: 上帧偏差 (导数用) */
static int16_t line_turn_slew = 0;            /* [调试] B分支转向斜坡: 上一帧实际输出, 限制每帧变化量(丝滑) */

static int16_t line_last_direction = 0;
static int16_t line_error_change = 0;
static int16_t line_error_integral = 0;    /* v31: 微型积分, 破电机死区 */
static int16_t line_drift_acc = 0;        /* v40: 中心漂移累积, 存小误差到阈值再释放 */
static uint8_t line_lost_frames = 0U;
static uint32_t line_lost_frame = 0U;
static float line_gyro_filtered = 0.0f;
static uint32_t line_gyro_frame = 0U;
static int16_t line_gyro_turn = 0;
static uint32_t line_straight_frame = 0U;
static uint8_t line_straight_frames = 0U;
static int8_t  line_filter_dir_sign  = 0;   /* v42: 滤波方向追踪, Line_FilterReset可重置 */
static uint8_t line_filter_dir_count = 0U;
static int16_t line_enc_l = 0;               /* 左编码器 10ms脉冲 */
static int16_t line_enc_r = 0;               /* 右编码器 10ms脉冲 */
static int16_t line_enc_bias = 0;            /* 编码器平衡累积偏置 */
static uint8_t tune_rx_byte = 0U;
static char tune_rx_buf[40];
static volatile uint8_t tune_rx_len = 0U;
static volatile uint8_t tune_cmd_ready = 0U;

/* ── 启停线停车状态机 (计时器方案) ── */
static volatile uint8_t  stop_state = 0;        /* 0=RUN, 1=CRAWL, 2=STOPPED */
static volatile uint32_t stop_start_tick = 0;   /* 启动时刻 */
static volatile uint32_t stop_end_tick = 0;     /* 停车时刻 */

/* ── 菜单 & 任务选择 ── */
static uint8_t  menu_sel = 0;          /* 0=A→B, 1=FullLap, 2=Ball */
static volatile uint8_t active_task = 0; /* 当前运行的任务 (ISR共享) */
static volatile int32_t  enc_sum = 0;           /* 累计编码器脉冲 (任务4用) */

/* ── 要求4: A→B循迹且滚球保持中心 ── */
static volatile int32_t req4_max_abs_ball = 0;
static volatile uint8_t req4_ball_violation = 0U;
static volatile uint8_t req4_done = 0U;
static volatile uint8_t req4_failed = 0U;
static volatile uint8_t req4_fail_reason = 0U;
static volatile uint8_t req4_b_reached = 0U;
static volatile uint32_t req4_pass_tick = 0U;
static volatile uint8_t req4_abort_req = 0U;
static volatile uint8_t req4_runtime_start_pending = 0U;
static volatile uint8_t req5_runtime_start_pending = 0U;
static volatile uint8_t req5_start_line_frames = 0U;
static volatile uint32_t req5_vision_lost_tick = 0U;
static volatile int16_t req4_line_dev = 0;
static volatile int16_t req4_line_turn = 0;
static volatile int16_t req4_line_speed = 0;
static volatile uint8_t req4_line_state = 0U;

/* ── 任务3: 摆球平衡 ── */
TIM_HandleTypeDef htim5_bal;            /* TIM5: 100Hz PID */
static uint8_t  maixcam_rx_byte;        /* USART2 RX 缓冲 */
static volatile int32_t bal_abs_pos = 0;        /* 电机累计脉冲 */
static volatile int32_t bal_target_pos = 0;     /* PID目标绝对位置 (TIM5更新, 主循环消费) */
static volatile uint8_t bal_target_valid = 0;   /* bal_target_pos 有效标记 */
static volatile uint8_t  bal_center_hold = 0U;    /* 中心保持状态 (迟滞) */
static volatile int32_t  bal_prev_ball_pos = 0;   /* 上一帧球位置, 计算移动速度 */
static volatile uint8_t  bal_prev_ball_valid = 0U;/* bal_prev_ball_pos 有效 */
static volatile uint32_t bal_prev_ball_tick = 0U; /* 上一有效视觉样本时间 */
static volatile uint32_t bal_last_vision_dt_ms = 0U; /* 遥测: 有效视觉样本间隔 */
static volatile int32_t  bal_step_limit = 2;      /* TIM5→主循环: 本次步数上限 */
static volatile int32_t bal_stiction_boost = 0;   /* 渐进摩擦补偿 (脉冲) */
static volatile uint8_t bal_stiction_frames = 0U; /* 连续停滞帧计数 */
static volatile int8_t  bal_prev_error_sign = 0;  /* 上帧误差符号 */
static volatile uint8_t bal_brake_mode = 0U;      /* 制动模式 */
static volatile uint8_t bal_turn_brake_active = 0U; /* 要求3折返点专用制动 */
static volatile uint8_t bal_brake_slow_frames = 0U; /* 制动退出低速帧数 */
static volatile uint8_t bal_recover_mode = 0U;    /* 端部救援模式 */
static volatile uint8_t bal_recover_frames = 0U;  /* 端部静止确认帧数 */
static volatile uint8_t bal_recover_move_frames = 0U; /* 救援运动确认帧数 */

/* 球速低通滤波 Q8 */
static volatile int32_t bal_delta_filt_q8 = 0;
static volatile int32_t bal_last_delta_filt = 0; /* 遥测: 每视觉帧滤波位移 cm×100 */
static volatile int32_t bal_motor_cmd = 0;      /* ISR→主循环 (已废弃, 保留兼容) */
static volatile uint8_t bal_cmd_new = 0;
static volatile uint8_t bal_stop_req = 0;
static volatile uint8_t bal_platform_centered = 1U; /* 统一终止时只回正一次 */
static volatile uint8_t bal_vision_timeout = 1;
static volatile uint8_t bal_failsafe_sent = 0;
static volatile int32_t  bal_last_valid_pos = 0;
static volatile uint8_t  bal_has_init_pos = 0;
static volatile uint32_t bal_last_tx_tick = 0;
static volatile uint32_t bal_seq_start_tick = 0;
static volatile uint8_t  bal_seq_phase = 0;
static volatile uint8_t  bal_seq_done = 0;
static volatile uint8_t  bal_seq_failed = 0;
static volatile uint8_t  bal_seq_confirm_frames = 0;
static volatile uint8_t  bal_req3_launch_done = 0U;
static volatile uint32_t bal_seq_done_tick = 0;
static volatile uint32_t bal_remote_start_guard_until = 0;
static volatile uint8_t bal_remote_start_pending = 0U;
static volatile uint8_t bal_main_loop_ready = 0U;
static volatile uint32_t bal_uart2_rx_count = 0U;
static volatile uint32_t bal_uart2_error_count = 0U;
static volatile uint32_t bal_uart2_last_error = 0U;
static uint8_t  bal_origin_valid = 0;   /* 仅在机械中心确认后置1 */
static uint8_t  cal_active = 0U;        /* 标定模式: 冻结PID, 手动调电机 */
static int32_t  cal_target = 0;         /* 标定目标脉冲位置 */
static volatile int32_t bal_user_setpoint = 0; /* 触摸目标 cm×100 (要求6) */
static volatile uint8_t req6_touch_selecting = 0U;
static volatile int16_t bal_tune_kp_x10 = 140; /* BKP: 滚球Kp×10 */
static volatile int16_t bal_tune_kd_x10 = 15;  /* BKD: 滚球Kd×10 */
static volatile int16_t bal_tune_max_pulses = T3_MAX_OFFSET_PULSES;

/* USART1 运行时参数; 上电菜单默认选中任务4 */
static int16_t tune_kp   = T4_KP;
static int16_t tune_ki   = T4_KI;
static int16_t tune_kd   = T4_KD;
static int16_t tune_speed = T4_SPEED;
/* A分支兼容变量 (USE_ADVANCED_ALGO=0 时编译需要但不使用) */
static int16_t tune_kp_center = 55;
static int16_t tune_kp_curve  = 45;
static int16_t tune_gyro_kd_x100 = 30;
static int16_t tune_straight_speed = 40;
static int16_t tune_right_curve_min_turn = 34;
static int16_t tune_right_curve_threshold = 6;
static int16_t tune_left_min_turn = 40;
static int16_t tune_edge_speed = 80;

/*
 * Line_GetDeviation — 计算连续黑线段的加权质心 (8路全参与)
 *
 * 输入: raw = IR_RawValue (bit7=x1..bit0=x8, 0=黑线 1=白底)
 * 输出: *dev = 与上一位置最近的黑线段质心 (负=偏左, 正=偏右)
 *        *edge_detected = bit0:W0黑, bit1:W7黑
 * 返回: 黑探头数量 (0=丢线)
 */
static uint8_t Line_GetDeviation(uint8_t raw, int16_t previous,
                                 int16_t *dev, uint8_t *edge_detected)
{
  static const int8_t pos[TRACKING_IR_NUM] = {
      LINE_POS_W0, LINE_POS_W1, LINE_POS_W2, LINE_POS_W3,
      LINE_POS_W4, LINE_POS_W5, LINE_POS_W6, LINE_POS_W7
  };
  int16_t best_dev = 0;
  int16_t best_distance = 32767;
  uint8_t total_black = 0U;
  uint8_t i = 0U;

  /* v38: W0/W7 边缘标记 (同时参与质心) */
  if (edge_detected != NULL) {
    uint8_t edge = 0U;
    if ((raw & 0x80U) == 0U) { edge |= 0x01U; }  /* W0=黑→左边缘 */
    if ((raw & 0x01U) == 0U) { edge |= 0x02U; }  /* W7=黑→右边缘 */
    *edge_detected = edge;
  }

  while (i < TRACKING_IR_NUM) {
    if ((raw & (uint8_t)(0x80U >> i)) == 0U) {
      int16_t sum = 0;
      int16_t center;
      int16_t distance;
      uint8_t cnt = 0U;

      /* 分别计算每一段连续黑色区域，避免岔线两段被平均到中间。 */
      while ((i < TRACKING_IR_NUM) &&
             ((raw & (uint8_t)(0x80U >> i)) == 0U)) {
        sum += pos[i];
        ++cnt;
        ++total_black;
        ++i;
      }
      center = (int16_t)(sum / (int16_t)cnt);
      distance = (int16_t)(center -
                           ((line_filter_valid != 0U) ? previous : 0));
      if (distance < 0) {
        distance = (int16_t)(-distance);
      }
      if (distance < best_distance) {
        best_distance = distance;
        best_dev = center;
      }
    } else {
      ++i;
    }
  }

  if (dev != NULL) {
    *dev = (total_black != 0U) ? best_dev : 0;
  }
  return total_black;
}

static void Line_FilterReset(void)
{
  line_filter_q8 = 0;
  line_filter_frame = 0U;
  line_filter_valid = 0U;
  line_pd_previous = 0;
  line_pd_output = 0;
  line_pd_frame = 0U;
  line_pd_valid = 0U;
  line_dev_prev_b = 0;
  line_turn_slew = 0;
  line_last_direction = 0;
  line_error_change = 0;
  line_error_integral = 0;
  line_drift_acc = 0;
  line_lost_frames = 0U;
  line_lost_frame = 0U;
  line_gyro_filtered = 0.0f;
  line_gyro_frame = 0U;
  line_gyro_turn = 0;
  line_straight_frame = 0U;
  line_straight_frames = 0U;
  line_filter_dir_sign  = 0;
  line_filter_dir_count = 0U;
  line_enc_bias = 0;
}

static int16_t Line_FilterDeviation(int16_t raw_dev, uint32_t frame_count)
{
  int32_t raw_q8 = (int32_t)raw_dev * 256;
  int32_t delta;
  int16_t abs_raw = (raw_dev < 0) ? (int16_t)(-raw_dev) : raw_dev;

  if (line_filter_valid == 0U) {
    line_filter_q8 = raw_q8;
    line_filter_frame = frame_count;
    line_filter_valid = 1U;
  } else if (frame_count != line_filter_frame) {
    line_filter_frame = frame_count;
    delta = raw_q8 - line_filter_q8;

    /* v41: 自适应滤波.
       方向持续≥3帧(真实漂移/入弯): alpha=1/4 τ≈35ms, 快速响应
       方向不持续(传感器时序抖动): alpha=1/8 τ≈70ms, 压噪声
       区分标准: 原始偏差连续同向→真实物理移动; 来回跳→时序抖动 */
    {
      int8_t cur_dir = (raw_dev > 0) ? 1 : ((raw_dev < 0) ? -1 : 0);
      if (cur_dir != 0 && cur_dir == line_filter_dir_sign) {
        ++line_filter_dir_count;
      } else {
        line_filter_dir_sign  = cur_dir;
        line_filter_dir_count = (cur_dir != 0) ? 1U : 0U;
      }

      if ((abs_raw >= LINE_FILTER_FAST_LIMIT) ||
          (delta >= ((int32_t)LINE_FILTER_FAST_LIMIT * 256)) ||
          (delta <= -((int32_t)LINE_FILTER_FAST_LIMIT * 256)) ||
          (line_filter_dir_count >= 3U)) {
        /* 大跳变 或 持续同向≥3帧 → 快速跟进 */
        line_filter_q8 += delta / 4;
      } else {
        /* 方向不持续(时序抖动) → 慢滤 */
        line_filter_q8 += delta / 8;
      }
    }
  }

  if (line_filter_q8 >= 0) {
    return (int16_t)((line_filter_q8 + 128) / 256);
  }
  return (int16_t)((line_filter_q8 - 128) / 256);
}

static int16_t Line_PDControl(int16_t deviation, uint32_t frame_count)
{
  int16_t abs_dev = (deviation < 0) ?
                    (int16_t)(-deviation) : deviation;
  int16_t derivative;
  int16_t proportional;
  int16_t i_term;
  int16_t target;
  int16_t raw_deviation = deviation;

  /* v42: 无死区, 有偏差就响应. 微型I破电机死区 + D压过冲. */
  proportional = (int16_t)(((int32_t)deviation * tune_kp_center) / 10);

  /* v31: 微型积分, 仅小偏差时累加, 打破电机死区极限环.
     限幅±15(约1.5个偏差单位), 大偏差清零防积分饱和. */
  if (abs_dev <= 4 && abs_dev > 0) {
    line_error_integral += deviation;
    if (line_error_integral > 15)  line_error_integral = 15;
    if (line_error_integral < -15) line_error_integral = -15;
  } else {
    line_error_integral = 0;
  }
  i_term = line_error_integral / 5;  /* I增益≈0.2 */

  if (line_pd_valid == 0U) {
    line_pd_previous = raw_deviation;
    line_pd_frame = frame_count;
    line_pd_valid = 1U;
    line_error_change = 0;
    line_pd_output = proportional + i_term;
    return line_pd_output;
  }
  if (frame_count == line_pd_frame) {
    return line_pd_output;
  }
  line_pd_frame = frame_count;

  derivative = (int16_t)(raw_deviation - line_pd_previous);
  line_pd_previous = raw_deviation;
  if (derivative > LINE_D_LIMIT) {
    derivative = LINE_D_LIMIT;
  } else if (derivative < -LINE_D_LIMIT) {
    derivative = (int16_t)(-LINE_D_LIMIT);
  }
  line_error_change = (derivative < 0) ?
                      (int16_t)(-derivative) : derivative;

  target = (int16_t)(proportional + i_term +
                     ((int32_t)derivative * tune_kd) / 10);
  if ((raw_deviation > 0) && (target < 0)) {
    target = 0;
  } else if ((raw_deviation < 0) && (target > 0)) {
    target = 0;
  }
  if (target > LINE_MAX_TURN) {
    target = LINE_MAX_TURN;
  } else if (target < -LINE_MAX_TURN) {
    target = (int16_t)(-LINE_MAX_TURN);
  }

  line_pd_output = target;
  return line_pd_output;
}

/*
 * v39: 陀螺仪自适应阻尼 + 弯道硬关断.
 * |turn|>25: 完全关陀螺, 弯道自由偏航.
 * |turn|≤25: 自适应阻尼抑震荡, 直线满增益→弯道递减.
 * correction = +gyro_z × gain(自适应), 纯阻尼不级联.
 */
static int16_t Line_GyroDampedTurn(int16_t line_turn, uint32_t now)
{
  float gyro_z;
  uint32_t gyro_tick;
  int16_t correction;
  int32_t target;
  int16_t abs_turn;
  int16_t adaptive_gain;  /* ×100, 0~100 */

  if ((JY901S_GetGyroZ(&gyro_z, &gyro_tick) == 0U) ||
      ((now - gyro_tick) > LINE_GYRO_TIMEOUT_MS)) {
    line_gyro_turn = 0;
    return line_turn;
  }

  if (gyro_tick != line_gyro_frame) {
    line_gyro_frame = gyro_tick;
    line_gyro_filtered += (gyro_z - line_gyro_filtered) * 0.25f;
  }
  if ((line_gyro_filtered < 1.0f) && (line_gyro_filtered > -1.0f)) {
    line_gyro_filtered = 0.0f;
  }

  abs_turn = (line_turn < 0) ? (int16_t)(-line_turn) : line_turn;

  /* v39: 急弯(>25)硬关陀螺, 避免抵消弯道持续偏航.
     直线/小弯: 自适应阻尼抑震荡. */
  if (abs_turn > 25) {
    line_gyro_turn = 0;
    return line_turn;  /* 弯道完全放开, 不干预转向 */
  }

  /* 自适应阻尼增益.
     直线(转向<5):  满增益GK   — 强力抑震荡
     小弯(5~15):    2/3增益    — 平滑但稳定
     中弯(15~25):   1/3增益    — 允许偏航 */
  if (abs_turn < 5) {
    adaptive_gain = tune_gyro_kd_x100;               /* GK */
  } else if (abs_turn < 15) {
    adaptive_gain = (int16_t)(tune_gyro_kd_x100 * 2 / 3);
  } else {
    adaptive_gain = (int16_t)(tune_gyro_kd_x100 / 3);
  }

  /* correction = +gyro × gain/100 (阻尼: 直线抑震, 弯道递减至0) */
  correction = (int16_t)(line_gyro_filtered *
                         ((float)adaptive_gain / 100.0f) *
                         (float)LINE_GYRO_DIRECTION);
  if (correction > LINE_GYRO_MAX_TURN) {
    correction = LINE_GYRO_MAX_TURN;
  } else if (correction < -LINE_GYRO_MAX_TURN) {
    correction = (int16_t)(-LINE_GYRO_MAX_TURN);
  }
  line_gyro_turn = correction;

  target = (int32_t)line_turn + correction;
  if (target > LINE_MAX_TURN) {
    target = LINE_MAX_TURN;
  } else if (target < -LINE_MAX_TURN) {
    target = -LINE_MAX_TURN;
  }
  return (int16_t)target;
}

/* 所有模式共用同一转向斜坡，防止循迹/丢线/重获线之间命令突变。 */
static int16_t Line_SlewTurn(int16_t current, int16_t target)
{
  int16_t delta = (int16_t)(target - current);

  if (delta > LINE_TURN_MAX_STEP) {
    delta = LINE_TURN_MAX_STEP;
  } else if (delta < -LINE_TURN_MAX_STEP) {
    delta = (int16_t)(-LINE_TURN_MAX_STEP);
  }
  return (int16_t)(current + delta);
}

/* v27: EMA平滑速度, 代替固定步长跳变.
   加速α=3/8≈0.375, 减速α=5/8≈0.625, 紧急保留硬减速.
   不与直线STR冲突: STR提升target, EMA自然跟随. */
static int16_t Line_BlendedSpeed(int16_t current, int16_t target,
                                 uint8_t urgent)
{
  int16_t diff;
  int16_t step;

  if (current <= 0) {
    return (target < LINE_SPEED_START) ? target : LINE_SPEED_START;
  }

  /* 正常循迹: EMA平滑过渡, 弯道降速柔和不突兀 */
  if (urgent == 0U) {
    if (target < LINE_CURVE_MIN_SPEED) {
      target = LINE_CURVE_MIN_SPEED;
    }
    diff = (int16_t)(target - current);
    if (diff > 0) {
      /* 加速: 柔和 */
      step = (int16_t)((diff * LINE_SPEED_ALPHA_UP +
                        (1 << (LINE_SPEED_ALPHA_SHIFT - 1))) >>
                       LINE_SPEED_ALPHA_SHIFT);
      if (step < 1) step = 1;
      return (int16_t)(current + step);
    } else if (diff < 0) {
      /* 减速: 较快但不突兀 */
      step = (int16_t)(((-diff) * LINE_SPEED_ALPHA_DN +
                        (1 << (LINE_SPEED_ALPHA_SHIFT - 1))) >>
                       LINE_SPEED_ALPHA_SHIFT);
      if (step < 1) step = 1;
      return (int16_t)(current - step);
    }
    return target;
  }

  /* urgent (边缘/丢线): 保留硬减速保证安全 */
  if (target < (int16_t)(current - LINE_URGENT_BRAKE_STEP)) {
    return (int16_t)(current - LINE_URGENT_BRAKE_STEP);
  }
  if (target > (int16_t)(current + LINE_URGENT_BRAKE_STEP)) {
    return (int16_t)(current + LINE_URGENT_BRAKE_STEP);
  }
  return target;
}

/* ── KEY3 消抖按键 ── */
static uint8_t Key3_Pressed(void)
{
  static GPIO_PinState last_sample = GPIO_PIN_SET;
  static GPIO_PinState stable_state = GPIO_PIN_SET;
  static uint32_t changed_tick = 0U;
  GPIO_PinState sample = HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_3);
  uint32_t now = HAL_GetTick();

  if (sample != last_sample) {
    last_sample = sample;
    changed_tick = now;
  }
  if ((sample != stable_state) &&
      ((now - changed_tick) >= LINE_KEY_DEBOUNCE_MS)) {
    stable_state = sample;
    if (stable_state == GPIO_PIN_RESET) {
      return 1U;
    }
  }
  return 0U;
}

/* ── KEY1/KEY2 消抖 (与KEY3同逻辑) ── */
static uint8_t Key1_Pressed(void)
{
  static GPIO_PinState last = GPIO_PIN_SET;
  static GPIO_PinState stable = GPIO_PIN_SET;
  static uint32_t tick = 0U;
  GPIO_PinState s = HAL_GPIO_ReadPin(KEY1_PORT, KEY1_PIN);
  uint32_t now = HAL_GetTick();
  if (s != last) { last = s; tick = now; }
  if ((s != stable) && ((now - tick) >= LINE_KEY_DEBOUNCE_MS)) {
    stable = s;
    if (stable == GPIO_PIN_RESET) return 1U;
  }
  return 0U;
}

static uint8_t Key2_Pressed(void)
{
  static GPIO_PinState last = GPIO_PIN_SET;
  static GPIO_PinState stable = GPIO_PIN_SET;
  static uint32_t tick = 0U;
  GPIO_PinState s = HAL_GPIO_ReadPin(KEY2_PORT, KEY2_PIN);
  uint32_t now = HAL_GetTick();
  if (s != last) { last = s; tick = now; }
  if ((s != stable) && ((now - tick) >= LINE_KEY_DEBOUNCE_MS)) {
    stable = s;
    if (stable == GPIO_PIN_RESET) return 1U;
  }
  return 0U;
}

/* Tell MaixCAM whether groove touches should select a Req6 target. */
static void Req6_SetTouchSelection(uint8_t enable)
{
  static const uint8_t select_on[] = "R6ON\n";
  static const uint8_t select_off[] = "R6OFF\n";
  const uint8_t *command = enable != 0U ? select_on : select_off;
  uint16_t command_len = enable != 0U
                       ? (uint16_t)(sizeof(select_on) - 1U)
                       : (uint16_t)(sizeof(select_off) - 1U);

  req6_touch_selecting = enable != 0U ? 1U : 0U;
  (void)HAL_UART_Transmit(&huart2, (uint8_t *)command,
                          command_len, 20U);
}

/* Req6 unified finish state: the caller has stopped the vehicle and returned
 * the balance platform to zero through Balance_Stop(). Clear the temporary
 * target before accepting another touch so no offset leaks into the next run. */
static void Req6_ResetTargetAndSelect(void)
{
  bal_user_setpoint = 0;
  g_pid.setpoint = 0;
  car_running = 0U;
  menu_sel = 4U;
  (void)Balance_ArmVisionOnly();
  Req6_SetTouchSelection(1U);
}

static int32_t MaixControl_ParseTarget(const char *text, uint8_t *valid)
{
  uint8_t i = 1U;
  int32_t sign = 1;
  int32_t whole = 0;
  int32_t frac = 0;
  uint8_t frac_digits = 0U;
  uint8_t dot_seen = 0U;
  uint8_t digits = 0U;

  *valid = 0U;
  if (text[0] != 'S') return 0;
  if (text[i] == '-') { sign = -1; ++i; }
  else if (text[i] == '+') { ++i; }

  for (; text[i] != '\0'; ++i) {
    char c = text[i];
    if (c == '.') {
      if (dot_seen != 0U || digits == 0U) return 0;
      dot_seen = 1U;
    } else if (c >= '0' && c <= '9') {
      ++digits;
      if (dot_seen == 0U) {
        whole = whole * 10 + (int32_t)(c - '0');
      } else if (frac_digits < 2U) {
        frac = frac * 10 + (int32_t)(c - '0');
        ++frac_digits;
      } else {
        return 0;
      }
    } else {
      return 0;
    }
  }
  if (digits == 0U || (dot_seen != 0U && frac_digits == 0U)) return 0;
  if (frac_digits == 1U) frac *= 10;
  int32_t result = sign * (whole * 100 + frac);
  if (result < -1200 || result > 1200) return 0;
  *valid = 1U;
  return result;
}

static void MaixControl_ParseByte(uint8_t byte)
{
  static char line[16];
  static uint8_t line_len = 0U;

  if (byte == '\n' || byte == '\r') {
    if (line_len > 0U) {
      uint8_t target_valid;
      line[line_len] = '\0';
      int32_t target = MaixControl_ParseTarget(line, &target_valid);
      if (target_valid != 0U && active_task == 4U &&
          req6_touch_selecting != 0U) {
        bal_user_setpoint = target;
      }
    }
    line_len = 0U;
    return;
  }

  if (line_len < (uint8_t)(sizeof(line) - 1U)) {
    line[line_len++] = (char)byte;
  } else {
    line_len = 0U;
  }
}

/* ── 中断回调 ── */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1) {
    if (tune_cmd_ready == 0U) {
      if ((tune_rx_byte == '\n') || (tune_rx_byte == '\r')) {
        if (tune_rx_len > 0U) {
          tune_rx_buf[tune_rx_len] = '\0';
          tune_cmd_ready = 1U;
        }
      } else if (tune_rx_len < (sizeof(tune_rx_buf) - 1U)) {
        tune_rx_buf[tune_rx_len++] = (char)tune_rx_byte;
      } else {
        tune_rx_len = 0U;
      }
    }
    (void)HAL_UART_Receive_IT(&huart1, &tune_rx_byte, 1U);
  } else if (huart->Instance == USART3) {
    /* USART3: 步进电机 (Emm_V5) — 不在此处理RX, 不重新启动RX IT */
    /* 保持 huart3.RxState = READY, 避免干扰 TX 发送 */
  } else if (huart->Instance == USART6) {
    JY901S_ParseByte(rx6_byte);
    (void)HAL_UART_Receive_IT(&huart6, &rx6_byte, 1U);
  } else if (huart->Instance == USART2) {
    /* USART2: MaixCam 摄像头 (Req3/4/5/6 共用) */
    ++bal_uart2_rx_count;
    MaixControl_ParseByte(maixcam_rx_byte);
    if (TASK_USES_BALANCE(active_task)
        && maixcam_rx_byte != 0x00 && maixcam_rx_byte != 0xFF) {
      MaixCam_RXCallback(maixcam_rx_byte);
    }
    (void)HAL_UART_Receive_IT(&huart2, &maixcam_rx_byte, 1U);
  }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART1) {
    tune_rx_len = 0U;
    (void)HAL_UART_Receive_IT(&huart1, &tune_rx_byte, 1U);
  } else if (huart->Instance == USART3) {
    /* USART3: 步进电机 — 不重新启动RX IT, 避免干扰TX */
  } else if (huart->Instance == USART6) {
    JY901S_UartError();
    (void)HAL_UART_Receive_IT(&huart6, &rx6_byte, 1U);
  } else if (huart->Instance == USART2) {
    ++bal_uart2_error_count;
    bal_uart2_last_error = HAL_UART_GetError(&huart2);
    (void)HAL_UART_AbortReceive(&huart2);
    __HAL_UART_CLEAR_OREFLAG(&huart2);
    if (TASK_USES_BALANCE(active_task)) {
      (void)HAL_UART_Receive_IT(&huart2, &maixcam_rx_byte, 1U);
    }
  }
}

/* ── 统一摆球启动 ── */
static void Balance_Start(uint32_t now)
{
  float start_kp = (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task))
                 ? T4_BAL_PID_KP
                 : (float)bal_tune_kp_x10 / 10.0f;
  float start_kd = (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task))
                 ? T4_BAL_PID_KD
                 : (float)bal_tune_kd_x10 / 10.0f;
  /*
   * 清理上一次运行状态。
   * 停止定时器后再修改共享变量，避免中断访问半初始化数据。
   */
  (void)HAL_TIM_Base_Stop_IT(&htim5_bal);
  HAL_NVIC_DisableIRQ(TIM5_IRQn);
  HAL_NVIC_DisableIRQ(USART2_IRQn);

  /* 结束旧接收，强制下一次 Init 重新执行 HAL_UART_MspInit */
  (void)HAL_UART_AbortReceive(&huart2);
  (void)HAL_UART_DeInit(&huart2);

  /* 清除 USART3 RX 残留状态, 避免干扰步进电机 TX */
  (void)HAL_UART_AbortReceive(&huart3);

  /* 如果 Track_I2C_Init 改写了 PA2/PA3，这里恢复 USART2 */
  MX_USART2_UART_Init();

  /* MaixCAM持续发送时，必须先清ORE并挂好单字节接收，再做后续电机初始化。 */
  MaixCam_Reset();
  maixcam_rx_byte = 0U;
  __HAL_UART_CLEAR_OREFLAG(&huart2);
  HAL_NVIC_SetPriority(USART2_IRQn, 2, 0);
  if (HAL_UART_Receive_IT(&huart2,
                          &maixcam_rx_byte,
                          1U) != HAL_OK) {
    Balance_Stop();
    Error_Handler();
  }
  HAL_NVIC_EnableIRQ(USART2_IRQn);

  PID_Init(&g_pid);
  PID_Set_Gains(&g_pid,
                start_kp,
                start_kd,
                bal_tune_max_pulses);
  g_pid.p.deadband = T3_PID_DEADBAND;

  /* 清空全部摆球运行状态 */
  if (!bal_origin_valid) {
    bal_abs_pos = 0;
    bal_origin_valid = 1;
  }
  bal_motor_cmd = 0;
  bal_cmd_new = 0;
  bal_target_pos = 0;
  bal_target_valid = 0;
  bal_center_hold = 0U;
  bal_prev_ball_pos = 0;
  bal_prev_ball_valid = 0U;
  bal_prev_ball_tick = 0U;
  bal_last_vision_dt_ms = 0U;
  bal_step_limit = T3_MAX_STEP_PULSES;
  bal_stiction_boost = 0;
  bal_stiction_frames = 0U;
  bal_prev_error_sign = 0;
  bal_brake_mode = 0U;
  bal_turn_brake_active = 0U;
  bal_brake_slow_frames = 0U;
  bal_recover_mode = 0U;
  bal_recover_frames = 0U;
  bal_recover_move_frames = 0U;
  bal_delta_filt_q8 = 0;
  bal_last_delta_filt = 0;
  bal_stop_req = 0;
  bal_seq_confirm_frames = 0U;

  bal_vision_timeout = 1;
  bal_failsafe_sent = 0;
  bal_last_valid_pos = 0;
  bal_has_init_pos = 0;

  bal_last_tx_tick = now;
  bal_seq_start_tick = now;
  bal_seq_phase = 0;
  bal_seq_done = 0;
  bal_seq_failed = 0;
  bal_seq_confirm_frames = 0;
  bal_req3_launch_done = 0U;
  bal_seq_done_tick = 0;
  bal_uart2_rx_count = 0U;
  bal_uart2_error_count = 0U;
  bal_uart2_last_error = 0U;
  bal_platform_centered = 0U;

  /* 清除可能残留的定时器状态 */
  __HAL_TIM_SET_COUNTER(&htim5_bal, 0);
  __HAL_TIM_CLEAR_FLAG(&htim5_bal, TIM_FLAG_UPDATE);

  /* 初始化并使能步进驱动器 */
  Emm_V5_Stop(EMM_ADDR, SYNC_OFF);
  HAL_Delay(20);

  Emm_V5_Enable(EMM_ADDR, 1, SYNC_OFF);
  HAL_Delay(20);

  HAL_NVIC_EnableIRQ(TIM5_IRQn);

  if (HAL_TIM_Base_Start_IT(&htim5_bal) != HAL_OK) {
    Balance_Stop();
    Error_Handler();
  }
}

/* ── 回中: 命令位置归零 (无物理限位/编码器时仅为尽力回中) ── */
static void Balance_ReturnCenter(void)
{
  while (bal_abs_pos != 0) {
    int32_t step = -bal_abs_pos;

    if (step > T3_MAX_STEP_PULSES) {
      step = T3_MAX_STEP_PULSES;
    } else if (step < -T3_MAX_STEP_PULSES) {
      step = -T3_MAX_STEP_PULSES;
    }

    if (Emm_V5_Move_Relative(step,
                             T3_MOTOR_SPEED,
                             T3_MOTOR_ACC) != HAL_OK) {
      break;
    }

    bal_abs_pos += step;
    HAL_Delay(T3_MOTOR_TX_INTERVAL_MS);
  }
}

/* ── 统一摆球停止 ── */
static void Balance_Stop(void)
{
  (void)HAL_TIM_Base_Stop_IT(&htim5_bal);

  HAL_NVIC_DisableIRQ(TIM5_IRQn);
  HAL_NVIC_DisableIRQ(USART2_IRQn);

  /* 结束仍处于 BUSY_RX 状态的串口接收 */
  (void)HAL_UART_AbortReceive(&huart2);
  (void)HAL_UART_DeInit(&huart2);

  bal_motor_cmd = 0;
  bal_cmd_new = 0;
  bal_target_valid = 0;
  bal_target_pos = 0;
  bal_center_hold = 0U;
  bal_prev_ball_valid = 0U;
  bal_step_limit = T3_MAX_STEP_PULSES;
  bal_stiction_boost = 0;
  bal_stiction_frames = 0U;
  bal_prev_error_sign = 0;
  bal_brake_mode = 0U;
  bal_brake_slow_frames = 0U;
  bal_recover_mode = 0U;
  bal_recover_frames = 0U;
  bal_recover_move_frames = 0U;
  bal_delta_filt_q8 = 0;
  bal_req3_launch_done = 0U;
  bal_stop_req = 0;

  /* 尽力回到机械零点再停驱动器 */
  Balance_ReturnCenter();

  /* 只有软件累计位置确实回零才标记完成；失败时主循环可重试。 */
  bal_platform_centered = (bal_abs_pos == 0) ? 1U : 0U;

  Emm_V5_Stop(EMM_ADDR, SYNC_OFF);
}

static HAL_StatusTypeDef Balance_ArmVisionOnly(void)
{
  HAL_NVIC_DisableIRQ(USART2_IRQn);
  (void)HAL_UART_AbortReceive(&huart2);
  (void)HAL_UART_DeInit(&huart2);
  MX_USART2_UART_Init();

  MaixCam_Reset();
  maixcam_rx_byte = 0U;
  bal_uart2_rx_count = 0U;
  bal_uart2_error_count = 0U;
  bal_uart2_last_error = 0U;
  __HAL_UART_CLEAR_OREFLAG(&huart2);
  HAL_NVIC_SetPriority(USART2_IRQn, 2, 0);
  if (HAL_UART_Receive_IT(&huart2, &maixcam_rx_byte, 1U) != HAL_OK) {
    return HAL_ERROR;
  }
  HAL_NVIC_EnableIRQ(USART2_IRQn);
  return HAL_OK;
}

/* ── TIM5 100Hz PID 初始化 ── */
static void MX_TIM5_Balance_Init(void)
{
  __HAL_RCC_TIM5_CLK_ENABLE();
  htim5_bal.Instance = TIM5;
  htim5_bal.Init.Prescaler = 8400 - 1;      /* 84MHz/8400=10kHz */
  htim5_bal.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5_bal.Init.Period = 100 - 1;           /* 10kHz/100=100Hz */
  htim5_bal.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5_bal.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5_bal) != HAL_OK) {
    Error_Handler();
  }
  HAL_NVIC_SetPriority(TIM5_IRQn, 1, 0);
  HAL_NVIC_DisableIRQ(TIM5_IRQn);
}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM5) {
    __HAL_RCC_TIM5_CLK_ENABLE();
  }
}

/* ── TIM5 100Hz 中断: 摆球PID控制 ── */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim != &htim5_bal || !TASK_USES_BALANCE(active_task)) return;

  uint32_t now = HAL_GetTick();

  if (MaixCam_IsTimeout(now)) {
    g_pid.last_error = 0;
    g_pid.last_tick = 0;
    bal_has_init_pos = 0;
    bal_prev_ball_valid = 0U;
    bal_prev_ball_tick = 0U;
    bal_last_vision_dt_ms = 0U;
    bal_target_valid = 0;
    bal_stiction_boost = 0;
    bal_stiction_frames = 0U;
    bal_prev_error_sign = 0;
    bal_brake_mode = 0U;
    bal_brake_slow_frames = 0U;
    bal_recover_mode = 0U;
    bal_recover_frames = 0U;
    bal_recover_move_frames = 0U;
    bal_delta_filt_q8 = 0;
    if (!bal_failsafe_sent) {
      bal_stop_req = 1;
      bal_failsafe_sent = 1;
    }
    if (TASK_IS_FULL_LAP_BALANCE(active_task) &&
        car_running != 0U && stop_state != 2U) {
      if (req5_vision_lost_tick == 0U) {
        req5_vision_lost_tick = now;
      }
      if (req4_b_reached == 0U &&
          (now - req5_vision_lost_tick) >= T5_VISION_ABORT_MS) {
        req4_failed = 1U;
        req4_fail_reason |= T4_FAIL_VISION;
        req4_abort_req = 1U;
      }
    } else if (active_task == 0U && car_running != 0U &&
               stop_state != 2U &&
               (now - stop_start_tick) >= T4_VISION_GRACE_MS) {
        req4_failed = 1U;
        req4_fail_reason |= T4_FAIL_VISION;
        req4_abort_req = 1U;
    }
    bal_vision_timeout = 1;
    return;
  }

  bal_vision_timeout = 0;
  bal_failsafe_sent = 0;
  req5_vision_lost_tick = 0U;
  int32_t pos_cm100;
  if (!MaixCam_GetPosition(&pos_cm100)) return;

  if ((active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) &&
      car_running != 0U && stop_state != 2U) {
    int32_t score_error = (active_task == 4U)
                        ? (pos_cm100 - bal_user_setpoint) : pos_cm100;
    int32_t abs_ball = score_error < 0 ? -score_error : score_error;
    int32_t safety_value = abs_ball;
    int32_t safety_limit;
    if (active_task == 4U) {
      /* Req6 can legitimately start with the ball at O and a far target.
       * Protect against leaving the physical groove, not against being far
       * from the newly selected target during acquisition. */
      safety_value = pos_cm100 < 0 ? -pos_cm100 : pos_cm100;
      safety_limit = T6_PHYSICAL_SAFETY_CM100;
    } else {
      safety_limit = TASK_IS_FULL_LAP_BALANCE(active_task)
                   ? T5_BALL_SAFETY_CM100
                   : T4_BALL_SAFETY_CM100;
    }
    if (abs_ball > req4_max_abs_ball) {
      req4_max_abs_ball = abs_ball;
    }
    if (abs_ball > T4_BALL_LIMIT_CM100) {
      req4_ball_violation = 1U;
      req4_failed = 1U;
      req4_fail_reason |= T4_FAIL_BALL;
    }
    if (safety_value >= safety_limit) {
      req4_failed = 1U;
      req4_fail_reason |= T4_FAIL_SAFETY;
      req4_abort_req = 1U;
    }
  }

  /* 第一帧有效数据只初始化位置；要求3计时从按键启动时开始。 */
  if (bal_has_init_pos == 0U) {
    bal_has_init_pos = 1U;
    bal_last_valid_pos = pos_cm100;
  }

  /* Req3自动序列: 按键后立即 O→+5cm；到达后折返→-5cm并保持。 */
  if (active_task == 2) {
    if (bal_seq_phase == 0U) {
      g_pid.setpoint = T3_REQ3_TARGET_CM100;
    } else if (bal_seq_phase == 1U) {
      g_pid.setpoint = -T3_REQ3_RETURN_AIM_CM100;
    } else {
      g_pid.setpoint = -T3_REQ3_TARGET_CM100;
    }
  } else {
    /* Req4/5/6: 用户设定目标位置 */
    g_pid.setpoint = bal_user_setpoint;
  }

  /* ── 球速: 按有效视觉样本间隔归一化到每100ms，再低通滤波 ── */
  int32_t delta_pos = 0;
  if (bal_prev_ball_valid != 0U) {
    delta_pos = pos_cm100 - bal_prev_ball_pos;
    uint32_t sample_dt_ms = now - bal_prev_ball_tick;
    if (sample_dt_ms == 0U) sample_dt_ms = 1U;
    bal_last_vision_dt_ms = sample_dt_ms;
    delta_pos = (int32_t)(((int64_t)delta_pos * T3_VELOCITY_REF_MS) /
                          (int64_t)sample_dt_ms);
  } else {
    bal_last_vision_dt_ms = 0U;
  }
  bal_prev_ball_pos = pos_cm100;
  bal_prev_ball_tick = now;
  bal_prev_ball_valid = 1U;

  /* 一阶低通 Q8: 新值3/4 + 旧值1/4 (更快响应球速变化) */
  int32_t delta_target_q8 = ((int32_t)delta_pos) << 8;
  bal_delta_filt_q8 += ((delta_target_q8 - bal_delta_filt_q8) * 3) / 4;
  int32_t delta_filt     = bal_delta_filt_q8 / 256;
  bal_last_delta_filt = delta_filt;
  int32_t abs_delta_filt = (delta_filt < 0) ? -delta_filt : delta_filt;

  int32_t error      = g_pid.setpoint - pos_cm100;
  int32_t abs_error  = (error < 0) ? -error : error;

  /*
   * 要求3到位状态机：+5cm首次进入±1cm窗口即折返；最终-5cm需
   * 在±1cm窗口内低速连续确认。完成后继续保持-5cm，不自动回中。
   */
  if (active_task == 2 && bal_seq_done == 0U && bal_seq_failed == 0U) {
    if ((now - bal_seq_start_tick) >= T3_TIMEOUT_MS) {
      bal_seq_failed = 1U;
      bal_seq_phase = 2U;
      bal_seq_confirm_frames = 0U;
      g_pid.setpoint = -T3_REQ3_TARGET_CM100;
      bal_brake_mode = 0U;
      bal_turn_brake_active = 0U;
      bal_center_hold = 1U;
      bal_stiction_boost = 0;
      bal_stiction_frames = 0U;
      bal_recover_mode = 0U;
    } else if (bal_seq_phase == 0U &&
               abs_error <= T3_REQ3_TOL_CM100) {
      /*
       * +5cm只要求到达后折返。实测球会高速穿过评分窗口，若等待低速
       * 连续确认会错过窗口并撞向端点，因此首次进入±1cm即立即反向。
       */
      bal_seq_phase = 1U;
      bal_seq_confirm_frames = 0U;
      g_pid.setpoint = -T3_REQ3_RETURN_AIM_CM100;
      g_pid.last_error = g_pid.setpoint - pos_cm100;
      g_pid.last_tick = now;
      bal_center_hold = 0U;
      bal_stiction_boost = 0;
      bal_stiction_frames = 0U;
      /* 折返点先消除正向球速，再进入回程，避免电机普通换向期间冲过+5cm。 */
      bal_brake_mode = 1U;
      bal_turn_brake_active = 1U;
      bal_brake_slow_frames = 0U;
      bal_recover_mode = 0U;
      bal_recover_frames = 0U;
      bal_recover_move_frames = 0U;
    } else if (bal_seq_phase == 1U &&
               pos_cm100 >= (-T3_REQ3_TARGET_CM100 - T3_REQ3_TOL_CM100) &&
               pos_cm100 <= (-T3_REQ3_TARGET_CM100 + T3_REQ3_TOL_CM100) &&
               abs_delta_filt <= T3_CAPTURE_SPEED_CM100) {
      /* 仅低速稳定停在-5±1cm才算完成，禁止把高速穿窗误报为成功。 */
      if (bal_seq_confirm_frames < T3_REQ3_CONFIRM_FRAMES) {
        ++bal_seq_confirm_frames;
      }
      if (bal_seq_confirm_frames >= T3_REQ3_CONFIRM_FRAMES) {
        bal_seq_confirm_frames = 0U;
        bal_seq_phase = 2U;
        bal_seq_done = 1U;
        bal_seq_done_tick = now;
        g_pid.setpoint = -T3_REQ3_TARGET_CM100;
        /* 已在目标窗内低速捕获：立即退出制动并回水平，避免完成后反向弹离。 */
        bal_brake_mode = 0U;
        bal_turn_brake_active = 0U;
        bal_brake_slow_frames = 0U;
        bal_center_hold = 1U;
        bal_stiction_boost = 0;
        bal_stiction_frames = 0U;
        g_pid.last_error = g_pid.setpoint - pos_cm100;
        g_pid.last_tick = now;
      }
    } else {
      bal_seq_confirm_frames = 0U;
    }
  }

  /* 状态切换可能刚改变目标，后续补偿、制动和PID必须使用新目标误差。 */
  error = g_pid.setpoint - pos_cm100;
  abs_error = (error < 0) ? -error : error;

  /* ── 误差符号, 供摩擦补偿判断方向 ── */
  int8_t error_sign;
  if (error > 0) {
    error_sign = 1;
  } else if (error < 0) {
    error_sign = -1;
  } else {
    error_sign = 0;
  }

  /* ── 渐进静摩擦补偿 ── */
  if (bal_center_hold != 0U ||
      abs_error <= T3_STICTION_START_CM100 ||
      error_sign == 0) {
    bal_stiction_boost   = 0;
    bal_stiction_frames  = 0U;
  } else if (bal_prev_error_sign != 0 &&
             error_sign != bal_prev_error_sign) {
    /* 球越过中心或误差换向, 立即清空补偿 */
    bal_stiction_boost   = 0;
    bal_stiction_frames  = 0U;
  } else if (abs_delta_filt <= T3_STICTION_SPEED_CM100) {
    /* 球停滞: 每隔若干帧增加1脉冲倾角 */
    ++bal_stiction_frames;
    if (bal_stiction_frames >= T3_STICTION_RAMP_FRAMES) {
      bal_stiction_frames = 0U;
      if (bal_stiction_boost < T3_STICTION_MAX_PULSES) {
        ++bal_stiction_boost;
      }
    }
  } else {
    /* 球已运动: 立即清除补偿, 防止继续加速造成过冲 */
    bal_stiction_frames = 0U;
    bal_stiction_boost = 0;
  }
  bal_prev_error_sign = error_sign;

  /* ── 动态制动检测 ── */
  if ((active_task == 2U &&
       (bal_seq_done != 0U || bal_seq_failed != 0U)) ||
      bal_recover_mode != 0U) {
    /* 完成锁定或救援期间制动不介入，禁止完成后同帧重新进入制动。 */
    bal_brake_mode = 0U;
    bal_turn_brake_active = 0U;
    bal_brake_slow_frames = 0U;
  } else {
    uint8_t moving_to_target = 0U;
    int32_t brake_zone_cm100 = T3_BRAKE_ZONE_CM100;
    if (active_task == 2U && bal_seq_phase == 1U &&
        bal_turn_brake_active == 0U) {
      brake_zone_cm100 = T3_REQ3_RETURN_BRAKE_BASE_CM100 +
                         T3_REQ3_RETURN_BRAKE_V_GAIN * abs_delta_filt;
      if (brake_zone_cm100 > T3_REQ3_RETURN_BRAKE_MAX_CM100) {
        brake_zone_cm100 = T3_REQ3_RETURN_BRAKE_MAX_CM100;
      }
    }
    if ((error > 0 && delta_filt > 0) ||
        (error < 0 && delta_filt < 0)) {
      moving_to_target = 1U;
    }

    if (bal_brake_mode == 0U) {
      /* Req4使用连续PD，不进入离散制动；其余任务沿用到点制动。 */
      if (active_task != 0U && !TASK_IS_FULL_LAP_BALANCE(active_task) &&
          !(active_task == 2U && bal_seq_phase == 0U) &&
          moving_to_target != 0U &&
          abs_error <= brake_zone_cm100 &&
          abs_delta_filt >= T3_BRAKE_ENTER_DELTA_CM100) {
        bal_brake_mode = 1U;
        bal_brake_slow_frames = 0U;
      }
    } else {
      /* 要求3折返点：球一旦反向朝-5cm运动，立即结束折返点制动。 */
      if (bal_turn_brake_active != 0U &&
          active_task == 2U && bal_seq_phase == 1U &&
          error < 0 && delta_filt < 0) {
        bal_brake_mode = 0U;
        bal_turn_brake_active = 0U;
        bal_brake_slow_frames = 0U;
        g_pid.last_error = error;
        g_pid.last_tick = now;
      } else if (abs_delta_filt <= T3_BRAKE_STOP_DELTA_CM100) {
        if (bal_brake_slow_frames < T3_BRAKE_STOP_FRAMES) {
          ++bal_brake_slow_frames;
        }
        if (bal_brake_slow_frames >= T3_BRAKE_STOP_FRAMES) {
          bal_brake_mode = 0U;
          bal_turn_brake_active = 0U;
          bal_brake_slow_frames = 0U;
          g_pid.last_error = error;
          g_pid.last_tick = now;
        }
      } else {
        bal_brake_slow_frames = 0U;
      }
    }
  }

  /* ── 端部救援检测 ── */
  if (bal_recover_mode == 0U) {
    if (abs_error >= T3_RECOVER_ENTER_CM100 &&
        abs_delta_filt <= T3_RECOVER_STILL_CM100) {
      if (bal_recover_frames < T3_RECOVER_CONFIRM_FRAMES) {
        ++bal_recover_frames;
      }
      if (bal_recover_frames >= T3_RECOVER_CONFIRM_FRAMES) {
        bal_recover_mode = 1U;
        bal_recover_frames = 0U;
        bal_recover_move_frames = 0U;
      }
    } else {
      bal_recover_frames = 0U;
    }
  } else {
    /* 救援只需启动球: 连续2帧运动 → 立即退出 */
    if (abs_delta_filt >= T3_RECOVER_MOVE_DELTA_CM100) {
      if (bal_recover_move_frames < T3_RECOVER_MOVE_FRAMES) {
        ++bal_recover_move_frames;
      }
    } else {
      bal_recover_move_frames = 0U;
    }
    if (bal_recover_move_frames >= T3_RECOVER_MOVE_FRAMES ||
        abs_error <= T3_RECOVER_EXIT_CM100) {
      bal_recover_mode = 0U;
      bal_recover_frames = 0U;
      bal_recover_move_frames = 0U;
      g_pid.last_error = error;
      g_pid.last_tick = now;
    }
  }

  /* 救援优先于制动和中心保持 */
  if (bal_recover_mode != 0U) {
    bal_brake_mode = 0U;
    bal_brake_slow_frames = 0U;
    bal_center_hold = 0U;
    bal_stiction_boost  = 0;
    bal_stiction_frames = 0U;
  }

  /* ── 中心捕获迟滞 (救援/制动期间禁止) ── */
  if (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) {
    /* Req4必须在中心附近连续响应车体加速度，禁止迟滞锁死为水平。 */
    bal_center_hold = 0U;
  } else if (bal_recover_mode != 0U || bal_brake_mode != 0U) {
    bal_center_hold = 0U;
  } else if (bal_center_hold == 0U) {
    if (abs_error <= T3_CAPTURE_ENTER_CM100 &&
        abs_delta_filt <= T3_CAPTURE_SPEED_CM100) {
      bal_center_hold = 1U;
    }
  } else {
    if (abs_error >= T3_CAPTURE_EXIT_CM100) {
      bal_center_hold = 0U;
    }
  }

  /* ── PID 绝对目标 ── */
  int32_t target_pulses = PID_Compute(&g_pid, pos_cm100, now);
  target_pulses *= T3_MOTOR_POLARITY;

  if (active_task == 2U && bal_seq_phase == 0U &&
      bal_req3_launch_done == 0U &&
      bal_abs_pos <= -T3_REQ3_LAUNCH_MIN_PULSES &&
      delta_filt > T3_REQ3_LAUNCH_SPEED_CM100) {
    bal_req3_launch_done = 1U;
  }

  /* 要求3起步负向存在机械死区：仅远离中心的出程饱和段提高到-90。 */
  if (active_task == 2U && bal_seq_phase == 0U &&
      bal_req3_launch_done == 0U &&
      abs_error > T3_TILT_FAR_CM100) {
    target_pulses = -T3_REQ3_OUTBOUND_PULSES;
  }

  /* ── 控制状态覆盖 ── */
  if (bal_recover_mode != 0U) {
    /* 端部启动: error_sign>0→正CMD(抬左), error_sign<0→负CMD(抬右) */
    target_pulses = (int32_t)error_sign * T3_RECOVER_TARGET_PULSES
                  * T3_MOTOR_POLARITY;
  } else if (bal_brake_mode != 0U) {
    /* 制动目标直接与球运动方向相反 */
    int32_t brake_magnitude;
    if (abs_delta_filt >= 25) {
      brake_magnitude = T3_BRAKE_TARGET_FAST;
    } else if (abs_delta_filt >= 15) {
      brake_magnitude = T3_BRAKE_TARGET_MID;
    } else {
      brake_magnitude = T3_BRAKE_TARGET_SLOW;
    }
    if (active_task == 0U) {
      if (abs_delta_filt >= 25) {
        brake_magnitude = T4_BRAKE_TARGET_FAST;
      } else if (abs_delta_filt >= 10) {
        brake_magnitude = T4_BRAKE_TARGET_MID;
      } else {
        brake_magnitude = T4_BRAKE_TARGET_SLOW;
      }
    }
    if (active_task == 2U && bal_seq_phase == 1U &&
        bal_turn_brake_active != 0U &&
        abs_delta_filt >= T3_REQ3_RETURN_BRAKE_FAST_DELTA_CM100) {
      brake_magnitude = T3_REQ3_TURN_BRAKE_FAST_PULSES;
    }
    if (active_task == 2U && bal_seq_phase == 1U &&
        bal_turn_brake_active == 0U) {
      if (abs_delta_filt >= T3_REQ3_RETURN_BRAKE_FAST_DELTA_CM100) {
        brake_magnitude = T3_REQ3_RETURN_BRAKE_FAST_PULSES;
      } else if (abs_delta_filt >= 15) {
        brake_magnitude = T3_BRAKE_TARGET_MID;
      } else {
        brake_magnitude = T3_BRAKE_TARGET_SLOW;
      }
    }
    /* Req4使用独立实车极性，避免改变已验证的Req3制动方向。 */
    int32_t brake_polarity = (active_task == 0U)
                           ? T4_BRAKE_MOTOR_POLARITY
                           : T3_MOTOR_POLARITY;
    if (delta_filt > 0) {
      target_pulses = -brake_magnitude * brake_polarity;
    } else if (delta_filt < 0) {
      target_pulses =  brake_magnitude * brake_polarity;
    } else {
      target_pulses = 0;
    }
  }

  /* 注入渐进摩擦补偿 (救援模式下不叠加) */
  if (bal_center_hold == 0U && bal_recover_mode == 0U &&
      bal_stiction_boost > 0) {
    int32_t boost_cmd = (error_sign > 0) ? bal_stiction_boost
                                         : -bal_stiction_boost;
    target_pulses += boost_cmd * T3_MOTOR_POLARITY;
  }

  /* ── 分段倾角限幅 (救援>制动>普通) ── */
  int32_t target_limit;
  if (bal_recover_mode != 0U) {
    target_limit   = bal_tune_max_pulses;
    bal_step_limit = T3_RECOVER_STEP_PULSES;
  } else if (bal_brake_mode != 0U) {
    target_limit   = bal_tune_max_pulses;
    bal_step_limit = T3_BRAKE_STEP_PULSES;
  } else if (abs_error > T3_TILT_FAR_CM100) {
    target_limit = (active_task == 2U && bal_seq_phase == 0U && target_pulses < 0)
                 ? T3_REQ3_OUTBOUND_PULSES : T3_TILT_FAR_PULSES;
    bal_step_limit = (active_task == 2U && bal_seq_phase == 0U)
                   ? T3_REQ3_LAUNCH_STEP_PULSES : T3_MAX_STEP_PULSES;
  } else if (abs_error > T3_TILT_MID_CM100) {
    target_limit = T3_TILT_MID_PULSES;
    bal_step_limit = 2;       /* 原来1 */
  } else {
    target_limit = T3_TILT_NEAR_PULSES;
    bal_step_limit = 1;       /* 中心附近保持1，防止抖动 */
  }
  if (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) {
    bal_step_limit = T4_BAL_STEP_PULSES;
  }

  /* ── 中心/完成保持: 要求3完成或超时后永久回水平 ── */
  if ((active_task == 2U &&
       (bal_seq_done != 0U || bal_seq_failed != 0U)) ||
      bal_center_hold != 0U) {
    target_pulses = 0;
  }

  /* ── 倾角限幅 ── */
  if (target_pulses > target_limit)  target_pulses = target_limit;
  if (target_pulses < -target_limit) target_pulses = -target_limit;

  /* 机械水平补偿: POS=0时摆杆已3°, 加到限幅之前让PID能用到全范围 */
  target_pulses += T3_LEVEL_OFFSET_PULSES;

  /* 绝对总限幅 */
  if (target_pulses > bal_tune_max_pulses) target_pulses = bal_tune_max_pulses;
  {
    int32_t negative_limit = bal_tune_max_pulses;
    if (active_task == 2U && bal_seq_phase == 0U &&
        negative_limit < T3_REQ3_OUTBOUND_PULSES) {
      negative_limit = T3_REQ3_OUTBOUND_PULSES;
    }
    if (target_pulses < -negative_limit) target_pulses = -negative_limit;
  }

  /* ── 发布目标位置和步数上限 ── */
  bal_target_pos = target_pulses;
  bal_target_valid = 1U;

#if BAL_DEBUG
  {
    static uint32_t last_pid_dbg = 0;
    if ((now - last_pid_dbg) >= 100U) {
      last_pid_dbg = now;
      char pb[80];
      int pn = snprintf(pb, sizeof(pb),
                "PID: pos=%ld err=%ld out=%ld lim=%ld hold=%d\r\n",
                (long)pos_cm100, (long)error,
                (long)target_pulses, (long)target_limit,
                (int)bal_center_hold);
      if (pn > 0) HAL_UART_Transmit(&huart1, (uint8_t *)pb, (uint16_t)pn, 10U);
    }
  }
#endif
}

/* ── 调试串口输出 (USART1, PA9-TX, 115200) ── */
static char debug_buf[288];

/* 按当前任务装载串口调参默认值 (0=A→B, 1/2=FullLap, 3=Slow Walk) */
static void Tune_ApplyTaskDefaults(void)
{
  if (active_task == 0) {
    tune_kp    = T4_KP;
    tune_ki    = T4_KI;
    tune_kd    = T4_KD;
    tune_speed = T4_SPEED;
  } else if (TASK_IS_FULL_LAP_BALANCE(active_task)) {
    tune_kp    = T5_KP;
    tune_ki    = T5_KI;
    tune_kd    = T5_KD;
    tune_speed = T5_SPEED;
  } else {
    tune_kp    = T2_KP;
    tune_ki    = T2_KI;
    tune_kd    = T2_KD;
    tune_speed = T2_SPEED;
  }
  Line_FilterReset();
}

static void Tune_SendConfig(void)
{
  int n = snprintf(debug_buf, sizeof(debug_buf),
      "KP=%d KI=%d KD=%d SPD=%d\r\n",
      (int)tune_kp, (int)tune_ki, (int)tune_kd, (int)tune_speed);
  if (n > 0) {
    (void)HAL_UART_Transmit(&huart1, (uint8_t *)debug_buf,
                            (uint16_t)n, 10U);
  }
}

static void Balance_ApplySerialTuning(void)
{
  __disable_irq();
  PID_Set_Gains(&g_pid,
                (float)bal_tune_kp_x10 / 10.0f,
                (float)bal_tune_kd_x10 / 10.0f,
                bal_tune_max_pulses);
  g_pid.p.deadband = T3_PID_DEADBAND;
  __enable_irq();
}

static void Balance_SendSerialConfig(void)
{
  int n = snprintf(debug_buf, sizeof(debug_buf),
      "BKP=%d BKD=%d BMAX=%d\r\n",
      (int)bal_tune_kp_x10,
      (int)bal_tune_kd_x10,
      (int)bal_tune_max_pulses);
  if (n > 0) {
    (void)HAL_UART_Transmit(&huart1, (uint8_t *)debug_buf,
                            (uint16_t)n, 10U);
  }
}

static void Balance_SendTelemetry(uint32_t now)
{
  int32_t pos = 0;
  int32_t cmd;
  int32_t abs_pos;
  uint32_t start_tick;
  uint8_t phase;
  uint8_t done;
  uint8_t failed;
  int32_t velocity;
  uint32_t vision_dt_ms;
  uint8_t brake;
  uint8_t turn_brake;
  int cam_ok = MaixCam_PeekPosition(&pos) &&
               !MaixCam_IsTimeout(now) &&
               huart2.RxState == HAL_UART_STATE_BUSY_RX;

  __disable_irq();
  cmd = bal_target_pos;
  abs_pos = bal_abs_pos;
  start_tick = bal_seq_start_tick;
  phase = bal_seq_phase;
  done = bal_seq_done;
  failed = bal_seq_failed;
  velocity = bal_last_delta_filt;
  vision_dt_ms = bal_last_vision_dt_ms;
  brake = bal_brake_mode;
  turn_brake = bal_turn_brake_active;
  __enable_irq();

  int n = snprintf(debug_buf, sizeof(debug_buf),
      "BT:X=%ld,V=%ld,VDT=%lu,PH=%u,BR=%u,TB=%u,CMD=%ld,ABS=%ld,T=%lu,D=%u,F=%u,CAM=%u,RUN=%u,TASK=%u,LOOP=%u,RX=%lu,UE=%lu,EC=%lu,RS=%u\r\n",
      (long)pos, (long)velocity, (unsigned long)vision_dt_ms,
      (unsigned int)phase,
      (unsigned int)brake, (unsigned int)turn_brake,
      (long)cmd, (long)abs_pos,
      (unsigned long)(now - start_tick),
      (unsigned int)done, (unsigned int)failed,
      (unsigned int)(cam_ok != 0),
      (unsigned int)car_running, (unsigned int)active_task,
      (unsigned int)bal_main_loop_ready,
      (unsigned long)bal_uart2_rx_count,
      (unsigned long)bal_uart2_error_count,
      (unsigned long)bal_uart2_last_error,
      (unsigned int)huart2.RxState);
  if (n > 0) {
    (void)HAL_UART_Transmit(&huart1, (uint8_t *)debug_buf,
                            (uint16_t)n, 10U);
  }
}

/* Requirement 4 run state.  One call defines one complete A->B trial. */
static void Req4_ResetState(uint32_t now)
{
  __disable_irq();
  stop_state = 0U;
  stop_start_tick = now;
  stop_end_tick = 0U;
  enc_sum = 0;
  req4_max_abs_ball = 0;
  req4_ball_violation = 0U;
  req4_done = 0U;
  req4_failed = 0U;
  req4_fail_reason = 0U;
  req4_b_reached = 0U;
  req4_pass_tick = 0U;
  req4_abort_req = 0U;
  req5_start_line_frames = 0U;
  req5_vision_lost_tick = 0U;
  req4_line_dev = 0;
  req4_line_turn = 0;
  req4_line_speed = 0;
  req4_line_state = 0U;
  if (active_task != 4U) {
    bal_user_setpoint = 0;
  }
  __enable_irq();
}

static void Req4_MarkBPassed(uint32_t now)
{
  uint32_t time_limit = TASK_IS_FULL_LAP_BALANCE(active_task)
                      ? T5_TIMEOUT_MS : T4_STOP_TIMEOUT_MS;
  __disable_irq();
  if (req4_b_reached == 0U &&
      (now - stop_start_tick) <= time_limit) {
    req4_b_reached = 1U;
    req4_pass_tick = now;
    if (req4_failed == 0U && req4_ball_violation == 0U) {
      req4_done = 1U;
    }
  }
  __enable_irq();
}

static void Req4_SetTerminal(uint32_t now, uint8_t fail_reason)
{
  __disable_irq();
  if (stop_state != 2U) {
    stop_state = 2U;
    stop_end_tick = now;
    if (fail_reason != 0U) {
      req4_failed = 1U;
      req4_fail_reason |= fail_reason;
    }
  }
  __enable_irq();
}

/* Unified VOFA telemetry for line tracking, ball balance and scoring. */
static void Req4_SendTelemetry(uint32_t now)
{
  int32_t pos = 0;
  int32_t max_abs;
  int32_t enc;
  int32_t velocity;
  int32_t cmd;
  int32_t abs_pos;
  uint32_t vision_dt_ms;
  uint32_t start_tick;
  uint32_t end_tick;
  uint32_t pass_tick;
  uint32_t elapsed;
  uint8_t stopped;
  uint8_t done;
  uint8_t failed;
  uint8_t reason;
  uint8_t running;
  uint8_t b_reached;
  int16_t dev;
  int16_t turn;
  int16_t speed;
  uint8_t line_state;
  uint8_t center_hold;
  uint8_t brake;
  int cam_ok = MaixCam_PeekPosition(&pos) &&
               !MaixCam_IsTimeout(now) &&
               huart2.RxState == HAL_UART_STATE_BUSY_RX;

  __disable_irq();
  max_abs = req4_max_abs_ball;
  enc = enc_sum;
  velocity = bal_last_delta_filt;
  cmd = bal_target_pos;
  abs_pos = bal_abs_pos;
  vision_dt_ms = bal_last_vision_dt_ms;
  start_tick = stop_start_tick;
  end_tick = stop_end_tick;
  pass_tick = req4_pass_tick;
  stopped = stop_state;
  done = req4_done;
  failed = req4_failed;
  reason = req4_fail_reason;
  running = car_running;
  b_reached = req4_b_reached;
  dev = req4_line_dev;
  turn = req4_line_turn;
  speed = req4_line_speed;
  line_state = req4_line_state;
  center_hold = bal_center_hold;
  brake = bal_brake_mode;
  __enable_irq();

  if (stopped == 0U && running == 0U) {
    elapsed = 0U;
  } else {
    elapsed = ((stopped == 2U) ? end_tick : now) - start_tick;
  }
  {
    const char *prefix = (active_task == 4U) ? "R6" :
                         (active_task == 3U) ? "R5" : "R4";
    const char *endpoint = TASK_IS_FULL_LAP_BALANCE(active_task) ? "A" : "B";
    int n = snprintf(debug_buf, sizeof(debug_buf),
        "%s:X=%ld,V=%ld,VDT=%lu,MAXX=%ld,CMD=%ld,ABS=%ld,H=%u,BR=%u,DEV=%d,TURN=%d,SPD=%d,LS=%u,ENC=%ld,EL=%d,ER=%d,T=%lu,%s=%u,PT=%lu,STOP=%u,D=%u,F=%u,R=%u,CAM=%u,RUN=%u,RX=%lu,UE=%lu\r\n",
        prefix,
        (long)pos, (long)velocity, (unsigned long)vision_dt_ms,
        (long)max_abs, (long)cmd, (long)abs_pos,
        (unsigned int)center_hold, (unsigned int)brake,
        (int)dev, (int)turn, (int)speed,
        (unsigned int)line_state, (long)enc,
        (int)line_enc_l, (int)line_enc_r, (unsigned long)elapsed,
        endpoint, (unsigned int)b_reached,
        (unsigned long)(b_reached != 0U ? pass_tick - start_tick : 0U),
        (unsigned int)stopped, (unsigned int)done, (unsigned int)failed,
        (unsigned int)reason, (unsigned int)(cam_ok != 0),
        (unsigned int)running, (unsigned long)bal_uart2_rx_count,
        (unsigned long)bal_uart2_error_count);
    if (n > 0 && n < (int)sizeof(debug_buf)) {
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)debug_buf,
                              (uint16_t)n, 25U);
    }
  }
}

static int16_t Tune_Clamp(int value, int minimum, int maximum)
{
  if (value < minimum) {
    return (int16_t)minimum;
  }
  if (value > maximum) {
    return (int16_t)maximum;
  }
  return (int16_t)value;
}

static void Tune_ProcessCommand(void)
{
  char command[40];
  int value;
  uint8_t length;

  if (tune_cmd_ready == 0U) {
    return;
  }
  __disable_irq();
  length = tune_rx_len;
  if (length >= sizeof(command)) {
    length = sizeof(command) - 1U;
  }
  memcpy(command, tune_rx_buf, length);
  command[length] = '\0';
  tune_rx_len = 0U;
  tune_cmd_ready = 0U;
  __enable_irq();

  if (strcmp(command, "R4START") == 0) {
    uint32_t start_now = HAL_GetTick();
    uint8_t switching_task = (active_task != 0U) ? 1U : 0U;
    if (car_running != 0U && active_task != 0U) {
      static const uint8_t deny[] = "R4START DENY\r\n";
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)deny,
                              (uint16_t)(sizeof(deny) - 1U), 10U);
      return;
    }
    if (car_running != 0U && active_task == 0U && stop_state != 2U) {
      static const uint8_t busy[] = "R4START BUSY\r\n";
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)busy,
                              (uint16_t)(sizeof(busy) - 1U), 10U);
      return;
    }
    active_task = 0U;
    menu_sel = 0U;
    if (switching_task != 0U) {
      Tune_ApplyTaskDefaults();
    }
    car_running = 1U;
    bal_remote_start_guard_until = start_now + 500U;
    if (bal_main_loop_ready != 0U) {
      req4_runtime_start_pending = 1U;
    } else {
      bal_remote_start_pending = 1U;
    }
    {
      static const uint8_t ok[] = "R4START OK\r\n";
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)ok,
                              (uint16_t)(sizeof(ok) - 1U), 10U);
    }
    return;
  }
  if (strcmp(command, "R4STOP") == 0) {
    uint32_t stop_now = HAL_GetTick();
    if (active_task == 0U) {
      if (stop_state != 2U) {
        Req4_SetTerminal(stop_now,
            req4_b_reached != 0U ? 0U : T4_FAIL_MANUAL);
      }
      req4_abort_req = 0U;
      Motor_Stop();
      Balance_Stop();
      car_running = 0U;
      menu_sel = 0U;
      (void)Balance_ArmVisionOnly();
    }
    {
      static const uint8_t ok[] = "R4STOP OK\r\n";
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)ok,
                              (uint16_t)(sizeof(ok) - 1U), 10U);
    }
    return;
  }
  if (strcmp(command, "R4STATE") == 0) {
    Req4_SendTelemetry(HAL_GetTick());
    return;
  }
  if (strcmp(command, "R5START") == 0) {
    uint32_t start_now = HAL_GetTick();
    uint8_t switching_task = (active_task != 3U) ? 1U : 0U;
    if (car_running != 0U && active_task != 3U) {
      static const uint8_t deny[] = "R5START DENY\r\n";
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)deny,
                              (uint16_t)(sizeof(deny) - 1U), 10U);
      return;
    }
    if (car_running != 0U && active_task == 3U && stop_state != 2U) {
      static const uint8_t busy[] = "R5START BUSY\r\n";
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)busy,
                              (uint16_t)(sizeof(busy) - 1U), 10U);
      return;
    }
    active_task = 3U;
    menu_sel = 3U;
    if (switching_task != 0U) {
      Tune_ApplyTaskDefaults();
    }
    car_running = 1U;
    bal_remote_start_guard_until = start_now + 500U;
    if (bal_main_loop_ready != 0U) {
      req5_runtime_start_pending = 1U;
    } else {
      bal_remote_start_pending = 1U;
    }
    {
      static const uint8_t ok[] = "R5START OK\r\n";
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)ok,
                              (uint16_t)(sizeof(ok) - 1U), 10U);
    }
    return;
  }
  if (strcmp(command, "R5STOP") == 0) {
    uint32_t stop_now = HAL_GetTick();
    if (active_task == 3U) {
      if (stop_state != 2U) {
        Req4_SetTerminal(stop_now,
            req4_b_reached != 0U ? 0U : T4_FAIL_MANUAL);
      }
      req4_abort_req = 0U;
      Motor_Stop();
      Balance_Stop();
      car_running = 0U;
      menu_sel = 3U;
      (void)Balance_ArmVisionOnly();
    }
    {
      static const uint8_t ok[] = "R5STOP OK\r\n";
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)ok,
                              (uint16_t)(sizeof(ok) - 1U), 10U);
    }
    return;
  }
  if (strcmp(command, "R5STATE") == 0) {
    Req4_SendTelemetry(HAL_GetTick());
    return;
  }
  if (strcmp(command, "BSTART") == 0) {
    uint32_t start_now;
    if (car_running != 0U && active_task != 2U) {
      (void)HAL_UART_Transmit(&huart1, (uint8_t *)"BSTART DENY\r\n", 13U, 10U);
      return;
    }
    if (bal_main_loop_ready != 0U && car_running != 0U) {
      Balance_Stop();
    }
    active_task = 2U;
    menu_sel = 2U;
    car_running = 1U;
    stop_state = 0U;
    start_now = HAL_GetTick();
    bal_remote_start_guard_until = start_now + 500U;
    if (bal_main_loop_ready != 0U) {
      Balance_Start(start_now);
    } else {
      bal_remote_start_pending = 1U;
    }
    (void)HAL_UART_Transmit(&huart1, (uint8_t *)"BSTART OK\r\n", 11U, 10U);
    return;
  }
  if (strcmp(command, "BSTOP") == 0) {
    if (car_running != 0U && active_task == 2U) {
      Balance_Stop();
      car_running = 0U;
      stop_state = 0U;
      menu_sel = 2U;
    }
    if (active_task == 2U) {
      (void)Balance_ArmVisionOnly();
    }
    (void)HAL_UART_Transmit(&huart1, (uint8_t *)"BSTOP OK\r\n", 10U, 10U);
    return;
  }
  if (strcmp(command, "TOG") == 0) {
    if (car_running != 0U) {
      if ((active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) &&
          stop_state != 2U) {
        Req4_SetTerminal(HAL_GetTick(),
            req4_b_reached != 0U ? 0U : T4_FAIL_MANUAL);
      }
      if (TASK_USES_BALANCE(active_task)) {
        Balance_Stop();
      }
      if (active_task != 2) {
        Motor_Stop();
      }
      car_running = 0U;
    }
    /* 注意: TOG 只停车不启动，避免绕过统一任务入口 */
    Line_FilterReset();
    Tune_SendConfig();
    return;
  }
  if (strcmp(command, "SHOW") == 0) {
    Tune_SendConfig();
    return;
  }
  if (strcmp(command, "BSHOW") == 0) {
    Balance_SendSerialConfig();
    return;
  }
  if (strcmp(command, "BSTATE") == 0) {
    Balance_SendTelemetry(HAL_GetTick());
    return;
  }
  if (strcmp(command, "RESET") == 0) {
    Tune_ApplyTaskDefaults();  /* 恢复当前任务默认 */
    Tune_SendConfig();
    return;
  }

  value = atoi(strchr(command, '=') != NULL ?
               strchr(command, '=') + 1 : "0");
  if (strncmp(command, "BKP=", 4U) == 0) {
    bal_tune_kp_x10 = Tune_Clamp(value, 10, 300);
    Balance_ApplySerialTuning();
    Balance_SendSerialConfig();
    return;
  } else if (strncmp(command, "BKD=", 4U) == 0) {
    bal_tune_kd_x10 = Tune_Clamp(value, 0, 150);
    Balance_ApplySerialTuning();
    Balance_SendSerialConfig();
    return;
  } else if (strncmp(command, "BMAX=", 5U) == 0) {
    bal_tune_max_pulses = Tune_Clamp(value, 20, T3_MAX_OFFSET_PULSES);
    Balance_ApplySerialTuning();
    Balance_SendSerialConfig();
    return;
  } else if (strncmp(command, "KP=", 3U) == 0) {
    tune_kp = Tune_Clamp(value, 1, 30);
  } else if (strncmp(command, "KI=", 3U) == 0) {
    tune_ki = Tune_Clamp(value, 0, 50);
  } else if (strncmp(command, "KD=", 3U) == 0) {
    tune_kd = Tune_Clamp(value, 0, 15);
  } else if (strncmp(command, "SPD=", 4U) == 0) {
    tune_speed = Tune_Clamp(value, 2, 60);
  } else if (strncmp(command, "CAL", 3U) == 0) {
    /* 标定模式: CAL=1冻结PID, 然后用POS=N手动调位置 */
    if (value) {
      cal_active = 1U;
      cal_target = 0;
      Balance_Start(HAL_GetTick());
      HAL_UART_Transmit(&huart1, (uint8_t *)"CAL ON\r\n", 8, 10U);
    } else {
      cal_active = 0U;
      Balance_Stop();
      HAL_UART_Transmit(&huart1, (uint8_t *)"CAL OFF\r\n", 9, 10U);
    }
    return;
  } else if (strncmp(command, "POS=", 4U) == 0 && cal_active) {
    cal_target = Tune_Clamp(value, -95, 95);
    int n2 = snprintf(debug_buf, sizeof(debug_buf), "OK POS=%ld\r\n", (long)cal_target);
    if (n2 > 0) HAL_UART_Transmit(&huart1, (uint8_t *)debug_buf, (uint16_t)n2, 10U);
    return;
  } else {
    return;
  }
  Line_FilterReset();
  Tune_SendConfig();
}

static void Debug_Send(int16_t dev, int16_t turn, int16_t spd, uint8_t state)
{
  int n;
  float gz = 0.0f;
  uint32_t gt = 0U;
  uint8_t gok = JY901S_GetGyroZ(&gz, &gt);

  if (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) {
    req4_line_dev = dev;
    req4_line_turn = turn;
    req4_line_speed = spd;
    req4_line_state = state;
    Req4_SendTelemetry(HAL_GetTick());
    return;
  }

  n = snprintf(debug_buf, sizeof(debug_buf),
    "D% d T% d V% d E% d,% d G% d.%d S%u\r\n",
    (int)dev, (int)turn, (int)spd,
    (int)line_enc_l, (int)line_enc_r,
    (int)gz, (int)((gz-(int)gz)*10.0f+0.5f), (unsigned int)gok);
  if (n > 0 && n < (int)sizeof(debug_buf)) {
    HAL_UART_Transmit(&huart1, (uint8_t *)debug_buf, (uint16_t)n, 10U);
  }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  MX_USART6_UART_Init();
  /* USER CODE BEGIN 2 */
  /* USART3 仅用于步进电机 TX, 关掉 NVIC 中断避免干扰 */
  HAL_NVIC_DisableIRQ(USART3_IRQn);
  Soft_I2C_Init();
  OLED_Init();
  OLED_ShowString(0U, 0U, "Balance Ball Car");
  OLED_ShowString(0U, 16U, "Init AT8236...");
  OLED_Refresh();

  Motor_Init();            /* AT8236: PWM + 编码器, 无返回值 */
  Motor_Stop();

  /* 编码器验证: 电机停着读一次确认通 */
  {
    int16_t te1, te2;
    Motor_ReadEncoders(&te1, &te2);
    char tb[32];
    int tn = snprintf(tb, sizeof(tb), "ENC:%d,%d\n", (int)te1, (int)te2);
    if (tn > 0) HAL_UART_Transmit(&huart1, (uint8_t *)tb, (uint16_t)tn, 100U);
  }

  OLED_Clear();
  OLED_ShowString(0U, 0U, "Init track I2C...");
  OLED_Refresh();
  Track_I2C_Init();
  JY901S_Init();

  /* 摆球定时器只初始化一次，进入任务时只启动和停止 */
  MX_TIM5_Balance_Init();

  /* Keep visual UART RX alive in the menu so Req6 touch targets and live
   * coordinates are available even before a balance task starts. */
  if (Balance_ArmVisionOnly() != HAL_OK) {
    Error_Handler();
  }
  /* Synchronise the MaixCAM stream state after either board is reset. */
  Req6_SetTouchSelection(0U);

  HAL_NVIC_SetPriority(USART1_IRQn, 2U, 0U);
  HAL_NVIC_EnableIRQ(USART1_IRQn);
  (void)HAL_UART_Receive_IT(&huart1, &tune_rx_byte, 1U);

  /* ── 启动菜单: KEY1选择, KEY2录像, KEY3确认 ── */
  while (1) {
    if (Key1_Pressed() != 0U || Key2_Pressed() != 0U) {
      menu_sel = (menu_sel + 1U) % MENU_TOTAL;
    }
    if (Key3_Pressed() != 0U) {
      if (menu_sel == 4) {
        /* Req6: 选目标位置, KEY1/2调, KEY3确认 */
        uint8_t req6_start = 0U;
        active_task = 4U;
        Req6_SetTouchSelection(1U);
        while (1) {
          int32_t setp = bal_user_setpoint;
          OLED_Clear();
          OLED_Printf(0U, 0U, "R6 TOUCH TARGET");
          OLED_Printf(0U, 16U, "%c%ld.%02ld cm",
            setp < 0 ? '-' : ' ', (long)(setp<0?-setp:setp)/100, (long)(setp<0?-setp:setp)%100);
          OLED_ShowString(0U, 34U, "Touch groove point");
          OLED_ShowString(0U, 50U, "K3:START");
          OLED_Refresh();
          if (Key3_Pressed()) {
            req6_start = 1U;
            break;
          }
          if (Key1_Pressed() != 0U || Key2_Pressed() != 0U) {
            menu_sel = (menu_sel + 1U) % MENU_TOTAL;
            break;
          }
          HAL_Delay(40U);
        }
        Req6_SetTouchSelection(0U);
        if (req6_start == 0U) {
          continue;
        }
        Tune_ApplyTaskDefaults();
        break;
      } else if (menu_sel == 5) {
        /* 标定模式: KEY1/2调位置, KEY3退出 */
        Balance_Start(HAL_GetTick());
        int32_t cal_pos = 0;
        while (1) {
          if (Key1_Pressed()) { cal_pos -= 10; if (cal_pos < -200) cal_pos = -200; }
          if (Key2_Pressed()) { cal_pos += 10; if (cal_pos >  200) cal_pos =  200; }
          int32_t step = cal_pos - bal_abs_pos;
          if (step > 3) step = 3; if (step < -3) step = -3;
          if (step != 0) {
            if (Emm_V5_Move_Relative(step, 20, 20) == HAL_OK) bal_abs_pos += step;
          }
          OLED_Clear();
          OLED_Printf(0U, 0U, "CAL: POS=%ld", (long)cal_pos);
          OLED_Printf(0U, 16U, "ABS=%ld", (long)bal_abs_pos);
          OLED_ShowString(0U, 36U, "K1:-10 K2:+10");
          OLED_ShowString(0U, 50U, "K3:exit");
          OLED_Refresh();
          if (Key3_Pressed()) break;
          HAL_Delay(30U);
        }
        Balance_Stop();
      } else {
        active_task = menu_sel;
        Tune_ApplyTaskDefaults();
        break;
      }
    }
    OLED_Clear();
    OLED_Printf(0U, 0U, "%s1.A-B(Req4)",
                menu_sel == 0 ? ">" : " ");
    OLED_Printf(0U, 10U, "%s2.Lap(Req2)",
                menu_sel == 1 ? ">" : " ");
    OLED_Printf(0U, 20U, "%s3.Bal(Req3)",
                menu_sel == 2 ? ">" : " ");
    OLED_Printf(0U, 30U, "%s4.LapBall(R5)",
                menu_sel == 3 ? ">" : " ");
    OLED_Printf(0U, 40U, "%s5.Pos(Req6)",
                menu_sel == 4 ? ">" : " ");
    OLED_Printf(0U, 50U, "%s6.Calib",
                menu_sel == 5 ? ">" : " ");
    OLED_ShowString(0U, 56U, "K1/2 SEL K3:GO");
    OLED_Refresh();
    Tune_ProcessCommand();
    if (bal_remote_start_pending != 0U) {
      bal_remote_start_pending = 0U;
      break;
    }
    HAL_Delay(50U);
  }
  Line_FilterReset();
  stop_state = 0;
  stop_start_tick = HAL_GetTick();
  enc_sum = 0;
  if (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) {
    Req4_ResetState(stop_start_tick);
  }
  Velocity_SetForwardSlew(active_task == 0U ? T4_FORWARD_SLEW_Q8 :
                          TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_FORWARD_SLEW_Q8 : 0U);
  Velocity_SetTurnSlew(active_task == 0U ? T4_TURN_SLEW_Q8 :
                       TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_TURN_SLEW_Q8 : 0U);
  Velocity_Reset();
  car_running = 1U;

  /* ── 摆球平衡初始化 (task 0/2/3) ── */
  if (TASK_USES_BALANCE(active_task)) {
    Balance_Start(HAL_GetTick());

    OLED_Clear();
    OLED_ShowString(0U, 0U,
      active_task == 2 ? "Ball Balance Go" :
      active_task == 0 ? "A->B + Ball" :
      active_task == 4 ? "Req6 Target Lap" : "Full Lap + Ball");
    OLED_Refresh();
  }
  bal_main_loop_ready = 1U;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    Tune_ProcessCommand();

    /* ── 标定模式: 冻结PID, 手动调电机 (不受car_running限制) ── */
    if (cal_active) {
      uint32_t cal_now = HAL_GetTick();
      int32_t step = cal_target - bal_abs_pos;
      if (step > 3) step = 3;
      if (step < -3) step = -3;
      if (step != 0 && (cal_now - bal_last_tx_tick) >= 20U) {
        if (Emm_V5_Move_Relative(step, 20, 20) == HAL_OK) {
          bal_abs_pos += step;
          bal_last_tx_tick = cal_now;
        }
      }
    }

    static uint32_t last_display  = 0U;
    static uint32_t last_bal_telemetry = 0U;
    static uint32_t last_control  = 0U;
    static uint32_t last_line_tick = 0U;
    static int16_t  deviation     = 0;
    static int16_t  turn_output   = 0;
    static int16_t  command_speed = 0;
    static uint8_t  motor_active  = 0U;
    static uint8_t  line_state    = 0U;
    static uint16_t i2c_err_cnt   = 0U;
    static uint8_t  i2c_addr      = 0x10;
    static uint8_t  i2c_found     = 0x12U;  /* I2C地址已确认 */
    uint32_t now      = HAL_GetTick();
    uint32_t frame_tick;
    static uint32_t frame_count = 0U;
    uint8_t  raw;
    uint8_t  have_frame;
    uint8_t  black_cnt;
    uint8_t  edge_detected;
    int16_t  dev;

    if (req4_runtime_start_pending != 0U) {
      req4_runtime_start_pending = 0U;
      Motor_Stop();
      Balance_Stop();
      active_task = 0U;
      menu_sel = 0U;
      Line_FilterReset();
      deviation = 0;
      turn_output = 0;
      command_speed = 0;
      motor_active = 0U;
      line_state = 0U;
      last_line_tick = 0U;
      i2c_err_cnt = 0U;
      Req4_ResetState(now);
      Velocity_SetForwardSlew(T4_FORWARD_SLEW_Q8);
      Velocity_SetTurnSlew(T4_TURN_SLEW_Q8);
      Velocity_Reset();
      car_running = 1U;
      Balance_Start(now);
      Track_I2C_Init();
    }

    if (req5_runtime_start_pending != 0U) {
      req5_runtime_start_pending = 0U;
      Motor_Stop();
      Balance_Stop();
      active_task = 3U;
      menu_sel = 3U;
      Line_FilterReset();
      deviation = 0;
      turn_output = 0;
      command_speed = 0;
      motor_active = 0U;
      line_state = 0U;
      last_line_tick = 0U;
      i2c_err_cnt = 0U;
      Req4_ResetState(now);
      Velocity_SetForwardSlew(T5_FORWARD_SLEW_Q8);
      Velocity_SetTurnSlew(T5_TURN_SLEW_Q8);
      Velocity_Reset();
      car_running = 1U;
      Balance_Start(now);
      Track_I2C_Init();
    }

    /* ── 菜单模式 ── */
    if (car_running == 0U) {
      if (huart2.RxState != HAL_UART_STATE_BUSY_RX) {
        (void)Balance_ArmVisionOnly();
      }

      if (req6_touch_selecting != 0U) {
        if (Key1_Pressed() != 0U || Key2_Pressed() != 0U) {
          Req6_SetTouchSelection(0U);
          menu_sel = (menu_sel + 1U) % MENU_TOTAL;
          stop_state = 0U;
        } else if ((int32_t)(now - bal_remote_start_guard_until) >= 0 &&
            Key3_Pressed() != 0U) {
          Req6_SetTouchSelection(0U);
          active_task = 4U;
          menu_sel = 4U;
          Tune_ApplyTaskDefaults();
          Req4_ResetState(now);
          Balance_Start(now);
          Track_I2C_Init();
          Line_FilterReset();
          deviation = 0;
          turn_output = 0;
          command_speed = 0;
          motor_active = 0U;
          line_state = 0U;
          Velocity_SetForwardSlew(T5_FORWARD_SLEW_Q8);
          Velocity_SetTurnSlew(T5_TURN_SLEW_Q8);
          Velocity_Reset();
          car_running = 1U;
        } else if ((now - last_display) >= LINE_DISPLAY_MS) {
          int32_t setp = bal_user_setpoint;
          last_display = now;
          OLED_Clear();
          OLED_ShowString(0U, 0U, "R6 TOUCH TARGET");
          OLED_Printf(0U, 16U, "%c%ld.%02ld cm",
                      setp < 0 ? '-' : ' ',
                      (long)(setp < 0 ? -setp : setp) / 100,
                      (long)(setp < 0 ? -setp : setp) % 100);
          OLED_ShowString(0U, 34U, "Touch groove point");
          OLED_ShowString(0U, 50U, "K3:START");
          OLED_Refresh();
        }
        Tune_ProcessCommand();
        HAL_Delay(10U);
        continue;
      }

      if (Key1_Pressed() != 0U || Key2_Pressed() != 0U) {
        menu_sel = (menu_sel + 1U) % MENU_TOTAL;
      }
      if ((int32_t)(now - bal_remote_start_guard_until) >= 0 &&
          Key3_Pressed() != 0U) {
        if (menu_sel == 4) {
          /* Req6: OLED选目标位置 */
          active_task = 4U;
          Tune_ApplyTaskDefaults();
          Req6_SetTouchSelection(1U);
        } else if (menu_sel == 5) {
          /* 标定模式 */
          Balance_Start(now);
          int32_t cal_pos = 0;
          while (1) {
            if (Key1_Pressed()) { cal_pos -= 10; if (cal_pos < -200) cal_pos = -200; }
            if (Key2_Pressed()) { cal_pos += 10; if (cal_pos >  200) cal_pos =  200; }
            int32_t step = cal_pos - bal_abs_pos;
            if (step > 3) step = 3; if (step < -3) step = -3;
            if (step != 0) {
              if (Emm_V5_Move_Relative(step, 20, 20) == HAL_OK) bal_abs_pos += step;
            }
            OLED_Clear();
            OLED_Printf(0U, 0U, "CAL: POS=%ld", (long)cal_pos);
            OLED_Printf(0U, 16U, "ABS=%ld", (long)bal_abs_pos);
            OLED_ShowString(0U, 36U, "K1:-10 K2:+10");
            OLED_ShowString(0U, 50U, "K3:exit");
            OLED_Refresh();
            if (Key3_Pressed()) break;
            HAL_Delay(30U);
          }
          Balance_Stop();
        } else {
          active_task = menu_sel;
          Tune_ApplyTaskDefaults();
          Line_FilterReset();
          deviation = 0;
          turn_output = 0;
          command_speed = 0;
          stop_state = 0;
          stop_start_tick = now;
          enc_sum = 0;
          if (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) {
            Req4_ResetState(now);
          }
          Velocity_SetForwardSlew(active_task == 0U ? T4_FORWARD_SLEW_Q8 :
                                  TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_FORWARD_SLEW_Q8 : 0U);
          Velocity_SetTurnSlew(active_task == 0U ? T4_TURN_SLEW_Q8 :
                               TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_TURN_SLEW_Q8 : 0U);
          Velocity_Reset();
          car_running = 1U;
          if (TASK_USES_BALANCE(active_task)) {
            Balance_Start(now);
          }
          if (active_task != 2) {
            Track_I2C_Init();
          }
        }
      }
      if ((now - last_display) >= LINE_DISPLAY_MS) {
        last_display = now;
        OLED_Clear();
        OLED_Printf(0U, 0U, "%s1.A-B(Req4)",
                    menu_sel == 0 ? ">" : " ");
        OLED_Printf(0U, 10U, "%s2.Lap(Req2)",
                    menu_sel == 1 ? ">" : " ");
        OLED_Printf(0U, 20U, "%s3.Bal(Req3)",
                    menu_sel == 2 ? ">" : " ");
        OLED_Printf(0U, 30U, "%s4.LapBall(R5)",
                    menu_sel == 3 ? ">" : " ");
        OLED_Printf(0U, 40U, "%s5.Pos(Req6)",
                    menu_sel == 4 ? ">" : " ");
        OLED_Printf(0U, 50U, "%s6.Calib",
                    menu_sel == 5 ? ">" : " ");
        OLED_ShowString(0U, 56U, "K1/2 SEL K3:GO");
        OLED_Refresh();
      }
      Tune_ProcessCommand();
      HAL_Delay(10U);
      continue;
    }

    /* ── 步进电机命令发送 (Req3/4/5/6 共用) ── */
    if (TASK_USES_BALANCE(active_task)) {
      /* 电机急停请求 */
      if (bal_stop_req) {
        bal_stop_req = 0;
        bal_target_valid = 0;
        bal_motor_cmd = 0;
        bal_cmd_new = 0;
        Emm_V5_Stop(EMM_ADDR, SYNC_OFF);
      }
      /* 电机命令发送 */
      else if (bal_target_valid != 0U) {
        int32_t  target, current, step, limit;
        uint8_t  brake_mode, recover_mode;
        uint32_t tx_interval;
        uint16_t motor_speed;
        uint8_t  motor_acc;

        __disable_irq();
        target       = bal_target_pos;
        current      = bal_abs_pos;
        limit        = bal_step_limit;
        brake_mode   = bal_brake_mode;
        recover_mode = bal_recover_mode;
        __enable_irq();

        if (recover_mode != 0U) {
          tx_interval = T3_RECOVER_TX_INTERVAL_MS;
          motor_speed = T3_RECOVER_MOTOR_SPEED;
          motor_acc   = T3_RECOVER_MOTOR_ACC;
          limit       = T3_RECOVER_STEP_PULSES;
        } else if (brake_mode != 0U) {
          tx_interval = T3_BRAKE_TX_INTERVAL_MS;
          motor_speed = T3_BRAKE_MOTOR_SPEED;
          motor_acc   = T3_BRAKE_MOTOR_ACC;
          limit       = T3_BRAKE_STEP_PULSES;
        } else {
          tx_interval = T3_MOTOR_TX_INTERVAL_MS;
          motor_speed = T3_MOTOR_SPEED;
          motor_acc   = T3_MOTOR_ACC;
          if (active_task == 2U && bal_seq_phase == 0U) {
            tx_interval = T3_REQ3_LAUNCH_TX_INTERVAL_MS;
          }
          if (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) {
            tx_interval = T4_BAL_TX_INTERVAL_MS;
            motor_speed = T4_BAL_MOTOR_SPEED;
            motor_acc   = T4_BAL_MOTOR_ACC;
            limit       = T4_BAL_STEP_PULSES;
          }
        }

        if ((now - bal_last_tx_tick) >= tx_interval) {
          step = target - current;

          if (step > limit)   step = limit;
          if (step < -limit)  step = -limit;

          if (step > -T3_MIN_STEP_PULSES && step < T3_MIN_STEP_PULSES) {
            step = 0;
          }

          if (step != 0) {
            HAL_StatusTypeDef tx_ret;
            tx_ret = Emm_V5_Move_Relative(step, motor_speed, motor_acc);
            if (tx_ret == HAL_OK) {
              __disable_irq();
              bal_abs_pos += step;
              __enable_irq();
              bal_last_tx_tick = now;
            } else {
              Emm_V5_Stop(EMM_ADDR, SYNC_OFF);
            }
          }
        }
      }
    }

    /* ── 任务3: 摆球平衡 (独立于循迹) ── */
    if (active_task == 2) {
      if (Key3_Pressed() != 0U) {
        Balance_Stop();

        car_running = 0U;
        stop_state = 0;
        menu_sel = active_task;
        continue;
      }

      /* 无视觉数据时ISR不会运行，主循环仍必须执行5秒超时判定。 */
      if (!bal_seq_done && !bal_seq_failed &&
          now - bal_seq_start_tick >= T3_TIMEOUT_MS) {
        bal_seq_failed = 1U;
        bal_seq_phase = 2U;
        bal_seq_confirm_frames = 0U;
        g_pid.setpoint = -T3_REQ3_TARGET_CM100;
      }

      /* OLED in task 3 */
      if ((now - last_display) >= LINE_DISPLAY_MS) {
        int32_t pos = 0;
        int valid = MaixCam_PeekPosition(&pos);
        last_display = now;
        OLED_Clear();
        OLED_Printf(0U, 0U, "BALL X:%c%ld.%02ldcm",
                    pos < 0 ? '-' : ' ',
                    (long)(pos >= 0 ? pos/100 : -pos/100),
                    (long)(pos >= 0 ? pos%100 : -pos%100));
        OLED_Printf(0U, 14U, "CMD:%ld ABS:%ld",
                    (long)bal_target_pos, (long)bal_abs_pos);
        if (bal_seq_failed) {
          OLED_ShowString(0U, 28U, "TIMEOUT K3:menu");
        } else if (bal_seq_done) {
          uint32_t used_ms = bal_seq_done_tick - bal_seq_start_tick;
          OLED_Printf(0U, 28U, "DONE %lu.%lus K3",
                      (unsigned long)(used_ms / 1000U),
                      (unsigned long)((used_ms % 1000U) / 100U));
        } else {
          OLED_Printf(0U, 28U, "TO:%s T:%lu.%lus",
                      bal_seq_phase == 0U ? "+5" : "-5",
                      (unsigned long)((now - bal_seq_start_tick) / 1000U),
                      (unsigned long)(((now - bal_seq_start_tick) % 1000U) / 100U));
        }
        OLED_Printf(0U, 42U, "CAM:%s",
                    valid ? "OK" : "--");
        OLED_Refresh();
      }

      if ((now - last_bal_telemetry) >= 200U) {
        last_bal_telemetry = now;
        Balance_SendTelemetry(now);
      }

      HAL_Delay(5U);
      continue;
    }

    JY901S_Service();

    if ((active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) &&
        req4_abort_req != 0U && stop_state != 2U) {
      req4_abort_req = 0U;
      Req4_SetTerminal(now, 0U);
      Motor_Stop();
      motor_active = 0U;
      Balance_Stop();
    }

    /* Requirement 4 terminal checks must run even when the line is lost. */
    if ((active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) &&
        car_running != 0U && stop_state == 0U) {
      uint32_t task_timeout = TASK_IS_FULL_LAP_BALANCE(active_task)
                            ? T5_TIMEOUT_MS : T4_STOP_TIMEOUT_MS;
      if (active_task == 0U && req4_b_reached == 0U &&
          enc_sum >= T4_STOP_ENC &&
          (now - stop_start_tick) <= task_timeout) {
        Req4_MarkBPassed(now);
      } else if (TASK_IS_FULL_LAP_BALANCE(active_task) &&
                 req4_b_reached == 0U &&
                 enc_sum >= T5_LAP_ENC &&
                 (now - stop_start_tick) <= task_timeout) {
        Req4_MarkBPassed(now);
        /* 要求5整圈完成即为项目结束：进入统一停车/平台回正路径。 */
        Req4_SetTerminal(now, 0U);
        Motor_Stop();
        motor_active = 0U;
      } else if (req4_b_reached == 0U &&
                 (now - stop_start_tick) > task_timeout) {
        Req4_SetTerminal(now, T4_FAIL_TIMEOUT);
        Motor_Stop();
        motor_active = 0U;
      }
    }

    /* 任意模式只要进入终止状态，就将摆球平台回到软件零位并停止。 */
    if (stop_state == 2U && bal_platform_centered == 0U) {
      Balance_Stop();
    }

    /* Req6 completion returns the platform to mechanical zero, then stays in
     * Req6 touch-selection mode so another target can be tapped immediately. */
    if (active_task == 4U && stop_state == 2U &&
        bal_platform_centered != 0U && car_running != 0U) {
      Motor_Stop();
      motor_active = 0U;
      Req6_ResetTargetAndSelect();
      continue;
    }

    /* KEY3 启停: 运行中按→停车回菜单 */
    if (Key3_Pressed() != 0U) {
      if (active_task == 0 || TASK_IS_FULL_LAP_BALANCE(active_task)) {
        if ((active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) &&
            stop_state != 2U) {
          Req4_SetTerminal(now,
              req4_b_reached != 0U ? 0U : T4_FAIL_MANUAL);
        }
        Balance_Stop();
      }
      Motor_Stop();
      motor_active = 0U;
      car_running = 0U;
      if (active_task == 4U) {
        Req6_ResetTargetAndSelect();
      }
      if (active_task != 0U && !TASK_IS_FULL_LAP_BALANCE(active_task)) {
        stop_state = 0U;
      }
      menu_sel = active_task;  /* 回菜单保持之前选择 */
    }

    /* ── 100Hz 控制循环 ── */
    if ((now - last_control) >= LINE_CONTROL_PERIOD_MS) {
      last_control = now;

      /* I2C读八路巡线 (地址0x12, 寄存器0x30) */
      {
        uint8_t i2c_raw;
        if (Track_I2C_Read(0x12, 0x30, &i2c_raw) == 0) {
          raw = i2c_raw;
          frame_tick = now;
          have_frame = 1U;
          frame_count++;
          i2c_err_cnt = 0U;
        } else {
          have_frame = 0U;
          i2c_err_cnt++;
        }
      }

      /* 通信超时 → 停车 (PWM模式需写0) */
      if ((have_frame == 0U) ||
          ((now - frame_tick) > LINE_FRAME_TIMEOUT_MS)) {
        line_state = 3U;
        if (motor_active != 0U) {
          Car_Differential(0, 0);  /* PWM清0, 不用Motor_Stop */
          motor_active = 0U;
        }
        Line_FilterReset();
        deviation = 0;
        turn_output = 0;
        command_speed = 0;
      }
#if USE_ADVANCED_ALGO
      /* 有数据帧 — A: 精简管线 (线性KP+强KD+自适应陀螺, 零额外延迟) */
      else {
        int16_t turn_raw;

        /* Step 1: 8路加权和 (与B分支完全一致) */
        {
          static const int8_t spos[8] = {-10,-7,-4,-1,1,4,7,10};
          uint8_t j;
          int16_t sum = 0;
          uint8_t bc = 0U;
          edge_detected = 0U;
          for (j = 0U; j < 8U; ++j) {
            if ((raw & (uint8_t)(0x80U >> j)) == 0U) {
              sum += spos[j];
              ++bc;
            }
          }
          if ((raw & 0x80U) == 0U) edge_detected |= 0x01U;
          if ((raw & 0x01U) == 0U) edge_detected |= 0x02U;
          black_cnt = bc;
          dev = sum;
        }

        if (black_cnt > 0U) {
          int16_t abs_dev = (dev < 0) ? (int16_t)(-dev) : dev;

          /* Req5终点：完成足够里程后，连续检测A点横向启停线。 */
          if (TASK_IS_FULL_LAP_BALANCE(active_task) &&
              req4_b_reached == 0U &&
              enc_sum >= T5_MIN_LAP_ENC &&
              black_cnt >= T5_START_LINE_BLACK) {
            if (req5_start_line_frames < T5_START_LINE_FRAMES) {
              ++req5_start_line_frames;
            }
            if (req5_start_line_frames >= T5_START_LINE_FRAMES) {
              Req4_MarkBPassed(now);
            }
          } else if (TASK_IS_FULL_LAP_BALANCE(active_task)) {
            req5_start_line_frames = 0U;
          }

          if (black_cnt >= 5U) {
            dev = (line_last_direction > 0) ? 10 : (line_last_direction < 0) ? -10 : 0;
          }

          /* Step 2: 线性PD (KP=5.5 + KD=2.0 + D限幅, 无滤波延迟) */
          turn_raw = Line_PDControl(dev, frame_count);

          /* Step 3: 自适应陀螺阻尼 (5/15/25三档, 直线抑震弯道放开) */
          turn_output = Line_GyroDampedTurn(turn_raw, now);

          if (turn_output > LINE_MAX_TURN)  turn_output = LINE_MAX_TURN;
          if (turn_output < -LINE_MAX_TURN) turn_output = (int16_t)(-LINE_MAX_TURN);

          /* Step 4: 瞬时速度 (与B分支完全一致) */
          command_speed = tune_speed - abs_dev * 4;
          if (command_speed < LINE_CURVE_MIN_SPEED) command_speed = LINE_CURVE_MIN_SPEED;
          if (command_speed > tune_speed) command_speed = tune_speed;

          line_state    = 1U;
          line_lost_frames = 0U;
          line_lost_frame = frame_count;
          deviation     = dev;
          last_line_tick = now;
          if (dev > 1 || dev < -1) line_last_direction = (dev > 0) ? 1 : -1;

          if (car_running != 0U) {
            Car_Differential((int16_t)(command_speed + enc_speed_bias),
                             (int16_t)(turn_output * LINE_DIRECTION));
            motor_active = 1U;
          }
        }
        else {
          /* ── 丢线 (全白) ── */
          if (frame_count != line_lost_frame) {
            line_lost_frame = frame_count;
            if (line_lost_frames < LINE_LOST_CONFIRM_FRAMES) {
              ++line_lost_frames;
            }
          }

          if ((line_lost_frames < LINE_LOST_CONFIRM_FRAMES) &&
              (last_line_tick != 0U) &&
              ((now - last_line_tick) <= LINE_LOST_SEARCH_MS) &&
              (deviation != 0)) {
            line_state = 1U;
            command_speed = Line_BlendedSpeed(
                command_speed, LINE_LOST_HOLD_SPEED, 1U);
            if (car_running != 0U) {
              Car_Differential((int16_t)(command_speed + enc_speed_bias),
                               (int16_t)(turn_output * LINE_DIRECTION));
              motor_active = 1U;
            }
          } else if ((last_line_tick != 0U) &&
              ((now - last_line_tick) <= LINE_LOST_SEARCH_MS) &&
              (deviation != 0)) {
            line_state = 2U;
            turn_output = Line_SlewTurn(
                turn_output,
                (deviation > 0) ? LINE_SEARCH_TURN
                                      : (int16_t)(-LINE_SEARCH_TURN));
            command_speed = Line_BlendedSpeed(
                command_speed, LINE_SEARCH_SPEED, 1U);
            if (car_running != 0U) {
              Car_Differential((int16_t)(command_speed + enc_speed_bias),
                               (int16_t)(turn_output * LINE_DIRECTION));
              motor_active = 1U;
            }
          } else {
            line_state   = 2U;
            deviation    = 0;
            turn_output  = 0;
            command_speed = 0;
            Line_FilterReset();
            if (motor_active != 0U) {
              Motor_Stop();
              motor_active = 0U;
            }
          }
        }
      }
#else
      /* 有数据帧 — B: 极简循迹 参照D157B例程 */
      else {
        /* 偏差: 8路加权, 每任务独立探头权重 */
        {
          static const int8_t w_t2[8] = {T2_B_W0,T2_B_W1,T2_B_W2,T2_B_W3,T2_B_W4,T2_B_W5,T2_B_W6,T2_B_W7};
          static const int8_t w_t4[8] = {T4_B_W0,T4_B_W1,T4_B_W2,T4_B_W3,T4_B_W4,T4_B_W5,T4_B_W6,T4_B_W7};
          static const int8_t w_t5[8] = {T5_B_W0,T5_B_W1,T5_B_W2,T5_B_W3,T5_B_W4,T5_B_W5,T5_B_W6,T5_B_W7};
          const int8_t *spos = (active_task == 0) ? w_t4 : TASK_IS_FULL_LAP_BALANCE(active_task) ? w_t5 : w_t2;
          uint8_t j;
          int16_t sum = 0;
          uint8_t bc = 0U;
          for (j = 0U; j < 8U; ++j) {
            if ((raw & (uint8_t)(0x80U >> j)) == 0U) {
              sum += spos[j];
              ++bc;
            }
          }
          dev = sum;
          black_cnt = bc;
        }

        if (black_cnt > 0U) {
          int16_t abs_dev = (dev < 0) ? (int16_t)(-dev) : dev;

          /* PD + 条件I: 弯道(偏差大)累积I, 直走(偏差小)清零 */
          {
            int16_t derivative = dev - line_dev_prev_b;
            line_dev_prev_b = dev;

            if (abs_dev > TASK_I_THRESHOLD) {
              line_error_integral += dev;
              if (line_error_integral >  TASK_I_LIMIT) line_error_integral =  TASK_I_LIMIT;
              if (line_error_integral < -TASK_I_LIMIT) line_error_integral = -TASK_I_LIMIT;
            } else {
              line_error_integral = 0;
            }

            turn_output = dev * tune_kp
                        + line_error_integral * tune_ki / TASK_KI_DIVISOR
                        + derivative * tune_kd;
          }

          if (turn_output >  TASK_MAX_TURN) turn_output =  TASK_MAX_TURN;
          if (turn_output < -TASK_MAX_TURN) turn_output = -TASK_MAX_TURN;

          /* 速度: 直线用基础速度, 弯道(偏差大)提速保证差速空间 */
          {
            int16_t tm = (active_task == 0) ? T4_MIN_SPEED : TASK_IS_FULL_LAP_BALANCE(active_task) ? T5_MIN_SPEED : T2_MIN_SPEED;
            /* 统一逻辑: 速度=基础-偏差, 下限tm, 上限tune_speed (恢复固化版, 无弯道提速) */
            command_speed = tune_speed - abs_dev;
            if (command_speed < tm) command_speed = tm;
            if (command_speed > tune_speed) command_speed = tune_speed;
            if (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) {
              int16_t ramp_cap = (int16_t)(T4_RAMP_START_SPEED +
                  (int16_t)((now - stop_start_tick) / T4_RAMP_STEP_MS));
              if (ramp_cap > tune_speed) ramp_cap = tune_speed;
              if (command_speed > ramp_cap) command_speed = ramp_cap;
            }
          }

          line_state    = 1U;
          deviation     = dev;
          last_line_tick = now;

          /* 陀螺仪 (编码器由 Car_Velocity_Control 内部读取, 此处用 vel_enc_l/r) */
          {
            int16_t abs_t = (turn_output < 0) ? (int16_t)(-turn_output) : turn_output;
            if (abs_t < TASK_GYRO_DAMP_THRESHOLD) {
              float gz; uint32_t gt;
              if (JY901S_GetGyroZ(&gz, &gt) != 0U) {
                turn_output += (int16_t)(gz * TASK_GYRO_DAMP_GAIN);
              }
            }
            if (turn_output >  TASK_MAX_TURN) turn_output =  TASK_MAX_TURN;
            if (turn_output < -TASK_MAX_TURN) turn_output = -TASK_MAX_TURN;
          }

          /* [调试] 转向斜坡限制: 每帧最多变 LINE_TURN_MAX_STEP(3), 入弯/出弯平滑不瞬跳(消除转弯卡顿) */
          {
            int16_t delta = (int16_t)(turn_output - line_turn_slew);
            if (delta >  LINE_TURN_MAX_STEP) delta =  LINE_TURN_MAX_STEP;
            if (delta < -LINE_TURN_MAX_STEP) delta = (int16_t)(-LINE_TURN_MAX_STEP);
            line_turn_slew += delta;
            turn_output = line_turn_slew;
          }


          /* 任务2保留原定时停车；Req4/5由各自评分状态机判定终点。 */
#if 1
          if (active_task == 1) {
            /* 任务2(FullLap): 原停车任务 */
            uint32_t lap_ms   = now - stop_start_tick;
            uint32_t crawl_ms = T2_CRAWL_MS;
            uint32_t stop_ms  = T2_STOP_MS;
            if (stop_state == 0 && lap_ms >= crawl_ms) {
              stop_state = 1;
            }
            if (stop_state == 1) {
              command_speed = STOP_CRAWL_SPEED;
              if (lap_ms >= stop_ms) {
                stop_state = 2;
                stop_end_tick = now;
              }
            }
          } else if (active_task == 0) {
            /* 任务4(A→B): 编码器里程停车 + 计时兜底 */
            uint32_t lap_ms = now - stop_start_tick;
            if (stop_state == 0) {
              if (req4_b_reached == 0U && enc_sum >= T4_STOP_ENC &&
                  lap_ms <= T4_STOP_TIMEOUT_MS) {
                Req4_MarkBPassed(now);
              } else if (req4_b_reached == 0U &&
                         lap_ms > T4_STOP_TIMEOUT_MS) {
                Req4_SetTerminal(now, T4_FAIL_TIMEOUT);
              }
            }
          }
#else
          /* [调试] 调试版停车逻辑:
             - FullLap(任务1): 保留计时器停车
             - A→B(任务0): 保留编码器+计时停车
             - Slow Walk(任务3): 不自动停车, 一直循迹, 用 TOG 命令或 KEY3 手动停 */
          if (active_task == 1) {
            /* 任务2(FullLap): 计时器停车 */
            uint32_t lap_ms   = now - stop_start_tick;
            uint32_t crawl_ms = T2_CRAWL_MS;
            uint32_t stop_ms  = T2_STOP_MS;
            if (stop_state == 0 && lap_ms >= crawl_ms) {
              stop_state = 1;
            }
            if (stop_state == 1) {
              command_speed = STOP_CRAWL_SPEED;
              if (lap_ms >= stop_ms) {
                stop_state = 2;
                stop_end_tick = now;
              }
            }
          } else if (active_task == 0) {
            /* 任务4(A→B): 编码器里程停车 + 计时兜底 */
            uint32_t lap_ms = now - stop_start_tick;
            if (stop_state == 0) {
              if (req4_b_reached == 0U && enc_sum >= T4_STOP_ENC &&
                  lap_ms <= T4_STOP_TIMEOUT_MS) {
                Req4_MarkBPassed(now);
              } else if (req4_b_reached == 0U &&
                         lap_ms > T4_STOP_TIMEOUT_MS) {
                Req4_SetTerminal(now, T4_FAIL_TIMEOUT);
              }
            }
          }
          /* active_task==3 (Slow Walk): 保持 stop_state=0, 一直循迹 */
#endif

          if (stop_state == 2) {
            Motor_Stop();
            motor_active = 0U;
          } else if (car_running != 0U) {
            Car_Velocity_Control(command_speed,
                                 (int16_t)(turn_output * LINE_DIRECTION));
            motor_active = 1U;
            /* 编码器累积: Car_Velocity_Control 已读取并存入 vel_enc_l/r */
            line_enc_l = vel_enc_l;
            line_enc_r = vel_enc_r;
            if ((active_task == 0 || TASK_IS_FULL_LAP_BALANCE(active_task)) &&
                stop_state != 2) {
              enc_sum += T4_ENCODER_SIGN *
                         (((int32_t)vel_enc_l + (int32_t)vel_enc_r) /
                          LINE_ENC_AVG_DIVISOR);
              if (active_task == 0 && req4_b_reached == 0U &&
                  enc_sum >= T4_STOP_ENC &&
                  (now - stop_start_tick) <= T4_STOP_TIMEOUT_MS) {
                Req4_MarkBPassed(now);
              }
            }
          }
        }
        else {
          /* 丢线 → 停车 */
          line_state   = 2U;
          deviation    = 0;
          turn_output  = 0;
          command_speed = 0;
          line_dev_prev_b = 0;
          line_turn_slew = 0;
          if (motor_active != 0U) {
            Motor_Stop();
            motor_active = 0U;
          }
        }
      }
#endif

      /* VOFA+: Req4/Req5均使用10Hz评分长帧。 */
      {
        static uint8_t debug_div = 0U;
        uint8_t debug_period = (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task))
                             ? 10U : 5U;
        if (++debug_div >= debug_period) {
          debug_div = 0U;
          Debug_Send(deviation, turn_output, command_speed, line_state);
        }
      }
    }

    /* ── OLED 显示 (200ms) ── */
    if ((now - last_display) >= LINE_DISPLAY_MS) {
      uint8_t i;
      last_display = now;
      OLED_Clear();
      if (stop_state == 2) {
        uint32_t lap_ms = stop_end_tick - stop_start_tick;
        if (active_task == 0U || TASK_IS_FULL_LAP_BALANCE(active_task)) {
          uint32_t score_ms = (req4_b_reached != 0U)
                            ? req4_pass_tick - stop_start_tick
                            : lap_ms;
          OLED_Printf(0U, 0U, "T%u %s %lu.%lus",
                      active_task == 4U ? 6U :
                      active_task == 3U ? 5U : 4U,
                      req4_done != 0U ? "PASS" : "FAIL",
                      (unsigned long)(score_ms / 1000U),
                      (unsigned long)((score_ms % 1000U) / 100U));
          OLED_Printf(0U, 16U, "ENC:%ld R:%u", (long)enc_sum,
                      (unsigned int)req4_fail_reason);
          OLED_Printf(0U, 30U, "MAX:%ld.%02ldcm",
                      (long)(req4_max_abs_ball / 100),
                      (long)(req4_max_abs_ball % 100));
        } else {
          OLED_Printf(0U, 0U, "T2 DONE %lu.%lus",
                      (unsigned long)(lap_ms / 1000U),
                      (unsigned long)((lap_ms % 1000U) / 100U));
        }
      } else if (stop_state == 1) {
        OLED_Printf(0U, 0U, "T2 STOPPING...");
        OLED_Printf(0U, 14U, "D:%d V:%d",
                    deviation, command_speed);
      } else {
        OLED_Printf(0U, 0U, "%s %s",
                    active_task == 0 ? "T4" :
                    active_task == 4 ? "T6" :
                    active_task == 3 ? "T5" : "T2",
                    line_state == 2U ? "LOST" :
                    line_state == 3U ? "NO DATA" : "RUN");
        OLED_Printf(0U, 14U, "D:%d T:%d S:%d",
                    deviation, turn_output, (int)stop_state);
        OLED_Printf(0U, 28U, "E:%d,%d raw:%02X",
                    (int)line_enc_l, (int)line_enc_r, (unsigned int)raw);
      }
      OLED_Printf(0U, 42U, "MODE:%s",
                  active_task == 4U ? "R6" : "RUN");
      /* 8路探头位 */
      for (i = 0U; i < TRACKING_IR_NUM; ++i) {
        OLED_ShowString((uint8_t)(i * 12U), 54U,
                        (raw & (uint8_t)(0x80U >> i)) != 0U ? "." : "#");
      }
      OLED_Refresh();
    }
    /* OLED全刷: OLED_Refresh内部只在dirty时刷 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
