#include "track_i2c.h"

static I2C_HandleTypeDef hi2c1;

void Track_I2C_Init(void)
{
  GPIO_InitTypeDef gpio = {0};

  /* I2C1: PB6=SCL, PB7=SDA, AF4 */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  gpio.Pin       = GPIO_PIN_6 | GPIO_PIN_7;
  gpio.Mode      = GPIO_MODE_AF_OD;
  gpio.Pull      = GPIO_PULLUP;
  gpio.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
  gpio.Alternate = GPIO_AF4_I2C1;
  HAL_GPIO_Init(GPIOB, &gpio);

  __HAL_RCC_I2C1_CLK_ENABLE();
  hi2c1.Instance             = I2C1;
  hi2c1.Init.ClockSpeed      = 400000;
  hi2c1.Init.DutyCycle       = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1     = 0;
  hi2c1.Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2     = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;
  HAL_I2C_Init(&hi2c1);

  HAL_Delay(50U);
}

int Track_I2C_Read(uint8_t addr, uint8_t reg, uint8_t *data)
{
  if (HAL_I2C_Mem_Read(&hi2c1, (uint16_t)(addr << 1), reg,
                        I2C_MEMADD_SIZE_8BIT, data, 1, 2) != HAL_OK) {
    return 1;
  }
  return 0;
}

int Track_I2C_Write(uint8_t addr, uint8_t reg, uint8_t data)
{
  if (HAL_I2C_Mem_Write(&hi2c1, (uint16_t)(addr << 1), reg,
                         I2C_MEMADD_SIZE_8BIT, &data, 1, 10) != HAL_OK) {
    return 1;
  }
  return 0;
}
