#include "motor_drv.h"

/* ═══════════════════════════════════════════════════════
 * D157B AT8236 电机驱动 — 完全参照 WHEELTEC D157B 例程
 *
 * PWM:  TIM3 CH1~CH4, 10kHz, slow decay
 *   正转: IN1=HIGH, IN2=PWM
 *   反转: IN1=PWM, IN2=HIGH
 *   刹车: IN1=HIGH, IN2=HIGH
 *
 * 编码器: TIM2(左) TIM4(右), 硬件正交解码 TI12
 * ═══════════════════════════════════════════════════════ */

/* ── 速度闭环 PID 参数 ── */
#define VEL_ENC_SCALE              6   /* 目标编码器: 1% → N counts/10ms [调试] 7→6: 全模式减速~14%; 再降可到5/4, 但<4接近电机死区 */
#define VEL_PID_KP                 8   /* 增量P增益 */
#define VEL_PID_KI                 2   /* 积分增益 */
#define VEL_PID_KD                 2   /* 增量D增益 */
#define VEL_PID_LIMIT           3000   /* PI输出限幅 */
#define LEFT_ENCODER_FORWARD_SIGN  (-1) /* 实测左轮前进原始计数为负 */
#define RIGHT_ENCODER_FORWARD_SIGN   1  /* 实测右轮前进原始计数为正 */

static TIM_HandleTypeDef htim3_pwm;
static TIM_HandleTypeDef htim2_enc;
static TIM_HandleTypeDef htim4_enc;

/* ── TIM3 PWM MSP: PA6(AIN1) PA7(AIN2) PB0(BIN1) PB1(BIN2) ── */
void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM3) {
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_TIM3_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Mode  = GPIO_MODE_AF_PP;
    g.Pull  = GPIO_PULLDOWN;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    g.Pin = GPIO_PIN_6 | GPIO_PIN_7;
    g.Alternate = GPIO_AF2_TIM3;
    HAL_GPIO_Init(GPIOA, &g);
    g.Pin = GPIO_PIN_0 | GPIO_PIN_1;
    g.Alternate = GPIO_AF2_TIM3;
    HAL_GPIO_Init(GPIOB, &g);
  }
}

/* ── 编码器 MSP: TIM2(PA0/PA1) TIM4(PD12/PD13) ── */
void HAL_TIM_Encoder_MspInit(TIM_HandleTypeDef *htim)
{
  GPIO_InitTypeDef g = {0};
  g.Mode  = GPIO_MODE_AF_PP;
  g.Pull  = GPIO_PULLUP;
  g.Speed = GPIO_SPEED_FREQ_LOW;
  if (htim->Instance == TIM2) {
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_TIM2_CLK_ENABLE();
    g.Pin = GPIO_PIN_0 | GPIO_PIN_1;
    g.Alternate = GPIO_AF1_TIM2;
    HAL_GPIO_Init(GPIOA, &g);
  } else if (htim->Instance == TIM4) {
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_TIM4_CLK_ENABLE();
    g.Pin = GPIO_PIN_12 | GPIO_PIN_13;
    g.Alternate = GPIO_AF2_TIM4;
    HAL_GPIO_Init(GPIOD, &g);
  }
}

/* ── PWM 初始化: TIM3, 10kHz ── */
static void PWM_Init(void)
{
  htim3_pwm.Instance               = TIM3;
  htim3_pwm.Init.Prescaler         = 0;
  htim3_pwm.Init.CounterMode       = TIM_COUNTERMODE_UP;
  htim3_pwm.Init.Period            = MOTOR_ARR;
  htim3_pwm.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
  htim3_pwm.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  HAL_TIM_PWM_Init(&htim3_pwm);

  TIM_OC_InitTypeDef oc = {0};
  oc.OCMode     = TIM_OCMODE_PWM1;
  oc.Pulse      = 0;
  oc.OCPolarity = TIM_OCPOLARITY_HIGH;
  oc.OCFastMode = TIM_OCFAST_DISABLE;
  HAL_TIM_PWM_ConfigChannel(&htim3_pwm, &oc, TIM_CHANNEL_1);
  HAL_TIM_PWM_ConfigChannel(&htim3_pwm, &oc, TIM_CHANNEL_2);
  HAL_TIM_PWM_ConfigChannel(&htim3_pwm, &oc, TIM_CHANNEL_3);
  HAL_TIM_PWM_ConfigChannel(&htim3_pwm, &oc, TIM_CHANNEL_4);

  /* 上电刹车 */
  TIM3->CCR1 = MOTOR_ARR;
  TIM3->CCR2 = MOTOR_ARR;
  TIM3->CCR3 = MOTOR_ARR;
  TIM3->CCR4 = MOTOR_ARR;

  HAL_TIM_PWM_Start(&htim3_pwm, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3_pwm, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3_pwm, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim3_pwm, TIM_CHANNEL_4);
}

/* ── 编码器初始化 ── */
static void Encoder_Init(void)
{
  TIM_Encoder_InitTypeDef enc = {0};
  enc.EncoderMode    = TIM_ENCODERMODE_TI12;
  enc.IC1Polarity    = TIM_ICPOLARITY_RISING;
  enc.IC1Selection   = TIM_ICSELECTION_DIRECTTI;
  enc.IC1Prescaler   = TIM_ICPSC_DIV1;
  enc.IC1Filter      = 10;
  enc.IC2Polarity    = TIM_ICPOLARITY_RISING;
  enc.IC2Selection   = TIM_ICSELECTION_DIRECTTI;
  enc.IC2Prescaler   = TIM_ICPSC_DIV1;
  enc.IC2Filter      = 10;

  htim2_enc.Instance               = TIM2;
  htim2_enc.Init.Prescaler         = 0;
  htim2_enc.Init.CounterMode       = TIM_COUNTERMODE_UP;
  htim2_enc.Init.Period            = 65535;
  htim2_enc.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
  htim2_enc.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  HAL_TIM_Encoder_Init(&htim2_enc, &enc);
  HAL_TIM_Encoder_Start(&htim2_enc, TIM_CHANNEL_ALL);

  htim4_enc.Instance               = TIM4;
  htim4_enc.Init.Prescaler         = 0;
  htim4_enc.Init.CounterMode       = TIM_COUNTERMODE_UP;
  htim4_enc.Init.Period            = 65535;
  htim4_enc.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
  htim4_enc.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  HAL_TIM_Encoder_Init(&htim4_enc, &enc);
  HAL_TIM_Encoder_Start(&htim4_enc, TIM_CHANNEL_ALL);
}

void Motor_Init(void)
{
  PWM_Init();
  Encoder_Init();
}

void Motor_Stop(void)
{
  TIM3->CCR1 = MOTOR_ARR;
  TIM3->CCR2 = MOTOR_ARR;
  TIM3->CCR3 = MOTOR_ARR;
  TIM3->CCR4 = MOTOR_ARR;
  /* PI状态由Car_Velocity_Control内部static持有,
     下次调用时从当前编码器值开始重新累积 */
}

/* ── 差速控制 — 完全参照 D157B 例程 Set_PWM 函数 ── */
void Car_Differential(int16_t forward, int16_t turn)
{
  int32_t left  = (int32_t)forward + (int32_t)turn;
  int32_t right = (int32_t)forward - (int32_t)turn;

  left  = left  * MOTOR_ARR / 100;
  right = right * MOTOR_ARR / 100;

  if (left  >  MOTOR_ARR) left  =  MOTOR_ARR;
  if (left  < -MOTOR_ARR) left  = -MOTOR_ARR;
  if (right >  MOTOR_ARR) right =  MOTOR_ARR;
  if (right < -MOTOR_ARR) right = -MOTOR_ARR;

#if RIGHT_MOTOR_INVERT
  right = -right;
#endif

  /* 两电机统一: 正转=IN1(PWM)+IN2(HIGH), 反转=IN1(HIGH)+IN2(PWM) */
  if (left > 0) {
    PWMA_IN1 = MOTOR_ARR - left;
    PWMA_IN2 = MOTOR_ARR;
  } else {
    PWMA_IN1 = MOTOR_ARR;
    PWMA_IN2 = MOTOR_ARR + left;
  }

  if (right > 0) {
    PWMB_IN1 = MOTOR_ARR - right;
    PWMB_IN2 = MOTOR_ARR;
  } else {
    PWMB_IN1 = MOTOR_ARR;
    PWMB_IN2 = MOTOR_ARR + right;
  }
}

/* ── 读编码器 — 参照例程 Read_Encoder ── */
int Motor_ReadEncoders(int16_t *left, int16_t *right)
{
  if (left != NULL) {
    *left = (int16_t)TIM2->CNT;
    TIM2->CNT = 0;
  }
  if (right != NULL) {
    *right = (int16_t)TIM4->CNT;
    TIM4->CNT = 0;
  }
  return 0;
}

/* ── 速度闭环: 前馈 + 增量PI微调, 参照24年电赛 i_pid ── */
int16_t vel_enc_l = 0;
int16_t vel_enc_r = 0;
static uint8_t vel_reset_flag = 0;
static uint16_t vel_forward_slew_q8 = 0U;
static uint16_t vel_turn_slew_q8 = 0U;
static int32_t vel_forward_cmd_q8 = 0;
static int32_t vel_turn_cmd_q8 = 0;

void Car_Velocity_Control(int16_t forward, int16_t turn)
{
  int32_t desired_forward_q8 = ((int32_t)forward) << 8;
  if (vel_forward_slew_q8 != 0U) {
    int32_t slew_error = desired_forward_q8 - vel_forward_cmd_q8;
    if (slew_error > (int32_t)vel_forward_slew_q8) {
      slew_error = (int32_t)vel_forward_slew_q8;
    } else if (slew_error < -(int32_t)vel_forward_slew_q8) {
      slew_error = -(int32_t)vel_forward_slew_q8;
    }
    vel_forward_cmd_q8 += slew_error;
  } else {
    vel_forward_cmd_q8 = desired_forward_q8;
  }

  int32_t desired_turn_q8 = ((int32_t)turn) << 8;
  if (vel_turn_slew_q8 != 0U) {
    int32_t turn_error = desired_turn_q8 - vel_turn_cmd_q8;
    if (turn_error > (int32_t)vel_turn_slew_q8) {
      turn_error = (int32_t)vel_turn_slew_q8;
    } else if (turn_error < -(int32_t)vel_turn_slew_q8) {
      turn_error = -(int32_t)vel_turn_slew_q8;
    }
    vel_turn_cmd_q8 += turn_error;
  } else {
    vel_turn_cmd_q8 = desired_turn_q8;
  }

  int32_t l_pct_q8 = vel_forward_cmd_q8 + vel_turn_cmd_q8;
  int32_t r_pct_q8 = vel_forward_cmd_q8 - vel_turn_cmd_q8;
  if (l_pct_q8 < 0) l_pct_q8 = 0;
  if (r_pct_q8 < 0) r_pct_q8 = 0;

  /* 前馈: 目标% → PWM基准值 */
  int32_t l_ff = l_pct_q8 * MOTOR_ARR / (100 * 256);
  int32_t r_ff = r_pct_q8 * MOTOR_ARR / (100 * 256);

  /* 目标编码器值 (1% ≈ 7 counts) */
  int32_t l_tgt = l_pct_q8 * VEL_ENC_SCALE / 256;
  int32_t r_tgt = r_pct_q8 * VEL_ENC_SCALE / 256;

  int16_t el, er;
  Motor_ReadEncoders(&el, &er);
  /* 速度闭环统一约定: 两轮前进反馈均为正。 */
  el = (int16_t)(el * LEFT_ENCODER_FORWARD_SIGN);
  er = (int16_t)(er * RIGHT_ENCODER_FORWARD_SIGN);
  vel_enc_l = el;
  vel_enc_r = er;

  /* 增量PI: 参照24年 i_pid, 强力锁定目标速度 */
  static int32_t l_pi = 0, r_pi = 0;
  static int32_t l_le = 0, r_le = 0;
  static int32_t l_lle = 0, r_lle = 0;

  /* ponytail: Velocity_Reset 设置此标志, 下次调用时清零PID状态 */
  if (vel_reset_flag) {
    l_pi = r_pi = 0;
    l_le = r_le = 0;
    l_lle = r_lle = 0;
    vel_reset_flag = 0;
  }

  int32_t le = l_tgt - el;
  int32_t re = r_tgt - er;

  /* KP=8(增量P), KI=2(积分), KD=2(增量D) — 强力锁定 */
  l_pi += (le - l_le) * VEL_PID_KP + le * VEL_PID_KI + (le - 2*l_le + l_lle) * VEL_PID_KD;
  r_pi += (re - r_le) * VEL_PID_KP + re * VEL_PID_KI + (re - 2*r_le + r_lle) * VEL_PID_KD;

  if (l_pi >  VEL_PID_LIMIT) l_pi =  VEL_PID_LIMIT;
  if (l_pi < -VEL_PID_LIMIT) l_pi = -VEL_PID_LIMIT;
  if (r_pi >  VEL_PID_LIMIT) r_pi =  VEL_PID_LIMIT;
  if (r_pi < -VEL_PID_LIMIT) r_pi = -VEL_PID_LIMIT;

  l_lle = l_le; l_le = le;
  r_lle = r_le; r_le = re;

  int32_t l_out = l_ff + l_pi;
  int32_t r_out = r_ff + r_pi;

  if (l_out >  MOTOR_ARR) l_out =  MOTOR_ARR;
  if (l_out < 0)           l_out = 0;
  if (r_out >  MOTOR_ARR) r_out =  MOTOR_ARR;
  if (r_out < 0)           r_out = 0;

  /* PWM */
  if (l_out > 0) { PWMA_IN1 = MOTOR_ARR - l_out; PWMA_IN2 = MOTOR_ARR; }
  else           { PWMA_IN1 = MOTOR_ARR;         PWMA_IN2 = MOTOR_ARR + l_out; }

  int32_t ro = r_out;
#if RIGHT_MOTOR_INVERT
  ro = -ro;
#endif
  if (ro > 0) { PWMB_IN1 = MOTOR_ARR - ro; PWMB_IN2 = MOTOR_ARR; }
  else        { PWMB_IN1 = MOTOR_ARR;       PWMB_IN2 = MOTOR_ARR + ro; }
}

/* ── 速度环PI状态重置 ── */
void Velocity_SetForwardSlew(uint16_t q8_per_call)
{
  vel_forward_slew_q8 = q8_per_call;
}

void Velocity_SetTurnSlew(uint16_t q8_per_call)
{
  vel_turn_slew_q8 = q8_per_call;
}

void Velocity_Reset(void)
{
  vel_reset_flag = 1;
  vel_forward_cmd_q8 = 0;
  vel_turn_cmd_q8 = 0;
  TIM2->CNT = 0U;
  TIM4->CNT = 0U;
  vel_enc_l = 0;
  vel_enc_r = 0;
}
