#include "tracking.h"
#include "usart.h"

uint8_t IR_Data[TRACKING_IR_NUM] = {1U, 1U, 1U, 1U, 1U, 1U, 1U, 1U};
volatile uint8_t IR_NewFrame = 0U;
volatile uint8_t IR_RawValue = 0xFFU;
volatile uint8_t Tracking_RxByte = 0U;
volatile uint8_t IR_LastRxByte = 0U;
volatile uint8_t IR_RxTrace[8] = {0U};
volatile uint8_t IR_RxTraceIndex = 0U;
volatile uint32_t IR_FrameCount = 0U;
volatile uint32_t IR_ErrorCount = 0U;
volatile uint32_t IR_RxByteCount = 0U;
volatile uint32_t IR_CommandCount = 0U;
volatile uint32_t IR_FrameInterval = 0U;    /* v30: 帧间隔(ms) */
volatile uint32_t IR_FrameLost = 0U;        /* v30: 丢帧计数(>50ms间隙) */

static const uint8_t tracking_start_command[] = "$0,0,1#";
static uint8_t rx_frame[48];
static uint8_t rx_index = 0U;
static uint8_t rx_active = 0U;
static uint32_t last_command_tick = 0U;
static volatile uint32_t last_frame_tick = 0U;
static uint32_t last_rx_restart_tick = 0U;

static uint8_t Tracking_ParseFrame(const uint8_t *frame, uint8_t length)
{
  uint8_t i;
  uint8_t raw = 0U;

  /* Vendor digital frame:
     $D,x1:0,x2:0,x3:0,x4:0,x5:0,x6:0,x7:0,x8:0# */
  if ((length != 43U) || (frame[0] != '$') || (frame[1] != 'D') ||
      (frame[2] != ',') || (frame[42] != '#')) {
    return 0U;
  }

  for (i = 0U; i < TRACKING_IR_NUM; ++i) {
    uint8_t base = (uint8_t)(3U + (i * 5U));
    uint8_t value;

    if ((frame[base] != 'x') || (frame[base + 1U] != (uint8_t)('1' + i)) ||
        (frame[base + 2U] != ':') ||
        ((frame[base + 3U] != '0') && (frame[base + 3U] != '1')) ||
        (((i < 7U) && (frame[base + 4U] != ',')) ||
         ((i == 7U) && (frame[base + 4U] != '#')))) {
      return 0U;
    }

    value = (uint8_t)(frame[base + 3U] - '0');
    IR_Data[i] = value;
    raw |= (uint8_t)(value << (7U - i));
  }

  IR_RawValue = raw;
  /* v30: 帧间隔检测丢包, >50ms间隙计数 */
  {
    uint32_t now = HAL_GetTick();
    IR_FrameInterval = now - last_frame_tick;
    if (IR_FrameInterval > 50U) {
      ++IR_FrameLost;
    }
  }
  ++IR_FrameCount;
  last_frame_tick = HAL_GetTick();
  IR_NewFrame = 1U;
  return 1U;
}

void Tracking_Init(void)
{
  IR_NewFrame = 0U;
  IR_RawValue = 0xFFU;
  IR_FrameCount = 0U;
  IR_ErrorCount = 0U;
  IR_RxByteCount = 0U;
  IR_CommandCount = 0U;
  IR_FrameInterval = 0U;
  IR_FrameLost = 0U;
  IR_LastRxByte = 0U;
  IR_RxTraceIndex = 0U;
  rx_index = 0U;
  rx_active = 0U;
  last_frame_tick = HAL_GetTick();
  last_rx_restart_tick = last_frame_tick;

  if (HAL_UART_Receive_IT(&huart3, (uint8_t *)&Tracking_RxByte, 1U) != HAL_OK) {
    ++IR_ErrorCount;
  }
  if (HAL_UART_Transmit(&huart3, (uint8_t *)tracking_start_command,
                        sizeof(tracking_start_command) - 1U, 100U) != HAL_OK) {
    ++IR_ErrorCount;
  } else {
    ++IR_CommandCount;
  }
  last_command_tick = HAL_GetTick();
}

void Tracking_Read(void)
{
  uint32_t now = HAL_GetTick();

  /* Recover if an UART error or a failed ISR re-arm stopped byte reception. */
  if ((huart3.RxState != HAL_UART_STATE_BUSY_RX) &&
      ((now - last_rx_restart_tick) >= 10U)) {
    if (HAL_UART_Receive_IT(&huart3, (uint8_t *)&Tracking_RxByte, 1U) != HAL_OK) {
      ++IR_ErrorCount;
    }
    last_rx_restart_tick = now;
  }

  /* The module streams after receiving the command. Retry only when the
     stream has stopped, so E counts meaningful communication recoveries. */
  if (((now - last_frame_tick) >= 1000U) &&
      ((now - last_command_tick) >= 1000U)) {
    if (HAL_UART_Transmit(&huart3, (uint8_t *)tracking_start_command,
                          sizeof(tracking_start_command) - 1U, 100U) != HAL_OK) {
      ++IR_ErrorCount;
    } else {
      ++IR_CommandCount;
    }
    last_command_tick = now;
  }
}

void Tracking_ParseByte(uint8_t data)
{
  IR_LastRxByte = data;
  IR_RxTrace[IR_RxTraceIndex] = data;
  IR_RxTraceIndex = (uint8_t)((IR_RxTraceIndex + 1U) & 0x07U);
  ++IR_RxByteCount;

  if (data == '$') {
    rx_active = 1U;
    rx_index = 0U;
    rx_frame[rx_index++] = data;
    return;
  }

  if (rx_active == 0U) {
    return;
  }

  if (rx_index >= sizeof(rx_frame)) {
    rx_active = 0U;
    rx_index = 0U;
    ++IR_ErrorCount;
    return;
  }

  rx_frame[rx_index++] = data;
  if (data == '#') {
    if (Tracking_ParseFrame(rx_frame, rx_index) == 0U) {
      ++IR_ErrorCount;
    }
    rx_active = 0U;
    rx_index = 0U;
  }
}

void Tracking_UartError(void)
{
  ++IR_ErrorCount;
  rx_active = 0U;
  rx_index = 0U;
}

uint8_t Tracking_GetSnapshot(uint8_t *raw, uint32_t *frame_tick,
                             uint32_t *frame_count)
{
  uint32_t primask;

  if ((raw == NULL) || (frame_tick == NULL) || (frame_count == NULL)) {
    return 0U;
  }

  primask = __get_PRIMASK();
  __disable_irq();
  *raw = IR_RawValue;
  *frame_tick = last_frame_tick;
  *frame_count = IR_FrameCount;
  if (primask == 0U) {
    __enable_irq();
  }

  return (*frame_count != 0U) ? 1U : 0U;
}
