#include "jy901s.h"
#include "usart.h"

float JY901S_Roll = 0.0f;
float JY901S_Pitch = 0.0f;
float JY901S_Yaw = 0.0f;
volatile float JY901S_GyroZ = 0.0f;
volatile float JY901S_AccX = 0.0f;   /* [调试] 加速度计 X (g) */
volatile float JY901S_AccY = 0.0f;   /* [调试] 加速度计 Y (g) */
uint8_t JY901S_Ready = 0U;
volatile uint8_t JY901S_GyroReady = 0U;
volatile uint8_t JY901S_AccReady = 0U;
volatile uint32_t JY901S_GyroFrameCount = 0U;
volatile uint32_t JY901S_AccFrameCount = 0U;
volatile uint32_t JY901S_AngleFrameCount = 0U;
volatile uint32_t JY901S_FrameErrorCount = 0U;
volatile uint32_t JY901S_RxByteCount = 0U;
volatile uint32_t JY901S_UartErrorCount = 0U;
volatile uint32_t JY901S_ActiveBaud = 9600U;
uint8_t rx6_byte = 0U;
static volatile uint32_t jy901s_gyro_tick = 0U;
static volatile uint32_t jy901s_acc_tick = 0U;
static uint8_t jy901s_frame[11];
static uint8_t jy901s_index = 0U;
static uint32_t jy901s_probe_tick = 0U;
static uint32_t jy901s_valid_frames = 0U;
static uint8_t jy901s_baud_locked = 0U;

static void JY901S_WriteRegister(uint8_t reg, uint16_t value)
{
  uint8_t command[5] = {
      0xFFU, 0xAAU, reg, (uint8_t)value, (uint8_t)(value >> 8)
  };
  (void)HAL_UART_Transmit(&huart6, command, sizeof(command), 50U);
  HAL_Delay(20U);
}

static void JY901S_StartPort(uint32_t baud)
{
  (void)HAL_UART_AbortReceive(&huart6);
  huart6.Init.BaudRate = baud;
  if (HAL_UART_Init(&huart6) != HAL_OK) {
    Error_Handler();
  }
  jy901s_index = 0U;
  JY901S_ActiveBaud = baud;
  if (HAL_UART_Receive_IT(&huart6, &rx6_byte, 1U) != HAL_OK) {
    Error_Handler();
  }

  JY901S_WriteRegister(0x69U, 0xB588U);
  JY901S_WriteRegister(0x02U, 0x000EU);  /* gyro+angle+magnetic */
  JY901S_WriteRegister(0x03U, 0x0007U);
  jy901s_probe_tick = HAL_GetTick();
}

void JY901S_Init(void)
{
  JY901S_GyroReady = 0U;
  JY901S_GyroZ = 0.0f;
  JY901S_AccReady = 0U;
  JY901S_AccX = 0.0f;
  JY901S_AccY = 0.0f;
  jy901s_gyro_tick = 0U;
  jy901s_acc_tick = 0U;
  JY901S_GyroFrameCount = 0U;
  JY901S_AccFrameCount = 0U;
  JY901S_AngleFrameCount = 0U;
  JY901S_FrameErrorCount = 0U;
  JY901S_RxByteCount = 0U;
  JY901S_UartErrorCount = 0U;
  jy901s_valid_frames = 0U;
  jy901s_baud_locked = 0U;
  jy901s_index = 0U;
  HAL_NVIC_SetPriority(USART6_IRQn, 1U, 0U);
  HAL_NVIC_EnableIRQ(USART6_IRQn);
  JY901S_StartPort(9600U);
}

void JY901S_Service(void)
{
  uint32_t now = HAL_GetTick();

  if (jy901s_baud_locked != 0U) {
    return;
  }
  if (jy901s_valid_frames != 0U) {
    jy901s_baud_locked = 1U;
    return;
  }
  if ((now - jy901s_probe_tick) >= 1500U) {
    JY901S_StartPort((JY901S_ActiveBaud == 9600U) ? 115200U : 9600U);
  }
}

void JY901S_ParseByte(uint8_t ch)
{
  uint8_t sum;
  uint8_t i;

  ++JY901S_RxByteCount;
  if (jy901s_index == 0U) {
    if (ch != 0x55U) {
      return;
    }
    jy901s_frame[jy901s_index++] = ch;
    return;
  }

  jy901s_frame[jy901s_index++] = ch;
  if (jy901s_index < sizeof(jy901s_frame)) {
    return;
  }
  jy901s_index = 0U;

  sum = 0U;
  for (i = 0U; i < 10U; ++i) {
    sum = (uint8_t)(sum + jy901s_frame[i]);
  }
  if (sum != jy901s_frame[10]) {
    ++JY901S_FrameErrorCount;
    return;
  }
  ++jy901s_valid_frames;

  if (jy901s_frame[1] == 0x51U) {
    /*
     * WIT private protocol 0x51: accelerometer.
     * signed little-endian, full scale +/-16g.
     * [调试] 用于小车加速度前馈: 车加速/减速时抵消惯性对球的影响.
     */
    int16_t ax = (int16_t)((uint16_t)jy901s_frame[2] |
                           ((uint16_t)jy901s_frame[3] << 8));
    int16_t ay = (int16_t)((uint16_t)jy901s_frame[4] |
                           ((uint16_t)jy901s_frame[5] << 8));
    JY901S_AccX = (float)ax * 16.0f / 32768.0f;
    JY901S_AccY = (float)ay * 16.0f / 32768.0f;
    jy901s_acc_tick = HAL_GetTick();
    ++JY901S_AccFrameCount;
    JY901S_AccReady = 1U;
  } else if (jy901s_frame[1] == 0x52U) {
    /*
     * WIT private protocol 0x52:
     * signed little-endian angular velocity, full scale +/-2000 deg/s.
     * A horizontally mounted module uses Z as the vehicle yaw-rate axis.
     */
    int16_t gz = (int16_t)((uint16_t)jy901s_frame[6] |
                           ((uint16_t)jy901s_frame[7] << 8));
    JY901S_GyroZ = (float)gz * 2000.0f / 32768.0f;
    jy901s_gyro_tick = HAL_GetTick();
    ++JY901S_GyroFrameCount;
    JY901S_GyroReady = 1U;
  } else if (jy901s_frame[1] == 0x53U) {
    int16_t roll = (int16_t)((uint16_t)jy901s_frame[2] |
                             ((uint16_t)jy901s_frame[3] << 8));
    int16_t pitch = (int16_t)((uint16_t)jy901s_frame[4] |
                              ((uint16_t)jy901s_frame[5] << 8));
    int16_t yaw = (int16_t)((uint16_t)jy901s_frame[6] |
                            ((uint16_t)jy901s_frame[7] << 8));
    JY901S_Roll = (float)roll * 180.0f / 32768.0f;
    JY901S_Pitch = (float)pitch * 180.0f / 32768.0f;
    JY901S_Yaw = (float)yaw * 180.0f / 32768.0f;
    ++JY901S_AngleFrameCount;
    JY901S_Ready = 1U;
  }
}

void JY901S_UartError(void)
{
  ++JY901S_UartErrorCount;
  jy901s_index = 0U;
}

uint8_t JY901S_GetAccX(float *acc_x, uint32_t *sample_tick)
{
  uint32_t primask;

  if ((acc_x == NULL) || (sample_tick == NULL)) {
    return 0U;
  }

  primask = __get_PRIMASK();
  __disable_irq();
  *acc_x = JY901S_AccX;
  *sample_tick = jy901s_acc_tick;
  if (primask == 0U) {
    __enable_irq();
  }
  return JY901S_AccReady;
}

uint8_t JY901S_GetGyroZ(float *gyro_z, uint32_t *sample_tick)
{
  uint32_t primask;

  if ((gyro_z == NULL) || (sample_tick == NULL)) {
    return 0U;
  }

  primask = __get_PRIMASK();
  __disable_irq();
  *gyro_z = JY901S_GyroZ;
  *sample_tick = jy901s_gyro_tick;
  if (primask == 0U) {
    __enable_irq();
  }
  return JY901S_GyroReady;
}
