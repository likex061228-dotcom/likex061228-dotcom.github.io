/**
 * pid.c — PD 控制器实现
 *
 * P 项: 位置比例控制, 受死区限制
 * D 项: 速度阻尼, 始终有效
 * 无 I 项 — 球杆系统本身不稳定
 */

#include "pid.h"
#include <stdlib.h>

PID_State g_pid;

void PID_Init(PID_State *pid)
{
    pid->p.kp        = 10.0f;
    pid->p.kd        = 1.5f;
    pid->p.out_max   = 45;
    pid->p.out_min   = -45;
    pid->p.deadband  = 10;        /* ±0.10cm */

    pid->setpoint    = 0;
    pid->last_error  = 0;
    pid->integral    = 0;
    pid->last_tick   = 0;
}

void PID_Set_Gains(PID_State *pid, float kp, float kd, int32_t clamp)
{
    pid->p.kp      = kp;
    pid->p.kd      = kd;
    pid->p.out_max = clamp;
    pid->p.out_min = -clamp;
}

int32_t PID_Compute(PID_State *pid, int32_t measurement, uint32_t now_ms)
{
    int32_t error = pid->setpoint - measurement;
    float error_cm = error * 0.01f;
    float derror_cm = 0.0f;

    if (pid->last_tick != 0U) {
        uint32_t dt_ms = now_ms - pid->last_tick;
        if (dt_ms == 0U) dt_ms = 1U;
        if (dt_ms > 150U) dt_ms = 150U;
        float dt = dt_ms * 0.001f;

        derror_cm = (error - pid->last_error) * 0.01f / dt;
        if (derror_cm > 40.0f)  derror_cm = 40.0f;
        if (derror_cm < -40.0f) derror_cm = -40.0f;
    }

    pid->last_tick = now_ms;
    pid->last_error = error;

    float p_error_cm = error_cm;
    if (abs(error) < pid->p.deadband) {
        p_error_cm = 0.0f;
    }

    float output = pid->p.kp * p_error_cm + pid->p.kd * derror_cm;

    int32_t out;
    if (output >= 0.0f) {
        out = (int32_t)(output + 0.5f);
    } else {
        out = (int32_t)(output - 0.5f);
    }

    if (out > pid->p.out_max)  out = pid->p.out_max;
    if (out < pid->p.out_min)  out = pid->p.out_min;

    return out;
}
