#ifndef __SOFT_I2C_H
#define __SOFT_I2C_H

#include "main.h"

/* Shared software I2C bus: PA8=SCL, PA15=SDA. */
#define SOFT_I2C_SCL_PIN GPIO_PIN_8
#define SOFT_I2C_SDA_PIN GPIO_PIN_15
#define SOFT_I2C_PORT    GPIOA

void Soft_I2C_Init(void);
void Soft_I2C_Start(void);
void Soft_I2C_Stop(void);
uint8_t Soft_I2C_Wait_Ack(void);
void Soft_I2C_Ack(void);
void Soft_I2C_NAck(void);
void Soft_I2C_Send_Byte(uint8_t data);
uint8_t Soft_I2C_Read_Byte(uint8_t ack);
int Soft_I2C_Write(uint8_t addr, uint8_t reg, uint8_t len, const uint8_t *data);
int Soft_I2C_Read(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *buf);
void delay_us(uint32_t us);

#endif
