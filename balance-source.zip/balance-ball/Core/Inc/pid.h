/**
 * pid.h — 小球平衡 PD 控制器
 *
 * 输入: 小球 X 坐标 (cm × 100, 即 0.01cm 分辨率)
 * 输出: 相对上电基准的目标脉冲偏移
 */

#ifndef __PID_H
#define __PID_H

#include <stdint.h>

/* ---------- PID 参数 ---------- */
typedef struct {
    float   kp;
    float   kd;
    int32_t out_max;
    int32_t out_min;
    int32_t deadband;      /* cm×100 */
} PID_Params;

/* ---------- PID 状态 ---------- */
typedef struct {
    PID_Params p;
    int32_t   setpoint;
    int32_t   last_error;
    int32_t   integral;
    uint32_t  last_tick;
} PID_State;

/* ---------- API ---------- */
void  PID_Init(PID_State *pid);
void  PID_Set_Gains(PID_State *pid, float kp, float kd, int32_t clamp);
int32_t PID_Compute(PID_State *pid, int32_t measurement, uint32_t now_ms);

/* 全局 PID 实例 */
extern PID_State g_pid;

#endif /* __PID_H */
