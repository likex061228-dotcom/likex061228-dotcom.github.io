#ifndef __MOTOR_DRV_H
#define __MOTOR_DRV_H

#include "main.h"

/* ── 电机方向: 1=右轮反向(对称放置), 0=同向 ── */
#define RIGHT_MOTOR_INVERT      1

/* PWM: TIM3, 84MHz/8400=10kHz */
#define MOTOR_ARR               8399

/* TIM3 CCR 直接操作 */
#define PWMA_IN1  (TIM3->CCR1)  /* PA6 左轮 IN1 */
#define PWMA_IN2  (TIM3->CCR2)  /* PA7 左轮 IN2 */
#define PWMB_IN1  (TIM3->CCR3)  /* PB0 右轮 IN1 */
#define PWMB_IN2  (TIM3->CCR4)  /* PB1 右轮 IN2 */

void Motor_Init(void);
void Motor_Stop(void);
void Car_Differential(int16_t forward, int16_t turn);
void Car_Velocity_Control(int16_t forward, int16_t turn);
int  Motor_ReadEncoders(int16_t *left, int16_t *right);
void Velocity_SetForwardSlew(uint16_t q8_per_call);
void Velocity_SetTurnSlew(uint16_t q8_per_call);
void Velocity_Reset(void);

/* 速度闭环反馈值 (Car_Velocity_Control 写入, main.c 读取) */
extern int16_t vel_enc_l;
extern int16_t vel_enc_r;

#endif
