#ifndef __TRACK_I2C_H
#define __TRACK_I2C_H

#include "main.h"

void Track_I2C_Init(void);
int Track_I2C_Read(uint8_t addr, uint8_t reg, uint8_t *data);
int Track_I2C_Write(uint8_t addr, uint8_t reg, uint8_t data);

#endif
