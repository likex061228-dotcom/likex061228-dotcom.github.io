#ifndef __JY901S_H
#define __JY901S_H

#include "main.h"

extern float JY901S_Roll;
extern float JY901S_Pitch;
extern float JY901S_Yaw;
extern volatile float JY901S_GyroZ;
extern volatile float JY901S_AccX;   /* [调试] 加速度计 X 轴 (g) */
extern volatile float JY901S_AccY;   /* [调试] 加速度计 Y 轴 (g) */
extern uint8_t JY901S_Ready;
extern volatile uint8_t JY901S_GyroReady;
extern volatile uint8_t JY901S_AccReady;
extern volatile uint32_t JY901S_GyroFrameCount;
extern volatile uint32_t JY901S_AccFrameCount;
extern volatile uint32_t JY901S_AngleFrameCount;
extern volatile uint32_t JY901S_FrameErrorCount;
extern volatile uint32_t JY901S_RxByteCount;
extern volatile uint32_t JY901S_UartErrorCount;
extern volatile uint32_t JY901S_ActiveBaud;
extern uint8_t rx6_byte;

void JY901S_Init(void);
void JY901S_Service(void);
void JY901S_ParseByte(uint8_t ch);
void JY901S_UartError(void);
uint8_t JY901S_GetGyroZ(float *gyro_z, uint32_t *sample_tick);
uint8_t JY901S_GetAccX(float *acc_x, uint32_t *sample_tick);  /* [调试] 读取X轴加速度(g) */

#endif
