/**
 * maixcam_proto.h — MaixCam 串口协议解析
 *
 * 协议: ASCII 文本行, 格式 "X+03.45\n" 或 "X-12.50\n"
 * 单位: cm, 范围 -12.50 ~ +12.50
 * 使用 USART2 (PA2/PA3)
 */

#ifndef __MAIXCAM_PROTO_H
#define __MAIXCAM_PROTO_H

#include <stdint.h>

/* ---------- 缓冲区 ---------- */
#define RX_BUF_SIZE     32

/* ---------- API ---------- */
int MaixCam_Feed(uint8_t byte);
int MaixCam_GetPosition(int32_t *pos_out);
int MaixCam_PeekPosition(int32_t *pos_out);
int MaixCam_IsFresh(void);
int MaixCam_IsTimeout(uint32_t now_ms);
void MaixCam_RXCallback(uint8_t byte);
void MaixCam_Tick(uint32_t now_ms);
void MaixCam_Reset(void);

#endif /* __MAIXCAM_PROTO_H */
