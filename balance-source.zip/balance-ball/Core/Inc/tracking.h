#ifndef __TRACKING_H
#define __TRACKING_H

#include "main.h"

#define TRACKING_IR_NUM 8

extern uint8_t IR_Data[TRACKING_IR_NUM];
extern volatile uint8_t IR_NewFrame;
extern volatile uint8_t IR_RawValue;
extern volatile uint8_t Tracking_RxByte;
extern volatile uint8_t IR_LastRxByte;
extern volatile uint8_t IR_RxTrace[8];
extern volatile uint8_t IR_RxTraceIndex;
extern volatile uint32_t IR_FrameCount;
extern volatile uint32_t IR_ErrorCount;
extern volatile uint32_t IR_RxByteCount;
extern volatile uint32_t IR_CommandCount;
extern volatile uint32_t IR_FrameInterval;   /* v30: 帧间隔ms */
extern volatile uint32_t IR_FrameLost;       /* v30: 丢帧计数 */

void Tracking_Init(void);
void Tracking_Read(void);
void Tracking_ParseByte(uint8_t data);
void Tracking_UartError(void);
uint8_t Tracking_GetSnapshot(uint8_t *raw, uint32_t *frame_tick,
                             uint32_t *frame_count);

#endif
