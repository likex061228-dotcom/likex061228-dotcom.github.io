#ifndef __OLED_H
#define __OLED_H

#include "main.h"

#define OLED_ADDR 0x3C

void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowString(uint8_t x, uint8_t y, const char *str);
void OLED_ShowNum(uint8_t x, uint8_t y, int32_t num, uint8_t len);
void OLED_ShowFloat(uint8_t x, uint8_t y, float num, uint8_t int_len, uint8_t dec_len);
void OLED_Refresh(void);
void OLED_Printf(uint8_t x, uint8_t y, const char *fmt, ...);

#endif
