/**
 * Emm_V5.h — ZhangDatou 闭环步进驱动器 串口协议
 *
 * TTL 直连, 115200-8-N-1, 默认校验 0x6B
 * 位置模式 13 字节命令
 * 本项目使用 USART3 (PC10/PC11)
 */

#ifndef __EMM_V5_H
#define __EMM_V5_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

/* ---------- 驱动器参数 ---------- */
#define EMM_ADDR         1       /* 电机地址 */
#define EMM_UART         huart3  /* 使用 USART3 (PC10-TX→驱动RX, PC11-RX←驱动TX) */
#define EMM_BAUDRATE     115200  /* 通讯波特率 */

/* 电机机械参数: 确保驱动器菜单细分设置与此一致 */
#define MOTOR_FULL_STEPS_PER_REV   200   /* 步进电机整步数/圈 */
#define MOTOR_MICROSTEP             16   /* 驱动器细分 */
#define MOTOR_PULSES_PER_REV       (MOTOR_FULL_STEPS_PER_REV * MOTOR_MICROSTEP)

/* ---------- 位置控制命令 ---------- */
#define CMD_POS_CTRL     0xFD    /* 位置模式功能码 */
#define DIR_CW           0x00    /* 顺时针 */
#define DIR_CCW          0x01    /* 逆时针 */
#define MODE_RELATIVE    0x00    /* 相对位置 */
#define MODE_ABSOLUTE    0x01    /* 绝对位置 */
#define SYNC_OFF         0x00    /* 立即执行 */
#define SYNC_ON          0x01    /* 等待同步信号 */

/* 最后一道软件保护: 单次相对运动最多允许的脉冲数 */
#define EMM_MAX_RELATIVE_PULSES   4

/* ---------- API ---------- */
HAL_StatusTypeDef Emm_V5_Pos_Control(uint8_t addr, uint8_t dir, uint16_t vel,
                                     uint8_t acc, uint32_t clk, uint8_t raF, uint8_t snF);
HAL_StatusTypeDef Emm_V5_Move_Relative(int32_t pulses, uint16_t vel, uint8_t acc);
HAL_StatusTypeDef Emm_V5_Move_Absolute(int32_t target_pulses, uint16_t vel, uint8_t acc);
void Emm_V5_Stop(uint8_t addr, uint8_t snF);
void Emm_V5_Enable(uint8_t addr, uint8_t en, uint8_t snF);

#endif /* __EMM_V5_H */
