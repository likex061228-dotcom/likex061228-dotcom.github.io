"""
2026 TI H problem - vehicle-mounted balance-ball vision for MaixCAM Pro.
2026年TI竞赛H题 - 基于MaixCAM Pro的车载平衡球视觉系统。

Open this complete folder in MaixVision and run main.py. The program:
在MaixVision中打开此完整文件夹并运行main.py。程序功能如下：
1. uses YOLO26 to identify the steel ball;
   使用YOLO26识别钢球；
2. refines its centre with local Hough-circle detection;
   通过局部霍夫圆检测精确定位钢球中心；
3. converts X position to centimetres relative to groove centre O;
   将X坐标转换为相对于凹槽中心O的厘米值；
4. keeps a short Alpha-Beta track through missed detections;
   在检测丢失时通过Alpha-Beta滤波器维持短期跟踪；
5. sends an annotated live image to MaixVision and the onboard LCD;
   将带标注的实时图像发送到MaixVision和板载屏；
6. records MP4 directly to MaixCAM Pro storage from the touchscreen.
   触摸屏启停录像，MP4直接保存在MaixCAM Pro本机。

The three files below must remain together:
以下三个文件必须放在一起：
  main.py
  steel_ball_v4.mud
  steel_ball_v4_int8.cvimodel
"""

import os  # 导入os模块，用于文件和路径操作
import time  # 导入time模块，用于时间相关操作

from maix import app, camera, display, image, nn, video, touchscreen, uart, pinmap, err  # 从maix库导入应用、摄像头、显示、图像、神经网络、录像、触摸屏、串口、引脚映射、错误处理模块

# ---------- UART for STM32 communication ----------
# ---------- 用于与STM32通信的UART串口配置 ----------
err.check_raise(  # 检查并抛出异常
    pinmap.set_pin_function("A16", "UART0_TX"),  # 将引脚A16设置为UART0的发送引脚
    "A16 UART0_TX mapping failed"  # 如果引脚映射失败，抛出此错误信息
)
err.check_raise(  # 检查并抛出异常
    pinmap.set_pin_function("A17", "UART0_RX"),  # 将引脚A17设置为UART0的接收引脚
    "A17 UART0_RX mapping failed"  # 如果引脚映射失败，抛出此错误信息
)

serial = uart.UART("/dev/ttyS0", 115200)  # 打开串口设备/dev/ttyS0，波特率115200，用于与STM32通信

UART_SEND_INTERVAL = 1  # 串口发送间隔帧数，1表示每帧都发送 (~30Hz)

# Independent NV21 channel for direct on-device MP4 recording. The RGB channel
# continues recognition at the same time; recording needs no PC-side process.
RECORD_WIDTH = 640
RECORD_HEIGHT = 480
RECORD_FPS = 20
RECORD_DIR = "/root/videos"
REC_BUTTON_X = 516
REC_BUTTON_Y = 420
REC_BUTTON_W = 118
REC_BUTTON_H = 52
TARGET_TOUCH_MARGIN_Y = 30


def uart_send(msg):  # 定义串口发送函数，参数msg为要发送的字符串消息
    try:  # 尝试执行以下代码块
        n = serial.write_str(msg)  # 通过串口写入字符串消息，返回写入的字节数
        return n > 0  # 如果写入字节数大于0，表示发送成功，返回True
    except Exception as e:  # 捕获所有异常，将异常对象赋值给e
        print("[UART] write err:", e)  # 打印UART写入错误信息和异常详情
        return False  # 发送失败，返回False


class LocalVideoRecorder:
    """Record MP4 on MaixCAM Pro without pausing the recognition channel."""

    def __init__(self, rgb_camera):
        self.camera = rgb_camera.add_channel(
            RECORD_WIDTH,
            RECORD_HEIGHT,
            image.Format.FMT_YVU420SP,
            fps=RECORD_FPS,
            buff_num=3,
        )
        os.makedirs(RECORD_DIR, exist_ok=True)
        self.writer = None
        self.active = False
        self.current_path = ""
        self.last_path = ""
        self.last_error = ""
        self.started_at = 0.0
        self.frames_written = 0

    @staticmethod
    def _new_path():
        now = time.localtime()
        stamp = "%04d%02d%02d_%02d%02d%02d" % (
            now.tm_year, now.tm_mon, now.tm_mday,
            now.tm_hour, now.tm_min, now.tm_sec,
        )
        path = "%s/balance_ball_%s.mp4" % (RECORD_DIR, stamp)
        suffix = 1
        while os.path.exists(path):
            path = "%s/balance_ball_%s_%02d.mp4" % (RECORD_DIR, stamp, suffix)
            suffix += 1
        return path

    def start(self):
        if self.active:
            return
        path = self._new_path()
        try:
            writer = video.Video(
                path=path,
                width=RECORD_WIDTH,
                height=RECORD_HEIGHT,
                format=image.Format.FMT_YVU420SP,
                time_base=RECORD_FPS,
                framerate=RECORD_FPS,
                capture=False,
                open=False,
            )
            err.check_raise(
                writer.bind_camera(self.camera),
                "MP4 recorder camera bind failed",
            )
            err.check_raise(
                writer.open(path, RECORD_FPS),
                "MP4 recorder open failed",
            )
            self.writer = writer
            self.current_path = path
            self.active = True
            self.last_error = ""
            self.started_at = time.monotonic()
            self.frames_written = 0
            print("[REC] device MP4 ON:", path)
        except Exception as exc:
            if self.writer is not None:
                try:
                    self.writer.close()
                except Exception:
                    pass
            self.writer = None
            self.current_path = ""
            self.active = False
            self.last_error = str(exc)
            print("[REC] device MP4 start failed; recognition continues:", exc)

    def update(self):
        """Encode one frame from the bound NV21 channel while recording."""
        if not self.active or self.writer is None:
            return
        try:
            self.writer.encode()
            self.frames_written += 1
        except Exception as exc:
            self.last_error = "encode: " + str(exc)
            print("[REC] device MP4 encode failed:", exc)
            self.stop()

    def stop(self):
        if not self.active:
            return
        saved_path = self.current_path
        try:
            if self.writer is not None:
                err.check_raise(
                    self.writer.finish(),
                    "MP4 recorder finish failed",
                )
                self.writer.close()
        except Exception as exc:
            self.last_error = "close: " + str(exc)
            print("[REC] device MP4 close warning:", exc)
        finally:
            self.writer = None
            self.current_path = ""
            self.active = False
            try:
                saved_ok = (
                    self.last_error == ""
                    and self.frames_written > 0
                    and os.path.exists(saved_path)
                    and os.path.getsize(saved_path) > 0
                )
            except Exception as exc:
                saved_ok = False
                self.last_error = "verify: " + str(exc)
            if saved_ok:
                self.last_path = saved_path
                print("[REC] device MP4 saved:", saved_path)
            else:
                self.last_path = ""
                if not self.last_error:
                    self.last_error = "no video data written"
                print("[REC] MP4 save verification failed:", self.last_error)

class TouchUiController:
    """Touch REC button and Req6 groove target selector."""

    def __init__(self, recorder):
        self.recorder = recorder
        self.touch = touchscreen.TouchScreen()
        self.rx_buffer = b""
        self.req6_selecting = False
        self.touch_down = False
        self.last_x = 0
        self.last_y = 0
        self.selected_x = None
        self.selected_cm = 0.0

    def poll_uart(self):
        """Read STM32 R6ON/R6OFF mode commands without blocking vision."""
        try:
            data = serial.read()
        except Exception as exc:
            print("[UART] read err:", exc)
            return
        if not data:
            return

        self.rx_buffer += data
        if len(self.rx_buffer) > 128:
            self.rx_buffer = self.rx_buffer[-128:]
        while b"\n" in self.rx_buffer:
            line, self.rx_buffer = self.rx_buffer.split(b"\n", 1)
            command = line.strip().upper()
            if command == b"R6ON":
                self.req6_selecting = True
                self.selected_x = None
                self.selected_cm = 0.0
                print("[R6] touch target selection ON")
            elif command == b"R6OFF":
                self.req6_selecting = False
                print("[R6] touch target selection OFF")

    @staticmethod
    def _inside(x, y, left, top, width, height):
        return left <= x < left + width and top <= y < top + height

    def _handle_click(self, x, y):
        if self._inside(
            x, y,
            REC_BUTTON_X, REC_BUTTON_Y,
            REC_BUTTON_W, REC_BUTTON_H,
        ):
            if self.recorder.active:
                self.recorder.stop()
            else:
                self.recorder.start()
            return

        target_top = GROOVE_ROI_Y - TARGET_TOUCH_MARGIN_Y
        target_height = GROOVE_ROI_H + TARGET_TOUCH_MARGIN_Y * 2
        if (
            self.req6_selecting
            and self._inside(
                x, y,
                GROOVE_X_LEFT, target_top,
                GROOVE_X_RIGHT - GROOVE_X_LEFT + 1,
                target_height,
            )
        ):
            selected_cm = pixel_to_cm(x)
            selected_cm = max(-12.0, min(12.0, selected_cm))
            self.selected_x = int(x)
            self.selected_cm = selected_cm
            uart_send("S%+07.2f\n" % selected_cm)
            print("[R6] target x=%d -> %+.2f cm" % (x, selected_cm))

    def poll_touch(self):
        while self.touch.available(0):
            x, y, pressed = self.touch.read()
            if pressed:
                self.touch_down = True
                self.last_x = x
                self.last_y = y
            elif self.touch_down:
                self.touch_down = False
                self._handle_click(self.last_x, self.last_y)

    def poll(self):
        self.poll_uart()
        self.poll_touch()

    def draw(self, img):
        button_color = COLOR_RED if self.recorder.active else COLOR_GREEN
        img.draw_rect(
            REC_BUTTON_X, REC_BUTTON_Y,
            REC_BUTTON_W, REC_BUTTON_H,
            button_color,
            thickness=-1,
        )
        img.draw_string(
            REC_BUTTON_X + 12,
            REC_BUTTON_Y + 13,
            "STOP REC" if self.recorder.active else "START REC",
            COLOR_WHITE,
        )

        # Recording state is shown directly on the MaixCAM Pro LCD. It is no
        # longer forwarded to the STM32 OLED.
        if self.recorder.active:
            elapsed = int(time.monotonic() - self.recorder.started_at)
            img.draw_string(
                8, 42,
                "REC ON  %02d:%02d  /root/videos" % (elapsed // 60, elapsed % 60),
                COLOR_RED,
            )
        elif self.recorder.last_error:
            img.draw_string(8, 42, "REC FAILED - recognition continues", COLOR_RED)
            # Show the real MaixPy exception on the LCD so recording can be
            # diagnosed without opening a terminal.
            error_text = self.recorder.last_error.replace("\n", " ")
            img.draw_string(8, 68, error_text[:72], COLOR_RED)
            if len(error_text) > 72:
                img.draw_string(8, 94, error_text[72:144], COLOR_RED)
        elif self.recorder.last_path:
            img.draw_string(
                8, 42,
                "SAVED: " + os.path.basename(self.recorder.last_path),
                COLOR_GREEN,
            )

        if self.req6_selecting:
            img.draw_string(8, 72, "R6: TOUCH GROOVE, THEN PRESS KEY3", COLOR_CYAN)
            if self.selected_x is not None:
                img.draw_line(
                    self.selected_x,
                    GROOVE_ROI_Y - 20,
                    self.selected_x,
                    GROOVE_ROI_Y + GROOVE_ROI_H + 20,
                    COLOR_CYAN,
                    thickness=3,
                )
                img.draw_string(
                    8, 100,
                    "TARGET %+.2f cm" % self.selected_cm,
                    COLOR_CYAN,
                )


# ---------------------------------------------------------------------------
# Model and camera
# 模型和摄像头配置
# ---------------------------------------------------------------------------

MODEL_LOCAL = "steel_ball_v4.mud"  # 模型文件的本地路径（与main.py同目录）
MODEL_FIXED = "/root/models/steel_ball_v4/steel_ball_v4.mud"  # 模型文件的固定路径（设备上的绝对路径）

# The model accepts a different image resolution and automatically resizes it.
# 模型接受不同的图像分辨率并自动调整大小。
# 640x480 provides more pixels for the final circle-centre measurement.
# 640x480为最终的圆心测量提供更多像素。
FRAME_WIDTH = 640  # 摄像头采集图像的宽度，单位像素
FRAME_HEIGHT = 480  # 摄像头采集图像的高度，单位像素
FRAME_FPS = 30  # 摄像头采集帧率，每秒30帧

# Run YOLO once every N display frames. Local traditional vision fills the
# frames between YOLO inferences.
# 每N个显示帧运行一次YOLO。YOLO推理之间的帧由局部传统视觉方法填充。
YOLO_INTERVAL = 2  # YOLO推理间隔帧数，隔帧运行YOLO以提升FPS
YOLO_CANDIDATE_CONF = 0.20  # YOLO候选检测的置信度阈值（跟踪中使用的较低阈值）
YOLO_NEW_TRACK_CONF = 0.40  # 新建跟踪时YOLO检测的置信度阈值（丢失后重新获取需要更高置信度）
YOLO_IOU_TH = 0.45  # YOLO非极大值抑制的IOU阈值


# ---------------------------------------------------------------------------
# Groove calibration
# 凹槽标定参数
# ---------------------------------------------------------------------------

# Adjust these values after the camera bracket is fixed. Yellow lines must
# coincide with the inner ends of the real 25 cm groove.
# 在摄像头支架固定后调整这些值。黄色线必须与实际25厘米凹槽的内端重合。
GROOVE_X_LEFT = 0  # 凹槽左端在图像中的X像素坐标（全宽）
GROOVE_X_RIGHT = FRAME_WIDTH - 1  # 凹槽右端在图像中的X像素坐标（全宽）
GROOVE_LENGTH_CM = 25.0  # 凹槽的实际物理长度，单位厘米

# Horizontal band containing only the groove and its steel ball.
# 水平带区域，仅包含凹槽及其钢球。
GROOVE_ROI_X = 0  # 凹槽ROI区域的左上角X坐标（全宽）
GROOVE_ROI_Y = 185  # 凹槽ROI区域的左上角Y坐标（缩窄以排除下方按钮）
GROOVE_ROI_W = FRAME_WIDTH  # 凹槽ROI区域的宽度（全宽）
GROOVE_ROI_H = 60   # 凹槽ROI区域的高度（y=185~245，仅保留球槽轨道）

# Display-only extension: show one additional band of the same width and
# height immediately above the recognition ROI. Recognition coordinates and
# search limits remain unchanged.
DISPLAY_VIEW_Y = max(0, GROOVE_ROI_Y - GROOVE_ROI_H)
DISPLAY_VIEW_H = GROOVE_ROI_H * 2

# Expected radius of a 1 cm steel ball in the 640x480 image.
# 1厘米钢球在640x480图像中的预期半径像素范围。
BALL_RADIUS_MIN = 6  # 钢球检测的最小半径，单位像素
BALL_RADIUS_MAX = 17  # 钢球检测的最大半径，单位像素
CIRCLE_THRESHOLD = 2200  # 霍夫圆检测的阈值，越高越严格，只有更明显的圆才会被检测到

# 钢球实际运动轨道的圆心Y范围（排除按钮、螺钉等圆形干扰物）
BALL_CENTER_Y_MIN = 195  # 球槽圆心Y坐标下限
BALL_CENTER_Y_MAX = 238  # 球槽圆心Y坐标上限

# YOLO钢球框合理尺寸（排除大框按钮、小噪点）
BALL_BOX_MIN_SIZE = 10   # 框宽/高最小像素
BALL_BOX_MAX_SIZE = 50   # 框宽/高最大像素

# 钢球框应接近正方形（排除长方形目标如按钮、LED）
BALL_BOX_ASPECT_MIN = 0.65  # 宽高比下限
BALL_BOX_ASPECT_MAX = 1.45  # 宽高比上限

# Local circle-search window around a YOLO box or predicted position.
# 围绕YOLO检测框或预测位置的局部圆形搜索窗口参数。
CIRCLE_BOX_MARGIN = 14  # 在YOLO检测框周围扩展的边距，扩大搜索范围
LOCAL_SEARCH_HALF_W = 55  # 局部搜索窗口的半宽度
LOCAL_SEARCH_HALF_H = 45  # 局部搜索窗口的半高度
MAX_CIRCLE_DISTANCE_PX = 55.0  # 圆与参考位置之间的最大允许距离（像素），超过此距离的圆被忽略

# Narrow full-groove reacquisition — used only when tracker is lost.
# 窄带全凹槽重新获取 — 仅在跟踪器丢失时使用。
# Scans the physical groove lane with strict multi-frame confirmation.
# 扫描物理凹槽通道，并使用严格的多帧确认机制。
GLOBAL_REACQUIRE_INTERVAL = 1   # 全凹槽扫描间隔帧数，frames between full-groove scans
GLOBAL_REACQUIRE_HALF_H = 42    # 窄带搜索区域的半高度，匹配凹槽高度，narrow Y band matching groove height
GLOBAL_REACQUIRE_THRESHOLD = 2000  # 全局重新获取时的霍夫圆检测阈值
REACQUIRE_CONFIRM_FRAMES = 3    # 必须连续看到一致的圆N次才确认，must see consistent circle N times
REACQUIRE_CONFIRM_DIST_PX = 40  # 确认帧之间允许的最大漂移距离（像素），max drift between confirm frames


# ---------------------------------------------------------------------------
# Temporal tracking
# 时序跟踪参数
# ---------------------------------------------------------------------------

FILTER_ALPHA = 0.60  # Alpha-Beta滤波器的Alpha系数，画面显示用平滑跟踪
FILTER_BETA = 0.06  # Alpha-Beta滤波器的Beta系数，速度估计更新速率
MAX_MISSED_FRAMES = 2  # 跟踪器允许的最大连续丢失帧数，超过此值认为跟踪丢失 (更快宣告丢失)
VELOCITY_DECAY = 0.75  # 丢失检测时速度的衰减系数，模拟钢球因摩擦减速
MAX_MEASUREMENT_JUMP_PX = 55.0  # 测量值允许的最大跳跃距离（像素），高速球允许更大
MAX_RESIDUAL_PX = 30.0  # 滤波器残差允许的最大值（像素），超过视为异常测量

# 双Alpha控制位置：球运动时高响应，静止时高抗噪
CONTROL_ALPHA_FAST = 0.92  # 球明显运动时，新测量权重92%
CONTROL_ALPHA_SLOW = 0.55  # 球基本静止时，新测量权重55%
CONTROL_SPEED_THRESHOLD = 8  # cm100/帧，低于此值用慢速alpha

DISPLAY_INTERVAL = 3  # 每3帧发送一次画面到MaixVision，优先保证检测和控制


COLOR_BLACK = image.Color.from_rgb(0, 0, 0)  # 定义黑色，用于遮罩管道外区域
COLOR_RED = image.Color.from_rgb(255, 40, 40)  # 定义红色，用于绘制YOLO检测框
COLOR_GREEN = image.Color.from_rgb(0, 255, 0)  # 定义绿色，用于绘制圆心和中心线
COLOR_CYAN = image.Color.from_rgb(0, 220, 255)  # 定义青色，用于绘制凹槽ROI区域
COLOR_YELLOW = image.Color.from_rgb(255, 220, 0)  # 定义黄色，用于绘制凹槽边界线和跟踪十字
COLOR_WHITE = image.Color.from_rgb(255, 255, 255)  # 定义白色，用于绘制搜索ROI框


def mask_outside_groove(img):  # 保留管道水平带，仅遮黑上方和下方
    """Fill top and bottom outside the groove band with black."""
    top = max(0, int(GROOVE_ROI_Y))
    bottom = min(FRAME_HEIGHT, int(GROOVE_ROI_Y + GROOVE_ROI_H))

    if top > 0:
        img.draw_rect(0, 0, FRAME_WIDTH, top, COLOR_BLACK, thickness=-1)
    if bottom < FRAME_HEIGHT:
        img.draw_rect(0, bottom, FRAME_WIDTH, FRAME_HEIGHT - bottom, COLOR_BLACK, thickness=-1)


def mask_outside_display_view(img):
    """Keep the groove plus one equal-size real-camera band above it visible."""
    top = max(0, int(DISPLAY_VIEW_Y))
    bottom = min(FRAME_HEIGHT, int(DISPLAY_VIEW_Y + DISPLAY_VIEW_H))

    if top > 0:
        img.draw_rect(0, 0, FRAME_WIDTH, top, COLOR_BLACK, thickness=-1)
    if bottom < FRAME_HEIGHT:
        img.draw_rect(0, bottom, FRAME_WIDTH, FRAME_HEIGHT - bottom, COLOR_BLACK, thickness=-1)


def clamp(value, lower, upper):  # 定义数值钳位函数，将value限制在lower和upper之间
    if value < lower:  # 如果值小于下限
        return lower  # 返回下限值
    if value > upper:  # 如果值大于上限
        return upper  # 返回上限值
    return value  # 值在范围内，原样返回


# ---------------------------------------------------------------------------
# 9-point measured distance calibration
# 9点实测距离标定（像素圆心X -> 真实距离cm）
# ---------------------------------------------------------------------------
# 按用户最新9张实测图建立，不强制左右像素比例相同：
#   185 -> +6 cm, 207 -> +5 cm, 229 -> +4 cm, 301 -> +1 cm
#   316 ->  0 cm
#   336 -> -1 cm, 408 -> -4 cm, 428 -> -5 cm, 452 -> -6 cm
# 标定点之间采用分段线性插值，因此每个给定点都会精确显示真实值。
CALIBRATION_PIXEL_X = (185.0, 207.0, 229.0, 301.0, 316.0,
                       336.0, 408.0, 428.0, 452.0)
CALIBRATION_TRUE_CM = ( 6.0,  5.0,  4.0,  1.0, 0.0,
                       -1.0, -4.0, -5.0, -6.0)
CALIBRATION_ZERO_X = 316.0

# ---------- ±5 cm target judgment lines (pixel coords from 9-point calibration) ----------
# ---------- ±5 cm 目标判定线（像素坐标来自9点标定） ----------
# Yellow target lines at exactly ±5 cm; white boundary lines at ±4 cm and ±6 cm.
# 黄色目标线在精确±5 cm处；白色边界线在±4 cm和±6 cm处。
# Judgment logic runs on STM32; MaixCAM only draws the visual reference lines.
# 判定逻辑在STM32上运行；MaixCAM仅绘制视觉参考线。
TARGET_PLUS5_X  = 207   # +5 cm target line  / +5 cm 目标线
TARGET_MINUS5_X = 428   # -5 cm target line  / -5 cm 目标线

PLUS5_MIN_X  = 185      # +6 cm boundary  / +6 cm 边界
PLUS5_MAX_X  = 229      # +4 cm boundary  / +4 cm 边界
MINUS5_MIN_X = 408      # -4 cm boundary  / -4 cm 边界
MINUS5_MAX_X = 452      # -6 cm boundary  / -6 cm 边界


def pixel_to_cm(x_px):
    """Use measured pixel/position points with piecewise-linear interpolation."""
    """使用实测像素/距离点进行分段线性插值。"""
    x = float(x_px)
    count = len(CALIBRATION_PIXEL_X)

    # 标定范围外分别沿最左、最右一段的比例继续外推。
    if x <= CALIBRATION_PIXEL_X[0]:
        index = 0
    elif x >= CALIBRATION_PIXEL_X[count - 1]:
        index = count - 2
    else:
        index = 0
        for i in range(count - 1):
            if CALIBRATION_PIXEL_X[i] <= x <= CALIBRATION_PIXEL_X[i + 1]:
                index = i
                break

    x0 = CALIBRATION_PIXEL_X[index]
    x1 = CALIBRATION_PIXEL_X[index + 1]
    cm0 = CALIBRATION_TRUE_CM[index]
    cm1 = CALIBRATION_TRUE_CM[index + 1]

    ratio = (x - x0) / (x1 - x0)
    value_cm = cm0 + ratio * (cm1 - cm0)

    # 槽长25 cm，最终输出限制在 -12.5 ... +12.5 cm。
    return clamp(value_cm, -GROOVE_LENGTH_CM * 0.5,
                 GROOVE_LENGTH_CM * 0.5)


def rect_intersection(rect_a, rect_b):  # 定义计算两个矩形交集面积的函数
    """Return intersection area of (x, y, w, h) rectangles."""
    """返回两个(x, y, w, h)矩形之间的交集面积。"""
    ax, ay, aw, ah = rect_a  # 解包矩形A的左上角坐标(ax, ay)和宽高(aw, ah)
    bx, by, bw, bh = rect_b  # 解包矩形B的左上角坐标(bx, by)和宽高(bw, bh)
    left = max(ax, bx)  # 交集矩形的左边界 = 两个矩形左边界的最大值
    top = max(ay, by)  # 交集矩形的上边界 = 两个矩形上边界的最大值
    right = min(ax + aw, bx + bw)  # 交集矩形的右边界 = 两个矩形右边界的最小值
    bottom = min(ay + ah, by + bh)  # 交集矩形的下边界 = 两个矩形下边界的最小值
    if right <= left or bottom <= top:  # 如果左右边界或上下边界没有交集（不相交或仅边界接触）
        return 0  # 返回交集面积为0
    return (right - left) * (bottom - top)  # 计算并返回交集矩形的面积（宽 × 高）


def object_is_in_groove(obj):  # 定义判断检测对象是否在凹槽区域内且尺寸合理的函数
    groove = (GROOVE_ROI_X, GROOVE_ROI_Y, GROOVE_ROI_W, GROOVE_ROI_H)  # 构造凹槽ROI区域的矩形元组
    box = (obj.x, obj.y, obj.w, obj.h)  # 构造检测对象边界框的矩形元组
    centre_x = obj.x + obj.w * 0.5  # 计算检测对象边界框的中心X坐标
    centre_y = obj.y + obj.h * 0.5  # 计算检测对象边界框的中心Y坐标
    centre_inside = (  # 判断中心点是否在凹槽ROI区域内
        GROOVE_ROI_X <= centre_x <= GROOVE_ROI_X + GROOVE_ROI_W  # 中心X坐标在凹槽ROI的X范围内
        and GROOVE_ROI_Y <= centre_y <= GROOVE_ROI_Y + GROOVE_ROI_H  # 中心Y坐标在凹槽ROI的Y范围内
    )
    if not centre_inside:
        return False

    # 只允许球槽实际轨道高度（排除按钮等不在轨道上的目标）
    if not (BALL_CENTER_Y_MIN <= centre_y <= BALL_CENTER_Y_MAX):
        return False

    # 排除过大或过小的框（按钮框约108×67，钢球框约20×20）
    if (
        obj.w < BALL_BOX_MIN_SIZE
        or obj.h < BALL_BOX_MIN_SIZE
        or obj.w > BALL_BOX_MAX_SIZE
        or obj.h > BALL_BOX_MAX_SIZE
    ):
        return False

    # 排除明显长方形目标（钢球框应为正方形）
    aspect = float(obj.w) / max(float(obj.h), 1.0)
    if not (BALL_BOX_ASPECT_MIN <= aspect <= BALL_BOX_ASPECT_MAX):
        return False

    return rect_intersection(box, groove) > 0  # 边界框与凹槽ROI有交集区域时返回True


class BallTracker:  # 定义钢球跟踪器类，使用Alpha-Beta滤波器进行一维位置跟踪
    """One-dimensional Alpha-Beta state tracker for the ball X position."""
    """一维Alpha-Beta状态跟踪器，用于跟踪钢球的X位置。"""

    def __init__(self):  # 跟踪器初始化方法
        self.x = 0.0  # 钢球当前估计的X像素位置
        self.v = 0.0  # 钢球当前估计的X方向速度（像素/秒）
        self.y = GROOVE_ROI_Y + GROOVE_ROI_H * 0.5  # 钢球Y位置，初始化为凹槽ROI的垂直中心
        self.radius = (BALL_RADIUS_MIN + BALL_RADIUS_MAX) * 0.5  # 钢球估计半径，初始化为最小和最大半径的平均值
        self.score = 0.0  # 当前跟踪的置信度分数
        self.last_time = 0.0  # 上次更新的时间戳
        self.misses = MAX_MISSED_FRAMES + 1  # 连续丢失帧计数，初始化为超过阈值表示跟踪未激活
        # ---- reacquisition state ----
        # ---- 重新获取状态 ----
        self.reacquire_x = 0.0  # 重新获取过程中候选圆的X坐标
        self.reacquire_y = 0.0  # 重新获取过程中候选圆的Y坐标
        self.reacquire_count = 0  # 重新获取连续确认的帧数计数
        self.reacquire_time = 0.0  # 重新获取过程中最近一次更新的时间戳

    def active(self):  # 判断跟踪器当前是否处于激活状态的方法
        return self.misses <= MAX_MISSED_FRAMES  # 连续丢失帧数不超过阈值时认为跟踪激活

    def predicted_x(self, now):  # 根据当前时间和运动模型预测钢球的X位置，参数now为当前时间
        if not self.active() or self.last_time == 0.0:  # 如果跟踪器未激活或者从未更新过
            return None  # 返回None表示无法预测
        dt = clamp(now - self.last_time, 0.005, 0.100)  # 计算时间差并钳位在5ms到100ms之间，防止异常时间值
        return clamp(  # 返回钳位后的预测X位置
            self.x + self.v * dt,  # 根据当前位置和速度预测新位置：x_pred = x + v * dt
            GROOVE_X_LEFT,  # 预测值下限：凹槽左端像素坐标
            GROOVE_X_RIGHT,  # 预测值上限：凹槽右端像素坐标
        )

    def update(self, measured_x, measured_y, radius, score, now):  # 用新的测量值更新跟踪器状态
        measured_x = clamp(  # 将测量到的X坐标钳位在有效范围内
            float(measured_x),  # 将测量值转换为浮点数
            GROOVE_X_LEFT,  # 下限：凹槽左端
            GROOVE_X_RIGHT,  # 上限：凹槽右端
        )

        if not self.active() or self.last_time == 0.0:  # 如果跟踪器未激活或是第一次更新
            self.x = measured_x  # 直接用测量值初始化位置估计
            self.v = 0.0  # 速度初始化为0
        else:  # 跟踪器处于激活状态，应用Alpha-Beta滤波
            dt = clamp(now - self.last_time, 0.005, 0.100)  # 计算并钳位时间差
            predicted = self.x + self.v * dt  # 根据上一步状态预测当前位置：x_pred = x + v * dt
            residual = measured_x - predicted  # 计算测量残差（新息）：测量值与预测值之差

            # 残差异常拒绝: 过大残差视为假测量, 按丢失处理
            if abs(residual) > MAX_RESIDUAL_PX:
                self.miss(now)
                return

            self.x = predicted + FILTER_ALPHA * residual  # 用Alpha系数平滑更新位置估计
            self.v += FILTER_BETA * residual / dt  # 用Beta系数更新速度估计

        self.y = float(measured_y)  # 更新钢球Y位置为最新测量值
        self.radius = float(radius)  # 更新钢球半径估计为最新测量值
        self.score = float(score)  # 更新跟踪置信度分数
        self.last_time = now  # 记录本次更新时间戳
        self.misses = 0  # 重置连续丢失帧计数为0（因为刚收到有效测量）

    def miss(self, now):  # 处理当前帧没有检测到钢球的情况，now为当前时间
        if not self.active():  # 如果跟踪器已经不活跃，无需处理
            return  # 直接返回
        dt = clamp(now - self.last_time, 0.005, 0.100)  # 计算并钳位时间差
        self.x = clamp(  # 用运动模型外推更新位置（仅预测，无测量修正）
            self.x + self.v * dt,  # 根据当前速度和位置外推新位置
            GROOVE_X_LEFT,  # 钳位下限
            GROOVE_X_RIGHT,  # 钳位上限
        )
        self.v *= VELOCITY_DECAY  # 速度衰减（模拟摩擦减速），乘以衰减系数0.75
        self.last_time = now  # 记录本次更新时间戳
        self.misses += 1  # 连续丢失帧计数加1

    def confirm_reacquire(self, circle, now):  # 多帧确认重新获取的圆是否有效，circle为候选圆对象
        """Multi-frame gate: only accept a circle seen consistently."""
        """多帧门控：只接受持续被看到的圆。"""
        x = float(circle.x())  # 获取候选圆的X中心坐标
        y = float(circle.y())  # 获取候选圆的Y中心坐标
        if (  # 判断是否与之前帧的候选圆一致
            self.reacquire_count > 0  # 之前已有候选圆
            and abs(x - self.reacquire_x) <= REACQUIRE_CONFIRM_DIST_PX  # X坐标变化在允许范围内
            and abs(y - self.reacquire_y) <= GLOBAL_REACQUIRE_HALF_H  # Y坐标变化在允许范围内
        ):
            self.reacquire_count += 1  # 位置一致，确认计数加1
        else:  # 位置不一致或是第一次候选
            self.reacquire_count = 1  # 重置确认计数为1，开始新的确认序列
        self.reacquire_x = x  # 保存当前候选圆的X坐标用于下一帧比较
        self.reacquire_y = y  # 保存当前候选圆的Y坐标用于下一帧比较
        self.reacquire_time = now  # 记录确认时间
        return self.reacquire_count >= REACQUIRE_CONFIRM_FRAMES  # 确认计数达到阈值时返回True，表示重新获取成功


def choose_yolo_candidate(objects, tracker, now):  # 从YOLO检测结果中选择最优的钢球候选对象
    """Select one class-0 detection using confidence and track continuity."""
    """根据置信度和跟踪连续性选择一个类别为0的检测对象。"""
    predicted_x = tracker.predicted_x(now)  # 获取跟踪器预测的当前X位置，可能为None
    best = None  # 初始化最优候选对象为None
    best_cost = 1e30  # 初始化最优代价为一个极大值，用于取最小代价

    for obj in objects:  # 遍历所有YOLO检测到的对象
        if obj.class_id != 0 or not object_is_in_groove(obj):  # 如果对象类别不是0（非钢球）或不在凹槽区域内
            continue  # 跳过该对象，继续下一个

        threshold = (  # 根据跟踪器状态选择置信度阈值
            YOLO_CANDIDATE_CONF if tracker.active()  # 跟踪激活时使用较低阈值0.20
            else YOLO_NEW_TRACK_CONF  # 跟踪丢失时使用较高阈值0.40
        )
        if obj.score < threshold:  # 如果对象置信度低于阈值
            continue  # 跳过该对象

        centre_x = obj.x + obj.w * 0.5  # 计算检测对象边界框的中心X坐标
        centre_y = obj.y + obj.h * 0.5  # 计算检测对象边界框的中心Y坐标

        if predicted_x is not None:  # 如果跟踪器能提供有效的预测位置
            dx = abs(centre_x - predicted_x)  # 计算检测中心与预测位置的X轴绝对距离
            if dx > MAX_MEASUREMENT_JUMP_PX:  # 如果距离超过最大允许跳跃值
                continue  # 跳过这个异常检测
        else:  # 跟踪器无法预测（未激活或首次运行）
            dx = abs(  # 计算检测中心与凹槽中心的X轴距离
                centre_x - (GROOVE_X_LEFT + GROOVE_X_RIGHT) * 0.5  # 距离凹槽中心的偏移量
            ) * 0.10  # 乘以0.10降低权重（因为没有先验信息）

        expected_y = (  # 期望的Y位置
            tracker.y if tracker.active()  # 跟踪激活时使用跟踪器记录的Y位置
            else GROOVE_ROI_Y + GROOVE_ROI_H * 0.5  # 跟踪未激活时使用凹槽ROI的垂直中心
        )
        cost = dx + abs(centre_y - expected_y) * 0.25  # 计算代价：X距离 + Y距离（权重0.25）
        cost -= obj.score * 30.0  # 减去置信度的加权值，置信度越高代价越低

        if cost < best_cost:  # 如果当前对象的代价小于当前最优代价
            best = obj  # 更新最优候选对象
            best_cost = cost  # 更新最优代价

    return best  # 返回最优候选对象（如果没有合适对象则返回None）


def clip_roi(x, y, w, h):  # 将搜索ROI裁剪到图像和凹槽ROI的有效范围内
    """Clip a search ROI to both the image and the calibrated groove ROI."""
    """将搜索ROI裁剪到图像边界和标定的凹槽ROI内。"""
    left = max(int(x), GROOVE_ROI_X, 0)  # 左边界 = x、凹槽ROI左端、0三者中的最大值
    top = max(int(y), GROOVE_ROI_Y, 0)  # 上边界 = y、凹槽ROI上端、0三者中的最大值
    right = min(  # 右边界 = 三个值中的最小值
        int(x + w),  # 请求ROI的右边界
        GROOVE_ROI_X + GROOVE_ROI_W,  # 凹槽ROI的右边界
        FRAME_WIDTH,  # 图像宽度边界
    )
    bottom = min(  # 下边界 = 三个值中的最小值
        int(y + h),  # 请求ROI的下边界
        GROOVE_ROI_Y + GROOVE_ROI_H,  # 凹槽ROI的下边界
        FRAME_HEIGHT,  # 图像高度边界
    )
    if right - left < BALL_RADIUS_MAX * 2:  # 如果裁剪后宽度小于钢球最大直径的2倍
        return None  # 区域太小无法检测，返回None
    if bottom - top < BALL_RADIUS_MAX * 2:  # 如果裁剪后高度小于钢球最大直径的2倍
        return None  # 区域太小无法检测，返回None
    return [left, top, right - left, bottom - top]  # 返回裁剪后的ROI列表：[左, 上, 宽, 高]


def circle_search_roi(yolo_obj, tracker, now):  # 确定圆检测的搜索ROI区域
    if yolo_obj is not None:  # 如果有YOLO检测结果
        return clip_roi(  # 以YOLO检测框为基础扩展边距，裁剪搜索区域
            yolo_obj.x - CIRCLE_BOX_MARGIN,  # 左边界 = YOLO框左端 - 边距
            yolo_obj.y - CIRCLE_BOX_MARGIN,  # 上边界 = YOLO框上端 - 边距
            yolo_obj.w + CIRCLE_BOX_MARGIN * 2,  # 宽度 = YOLO框宽度 + 2倍边距
            yolo_obj.h + CIRCLE_BOX_MARGIN * 2,  # 高度 = YOLO框高度 + 2倍边距
        )

    predicted_x = tracker.predicted_x(now)  # 获取跟踪器预测的X位置
    if predicted_x is None:  # 如果无法预测位置（跟踪器未激活）
        return None  # 返回None，无法确定搜索区域

    return clip_roi(  # 以预测位置为中心，裁剪局部搜索区域
        predicted_x - LOCAL_SEARCH_HALF_W,  # 左边界 = 预测X - 半宽度
        tracker.y - LOCAL_SEARCH_HALF_H,  # 上边界 = 跟踪器Y - 半高度
        LOCAL_SEARCH_HALF_W * 2,  # 宽度 = 2倍半宽度
        LOCAL_SEARCH_HALF_H * 2,  # 高度 = 2倍半高度
    )


def refine_circle(img, search_roi, reference_x, reference_y):  # 在局部ROI内精确定位钢球圆
    """Find the most plausible steel-ball circle in a small local ROI."""
    """在小的局部ROI内找到最可信的钢球圆。"""
    if search_roi is None:  # 如果搜索ROI为空
        return None  # 直接返回None

    circles = img.find_circles(  # 在图像中查找圆（霍夫圆检测）
        roi=search_roi,  # 在指定的ROI区域内搜索
        x_stride=2,  # X方向的搜索步长，2像素步长平衡速度和精度
        y_stride=2,  # Y方向的搜索步长，2像素步长平衡速度和精度
        threshold=CIRCLE_THRESHOLD,  # 霍夫圆检测的阈值（2200）
        x_margin=10,  # 圆心的X方向合并边距，用于去重
        y_margin=10,  # 圆心的Y方向合并边距，用于去重
        r_margin=4,  # 半径的合并边距，用于去重
        r_min=BALL_RADIUS_MIN,  # 检测圆的最小半径
        r_max=BALL_RADIUS_MAX,  # 检测圆的最大半径
        r_step=1,  # 半径搜索步长，1像素精细搜索
    )

    expected_radius = (BALL_RADIUS_MIN + BALL_RADIUS_MAX) * 0.5  # 计算期望的钢球半径（最小和最大的平均值）
    best = None  # 初始化最优圆为None
    best_cost = 1e30  # 初始化最优代价为极大值

    for circle in circles:  # 遍历所有检测到的圆
        # 排除按钮、螺钉等不在球槽中心线上的圆
        if not (BALL_CENTER_Y_MIN <= circle.y() <= BALL_CENTER_Y_MAX):
            continue

        dx = float(circle.x()) - float(reference_x)  # 计算圆心的X坐标与参考X坐标的差值
        dy = float(circle.y()) - float(reference_y)  # 计算圆心的Y坐标与参考Y坐标的差值
        distance = (dx * dx + dy * dy) ** 0.5  # 计算圆心到参考点的欧几里得距离
        if distance > MAX_CIRCLE_DISTANCE_PX:  # 如果距离超过最大允许值
            continue  # 跳过这个圆

        cost = distance + abs(circle.r() - expected_radius) * 2.0  # 代价 = 距离 + 半径偏差 × 2.0
        cost -= circle.magnitude() * 0.0001  # 减去圆强度的加权值，圆越明显代价越低
        if cost < best_cost:  # 如果当前代价小于最优代价
            best = circle  # 更新最优圆
            best_cost = cost  # 更新最优代价

    return best  # 返回最优圆（如果没有找到合适的圆则返回None）


def global_reacquire_circle(img, tracker, now):  # 全局重新获取：在跟踪丢失时扫描整个凹槽来寻找钢球
    """Reacquire a lost ball inside the narrow physical groove lane.

    Only runs when the tracker is inactive (lost).  Scans the full groove
    width in a narrow Y band and requires multi-frame confirmation before
    the result is accepted.
    """
    """在狭窄的物理凹槽通道内重新获取丢失的钢球。

    仅在跟踪器非活跃（丢失）时运行。在窄Y带内扫描整个凹槽宽度，
    并需要多帧确认后才接受结果。
    """
    band_y = int(tracker.y) if tracker.last_time > 0 else (  # 确定搜索带的Y中心：如果跟踪器有历史则用记录的Y，否则用默认值
        GROOVE_ROI_Y + GROOVE_ROI_H // 2  # 使用凹槽ROI的垂直中心作为默认搜索Y坐标
    )
    roi = clip_roi(  # 裁剪搜索ROI：覆盖整个凹槽宽度但Y方向收窄
        GROOVE_ROI_X,  # X起点 = 凹槽ROI左端
        band_y - GLOBAL_REACQUIRE_HALF_H,  # Y起点 = 搜索带中心 - 半高度
        GROOVE_ROI_W,  # 宽度 = 整个凹槽ROI宽度
        GLOBAL_REACQUIRE_HALF_H * 2,  # 高度 = 2倍半高度（窄带搜索）
    )
    if roi is None:  # 如果裁剪后ROI无效
        return None, None  # 返回两个None表示无法搜索

    # When lost, prefer circles near the last known position or groove centre.
    # 丢失状态时，优先考虑靠近最后已知位置或凹槽中心的圆。
    if tracker.last_time > 0:  # 如果跟踪器之前有有效状态
        ref_x = clamp(tracker.x, GROOVE_X_LEFT, GROOVE_X_RIGHT)  # 使用跟踪器最后的X位置作为参考，钳位到有效范围
    else:  # 跟踪器从未有过有效状态
        ref_x = (GROOVE_X_LEFT + GROOVE_X_RIGHT) * 0.5  # 使用凹槽中心作为参考X

    circles = img.find_circles(  # 在图像中查找圆（霍夫圆检测）
        roi=roi,  # 在窄带ROI区域内搜索
        x_stride=2,  # X方向搜索步长
        y_stride=2,  # Y方向搜索步长
        threshold=GLOBAL_REACQUIRE_THRESHOLD,  # 使用全局重新获取的阈值（2000，比局部检测稍低）
        x_margin=10,  # 圆心X方向去重边距
        y_margin=10,  # 圆心Y方向去重边距
        r_margin=4,  # 半径去重边距
        r_min=BALL_RADIUS_MIN,  # 最小半径
        r_max=BALL_RADIUS_MAX,  # 最大半径
        r_step=1,  # 半径搜索步长
    )

    expected_radius = (BALL_RADIUS_MIN + BALL_RADIUS_MAX) * 0.5  # 计算期望的钢球半径
    best = None  # 初始化最优圆
    best_cost = 1e30  # 初始化最优代价

    for circle in circles:  # 遍历所有检测到的圆
        # 排除按钮、螺钉等不在球槽中心线上的圆
        if not (BALL_CENTER_Y_MIN <= circle.y() <= BALL_CENTER_Y_MAX):
            continue

        dx = float(circle.x()) - ref_x  # 圆心的X坐标与参考X坐标的差值
        dy = float(circle.y()) - band_y  # 圆心的Y坐标与搜索带中心的差值
        dist = (dx * dx + dy * dy) ** 0.5  # 计算圆心到参考点的欧几里得距离
        cost = dist + abs(circle.r() - expected_radius) * 2.0  # 代价 = 距离 + 半径偏差 × 2.0
        cost -= circle.magnitude() * 0.0001  # 减去圆强度加权值
        if cost < best_cost:  # 如果当前代价更优
            best = circle  # 更新最优圆
            best_cost = cost  # 更新最优代价

    return best, roi  # 返回最优圆和使用的ROI区域（best可能为None）


def draw_overlay(  # 定义绘制叠加层的函数，在图像上添加可视化标注
    img,  # 要绘制的图像对象
    tracker,  # 钢球跟踪器对象
    yolo_obj,  # YOLO检测到的最优候选对象（可能为None）
    refined_circle,  # 霍夫圆检测精炼后的圆（可能为None）
    search_roi,  # 当前使用的搜索ROI区域（可能为None）
    fps,  # 当前帧率值
):
    centre_x = int(CALIBRATION_ZERO_X)  # 真实0 cm中心线：X=316像素

    img.draw_rect(  # 绘制凹槽ROI的青色边框矩形
        GROOVE_ROI_X,  # 矩形左上角X
        GROOVE_ROI_Y,  # 矩形左上角Y
        GROOVE_ROI_W,  # 矩形宽度
        GROOVE_ROI_H,  # 矩形高度
        COLOR_CYAN,  # 青色
        thickness=2,  # 线宽2像素
    )
    img.draw_line(  # 绘制凹槽左端黄色边界线
        GROOVE_X_LEFT,  # 起点X
        GROOVE_ROI_Y,  # 起点Y（ROI顶部）
        GROOVE_X_LEFT,  # 终点X（垂直向下）
        GROOVE_ROI_Y + GROOVE_ROI_H,  # 终点Y（ROI底部）
        COLOR_YELLOW,  # 黄色
        thickness=2,  # 线宽2像素
    )
    img.draw_line(  # 绘制凹槽右端黄色边界线
        GROOVE_X_RIGHT,  # 起点X
        GROOVE_ROI_Y,  # 起点Y（ROI顶部）
        GROOVE_X_RIGHT,  # 终点X（垂直向下）
        GROOVE_ROI_Y + GROOVE_ROI_H,  # 终点Y（ROI底部）
        COLOR_YELLOW,  # 黄色
        thickness=2,  # 线宽2像素
    )
    img.draw_line(  # 绘制凹槽中心的绿色参考线
        centre_x,  # 起点X
        GROOVE_ROI_Y,  # 起点Y
        centre_x,  # 终点X（垂直向下）
        GROOVE_ROI_Y + GROOVE_ROI_H,  # 终点Y
        COLOR_GREEN,  # 绿色
        thickness=2,  # 线宽2像素
    )

    # ---- ±5 cm target lines (yellow, thick) ----
    # ---- ±5 cm 目标线（黄色，粗线） ----
    img.draw_line(
        TARGET_PLUS5_X, GROOVE_ROI_Y,
        TARGET_PLUS5_X, GROOVE_ROI_Y + GROOVE_ROI_H,
        COLOR_YELLOW, thickness=2,
    )
    img.draw_line(
        TARGET_MINUS5_X, GROOVE_ROI_Y,
        TARGET_MINUS5_X, GROOVE_ROI_Y + GROOVE_ROI_H,
        COLOR_YELLOW, thickness=2,
    )

    # ---- ±4 cm / ±6 cm boundary lines (white, thin) ----
    # ---- ±4 cm / ±6 cm 合格区边界线（白色，细线） ----
    for line_x in (PLUS5_MIN_X, PLUS5_MAX_X, MINUS5_MIN_X, MINUS5_MAX_X):
        img.draw_line(
            line_x, GROOVE_ROI_Y,
            line_x, GROOVE_ROI_Y + GROOVE_ROI_H,
            COLOR_WHITE, thickness=1,
        )

    if search_roi is not None:  # 如果存在搜索ROI
        img.draw_rect(  # 绘制白色搜索ROI边框
            search_roi[0],  # ROI左上角X
            search_roi[1],  # ROI左上角Y
            search_roi[2],  # ROI宽度
            search_roi[3],  # ROI高度
            COLOR_WHITE,  # 白色
            thickness=1,  # 线宽1像素
        )

    if yolo_obj is not None:  # 如果存在YOLO检测结果
        img.draw_rect(  # 绘制红色YOLO检测框
            yolo_obj.x,  # 检测框左上角X
            yolo_obj.y,  # 检测框左上角Y
            yolo_obj.w,  # 检测框宽度
            yolo_obj.h,  # 检测框高度
            COLOR_RED,  # 红色
            thickness=2,  # 线宽2像素
        )

    if refined_circle is not None:  # 如果存在精炼后的圆检测结果
        img.draw_circle(  # 绘制绿色圆形标记
            refined_circle.x(),  # 圆心X坐标
            refined_circle.y(),  # 圆心Y坐标
            refined_circle.r(),  # 圆的半径
            COLOR_GREEN,  # 绿色
            thickness=3,  # 线宽3像素
        )

    if tracker.active():  # 如果跟踪器处于激活状态
        x_px = int(tracker.x)  # 获取跟踪器估计的X像素位置并转为整数
        x_cm = pixel_to_cm(tracker.x)  # 将像素坐标转换为厘米坐标
        img.draw_cross(  # 绘制黄色十字标记表示跟踪位置
            x_px,  # 十字中心X
            int(tracker.y),  # 十字中心Y（转为整数）
            COLOR_YELLOW,  # 黄色
            size=10,  # 十字大小10像素
            thickness=2,  # 线宽2像素
        )
        img.draw_line(  # 绘制红色竖线穿过跟踪位置
            x_px,  # 起点X
            GROOVE_ROI_Y,  # 起点Y（ROI顶部）
            x_px,  # 终点X（垂直向下）
            GROOVE_ROI_Y + GROOVE_ROI_H,  # 终点Y（ROI底部）
            COLOR_RED,  # 红色
            thickness=2,  # 线宽2像素
        )
        img.draw_string(  # 绘制钢球位置（厘米）和置信度文本
            8,  # 文本左上角X坐标
            8,  # 文本左上角Y坐标
            "BALL x=%+.2f cm  conf=%.2f" % (x_cm, tracker.score),  # 格式化字符串：位置(厘米)和置信度
            COLOR_GREEN,  # 绿色文字
        )
        img.draw_string(  # 绘制像素位置和丢失计数文本
            8,  # 文本左上角X坐标
            36,  # 文本左上角Y坐标
            "pixel=%d miss=%d" % (x_px, tracker.misses),  # 格式化字符串：像素坐标和丢失帧数
            COLOR_WHITE,  # 白色文字
        )
    else:  # 跟踪器未激活（丢失状态）
        if tracker.reacquire_count > 0:  # 如果正在进行重新获取确认
            img.draw_string(  # 绘制重新获取进度文本
                8, 8,  # 文本位置(X, Y)
                "REACQ %d/%d" % (tracker.reacquire_count,  # 当前确认帧数
                                  REACQUIRE_CONFIRM_FRAMES),  # 所需确认帧数
                COLOR_YELLOW,  # 黄色文字
            )
        else:  # 没有进行重新获取
            img.draw_string(8, 8, "BALL NOT FOUND", COLOR_RED)  # 绘制"未找到钢球"的红色警告文字
        img.draw_string(  # 绘制丢失状态下的调试信息
            8,  # 文本X坐标
            36,  # 文本Y坐标
            "miss=%d  x=%.0f v=%.0f" % (tracker.misses, tracker.x,  # 丢失帧数、当前位置X、当前速度V
                                         tracker.v),
            COLOR_YELLOW,  # 黄色文字
        )

    img.draw_string(  # 绘制帧率FPS和YOLO间隔信息
        8,  # 文本X坐标
        FRAME_HEIGHT - 34,  # 文本Y坐标（图像底部上方34像素处）
        "FPS %.1f  YOLO/FRAME %d" % (fps, YOLO_INTERVAL),  # 格式化字符串：帧率和YOLO间隔
        COLOR_WHITE,  # 白色文字
    )

def get_model_path():  # 获取模型文件的路径，优先使用本地路径
    if os.path.exists(MODEL_LOCAL):  # 检查本地路径是否存在模型文件
        return MODEL_LOCAL  # 返回本地模型路径
    if os.path.exists(MODEL_FIXED):  # 检查固定路径是否存在模型文件
        return MODEL_FIXED  # 返回固定模型路径
    raise RuntimeError(  # 两个路径都不存在，抛出运行时错误
        "steel_ball_v4.mud not found; run the complete MaixVision folder"  # 错误提示信息
    )


def main():  # 主函数，程序的入口点
    if GROOVE_X_RIGHT <= GROOVE_X_LEFT:  # 验证凹槽标定参数的有效性：右端必须大于左端
        raise ValueError(  # 参数无效，抛出值错误异常
            "GROOVE_X_RIGHT must be greater than GROOVE_X_LEFT"  # 错误提示信息
        )

    model_path = get_model_path()  # 获取模型文件的路径
    detector = nn.YOLO26(model=model_path)  # 加载YOLO26目标检测模型，创建检测器对象
    print(  # 打印模型信息到控制台
        "MODEL:",  # 模型标签
        model_path,  # 模型文件路径
        "input=",  # 输入尺寸标签
        detector.input_width(),  # 模型期望的输入宽度
        "x",  # 乘号分隔符
        detector.input_height(),  # 模型期望的输入高度
    )

    # RGB main channel: YOLO, traditional vision and MaixVision display.
    # RGB主通道：用于YOLO、传统视觉和MaixVision显示。
    cam = camera.Camera(  # 创建摄像头对象
        FRAME_WIDTH,  # 图像宽度640
        FRAME_HEIGHT,  # 图像高度480
        detector.input_format(),  # 使用模型要求的像素格式（与YOLO输入匹配）
        fps=FRAME_FPS,  # 帧率30fps
        buff_num=2,  # 帧缓冲数量2，平衡延迟与稳定性
    )
    # A second hardware camera channel writes MP4 to local storage while the
    # RGB channel keeps recognition running. No PC recorder is required.
    recorder = LocalVideoRecorder(cam)
    touch_ui = TouchUiController(recorder)
    # MaixCAM Pro 板载屏。与 MaixVision 共用同一张带检测标注的 RGB 图像。
    disp = display.Display()

    tracker = BallTracker()  # 创建钢球跟踪器实例
    fast_x_px = None  # 控制用快速位置（低延迟，双Alpha平滑）
    fast_v_px = 0.0  # 快速位置的变化量，用于判断球运动/静止
    frame_index = 0  # 初始化帧计数为0
    last_frame_time = time.monotonic()  # 记录上一帧的时间（使用单调时钟，不受系统时间调整影响）
    fps = 0.0  # 初始化帧率显示值为0

    while not app.need_exit():  # 主循环：应用不需要退出时持续运行
        loop_time = time.monotonic()  # 记录当前循环迭代的开始时间
        touch_ui.poll()  # 非阻塞处理触摸和STM32要求6状态，不中断识别
        img = cam.read()  # 从摄像头读取一帧图像
        recorder.update()  # 录像开启时，从独立NV21通道编码并写入一帧MP4

        # Preserve an unmodified camera copy for LCD/MaixVision. Only this
        # display copy gets the extra equal-size visible band above the groove.
        display_img = img.copy()
        mask_outside_display_view(display_img)

        # 仅保留管道区域，其他区域全部变黑，排除桌面、电机、铝型材等背景干扰
        mask_outside_groove(img)

        run_yolo = frame_index % YOLO_INTERVAL == 0  # 判断当前帧是否需要运行YOLO（每YOLO_INTERVAL帧运行一次）
        yolo_obj = None  # 初始化YOLO检测结果为None

        if run_yolo:  # 如果当前帧需要运行YOLO检测
            objects = detector.detect(  # 调用YOLO检测器在图像上执行目标检测
                img,  # 输入图像
                conf_th=YOLO_CANDIDATE_CONF,  # 置信度阈值0.20
                iou_th=YOLO_IOU_TH,  # NMS的IOU阈值0.45
                fit=image.Fit.FIT_CONTAIN,  # 图像适应模式：保持比例缩放以包含整个图像
            )
            yolo_obj = choose_yolo_candidate(  # 从检测结果中选择最优钢球候选
                objects,  # YOLO检测到的所有对象列表
                tracker,  # 当前跟踪器状态
                loop_time,  # 当前时间
            )

        search_roi = circle_search_roi(yolo_obj, tracker, loop_time)  # 确定霍夫圆检测的搜索ROI
        refined_circle = None  # 初始化精炼圆检测结果为None
        measured_this_frame = False  # 本帧是否有真实测量 (非预测)

        if search_roi is not None:  # 如果存在有效的搜索ROI
            if yolo_obj is not None:  # 如果有YOLO检测结果
                reference_x = yolo_obj.x + yolo_obj.w * 0.5  # 使用YOLO框中心X作为参考
                reference_y = yolo_obj.y + yolo_obj.h * 0.5  # 使用YOLO框中心Y作为参考
            else:  # 没有YOLO结果，使用跟踪器预测
                reference_x = tracker.predicted_x(loop_time)  # 使用跟踪器预测的X位置
                reference_y = tracker.y  # 使用跟踪器记录的Y位置

            refined_circle = refine_circle(  # 在搜索ROI内执行霍夫圆精炼检测
                img,  # 输入图像
                search_roi,  # 搜索ROI区域
                reference_x,  # 参考X坐标
                reference_y,  # 参考Y坐标
            )

        # --- Reacquisition: scan full groove when tracker is lost ---
        # --- 重新获取：跟踪丢失时扫描整个凹槽 ---
        used_reacquire = False  # 标记是否使用了全局重新获取的结果
        if (  # 判断是否需要触发全局重新获取
            refined_circle is None  # 精炼圆检测没有结果
            and yolo_obj is None  # YOLO也没有检测到钢球
            and not tracker.active()  # 跟踪器处于丢失状态
            and frame_index % GLOBAL_REACQUIRE_INTERVAL == 0  # 到达全局重新获取的间隔帧
        ):
            reacq_circle, reacq_roi = global_reacquire_circle(  # 调用全局重新获取函数
                img, tracker, loop_time  # 传入图像、跟踪器和当前时间
            )
            if reacq_roi is not None:  # 如果返回了有效的搜索ROI
                search_roi = reacq_roi  # 将搜索ROI更新为全局重新获取的ROI（用于显示）
            if reacq_circle is not None:  # 如果找到了候选圆
                if tracker.confirm_reacquire(reacq_circle, loop_time):  # 多帧确认候选圆是否有效
                    refined_circle = reacq_circle  # 确认通过，将候选圆作为精炼结果
                    used_reacquire = True  # 标记使用了重新获取

        if refined_circle is not None:  # 如果存在有效的精炼圆检测结果
            if used_reacquire:  # 如果是通过全局重新获取得到的
                score = 0.30  # 赋一个固定较低的置信度分数0.30
            elif yolo_obj is not None:  # 如果有YOLO检测支持
                score = yolo_obj.score  # 使用YOLO检测的置信度分数
            else:  # 没有YOLO支持（仅基于跟踪器预测的局部搜索）
                score = tracker.score  # 保持使用跟踪器之前的置信度分数

            # 双Alpha快速位置：球运动时92%新值，静止时55%新值
            measured_x = float(refined_circle.x())
            if fast_x_px is None:
                fast_x_px = measured_x
            else:
                delta = measured_x - fast_x_px
                fast_v_px = abs(delta)
                # 像素变化转cm/帧判断运动状态
                span = float(GROOVE_X_RIGHT - GROOVE_X_LEFT)
                speed_cm100 = fast_v_px * GROOVE_LENGTH_CM * 100.0 / span
                alpha = CONTROL_ALPHA_FAST if speed_cm100 > CONTROL_SPEED_THRESHOLD else CONTROL_ALPHA_SLOW
                fast_x_px += alpha * delta

            tracker.update(  # 用精炼圆更新跟踪器状态
                refined_circle.x(),  # 圆的X中心坐标
                refined_circle.y(),  # 圆的Y中心坐标
                refined_circle.r(),  # 圆的半径
                score,  # 置信度分数
                loop_time,  # 当前时间
            )
            measured_this_frame = True  # 本帧有真实测量
        elif yolo_obj is not None:  # 没有精炼圆但有YOLO检测结果
            # 霍夫圆验证失败，但YOLO置信度足够高时，使用YOLO框中心作为回退位置。
            # 这解决了"检测到小球却不能输出坐标"的问题。
            # 要求较高置信度（≥0.40）以防止误识别按钮驱动电机。
            if yolo_obj.score >= YOLO_NEW_TRACK_CONF:
                fallback_x = yolo_obj.x + yolo_obj.w * 0.5  # YOLO框中心X
                fallback_y = yolo_obj.y + yolo_obj.h * 0.5  # YOLO框中心Y
                fallback_r = (yolo_obj.w + yolo_obj.h) * 0.25  # 估算半径

                # 双Alpha快速位置（YOLO回退也更新控制位置）
                measured_x = float(fallback_x)
                if fast_x_px is None:
                    fast_x_px = measured_x
                else:
                    delta = measured_x - fast_x_px
                    fast_v_px = abs(delta)
                    span = float(GROOVE_X_RIGHT - GROOVE_X_LEFT)
                    speed_cm100 = fast_v_px * GROOVE_LENGTH_CM * 100.0 / span
                    alpha = CONTROL_ALPHA_FAST if speed_cm100 > CONTROL_SPEED_THRESHOLD else CONTROL_ALPHA_SLOW
                    fast_x_px += alpha * delta

                tracker.update(fallback_x, fallback_y, fallback_r,
                               yolo_obj.score, loop_time)
                measured_this_frame = True
                if frame_index % 10 == 0:
                    print("[FALLBACK] circle fail, using YOLO centre x=%.1f conf=%.2f" % (fallback_x, yolo_obj.score))
            else:
                # YOLO置信度不足，按丢失处理，防止误识别
                tracker.miss(loop_time)
                measured_this_frame = False
        else:  # 既没有精炼圆也没有YOLO检测
            tracker.miss(loop_time)  # 通知跟踪器本帧丢失，进行预测外推

        # ---- UART send: position in cm to STM32 ----
        # ---- 串口发送：将厘米位置发送给STM32 (仅真实测量, 不发送预测位置) ----
        if (
            measured_this_frame                          # 本帧有真实测量
            and (frame_index % UART_SEND_INTERVAL == 0)  # 到达发送间隔
            and tracker.active()                         # 跟踪器激活
        ):
            x_cm = pixel_to_cm(fast_x_px)  # 用快速位置（低延迟双Alpha），非显示用tracker.x
            msg = "X%+07.2f\n" % x_cm  # 格式化消息：如"X+12.50\n"，7字符宽、带符号、2位小数
            ok = uart_send(msg)  # 通过串口发送消息，返回发送是否成功
            if frame_index % 10 == 0:  # 每10帧打印一次调试信息
                print("[UART TX]", repr(msg), "ok=", ok)  # 打印发送的消息内容和发送结果

        frame_index += 1  # 帧计数加1（放在所有检测逻辑之后，确保帧索引一致）

        frame_dt = max(loop_time - last_frame_time, 0.001)  # 计算帧间隔时间，最小0.001秒防止除零
        instant_fps = 1.0 / frame_dt  # 计算瞬时帧率 = 1 / 帧间隔
        fps = (  # 使用指数移动平均平滑帧率显示
            instant_fps  # 如果fps还是初始值0
            if fps == 0.0  # 第一帧时直接用瞬时帧率
            else fps * 0.90 + instant_fps * 0.10  # 旧值权重90%，新值权重10%，平滑过渡
        )
        last_frame_time = loop_time  # 更新上一帧时间为当前时间

        draw_overlay(  # 在图像上绘制所有可视化叠加层
            display_img,  # 显示图像；识别仍使用严格球槽ROI图像
            tracker,  # 跟踪器对象
            yolo_obj,  # YOLO检测结果
            refined_circle,  # 精炼圆结果
            search_roi,  # 搜索ROI
            fps,  # 当前帧率
        )
        touch_ui.draw(display_img)

        if frame_index % DISPLAY_INTERVAL == 0:
            disp.show(display_img)  # 在 MaixCAM Pro 板载屏显示扩展后的真实画面
            display.send_to_maixvision(display_img)  # 每N帧发送一次画面，节省处理时间

    recorder.stop()


main()  # 调用主函数，启动程序
