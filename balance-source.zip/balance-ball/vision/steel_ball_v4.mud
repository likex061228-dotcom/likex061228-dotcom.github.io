[basic]
type = cvimodel
model = steel_ball_v4_int8.cvimodel

[extra]
model_type = yolo26
input_type = rgb
mean = 0, 0, 0
scale = 0.00392156862745098, 0.00392156862745098, 0.00392156862745098
labels = steel_ball
