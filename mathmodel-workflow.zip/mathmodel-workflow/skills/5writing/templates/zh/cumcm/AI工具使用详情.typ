#set page(paper: "a4", margin: 25mm)
#set text(size: 11pt, lang: "zh")
#set par(justify: true, leading: 0.65em)

= AI工具使用详情

本文件必须根据竞赛期间的真实记录填写并单独编译为 `AI工具使用详情.pdf`，放入支撑材料。任何未知工具型号、用途、交互过程或人工核验情况均保持“PENDING”，不得猜测补齐。

== 所用工具名称、版本或型号

PENDING

== 具体使用目的和环节

PENDING

== 主要提示方式与使用过程

PENDING

== 采纳、人工修改和核验情况

PENDING（本项只能由参赛者确认）
