---
name: 6verity
description: "数学建模竞赛最终验证和验收阶段，支持 Typst 和 LaTeX 双引擎。用于论文写完后检查章节数量、标题顺序、图表引用、数值一致性、占位符、内部文件泄露、参考文献、代码可复现性、编译和提交就绪状态。"
allowed-tools: Bash(*), Read, Write, Edit, Grep, Glob, Agent, WebSearch, WebFetch
---

# 验证和验收（Typst / LaTeX）

本 skill 是完整工作流的最后一关。它不重新建模、不生成新结果、不代替写作阶段重写论文；它负责发现硬错误、修复可直接修复的问题，并输出 `reports/VERIFY_REPORT.md`。

## 方案 B：双门禁总验收

验收必须同时消费 `evidence/score-evidence-matrix.json`、`evidence/claim-registry.json`、`evidence/diagnostic-registry.json` 和 `figures/figure-plan.json`，并回查 `problem/problem-contract.json`。科学门禁检查方向、独立单位、量纲、约束、Oracle、机器诊断、误差和论断证据；数据图的 `diagnostic_ids` 必须指向已通过诊断，场景/机理/流程图的 `structural_evidence` 必须与当前题意、算法或运行文件哈希一致。提交门禁检查官方格式、匿名、代码/支撑材料、AI 声明与最终 PDF。排版编译成功不能覆盖科学门禁失败。

任一关键歧义、重要论断、核心图的三层审核或 AI 人工核验仍为 `PENDING`，必须写 `submission_ready=false`。只有参赛者本人完成题面、数据、模型、数值和 AI 采纳结果的人工核对后，才能将对应状态改为 `APPROVED`。

## 数学建模规范参考

如需领域判断，读取 `../_references/math_modeling_norms.md` 中的"论文验收与一致性"小节。该文件只是规范知识库，不是固定执行流程；具体目录、入口文件、结果文件和图表目录由当前项目结构决定。

## 阶段边界

- 本阶段负责：结构验收、文本质量门禁、图表引用检查、结果一致性检查、Typst/LaTeX 编译检查、PDF 视觉检查、提交清单。
- 本阶段不负责：重新设计模型、重新跑大规模实验、重新组织整篇论文。
- 发现硬错误时，优先做小范围修复；如果需要回到前序阶段，写入 `reports/VERIFY_REPORT.md` 并标记为未通过。

## 2026 CUMCM 硬门禁

全国赛/国赛/CUMCM 必须核对：正文不超过 30 页、不要目录、A4 四边至少 25 mm；“AI工具使用声明”位于参考文献之前；使用 AI 时支撑材料包含 `AI工具使用详情.pdf`。详情中的采纳、修改和人工核验只能由参赛者确认。人工核验仍为 `PENDING` 时，验证报告不得写提交就绪。竞赛期间不得在 GitHub 等平台浏览、发布或讨论与当届赛题有关的内容；赛前固定的离线通用组件可以运行。

官方没有最低页数，附录页数不限。验收报告必须分别给出摘要页数、正文页数、附录页数和总页数；正文超过 30 页才触发官方页数 FAIL。正文约 23--27 页只是内部质量目标，偏离目标只能标为质量复核 `PENDING`，不能伪报官方违规。AI 声明与参考文献在附录前，按保守口径计入正文。

排版验收还必须核对：正文默认 12pt；表格和图题不得小于 10pt；中文正文、中文标题与西文分别使用可嵌入的 SimSun、SimHei、Times New Roman 或已批准的等价字体。编译后使用 `pdffonts` 检查实际嵌入字体，不能只根据 Typst/LaTeX 源码声明判定通过。显式小字号、伪粗体、图表编号风格漂移和不均衡分页记为版式问题。

## 输入

由模型先根据当前工作区判断项目布局，再把实际路径传给检查脚本。常见输入包括但不限于：

1. 论文入口文件：`main.typ`（Typst）或 `main.tex`（LaTeX）。
2. 正文章节目录或若干正文文件（`.typ` 或 `.tex`）。
3. 参考文献文件（`references.typ` 或 `references.tex`）。
4. 前序阶段的分析、建模、结果、图示报告。
5. 图表目录
6. 可复现代码目录。
7. 编译后的 PDF，或可由入口文件编译得到的输出 PDF。

不要假设论文目录一定叫 `paper/`，也不要假设结果文件一定在项目根。若项目使用不同命名，按实际结构传参并在 `reports/VERIFY_REPORT.md` 中说明。

## 工作流程


### Step 1: 运行文本质量门禁

优先运行本 skill 的脚本。脚本按入口文件扩展名自动选择检查逻辑（`.typ` → Typst 检查，`.tex` → LaTeX 检查）：

```bash
set -o pipefail
mkdir -p _tmp
SCRIPT_PATH="<按当前 skill 实际位置确定>/scripts/writing_check.sh"
bash "$SCRIPT_PATH" \
  --paper-dir "$PAPER_DIR" \
  --main "$MAIN_FILE" \
  --sections-dir "$SECTIONS_DIR" \
  --references "$REFERENCES_FILE" \
  --figures-dir "$FIGURES_DIR" \
  --results-file "$RESULTS_FILE" \
  --problem-analysis "$PROBLEM_ANALYSIS_FILE" \
  --all-results "$ALL_RESULTS_FILE" \
  | tee _tmp/writing_check.log
```

如果本 skill 被复制到其他目录，使用实际脚本路径。可以先运行 `bash <script> --help` 查看参数。不要把脚本路径、论文目录或文件名写死在验收逻辑中。

脚本只扫描文本，不生成论文，也不编译 PDF。它的 `FAIL` 属于硬错误，必须修复后重跑。

### Step 2: 章节数量和标题顺序

**Typst 引擎**检查：

- 入口 `.typ` 文件中 `#include("...")` 的数量是否与实际正文结构匹配。
- include 顺序是否符合文件名前缀顺序，例如 `1_...`, `2_...`, `3_...`。
- 每个 section 是否有明确一级标题（`= 标题`，等号后有空格）。
- 标题顺序是否符合所选论文类型。

**LaTeX 引擎**检查：

- 入口 `.tex` 文件中 `\input{...}` 或 `\include{...}` 的数量是否与实际正文结构匹配。
- 章节顺序是否符合文件名前缀顺序。
- 每个 section 是否有 `\section{}` 或对应级别标题。

通用检查（两种引擎）：

- 章节文件是否缺失、重复引用、未被引用。
- 如果题目不是三问，不强行要求三段问题章节；按 `ANALYSIS_MODELING_REPORT.md` 的子问题数量核对。

### Step 3: 图表和章节匹配

**Typst 引擎**检查：

- 图表目录中的 PDF 是否在正文中被引用。
- `#figure(image(...), caption: [...])` 的图片是否真实存在。图片路径必须相对于 `.typ` 文件。
- 数据图是否放在对应结果/分析章节，非数据流程图是否放在方法/总体思路章节。

**LaTeX 引擎**检查：

- `\includegraphics{}` 引用的图片文件是否真实存在。路径相对于 `.tex` 文件。
- `\caption{}` 是否存在。
- 数据图是否放在对应结果/分析章节。

通用检查（两种引擎）：

- 连续图表之间是否有足够解释文字。
- caption 是否过长、过泛或与图意不一致。
- 图表编号、正文引用和章节语义是否一致。

不要生成 `*_typst_includes.typ` 或 `*_latex_includes.tex`；图表必须直接嵌在对应 section 中。

### Step 4: 写作质量和泄露检查

检查并修复：

- `TODO`、`PLACEHOLDER`、`待补充`、`待续写`、`示例数据` 等占位符。
- 论文正文出现内部工作流文件名、临时目录名、代码目录名或结果 JSON 路径。
- 过多列表式写作（Typst 中大量 `#list`、`enum`，LaTeX 中大量 `\begin{itemize}`、`\begin{enumerate}`）。
- 段落反复以"如图""由图""图 X 展示了"开头。
- 图表后没有解释、公式后没有变量含义、结论只报数不解释。

### Step 5: 数值和结果一致性

检查：

- 论文中的关键数值必须来自当前工作流声明的结果记录或结果 JSON。
- `evidence/diagnostic-registry.json` 中来源、生成器和输出的 SHA-256 必须与当前文件一致，数值必须有限且不变量不得失败。
- 目标函数值、误差指标、排名、权重、阈值、灵敏度结果不得与结果记录冲突。
- 如果存在汇总结果 JSON，抽取关键指标并确认论文正文中有对应结果。
- 公式中的符号应在符号说明或正文首次出现处解释。

发现数值冲突时，不要自行发明新结果；应回到结果记录或代码输出修正论文。

### Step 6: 引用和模板规范

检查：

- 参考文献文件是否存在，或模板是否采用了其他真实参考文献机制。
- 正文引用标记（Typst 的 `@label`/`#super`，LaTeX 的 `\cite{}`）是否能对应到真实参考文献。
- 中文论文 caption、表题、摘要语言保持中文；英文论文保持英文。
- 选定的模板入口是否保留所选比赛模板的必要封面、摘要、编号、页眉页脚或提交格式。
- 不要把模板结构误删成普通空白文档。


### Step 7: 编译

**Typst 编译**：

```bash
command -v typst >/dev/null 2>&1 && typst compile "$MAIN_FILE" "$OUTPUT_PDF"
```

**LaTeX 编译**：

```bash
command -v xelatex >/dev/null 2>&1 && xelatex -interaction=nonstopmode "$MAIN_FILE" && xelatex -interaction=nonstopmode "$MAIN_FILE"
```

xelatex 需跑两遍解决目录和交叉引用。

编译失败必须修复语法、路径、图片引用或模板问题后重跑。编译通过后确认输出 PDF 非空。

### Step 8: PDF 视觉检查

如果模型有视觉能力，必须把编译后的 PDF 每页导出为 PNG 并逐页查看。这个步骤用于发现纯文本扫描和编译器无法发现的版式错误。

优先使用系统已有工具导出页面 PNG；不要为了视觉检查引入沉重依赖。可选命令示例：

```bash
mkdir -p _tmp/pdf-pages
if command -v pdftoppm >/dev/null 2>&1; then
  pdftoppm -png -r 160 "$OUTPUT_PDF" _tmp/pdf-pages/page
elif command -v mutool >/dev/null 2>&1; then
  mutool draw -r 160 -o _tmp/pdf-pages/page-%03d.png "$OUTPUT_PDF"
elif command -v magick >/dev/null 2>&1; then
  magick -density 160 "$OUTPUT_PDF" _tmp/pdf-pages/page-%03d.png
else
  echo "No PDF rasterizer found; record visual check as not run."
fi
```

导出后逐页检查：

- 页面是否空白、缺页、页数异常或页面尺寸异常。
- 标题、摘要、正文、页眉页脚、页码是否被裁切或位置明显错误。
- 表格是否超出页边距，单元格文字是否重叠、溢出、被截断。
- 图片、图题、表题、公式、编号是否与正文重叠。
- 公式是否越界，长公式是否压到页边距或下一段文字。
- 列表、段落、脚注、参考文献是否出现异常大空白、重叠或孤立残行。
- 中文/英文/数学符号字体是否明显缺字、乱码或 fallback 异常。
- 封面、摘要页、目录、附录等模板关键页面是否保留比赛要求的视觉结构。

如果是模板转换或已有参考 PDF 的项目，还应将不同引擎的 PDF 都逐页导出 PNG，按页对比版式差异；页数或页面尺寸不一致必须记录为硬错误或明确说明原因。

如果模型没有视觉能力，必须在 `reports/VERIFY_REPORT.md` 中明确写出“未执行视觉检查”的原因，并至少完成 PDF 非空、页数、页面尺寸等可程序化检查。

未执行视觉检查时不得写 PASS 或“可以提交”；总状态必须保持 `PENDING`，直到逐页视觉检查实际完成。程序化页数/尺寸检查不能替代图表真值、裁切、重叠、乱码和阅读尺度检查。

### Step 9: 写验收报告

创建 `reports/VERIFY_REPORT.md`：

```markdown
# 验证和验收报告

## 结论
PASS / PENDING / FAIL

## 检查项
| 检查项 | 结果 | 说明 |
| --- | --- | --- |

## 章节结构

## 图表引用

## 数值一致性

## 文本质量门禁

## 编译

## PDF 视觉检查

## 仍需处理的问题
```

只有当硬错误都修复、文本门禁通过、核心图表都引用、数值一致、编译成功且逐页视觉检查实际通过，同时所有必需人工审核已由参赛者批准时，才写 `PASS`。编译或视觉检查无法执行、关键科学歧义未决、AI/题意/数值/核心图人工审核未完成时写 `PENDING`，不得用“已记录原因”升级为 PASS。

## 硬错误标准

以下问题必须判定 `FAIL`：

- 缺少选定的论文入口文件（`main.typ` 或 `main.tex`）或核心正文。
- 论文入口引用的章节文件不存在。
- Typst 入口缺少 `#include`；LaTeX 入口缺少 `\input`/`\include`。
- 正文章节缺少一级标题（Typst `= ` 后缺空格，LaTeX `\section{}` 缺失）。
- 章节顺序明显错误或重复。
- 正文仍有占位符。
- 正文泄露内部工作流文件名。
- 引用的图片不存在。
- 关键数值与结果记录冲突。
- 编译器可用但论文编译失败。
- 编译后的 PDF 为空、缺页、页数异常或页面尺寸异常且无法解释。
- 视觉检查发现正文、表格、图片、公式、页眉页脚、页码等关键元素重叠、裁切、越界或乱码。

## 警告标准

以下问题可判定为 `WARN`，但应尽量修复：

- 未引用的备用图片。
- 某章节过短或明显不均衡。
- caption 偏长。
- 参考文献偏少。
- 图表后解释文字不足。
- 视觉检查工具不可用且已记录原因：总状态仍为 `PENDING`，只能作为待办说明，不能判定 PASS。
- 代码完整复现耗时过长，只做了轻量检查。

### 整改证据闭环

三视角评委发现写入 `reviews/review-resolution.json`，运行 `code/review_resolution.py`。P0/P1 为 OPEN 或 ACCEPTED_RISK 时阻断；RESOLVED 必须有整改说明、当前证据 SHA-256、`reviewed_input_hash` 和复审 PASS。证据文件改变后旧解决状态失效。该门禁只证明闭环可追溯，不能替代科学判断；最终人工审核未批准时 `submission_ready=false`。

## Claude 融合后的新增验收

- 读取 `assets/advanced-figure-catalog.json`，条件图的前置证据缺失时保持 `PENDING`，默认阻断装饰性弦图、拥挤环形热图、伪连续三维和超密集矩阵。
- 审计 `evidence/visual-claim-trace.json`：源数据与生成脚本的 SHA-256、原子图题结论、正文支持结论、定位和局限必须完整；同时检查登记结论的正向引用与正文实质使用的反向覆盖。
- 图表按最终入文尺寸验收；源代码不得使用 `bbox_inches="tight"` 逃避尺寸检查。颜色不是唯一编码，图题不在图片内部重复写论文总标题。
- 运行 `audit_prose_quality` 后，风格提示只能记为 `ADVISORY`，不输出 AIGC 概率；人工读者旅程和承重段落检查没有完成时保持 `PENDING`。

运行 `code/composite_figure_audit.py` 审计 `figures/composite-figure-contract.json`：逐面板复算来源哈希和事实，跨面板核对稳定 ID，并把图中主数字与最终 PDF 提取正文逐项比较。任何一层错配均阻断；人工科学审核未完成时 `submission_ready=false`。
