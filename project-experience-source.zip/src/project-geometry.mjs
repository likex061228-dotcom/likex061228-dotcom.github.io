// Illustrative mechanism dimensions, not a measurement of the physical build.
export function linkage(angle){
 if(!Number.isFinite(angle)||Math.abs(angle)>.100001)throw Error('管倾角超过示意机构的范围');
 const fixed={x:-.125,z:.25},motor={x:.07,z:.20},end={x:fixed.x+.25*Math.cos(angle),z:fixed.z+.25*Math.sin(angle)},r=.03,L=.075,dx=end.x-motor.x,dz=end.z-motor.z,d=Math.hypot(dx,dz),a=(r*r-L*L+d*d)/(2*d),h=Math.sqrt(Math.max(0,r*r-a*a));
 if(d>r+L||d<Math.abs(r-L))throw Error('此倾角下机构不能闭合');
 const pin={x:motor.x+a*dx/d+h*dz/d,z:motor.z+a*dz/d-h*dx/d};
 return{fixed,motor,end,pin};
}
