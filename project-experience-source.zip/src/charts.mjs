export function drawChart(canvas,rows,reference,mode,project){
 const ctx=canvas.getContext('2d'),w=1000,h=270;ctx.clearRect(0,0,w,h);const motion=mode==='motion';
 const channels=project==='balance'?['球位置 / cm','目标 / cm']:project==='car'?['前向距离 / m','避障阈值 / m']:['弹跳光点 / 颗','总光点 / 颗'];
 if(motion)channels.splice(0,2,'速度 / m/s','加速度 / m/s²');
 const data=rows.map(r=>({t:r.t,a:motion?r.speed:r.a,b:motion?r.acceleration:r.b})),old=(reference||[]).map(r=>({t:r.t,a:motion?r.speed:r.a,b:motion?r.acceleration:r.b}));
 const values=[...data,...old].flatMap(r=>[r.a,r.b]).filter(Number.isFinite);let lo=Math.min(0,...values),hi=Math.max(.01,...values);const span=hi-lo;lo-=span*.12;hi+=span*.12;
 const time0=data[0]?.t||0,ref0=old[0]?.t||0,duration=Math.max(2,((data.at(-1)?.t||0)-time0),((old.at(-1)?.t||0)-ref0));
 const X=t=>60+t/duration*910,Y=v=>228-(v-lo)/(hi-lo)*205;
 ctx.font='12px Consolas,monospace';ctx.lineWidth=1;for(let i=0;i<5;i++){const v=lo+(hi-lo)*i/4,y=Y(v);ctx.strokeStyle='#2a443d';ctx.beginPath();ctx.moveTo(60,y);ctx.lineTo(970,y);ctx.stroke();ctx.fillStyle='#829c8b';ctx.fillText(v.toPrecision(3),3,y+4);const t=duration*i/4;ctx.fillText(t.toFixed(1)+'s',X(t)-10,254);}
 ctx.save();ctx.beginPath();ctx.rect(60,12,910,218);ctx.clip();for(const [list,base,dashed]of [[old,ref0,true],[data,time0,false]])for(const [key,color]of [['a',dashed?'#7599a8':'#afe0bf'],['b',dashed?'#7d7776':'#dfbd8b']]){ctx.strokeStyle=color;ctx.lineWidth=dashed?1.6:2;ctx.setLineDash(dashed?[6,5]:[]);ctx.beginPath();list.forEach((r,i)=>i?ctx.lineTo(X(r.t-base),Y(r[key])):ctx.moveTo(X(r.t-base),Y(r[key])));ctx.stroke();}ctx.restore();
 return channels;
}
export function comparison(rows,reference,project){if(!rows.length||!reference?.length)return '';const metric=data=>project==='balance'?Math.max(...data.map(r=>Math.abs(r.a-r.b))):project==='car'?Math.min(...data.map(r=>r.a)):Math.max(...data.map(r=>r.a));const a=metric(reference),b=metric(rows),unit=project==='balance'?'cm':project==='car'?'m':'颗',name=project==='balance'?'窗口最大目标误差':project==='car'?'窗口最小前向距离':'窗口最多弹跳光点';return `${name}：A ${a.toFixed(3)} ${unit} / B ${b.toFixed(3)} ${unit}。比较窗口为各自保留的最近20秒，以窗口起点对齐。`;}
