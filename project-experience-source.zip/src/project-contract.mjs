// Version 2 checkpoints deliberately omit trace samples; comparison traces stay local.
const MAX_BYTES=60000;
const fail=()=>{throw Error('实验格式无效或超出安全范围');};
function object(v,keys){if(!v||typeof v!=='object'||Array.isArray(v)||![Object.prototype,null].includes(Object.getPrototypeOf(v))||Reflect.ownKeys(v).some(k=>typeof k!=='string'||!keys.includes(k)))fail();}
function number(v,min=-1e6,max=1e6){if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max)fail();return v;}
function fields(v,keys,min=-1e6,max=1e6){object(v,keys);if(keys.some(k=>!Object.hasOwn(v,k)))fail();return Object.fromEntries(keys.map(k=>[k,number(v[k],min,max)]));}
const numeric='servoAngle scanLeft scanRight time speed omega acceleration front left right phaseAge turnSign scans collisions ball ballV angle observed observedV cameraAge cameraClock brake trackError particleTick progress lastCourse maxError settleAge outboundAt stopError traceClock'.split(' ');
const booleans='contact visionLost safeStop ballEscaped completed outboundReached offTrack taskResult'.split(' ');
const textKeys=['status','phase','carMode'];
const complex=['pose','manual','driveCommand','soundCommand','sensors','mics','particles','cameraQueue','events'];
const allowed=[...numeric,...booleans,...textKeys,...complex];
function snapshot(input){object(input,allowed);const out={};for(const [k,v] of Object.entries(input)){
 if(numeric.includes(k)){const counters=['particleTick','scans','collisions'];const nonnegative=['time','phaseAge','cameraAge','cameraClock',...counters];out[k]=number(v,nonnegative.includes(k)?0:-1e6,nonnegative.includes(k)?1e9:1e6);if(counters.includes(k)&&!Number.isInteger(v))fail();continue;}
 if(booleans.includes(k)){if(typeof v!=='boolean')fail();out[k]=v;continue;}
 if(textKeys.includes(k)){if(typeof v!=='string'||v.length>300)fail();out[k]=v;continue;}
 if(k==='pose'){out[k]=fields(v,['x','y','a']);number(v.x,-100,100);number(v.y,-100,100);continue;}
 if(k==='manual'){out[k]=fields(v,['v','w'],-1,1);continue;}
 if(k==='driveCommand'||k==='soundCommand'){out[k]=fields(v,['v','w'],-3,3);continue;}
 if(!Array.isArray(v))fail();
 if(k==='sensors'||k==='mics'){if(v.length!==(k==='sensors'?8:2))fail();out[k]=v.map(x=>number(x));}
 else if(k==='particles'){if(v.length!==0&&v.length!==64)fail();const cells=new Set();out[k]=v.map(p=>{const q=fields(p,['x','y','vx','vy','rx','ry','h','vh']);if(!Number.isInteger(q.x)||!Number.isInteger(q.y)||q.x<0||q.x>31||q.y<0||q.y>7||q.h<0)fail();const id=q.x+','+q.y;if(cells.has(id))fail();cells.add(id);return q;});}
 else if(k==='cameraQueue'){if(v.length>128)fail();out[k]=v.map(p=>fields(p,['at','x']));}
 else if(k==='events'){if(v.length>64)fail();out[k]=v.map(p=>{object(p,['t','text']);if(typeof p.text!=='string'||p.text.length>300)fail();return{t:number(p.t,0,1e9),text:p.text};});}
 }return out;}
function validateContinuation(state,saved){
 // Every field in a freshly created model is mandatory; optional runtime fields
 // have explicit dependencies below, so deletion cannot silently reset dynamics.
 for(const key of Object.keys(state))if(allowed.includes(key)&&!Object.hasOwn(saved,key))fail();
 const taskOnly=['progress','lastCourse','maxError','settleAge','events','outboundAt','stopError','outboundReached','offTrack','taskResult'];
 if(state.project!=='balance'&&taskOnly.some(k=>Object.hasOwn(saved,k)))fail();
 if(saved.completed&&state.project!=='balance')fail();
 if(saved.outboundReached&&(state.project!=='balance'||state.config.scenario!=='req3'||!Object.hasOwn(saved,'outboundAt')))fail();
 if(Object.hasOwn(saved,'taskResult')&&!saved.completed)fail();
 if(state.project!=='car'){
  if(saved.phase!=='drive'||['carMode','soundCommand','scanLeft','scanRight'].some(k=>Object.hasOwn(saved,k)))fail();
  return;
 }
 const phases={manual:['drive'],sound:['soundSample','soundPulse'],avoid:['drive','brake','scanLeft','scanRight','scanCenter','turn','backup','backupStop','spin']};
 if(saved.carMode===undefined){if(saved.time!==0||saved.phase!=='drive'||Object.hasOwn(saved,'soundCommand'))fail();return;}
 if(saved.carMode!==state.config.scenario||!Object.hasOwn(phases,saved.carMode)||!phases[saved.carMode].includes(saved.phase)||!Object.hasOwn(saved,'soundCommand'))fail();
 if(['scanRight','scanCenter','turn','backup','backupStop','spin'].includes(saved.phase)&&!Object.hasOwn(saved,'scanLeft'))fail();
 if(['scanCenter','turn','backup','backupStop','spin'].includes(saved.phase)&&!Object.hasOwn(saved,'scanRight'))fail();
 if(Object.hasOwn(saved,'scanRight')&&!Object.hasOwn(saved,'scanLeft'))fail();

}
function boardPose(v){return fields(v,['rx','ry'],-Math.PI*2,Math.PI*2);}
function size(value){let text;try{text=JSON.stringify(value);}catch{fail();}if(typeof text!=='string'||new TextEncoder().encode(text).length>MAX_BYTES)fail();return text;}
export function tiltToGravity(rx,ry){number(rx,-Math.PI*2,Math.PI*2);number(ry,-Math.PI*2,Math.PI*2);return{x:Math.cos(rx)*Math.sin(ry),y:(-Math.sin(rx))||0,normal:Math.cos(rx)*Math.cos(ry)};}
export function seededState(engine,project,config,seed=1){number(seed,0,4294967295);if(!Number.isInteger(seed))fail();const state=engine.parse(JSON.stringify({version:1,project,config}));state.seed=seed;if(project==='matrix'&&state.config.scenario==='beads'){let n=seed>>>0;const random=()=>{n=(n+0x6D2B79F5)>>>0;let t=n;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};state.particles=[];for(let x=0;x<32;x++){const a=Math.floor(random()*8),b=(a+1+Math.floor(random()*7))%8;for(const y of [a,b])state.particles.push({x,y,vx:0,vy:0,rx:0,ry:0,h:0,vh:0});}}return state;}
export function createExperiment(engine,state,board={rx:0,ry:0}){const candidate={};for(const key of allowed)if(Object.hasOwn(state,key))candidate[key]=state[key];const result={version:2,scene:JSON.parse(engine.serialize(state)),snapshot:snapshot(candidate),seed:state.seed??1,board:boardPose(board)};restoreExperiment(engine,result);return result;}
export function restoreExperiment(engine,value){size(value);if(value?.version===1){const state=engine.parse(JSON.stringify(value));state.seed=1;return{state,board:{rx:0,ry:0}};}object(value,['version','scene','snapshot','seed','board']);if(value.version!==2)fail();const seed=number(value.seed,0,4294967295);if(!Number.isInteger(seed))fail();const state=engine.parse(JSON.stringify(value.scene));const saved=snapshot(value.snapshot);validateContinuation(state,saved);for(const key of ['time','pose','speed','omega','particles','cameraQueue'])if(!Object.hasOwn(saved,key))fail();if(state.project==='matrix'&&saved.particles.length!==64||state.project!=='matrix'&&saved.particles.length!==0)fail();if(state.project==='matrix'&&saved.particles.some(p=>!engine.allowed(p.x,p.y,state.config.scenario)))fail();Object.assign(state,saved,{seed,trace:[]});return{state,board:boardPose(value.board)};}
// Percent-encoded JSON is portable across Node and browsers, including Unicode.
export function encodeExperiment(value){return encodeURIComponent(size(value));}
export function decodeExperiment(text){if(typeof text!=='string'||text.length>MAX_BYTES*9)fail();try{const decoded=decodeURIComponent(text.replace(/^#/,''));if(new TextEncoder().encode(decoded).length>MAX_BYTES)fail();return JSON.parse(decoded);}catch{throw Error('无法读取实验链接或 JSON 编码');}}





