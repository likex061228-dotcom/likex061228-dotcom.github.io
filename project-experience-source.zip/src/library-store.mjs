export const LIBRARY_KEY='Like_x.project.experiments.v2';
export const LIBRARY_LIMIT=20;
export const LIBRARY_SLUGS=['balance','smartcar','matrix'];
export const LIBRARY_EMPTY='还没有本机实验。打开任一项目，调整后点击“保存到本机”。';

export function isRecord(record){
  return Boolean(record)&&typeof record.id==='string'&&typeof record.name==='string'&&LIBRARY_SLUGS.includes(record.slug)&&Boolean(record.experiment)&&typeof record.experiment==='object';
}

export function parseRecords(raw){
  let list;
  try{list=JSON.parse(raw||'[]');}catch{throw new Error('保存格式无效');}
  if(!Array.isArray(list))throw new Error('保存格式无效');
  return list.slice(0,LIBRARY_LIMIT).filter(isRecord);
}

export function withoutRecord(list,id){
  return Array.isArray(list)?list.filter(record=>record.id!==id):[];
}

export function summary(records){
  const count=Array.isArray(records)?records.length:0;
  if(!count)return LIBRARY_EMPTY;
  return `本机共 ${count} / ${LIBRARY_LIMIT} 份实验；新的保存会挤掉最旧一份，删除只影响当前浏览器。`;
}
