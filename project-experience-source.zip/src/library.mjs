import {LIBRARY_KEY,LIBRARY_LIMIT,LIBRARY_EMPTY,parseRecords,withoutRecord,summary} from './library-store.mjs';

const host=document.getElementById('saved-experiments'),notice=document.getElementById('library-notice');
const DEFAULT_NOTICE='实验在本机保存，模型与记录不会自动上传。';
const element=(tag,text)=>{const el=document.createElement(tag);el.textContent=text;return el;};
const quiet=text=>{const el=element('p',text);el.className='quiet';return el;};
const read=()=>parseRecords(localStorage.getItem(LIBRARY_KEY));
const write=list=>localStorage.setItem(LIBRARY_KEY,JSON.stringify(list.slice(0,LIBRARY_LIMIT)));

function recordRow(record,records){
  const container=element('div','');
  container.className='saved-row';
  const text=element('div','');
  text.append(element('strong',record.name.slice(0,60)),element('small',(window.LikeProjects?.[record.slug]?.title||record.slug)+' · '+(record.date?.slice(0,10)||'本机记录')));
  const buttons=element('div','');
  buttons.className='button-row';
  const link=element('a','继续实验 ↗');
  link.className='button';
  link.href='project.html?project='+record.slug+'&workspace=1&saved='+encodeURIComponent(record.id);
  const remove=element('button','删除');
  remove.className='button';
  remove.type='button';
  remove.setAttribute('aria-label','删除实验 '+record.name.slice(0,60));
  remove.addEventListener('click',()=>confirmDelete(record,records,buttons));
  buttons.append(link,remove);
  container.append(text,buttons);
  return container;
}

function confirmDelete(record,records,buttons){
  const label=record.name.slice(0,40);
  buttons.replaceChildren();
  const accept=element('button','确认删除');
  accept.type='button';
  accept.className='button';
  const cancel=element('button','取消');
  cancel.type='button';
  cancel.className='button';
  accept.addEventListener('click',()=>{
    try{
      const next=withoutRecord(records,record.id);
      write(next);
      render();
      notice.textContent=next.length?`已删除《${label}》。${summary(next)}`:`已删除《${label}》。本机已没有保存的实验。`;
    }catch(e){notice.textContent='删除失败：本机存储不可写（'+e.message+'）。';}
  });
  cancel.addEventListener('click',()=>{render();});
  buttons.append(accept,cancel);
  notice.textContent=`删除《${label}》？只改动当前浏览器，不影响已导出的JSON。`;
}

function render(){
  let records;
  try{records=read();}catch(e){host.replaceChildren(quiet(LIBRARY_EMPTY));notice.textContent='无法读取本机记录：'+e.message;return;}
  if(!records.length){host.replaceChildren(quiet(LIBRARY_EMPTY));notice.textContent=DEFAULT_NOTICE;return;}
  host.replaceChildren(quiet(summary(records)));
  for(const record of records)host.append(recordRow(record,records));
  notice.textContent=DEFAULT_NOTICE;
}

if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',render,{once:true});else render();
