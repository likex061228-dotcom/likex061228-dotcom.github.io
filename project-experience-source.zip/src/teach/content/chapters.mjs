import { GPIO_LESSON } from './gpio-lesson.mjs';
import { WORKSHOP_LESSONS } from './workshops.mjs';
import { COURSE } from './course.mjs';
import { C_LESSON } from './c-lesson.mjs';
import { C_SECOND } from './c-second.mjs';
import { QUIZ } from '../data/quiz.mjs';
// 教学内容：章节 / 小节 / HTML。交互组件用 data-widget 占位，由 widgets 注册表挂载。
// 说明：所有数值与寄存器结论来自 STM32F103/F407 参考手册，页面只做"解释"，不执行固件。

const code = (s) => '<pre class="code"><code>' + s.trim().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;') + '</code></pre>';

export const CHAPTERS = [
  COURSE,
  {...GPIO_LESSON,title:'实验课：NANO F1入门',sections:[...GPIO_LESSON.sections,...WORKSHOP_LESSONS]},
  {
    id: 'intro',
    group: '入门',
    title: '开始之前：板子、工具链与一次完整流程',
    kicker: '课程板卡、工具与上板流程',
    sections: [
      {
        id: 'how-to-use',
        title: '这套页面怎么用',
        html: `
<p>从“实验一：控制一只LED”开始：先看接法，预测结果，再操作和排错。主线使用NANO STM32F1与HAL；其他芯片只用于对比查阅。</p>
<div class="note"><a href="#/lessons/led">打开GPIO实验课 →</a>。做完后，按需要查GPIO、按键、中断、定时器和PWM参考章节。浏览记录只表示打开过，不作为掌握情况。</div>
<p>交互采用教学规则，不执行固件；板卡接线与时钟配置以上板资料为准。当前GPIO实验课包含操作检查和完整上板步骤，其他章节仍在逐步完善。</p>
<h4>三块板子的约定</h4>
<table class="tbl"><thead><tr><th>板子</th><th>芯片</th><th>板载 LED</th><th>板载按键</th></tr></thead><tbody>
<tr><td>正点原子 NANO STM32F1 V2.0</td><td>STM32F103RCT6（LQFP64）</td><td>PC0–PC7（LED0–LED7，低电平点亮）</td><td>PC8=KEY0、PC9=KEY1、PD2=KEY2、PA0=WK_UP</td></tr>
<tr><td>Blue Pill 最小系统板</td><td>STM32F103C8T6（LQFP48）</td><td>PC13（低电平点亮）</td><td>无板载按键</td></tr>
<tr><td>通用 F407 开发板</td><td>STM32F407VET6（LQFP100）</td><td>按你的板子原理图（页面演示用 PB0 外接）</td><td>按原理图（演示用 PB1 外接）</td></tr>
</tbody></table>
<div class="note warn"><strong>关于型号：</strong>STM32F407RCT6 并不是 ST 的产品型号（F407 没有 64 脚 RC 组合，64 脚 F4 是 F405RGT6）。本节按最常见的 F407VET6 建模。</div>`
      },
      {
        id: 'toolchain',
        title: 'CubeMX、Keil、下载器各自做什么',
        html: `
<p>新手最容易混的地方：以为"写了代码板子就会动"。实际上一条链上有四个角色：</p>
<div class="flow">
<div><b>CubeMX</b><span>选芯片、点引脚、配时钟，生成初始化代码（main.c、gpio.c、tim.c…）</span></div>
<div><b>Keil</b><span>编辑业务代码、编译成 .hex/.axf、调用下载器烧进芯片</span></div>
<div><b>ST-Link / DAP</b><span>把程序写进 Flash，或进入调试（单步、看变量）</span></div>
<div><b>芯片</b><span>复位后从 Flash 取指令，按寄存器配置驱动引脚</span></div>
</div>
<p>所以"灯不亮"可能坏在任一环：CubeMX 配置错了、代码没编译进去、下载没成功、或者根本没按复位。第 8 章会按这个顺序帮你排查。</p>
<h4>CubeMX 里最容易漏的三步</h4>
<ol class="steps">
<li><strong>RCC：</strong>High Speed Clock 选 Crystal/Ceramic Resonator（用外部晶振）。</li>
<li><strong>SYS：</strong>Debug 选 Serial Wire，否则下载一次后可能再也连不上。</li>
<li><strong>Project Manager：</strong>Toolchain 选 MDK-ARM，并且把"生成 .c/.h 分文件"勾上。</li>
</ol>`
      },
      {
        id: 'workflow',
        title: '一次完整流程：从新建工程到灯闪',
        html: `
<ol class="steps">
<li>打开 CubeMX → New Project → 搜索并选中芯片（如 STM32F103RCT6）。</li>
<li>System Core → <b>RCC</b> 选外部晶振；<b>SYS</b> 的 Debug 选 <b>Serial Wire</b>。</li>
<li>点引脚 → 选 GPIO_Output；或在 GPIO 表格里设 Mode / Pull / Speed / User Label。</li>
<li>Clock Configuration：把 HCLK 设到 72 MHz（F1，HSE 8 MHz × 9），让红色变绿。</li>
<li>Project Manager：工程名、Toolchain=MDK-ARM、勾选生成外设 .c/.h。</li>
<li>GENERATE CODE → 用 Keil 打开工程 → 在 <code>while(1)</code> 里写业务 → 编译（F7）。</li>
<li>魔术棒里选好下载器（Debug → ST-Link），勾 Reset and Run → 下载（F8）→ 按复位。</li>
</ol>
<div class="note"><strong>顺序原则：</strong>先让 CubeMX 生成"能跑的空工程"并成功下载一次，再加自己的代码。这样出问题时能确定是不是自己写坏的。</div>`
      },
      {
        id: 'download-vs-debug',
        title: '下载、运行、调试是三件事',
        html: `
<table class="tbl"><thead><tr><th>动作</th><th>发生了什么</th><th>什么时候用</th></tr></thead><tbody>
<tr><td>编译</td><td>把 C 变成机器码，生成 .axf/.hex</td><td>每次改代码后</td></tr>
<tr><td>下载（Download）</td><td>通过 SWD 把程序写进 Flash，然后复位运行</td><td>验证功能</td></tr>
<tr><td>调试（Debug）</td><td>芯片停下来，可以单步、打断点、看寄存器和变量</td><td>找"为什么不对"</td></tr>
</tbody></table>
<p>调试界面里看到的值来自芯片真实的寄存器，比串口打印更直接。新手最值得学的两个操作：<strong>打断点单步</strong>，以及<strong>在 Peripherals 菜单里直接看 GPIO 的 ODR/IDR</strong>。</p>
<div class="note warn"><strong>常见误区：</strong>只点编译没点下载；下载后没按复位；魔术棒里没勾 Reset and Run，于是程序写进去了但还在跑旧代码。</div>`
      }
    ]
  },
  C_LESSON,
  C_SECOND,
  {
    id: 'gpio-out',
    group: 'GPIO',
    title: 'GPIO 输出：从寄存器到一只点亮的 LED',
    kicker: '推挽、开漏、速度档位，以及那个让人困惑的"低电平点亮"',
    sections: [
      {
        id: 'pushpull',
        title: '推挽与开漏：引脚内部到底连了什么',
        html: `
<p>GPIO 输出级只有两个"开关"：一个接 VDD 的 <b>P-MOS</b>，一个接 GND 的 <b>N-MOS</b>。</p>
<div class="two-col">
<div class="diagram"><svg viewBox="0 0 320 190" role="img" aria-label="推挽与开漏结构示意">
<text x="8" y="16" fill="#8ba99b" font-size="11" font-family="Consolas">推挽 Push-Pull</text>
<line x1="40" y1="30" x2="150" y2="30" stroke="#3d5752"/><text x="150" y="28" fill="#9bb0a7" font-size="9">VDD</text>
<rect x="80" y="44" width="30" height="26" fill="none" stroke="#acdfc4"/><text x="86" y="62" fill="#acdfc4" font-size="9">P</text>
<rect x="80" y="104" width="30" height="26" fill="none" stroke="#acdfc4"/><text x="86" y="122" fill="#acdfc4" font-size="9">N</text>
<line x1="95" y1="30" x2="95" y2="44" stroke="#3d5752"/><line x1="95" y1="70" x2="95" y2="104" stroke="#3d5752"/><line x1="95" y1="130" x2="95" y2="160" stroke="#3d5752"/>
<text x="102" y="160" fill="#9bb0a7" font-size="9">GND</text>
<line x1="110" y1="87" x2="190" y2="87" stroke="#d9bf98"/><text x="196" y="91" fill="#d9bf98" font-size="10">引脚</text>
<text x="8" y="182" fill="#6f8c84" font-size="9">上、下管交替工作：主动输出高或低，不能同时导通</text>
</svg></div>
<div class="diagram"><svg viewBox="0 0 320 190" role="img" aria-label="开漏结构示意">
<text x="8" y="16" fill="#8ba99b" font-size="11" font-family="Consolas">开漏 Open-Drain</text>
<rect x="80" y="104" width="30" height="26" fill="none" stroke="#acdfc4"/><text x="86" y="122" fill="#acdfc4" font-size="9">N</text>
<line x1="95" y1="130" x2="95" y2="160" stroke="#3d5752"/><text x="102" y="160" fill="#9bb0a7" font-size="9">GND</text>
<line x1="95" y1="104" x2="95" y2="86" stroke="#3d5752"/><line x1="95" y1="86" x2="190" y2="86" stroke="#d9bf98"/><text x="196" y="90" fill="#d9bf98" font-size="10">引脚</text>
<line x1="150" y1="86" x2="150" y2="46" stroke="#efa78e" stroke-dasharray="4 3"/><rect x="137" y="30" width="26" height="16" fill="none" stroke="#efa78e"/><text x="170" y="44" fill="#efa78e" font-size="9">外部上拉</text>
<text x="8" y="182" fill="#6f8c84" font-size="9">只有下拉管：高电平靠外部上拉电阻</text>
</svg></div>
</div>
<table class="tbl"><thead><tr><th>模式</th><th>写 1</th><th>写 0</th><th>典型用途</th></tr></thead><tbody>
<tr><td>推挽</td><td>输出高（源出／拉电流）</td><td>输出低（吸收／灌电流）</td><td>点 LED、驱动普通数字输入</td></tr>
<tr><td>开漏</td><td>高阻（悬空）</td><td>输出低</td><td>I²C 总线、多设备共享一根线、电平转换</td></tr>
</tbody></table>
<div class="note warn"><strong>记住一句话：</strong>开漏写 1 不是"输出高电平"，而是"放手"。没有外部上拉时它既不是高也不是低，是浮空。</div>`
      },
      {
        id: 'speed-pull',
        title: '速度档位和上下拉，什么时候要管',
        html: `
<p><b>速度（Speed）</b>控制的是引脚翻转的驱动能力（上升/下降沿有多陡），不是"程序跑多快"。较高档位通常使边沿更快，可能增加信号完整性与EMI问题；实际功耗取决于负载、电压和切换频率。</p>
<ul>
<li>点 LED、读按键：低速就够，别顺手选 50 MHz。</li>
<li>SPI、外部存储器：按器件手册要求提高档位。</li>
<li>输出模式下的"上下拉"通常保持 <code>GPIO_NOPULL</code>；上下拉主要用于输入。</li>
</ul>
<div class="note tip"><strong>经验法则：</strong>能用低速就用低速。高频信号再用高速，并且尽量缩短走线。</div>`
      },
      {
        id: 'lab',
        title: '动手：配置一个引脚，看三种视图',
        html: `
<p>完整的PC0实验已移到<a href="#/lessons/led">控制一只LED</a>。下面的引脚配置表供对比芯片寄存器使用，不是CubeMX，也不代表你的板卡实时状态。</p>
<details><summary>展开引脚与寄存器参考工具（进阶）</summary><div data-widget="pin-lab"></div></details>`
      },
      {
        id: 'hal-code',
        title: '这段 HAL 代码在做什么',
        html: `
<p>CubeMX 生成的 GPIO 初始化，本质只做两件事：开时钟、写寄存器。手写的等价代码如下：</p>
${code(`/* 1. 开时钟：不开时钟，后面写寄存器全部无效 */
__HAL_RCC_GPIOC_CLK_ENABLE();

/* 2. 填一个结构体，描述这个引脚要怎么工作 */
GPIO_InitTypeDef gpio = {0};
gpio.Pin   = GPIO_PIN_0;              /* 第 0 号引脚 */
gpio.Mode  = GPIO_MODE_OUTPUT_PP;     /* 推挽输出 */
gpio.Pull  = GPIO_NOPULL;             /* 输出模式一般不用上下拉 */
gpio.Speed = GPIO_SPEED_FREQ_LOW;     /* 低速档 */
HAL_GPIO_Init(GPIOC, &gpio);          /* 写进 CRL/CRH 寄存器 */

/* 3. 输出电平：SET 为高，RESET 为低 */
HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET);`)}
<p>在调试器里看 <code>GPIOC-&gt;CRL</code> 的第 0–3 位：推挽输出、低速，应该是 <code>0b0010</code>——和页面寄存器视图里的一致。</p>
<h3>试一试：一行一行看它生效</h3>
<p>下面把这段初始化拆成 8 步。点“下一步”，看每一行代码执行后寄存器、引脚和 LED 怎么变——尤其是“开时钟”和“写 ODR”这两步。</p>
<div data-widget="mcu-codeviz" data-mode="output"></div>`
      },
      {
        id: 'led-polarity',
        title: '为什么 LED 常常"低电平点亮"',
        html: `
<p>看原理图：LED 正极经限流电阻接 3.3 V，负极接 GPIO。这时 GPIO 输出低电平，电流从 3.3 V 流过 LED 进入引脚，灯亮；输出高电平，两端都是 3.3 V，灯灭。</p>
<table class="tbl"><thead><tr><th>接法</th><th>点亮条件</th><th>说明</th></tr></thead><tbody>
<tr><td>正极→3.3V，负极→GPIO</td><td>输出低</td><td>灌电流，NANO 的 LED0–LED7 与 Blue Pill 的 PC13 多为这种</td></tr>
<tr><td>正极→GPIO，负极→GND</td><td>输出高</td><td>拉电流，驱动能力受芯片限制</td></tr>
</tbody></table>
<div class="note warn"><strong>别背结论，去查原理图：</strong>同一块芯片、不同板子，LED 接法可能相反。页面预览按所列教学接法显示，实物仍需核对。</div>`
      },
      {
        id: 'pitfalls',
        title: '这一章的常见错误',
        html: `
<table class="tbl"><thead><tr><th>现象</th><th>原因</th><th>检查</th></tr></thead><tbody>
<tr><td>引脚完全没反应</td><td>没开 GPIO 时钟</td><td>看 MX_GPIO_Init 里有没有 __HAL_RCC_GPIOx_CLK_ENABLE()</td></tr>
<tr><td>灯一直亮/一直灭</td><td>极性判断反了</td><td>量一下引脚电压，对照原理图</td></tr>
<tr><td>改了代码但行为没变</td><td>没重新下载，或没按复位</td><td>勾 Reset and Run，或手动按复位</td></tr>
<tr><td>编译 0 错误，下载成功，灯不亮</td><td>写错端口/引脚号</td><td>用调试器看 ODR 位，或换另一个灯验证</td></tr>
<tr><td>下载后连不上芯片</td><td>把 SWD 引脚配成了普通 IO</td><td>用串口下载救回，或按住复位再下载</td></tr>
</tbody></table>
<div data-widget="c-quick" data-check="mc-gpio-out"></div>`
      }
    ]
  },
  {
    id: 'gpio-in',
    group: 'GPIO',
    title: 'GPIO 输入：按键、上下拉与消抖',
    kicker: '为什么按键要上拉，为什么按一下会跳好几次',
    sections: [
      {
        id: 'pull',
        title: '浮空、上拉、下拉：电流往哪走',
        html: `
<p>输入引脚本身不"产生"电平，它只是测量外部电压。问题在于：如果外部什么都没接，电压是<strong>不确定</strong>的。</p>
<table class="tbl"><thead><tr><th>模式</th><th>等效电路</th><th>松开时读到</th><th>按下（另一端接 GND）时读到</th></tr></thead><tbody>
<tr><td>浮空</td><td>什么都不接</td><td>随机（像天线）</td><td>低</td></tr>
<tr><td>上拉</td><td>内部约 30–50 kΩ 接 VDD</td><td>高</td><td>低</td></tr>
<tr><td>下拉</td><td>内部约 30–50 kΩ 接 GND</td><td>低</td><td>低（分不清）</td></tr>
</tbody></table>
<div class="note tip"><strong>结论：</strong>按键一端接 GND 时用<strong>上拉</strong>；按下为低、松开为高，逻辑最直观。另一端接 VCC 时用下拉。</div>
<h3>试一试：上拉/按键与 IDR</h3>
<p>下面把 PC8 的输入初始化拆成 7 步，勾选“按下按键”可以看到引脚被拉到 GND、IDR 变成 0。</p>
<div data-widget="mcu-codeviz" data-mode="input"></div>
<div class="note warn"><strong>浮空输入不是"省事"，是隐患：</strong>手靠近都可能让读数翻转，还会让后面接的中断疯狂触发。</div>`
      },
      {
        id: 'bounce',
        title: '抖动：一次按下，为什么有多个边沿',
        html: `
<p>机械触点闭合/断开时会弹跳，通常在几毫秒内产生多次通断。下面是模型按真实抖动生成的波形：上排是引脚原始电平，下排是"每 10 ms 采样、连续 3 次一致才确认"之后的结果。</p>
<div data-widget="debounce"></div>
<p>把"抖动时长"拉到 20 ms、把"连续一致次数"降到 1，就能复现新手最常见的现象：<strong>按一下，程序识别成按了好几次</strong>。</p>`
      },
      {
        id: 'click-long',
        title: '单击与长按：一个三行的状态机',
        html: `
<p>核心只有两个时间戳和两个判断：</p>
${code(`按下（消抖后）→ 记下 t_press
松开（消抖后）→ 计算 held = t_release - t_press
if (held < 500ms)  单击
else               长按`)}
<ul>
<li><b>阈值要试：</b>常见 300–1000 ms。阈值太短会误判单击，太长会觉得"按不动"。</li>
<li><b>长按也可以"按住到阈值就触发"：</b>那属于另一种交互设计，需要在定时器里持续检查，而不是等松开。</li>
<li><b>按键连击：</b>两次按下之间也要留最小间隔，否则机械弹跳会被当成两次单击。</li>
</ul>`
      },
      {
        id: 'polling-vs-timer',
        title: '轮询还是定时器采样',
        html: `
<table class="tbl"><thead><tr><th>方式</th><th>写法</th><th>优点</th><th>缺点</th></tr></thead><tbody>
<tr><td>主循环轮询 + HAL_Delay</td><td>最简单，适合入门</td><td>好理解</td><td>Delay 会阻塞其他逻辑，按键响应变慢</td></tr>
<tr><td>定时器 10 ms 采样</td><td>在更新中断里读引脚、跑消抖</td><td>不阻塞，节拍稳定</td><td>需要理解定时器中断</td></tr>
<tr><td>外部中断 + 定时器确认</td><td>EXTI 唤醒，定时器复核</td><td>省电、响应快</td><td>最容易遇到抖动重复触发</td></tr>
</tbody></table>
<p>课程练习建议：先用轮询把逻辑跑通，再改成 10 ms 定时器采样，对比手感。</p>`
      },
      {
        id: 'pitfalls',
        title: '这一章的常见错误',
        html: `
<table class="tbl"><thead><tr><th>现象</th><th>原因</th><th>检查</th></tr></thead><tbody>
<tr><td>按键读数乱跳</td><td>浮空输入</td><td>改成上拉输入</td></tr>
<tr><td>一直读到低</td><td>配了下拉，按键又接 GND</td><td>换上拉</td></tr>
<tr><td>按一下触发多次</td><td>没消抖，或在中断里直接处理</td><td>加采样消抖，或改成定时器轮询</td></tr>
<tr><td>按下没反应</td><td>按键接的是另一端电平</td><td>万用表量按下前后电压</td></tr>
<tr><td>时好时坏</td><td>杜邦线/面包板接触不良</td><td>换线，直接焊排针</td></tr>
</tbody></table>
<div data-widget="c-quick" data-check="mc-gpio-in"></div>`
      }
    ]
  },
  {
    id: 'exti',
    group: '中断',
    title: '外部中断 EXTI：按键一按就进中断',
    kicker: '边沿、EXTI 线、回调函数，以及"按一下进八次"',
    sections: [
      {
        id: 'edge-line',
        title: '边沿触发与 EXTI 线怎么对应',
        html: `
<p>EXTI 是"边沿检测器"：把引脚电平的变化变成中断请求。编号相同的引脚共用一条线——<b>PA0、PB0、PC0 共用 EXTI0</b>，同一时刻只能选一个。</p>
<div data-widget="exti-line"></div>
<p>F1 上用 <code>AFIO-&gt;EXTICR</code> 选择端口，F4 上用 <code>SYSCFG-&gt;EXTICR</code>。CubeMX 会自动生成这部分，但你要知道它存在，否则遇到"换了端口就不触发"会毫无头绪。</p>`
      },
      {
        id: 'isr',
        title: '中断服务函数与回调',
        html: `
<p>CubeMX 会生成 <code>stm32f1xx_it.c</code>，里面有 <code>EXTI0_IRQHandler()</code>。HAL 把流程拆成两层：</p>
${code(`void EXTI0_IRQHandler(void)          /* 芯片向量表指向这里 */
{
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_0);  /* 清标志 + 调回调 */
}

/* 你只需要重写这个弱函数 */
void HAL_GPIO_EXTI_Callback(uint16_t pin)
{
  if (pin == GPIO_PIN_0) {
    /* 只做标记，处理放到主循环 */
    key_pressed = 1;
  }
}`)}
<div class="note warn"><strong>三条铁律：</strong>中断里不调 <code>HAL_Delay</code>；不做长循环；不打印大段串口（会卡住）。中断只负责"记一笔"，处理交给主循环。</div>`
      },
      {
        id: 'bounce-isr',
        title: '为什么按一下会进很多次中断',
        html: `
<p>下降沿触发 + 机械抖动 = 一次按下产生多个下降沿。下面是同一段抖动，分别用"不消抖"和"消抖后边沿"统计中断次数：</p>
<div data-widget="exti-count"></div>
<p>三种处理方式：</p>
<ol class="steps">
<li><strong>中断里加时间窗：</strong>记录上次中断时间，20 ms 内不再响应。</li>
<li><strong>中断只置标志，定时器复核：</strong>最稳，推荐。</li>
<li><strong>硬件：</strong>按键两端并 0.1 µF 电容，或在软件里加 RC 滤波。</li>
</ol>`
      },
      {
        id: 'pitfalls',
        title: '这一章的常见错误',
        html: `
<table class="tbl"><thead><tr><th>现象</th><th>原因</th><th>检查</th></tr></thead><tbody>
<tr><td>完全进不了中断</td><td>NVIC 没使能，或 EXTI 线没连到该端口</td><td>CubeMX 的 NVIC 标签里勾没勾</td></tr>
<tr><td>进一次就再也不进</td><td>没清中断标志</td><td>用 HAL 的 Handler，别自己写裸函数还不清标志</td></tr>
<tr><td>一按进好多次</td><td>抖动</td><td>时间窗或定时器复核</td></tr>
<tr><td>程序卡死</td><td>中断里死等/延时</td><td>中断只置标志</td></tr>
<tr><td>换到 PB0 不触发</td><td>EXTI0 仍指向 PA0</td><td>检查 AFIO/SYSCFG 的 EXTICR 配置</td></tr>
</tbody></table>
<div data-widget="c-quick" data-check="mc-exti"></div>`
      }
    ]
  },
  {
    id: 'nvic',
    group: '中断',
    title: 'NVIC 优先级：谁能打断谁',
    kicker: '抢占优先级决定嵌套，子优先级只决定排队',
    sections: [
      {
        id: 'preempt-sub',
        title: '抢占优先级与子优先级',
        html: `
<p>每个中断有两个"分数"：<b>抢占优先级</b>和<b>子优先级</b>。数值<strong>越小</strong>优先级越高。</p>
<ul>
<li><b>抢占优先级更高</b>（数值更小）→ 可以打断正在执行的中断，形成嵌套。</li>
<li><b>抢占优先级相同</b> → 不能互相打断，只能排队；同时挂起时，子优先级小的先执行。</li>
<li><b>两者都相同</b> → 先到的先执行。</li>
</ul>
<div data-widget="nvic"></div>
<p>点上面的预设，观察时间轴：只有抢占优先级数值更小的才会切进去，其余都在排队。注意"等待/完成"时刻的变化。</p>`
      },
      {
        id: 'grouping',
        title: '优先级分组：4 位怎么分',
        html: `
<p>STM32 的优先级寄存器只有 4 位可用，用"分组"决定这 4 位里几位给抢占、几位给子优先级。常见分组：</p>
<table class="tbl"><thead><tr><th>分组</th><th>抢占位数</th><th>子优先级位数</th><th>效果</th></tr></thead><tbody>
<tr><td>NVIC_PRIORITYGROUP_4</td><td>4</td><td>0</td><td>16 级抢占，最灵活，但不能用子优先级细分</td></tr>
<tr><td>NVIC_PRIORITYGROUP_3</td><td>3</td><td>1</td><td>8 级抢占 + 2 级排队</td></tr>
<tr><td>NVIC_PRIORITYGROUP_2</td><td>2</td><td>2</td><td>4 级抢占 + 4 级排队</td></tr>
<tr><td>NVIC_PRIORITYGROUP_1</td><td>1</td><td>3</td><td>2 级抢占</td></tr>
<tr><td>NVIC_PRIORITYGROUP_0</td><td>0</td><td>4</td><td>完全不嵌套，只排队</td></tr>
</tbody></table>
<p>HAL 初始化时用 <code>HAL_NVIC_SetPriorityGrouping()</code> 设定一次，全工程统一。CubeMX 默认一般是 Group 4。</p>`
      },
      {
        id: 'isr-rules',
        title: '中断里的禁忌清单',
        html: `
<table class="tbl"><thead><tr><th>不要做</th><th>为什么</th><th>替代做法</th></tr></thead><tbody>
<tr><td>HAL_Delay / 长 while</td><td>整个系统被拖住，同级与更低优先级都无法响应</td><td>置标志，主循环处理</td></tr>
<tr><td>浮点打印、大段 sprintf</td><td>耗时长，可能重入</td><td>只存数据，主循环打印</td></tr>
<tr><td>调用可能阻塞的 HAL（如 HAL_UART_Transmit 带超时）</td><td>可能死等</td><td>用中断/DMA 版本，或置标志</td></tr>
<tr><td>和主循环共享变量却不加 volatile</td><td>编译器优化后读到旧值</td><td>加 <code>volatile</code></td></tr>
</tbody></table>
<div data-widget="c-quick" data-check="mc-nvic"></div>`
      }
    ]
  },
  {
    id: 'timer',
    group: '外设',
    title: '定时器：1 kHz 的节拍从哪来',
    kicker: '向上计数：预分频、重装载与更新事件',
    sections: [
      {
        id: 'cnt',
        title: '计数器怎么数',
        html: `
<p>定时器内部就是一个不断自增的计数器 CNT：从 0 数到 ARR，然后回到 0 并产生一次<b>更新事件</b>（可以产生中断）。PSC 决定"每数一个数需要几个时钟"。</p>
${code(`计数频率 = 定时器时钟 / (PSC + 1)
更新频率 = 定时器时钟 / ((PSC + 1) × (ARR + 1))
更新周期 = 1 / 更新频率`)}
<div data-widget="cnt"></div>
<p>注意：定时器的时钟不一定等于 APB 时钟。F1 在 APB1 预分频不为 1 时，定时器时钟是 APB1 的 2 倍（72 MHz）；F4 的 APB1 定时器时钟是 84 MHz。</p>`
      },
      {
        id: 'calc',
        title: '手算一个 1 kHz 中断',
        html: `
<p>目标：每 1 ms 进一次中断。假设定时器时钟 72 MHz。</p>
<ol class="steps">
<li>先定 PSC：想让计数频率是 1 MHz，则 PSC = 72 − 1 = <b>71</b>（每个计数 1 µs）。</li>
<li>再定 ARR：1 MHz 数到 1000 就是 1 ms，则 ARR = 1000 − 1 = <b>999</b>。</li>
<li>更新频率 = 72 MHz / (72 × 1000) = <b>1 kHz</b>。</li>
</ol>
<div class="note tip"><strong>口诀：</strong>PSC 管"一个计数多久"，ARR 管"数多少个"。两个 (x+1) 相乘是总的分频倍数。</div>`
      },
      {
        id: 'isr-timer',
        title: '更新中断里该做什么',
        html: `
<p>典型用法：每 1 ms 做一次"节拍"，在主循环里按节拍跑任务。</p>
${code(`volatile uint32_t tick_ms = 0;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM2) tick_ms++;
}

/* 主循环 */
if (tick_ms - last >= 500) { last += 500; HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_0); }`)}
<p>用"减法比较"而不是"等于判断"，能自然处理溢出，也不会漏拍。</p>`
      },
      {
        id: 'pitfalls',
        title: '这一章的常见错误',
        html: `
<table class="tbl"><thead><tr><th>现象</th><th>原因</th><th>检查</th></tr></thead><tbody>
<tr><td>完全没进中断</td><td>没调用 HAL_TIM_Base_Start_IT</td><td>启动函数带不带 _IT</td></tr>
<tr><td>频率差一倍</td><td>忘了 APB 预分频对定时器时钟的 ×2</td><td>核对 timApb 时钟</td></tr>
<tr><td>周期差 10 倍</td><td>PSC/ARR 手算错</td><td>用页面的计算器反算</td></tr>
<tr><td>偶尔卡顿</td><td>中断里做了耗时操作</td><td>只加计数，处理放主循环</td></tr>
</tbody></table>
<div data-widget="c-quick" data-check="mc-timer"></div>`
      }
    ]
  },
  {
    id: 'pwm',
    group: '外设',
    title: 'PWM 与调光：不调电压也能变暗',
    kicker: '占空比、频率、平均电流与呼吸灯',
    sections: [
      {
        id: 'duty',
        title: '占空比到底是什么',
        html: `
<p>PWM 就是在高/低之间快速切换。一个周期里高电平占的比例叫<b>占空比</b>。LED 的亮度、电机的转速，看到的都是"平均值"。</p>
<div data-widget="pwm"></div>
<p>公式：<code>f = 定时器时钟 / ((PSC+1) × (ARR+1))</code>，<code>duty = CCR / (ARR+1)</code>。注意分母是 ARR+1。</p>`
      },
      {
        id: 'freq',
        title: '频率怎么选',
        html: `
<table class="tbl"><thead><tr><th>用途</th><th>典型频率</th><th>理由</th></tr></thead><tbody>
<tr><td>LED 调光</td><td>1–5 kHz</td><td>高于人眼闪烁感知，又要避免开关损耗</td></tr>
<tr><td>舵机</td><td>50 Hz</td><td>标准舵机协议：20 ms 周期，脉宽 0.5–2.5 ms</td></tr>
<tr><td>直流电机</td><td>10–20 kHz</td><td>高于人耳可听范围，减少啸叫</td></tr>
<tr><td>蜂鸣器（无源）</td><td>2–4 kHz</td><td>谐振频率附近最响</td></tr>
</tbody></table>
<div class="note warn"><strong>频率太低会肉眼可见闪烁；</strong>频率太高而分辨率不够时，占空比档位会变粗（ARR 太小）。</div>`
      },
      {
        id: 'breath',
        title: '呼吸灯怎么写',
        html: `
${code(`/* 在 1 ms 节拍里，每 10 ms 调一次占空比 */
static uint16_t duty = 0;
static int8_t dir = 1;
if (tick_ms % 10 == 0) {
  duty += dir * 10;
  if (duty >= 1000) { duty = 1000; dir = -1; }
  if (duty == 0)    { dir = 1; }
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, duty);
}`)}
<p>人眼对亮度的感知接近对数，线性改变占空比会显得"前段变化快、后段不明显"。想要更自然，可以按查表做伽马校正——这是进阶练习。</p>`
      },
      {
        id: 'pitfalls',
        title: '这一章的常见错误',
        html: `
<table class="tbl"><thead><tr><th>现象</th><th>原因</th><th>检查</th></tr></thead><tbody>
<tr><td>引脚一直是高/低</td><td>没调用 HAL_TIM_PWM_Start</td><td>启动函数带 _PWM_Start</td></tr>
<tr><td>亮度不变</td><td>CCR 没改，或改了别的通道</td><td>__HAL_TIM_SET_COMPARE 的通道号</td></tr>
<tr><td>LED 闪</td><td>频率太低（几十 Hz）</td><td>提到 1 kHz 以上</td></tr>
<tr><td>占空比调不到 100%</td><td>CCR 超过 ARR 被截断</td><td>CCR ≤ ARR，页面会提示</td></tr>
<tr><td>没有输出</td><td>通道引脚没设成复用推挽</td><td>CubeMX 里该引脚应为 AF_PP</td></tr>
</tbody></table>
<div data-widget="c-quick" data-check="mc-pwm"></div>`
      }
    ]
  },
  {
    id: 'faq',
    group: '排错',
    title: '常见问题：CubeMX、Keil、下载与硬件',
    kicker: '按现象查，不按顺序读',
    sections: [
      {
        id: 'faq-all',
        title: '按现象搜索',
        html: `
<p>下面每一条都是"现象 → 原因 → 检查顺序"。输入关键词过滤，比如 <code>下载</code>、<code>时钟</code>、<code>中断</code>、<code>中文</code>。</p>
<div data-widget="faq"></div>`
      }
    ]
  },
  {
    id: 'quiz',
    group: '自检',
    title: '自检题库',
    kicker: '按章节筛选，答完立刻给解释',
    sections: [
      {
        id: 'quiz-all',
        title: '开始做题',
        html: `
<p>共 ${QUIZ.length} 道：STM32 部分覆盖 7.1–9.3 与高频坑，另有 C 语言第一课的输出、输入、类型、分支、循环与运算题。数值题的答案由同一套公式实时计算，改参数也不会"答案对不上"。</p>
<div data-widget="quiz"></div>`
      }
    ]
  }
];

export const FLAT = CHAPTERS.flatMap(ch =>
  ch.sections.map((sec, i) => ({ chapterId: ch.id, chapterTitle: ch.title, group: ch.group, id: sec.id, title: sec.title, first: i === 0 }))
);

export function findSection(chapterId, sectionId) {
  const ch = CHAPTERS.find(c => c.id === chapterId);
  if (!ch) return null;
  const sec = ch.sections.find(s => s.id === sectionId) || ch.sections[0];
  return { chapter: ch, section: sec };
}
