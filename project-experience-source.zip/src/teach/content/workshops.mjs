const RM = 'https://www.st.com/resource/en/reference_manual/cd00171190-stm32f101xx-stm32f102xx-stm32f103xx-stm32f105xx-and-stm32f107xx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf';
const source = (chapter) => `<p class="lesson-source">依据：<a href="${RM}" target="_blank" rel="noopener">ST RM0008：${chapter}</a>。配置名称随CubeMX版本略有不同，以生成代码和芯片参考手册为准。</p>`;

export const WORKSHOP_LESSONS = [
 {id:'button',title:'读取按键并确认一次按下',kicker:'实验 02 · PC8 · 输入上拉与轮询消抖',html:`
<div class="course-intro"><span class="course-number">实验 02</span><p><b>任务：</b>把一串抖动电平整理成一次按下事件，并能解释为什么读到0才是按下。</p><dl><div><dt>条件</dt><dd>NANO STM32F103RCT6；教学按键接PC8与GND，输入上拉</dd></div><div><dt>完成证据</dt><dd>一次稳定按下只累计一次，保持按住不重复累计，释放后可再次累计</dd></div></dl></div>
<p class="course-assumption">这是教学接法，尚未核对实物原理图。接线前确认PC8没有被板上其他电路驱动，使用板卡允许的逻辑电压并共地。网页只处理逻辑采样，不模拟接触电阻、干扰或实际时间。</p>
<h3>1. 先观察原始电平，再看确认事件</h3><p>释放时上拉使PC8为1，按下接地使其为0。试着注入抖动、保持按下、再释放；对比原始读数和消抖后的事件数。短于确认时间的动作可能被忽略，这是策略的取舍。</p>
<div data-widget="button-workshop"></div>
<h3>2. 采样和事件不是同一件事</h3><p>网页按固定间隔采样，默认每10ms一次、连续3次相同才确认稳定状态；确认延迟还取决于边沿落在采样间隔的哪个位置，不能直接说成固定30ms。网页在确认释放时按持续时间区分单击与长按。下方固件例子采用另一种策略：候选电平保持20ms后确认，只在稳定状态从1变0时增加press_count，不分类单击或长按。两者目标都是过滤抖动，但时序与事件定义不同，不能逐步对照计数。参数需结合实际按键和响应要求调整。</p>
<h3>3. CubeMX与代码放在哪里</h3><ol class="steps"><li>选STM32F103RCT6，保留SYS → Serial Wire；PC8选GPIO_Input，Pull-up。检查MX_GPIO_Init中GPIOC时钟、GPIO_PIN_8、GPIO_MODE_INPUT与GPIO_PULLUP。</li><li>在main.c的USER CODE BEGIN PV中声明下列状态。HAL头文件须已可见。</li></ol>
<pre class="code"><code>static GPIO_PinState candidate = GPIO_PIN_SET;
static GPIO_PinState stable = GPIO_PIN_SET;
static uint32_t changed_at;
volatile uint32_t press_count;</code></pre>
<p>在USER CODE BEGIN 2中（MX_GPIO_Init之后）读取一次PC8，给candidate、stable赋相同初值，changed_at赋HAL_GetTick()；上电已按住不算新按下。以下放在while内的USER CODE BEGIN 3，循环不要加入长阻塞任务：</p>
<pre class="code"><code>GPIO_PinState raw = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8);
uint32_t now = HAL_GetTick();
if (raw != candidate) { candidate = raw; changed_at = now; }
if (candidate != stable &amp;&amp; (uint32_t)(now - changed_at) &gt;= 20U) {
  stable = candidate;
  if (stable == GPIO_PIN_RESET) ++press_count;
}</code></pre>
<h3>4. 一次有目的的排查</h3><p><b>现象：按住时计数飞快增加。</b>先查看是否把“raw等于0就加一”放在循环里；那是在累计采样次数。改为稳定状态转换时累计，再试一次长按。若原始电平从未改变，先查引脚、共地和接线，消抖无法修复断线。</p>
<ul><li>上板前：确认PC8接法、上拉和电压，断电接线；编译无错误再下载并Run。</li><li>验证：Watch观察press_count；连续短按、长按、释放后再按，各自记录结果。断点会扰乱采样时间，计数验证优先运行后读取。</li><li>核对：PC8的IDR位应在按下时为0；循环采样间隔影响可检测的最短按压。网页结果不是固件时序测试。</li></ul>
${source('GPIO输入配置与IDR寄存器')}`},
 {id:'exti',title:'让PC8边沿发出中断请求',kicker:'实验 03 · EXTI8 → EXTI9_5 · HAL回调',html:`
<div class="course-intro"><span class="course-number">实验 03</span><p><b>任务：</b>追踪一次PC8下降沿从EXTI挂起到回调的路径，解释为什么按一下可能触发多次。</p><dl><div><dt>条件</dt><dd>NANO STM32F103RCT6；PC8输入上拉、按下接GND的教学接法，实物接线须另行核对</dd></div><div><dt>完成证据</dt><dd>能区分输入边沿、EXTI挂起、NVIC响应和回调计数</dd></div></dl></div>
<h3>1. 沿着请求路径逐步运行</h3><p>先发送下降沿，再分别关闭EXTI屏蔽位和NVIC使能，比较挂起状态与处理结果。PC8使用EXTI8，F1通过AFIO选择端口；PC8与PA8等不能同时独立占用EXTI8。</p>
<div data-widget="exti-workshop"></div>
<h3>2. 挂起位不是事件队列</h3><p>EXTI8的挂起标志只有一位，处理前的多个边沿可能合并，不能靠回调数还原全部边沿。禁用NVIC只阻止CPU受理该IRQ，并不屏蔽EXTI输入检测；重新使能前要理解遗留挂起请求。EXTI屏蔽、触发边沿和NVIC是不同层次。NVIC也有独立的挂起状态：边沿已经锁存到NVIC后，再屏蔽EXTI或只清PR，不会自动撤回它。随后仍可能进入IRQ，但HAL发现PR已清除就不会执行该引脚回调。网页省略进入延迟与服务执行时间。</p>
<h3>3. 配置PC8和共享入口</h3><ol class="steps"><li>CubeMX中PC8选GPIO_EXTI8；GPIO模式External Interrupt Mode with Falling edge trigger detection，Pull-up。启用EXTI line[9:5] interrupts。</li><li>检查GPIOC及AFIO时钟、PC8映射、下降沿配置和NVIC使能。生成的stm32f1xx_it.c应包含下面的调用；保留生成入口，不再定义第二个同名入口。</li></ol>
<pre class="code"><code>void EXTI9_5_IRQHandler(void)
{
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_8);
}</code></pre>
<p>在main.c的USER CODE BEGIN PV声明计数，在文件作用域的USER CODE BEGIN 4添加回调，不能放进while。无需在循环中反复启动EXTI。</p>
<pre class="code"><code>/* USER CODE BEGIN PV */
volatile uint32_t edge_count;
/* USER CODE END PV */
/* USER CODE BEGIN 4 */
void HAL_GPIO_EXTI_Callback(uint16_t pin)
{
  if (pin == GPIO_PIN_8) ++edge_count;
}
/* USER CODE END 4 */</code></pre>
<p>HAL_GPIO_EXTI_IRQHandler检查对应挂起位，写1清除后调用回调。不要用普通读改写随意清PR，也不要省略HAL处理而仅调用回调。共享入口若还使用其他EXTI线，需要处理那些已配置的引脚。</p>
<h3>4. 一按累计多次，先保留证据</h3><p>先观察edge_count，验证中断链路确实通，再把业务按键确认放到主循环或定时任务。机械抖动会产生多个下降沿；上一课轮询消抖是软件采样策略，不是EXTI硬件滤波器。本例故意只计边沿，不能直接当可靠按键次数。</p>
<ul><li>硬件：确认PC8释放为高、按下为低；先断电接线，确认极性后再接板卡或外部电路。</li><li>工程：下载并Run，检查向量入口、GPIO_PIN_8和回调签名；断点停在回调只能证明进入，无法测量真实抖动间隔。</li><li>纪律：中断里只记状态，避免HAL_Delay和长打印；网页不模拟电气噪声、中断延迟或丢边沿概率。</li></ul>
${source('AFIO、EXTI及中断向量表')}`},
 {id:'nvic',title:'预测中断响应与抢占顺序',kicker:'实验 04 · 优先级分组 · 等待与嵌套',html:`
<div class="course-intro"><span class="course-number">实验 04</span><p><b>任务：</b>先写出三个请求的执行顺序，再用分组和优先级解释每次切换。</p><dl><div><dt>条件</dt><dd>NANO STM32F103RCT6；TIM2 IRQ28、EXTI9_5 IRQ23、USART1 IRQ37各一次示例事件</dd></div><div><dt>完成证据</dt><dd>区分抢占优先级、子优先级与IRQ编号，并能解释等待的原因</dd></div></dl></div>
<h3>1. 先预测谁能打断正在运行的处理程序</h3><p>比较同抢占级、不同抢占级和Group 0三种情况。改变配置并应用后，场景会重新开始；记录开始、抢占、恢复和结束的顺序。</p>
<div data-widget="nvic-workshop"></div>
<p class="course-assumption">这是三个单次事件的教学调度模型，使用整数毫秒表示示例到达和处理时长，不代表CPU周期、异常入口耗时、尾链或实测性能。实际芯片还有系统异常、屏蔽状态和外设行为。</p>
<h3>2. 比较时先看抢占级</h3><p>数值越小优先级越高。更高抢占级可打断当前中断；同抢占级不能互相抢占。子优先级只决定同时等待时的先后，不能让处理程序嵌套。两者都相同的外部IRQ，由较小IRQ编号优先受理。Group 0没有抢占位，三个外部中断之间不会因子优先级发生抢占。</p>
<h3>3. 在工程中落实一个明确分组</h3><p>下面选Group 2，F103实现的4位优先级分成2位抢占、2位子优先级。CubeMX的System Core → NVIC配置相同分组，并设置已启用的三项中断。保留各外设生成的IRQ入口和HAL处理函数。</p>
<pre class="code"><code>/* main.c USER CODE BEGIN 2：所有MX_..._Init之后，启动外设之前 */
HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_2);
HAL_NVIC_SetPriority(TIM2_IRQn, 2, 0);
HAL_NVIC_SetPriority(EXTI9_5_IRQn, 1, 1);
HAL_NVIC_SetPriority(USART1_IRQn, 1, 0);</code></pre>
<p>确保全工程分组一致，避免稍后初始化又改回去。配置时让外设保持未启动、无待处理请求；若CubeMX已使能EXTI的NVIC入口，配置期间不要触发按键，运行中的工程须先停用相关请求并妥善处理挂起状态。外部IRQ还受外设中断源、NVIC使能和CPU全局屏蔽状态共同约束。只有设置优先级不会产生请求：TIM2需启动中断计时，EXTI需边沿，USART1需相应接收/发送中断源和启动操作。本课不要求为演示随意接入串口线路。已在运行的工程应在使能请求前完成配置。</p>
<h3>4. 改了子优先级却没有抢占</h3><p><b>现象：</b>USART1子优先级比EXTI小，但仍等EXTI结束。先核对两者抢占级；相同就应等待，不是配置失效。若需要更快响应，先缩短处理程序，再根据系统需求调整抢占级，不能只修改子优先级。</p>
<ul><li>核对工程分组、实际已编码优先级和IRQ使能；硬件外设入口中仍须清除/处理自己的中断源。</li><li>验证实际顺序可用短状态记录或已确认接线的测量引脚；断点和串口长打印会改变时序，网页毫秒不可当实测。</li><li>不要在ISR里HAL_Delay：若HAL时基中断无法抢占它，等待可能永不结束。把耗时工作交给主循环。</li></ul>
<p class="lesson-source">IRQ编号核对：<a href="https://github.com/STMicroelectronics/cmsis-device-f1/blob/master/Include/stm32f103xe.h" target="_blank" rel="noopener">ST CMSIS设备头文件stm32f103xe.h，IRQn_Type及4位优先级定义</a>。</p>${source('中断向量表；NVIC属于Cortex-M3内核，分组配置同时以工程CMSIS定义为准')}`},
 {id:'timer',title:'从计数时钟推导1ms更新',kicker:'实验 05 · TIM2 · PSC与ARR',html:`
<div class="course-intro"><span class="course-number">实验 05</span><p><b>任务：</b>推导TIM2更新周期，并通过计数器单步观察溢出与更新事件。</p><dl><div><dt>条件</dt><dd>NANO STM32F103RCT6；课程时钟假设APB1=36MHz，TIM2时钟=72MHz，向上计数</dd></div><div><dt>完成证据</dt><dd>解释PSC=71、ARR=999为什么对应1ms，回调累计更新次数</dd></div></dl></div>
<h3>1. 单步走过ARR边界</h3><p>先计算再应用参数，单步推进一次计数器节拍，观察CNT从ARR回到0。这里的单步是分频后的计数器节拍，不是72MHz源时钟，也不是浏览器实时动画。</p>
<div data-widget="timer-workshop"></div>
<h3>2. 两个“加一”不能漏</h3><p>本例APB1预分频不为1，F1定时器时钟为PCLK1的2倍，因此36MHz × 2 = 72MHz。计数频率=72MHz ÷ (71+1)=1MHz；更新周期=(999+1) ÷ 1MHz=1ms，即每秒1000次更新。若APB预分频为1，定时器时钟直接等于PCLK，不能继续套用翻倍。</p>
<h3>3. 配置与启动</h3><ol class="steps"><li>先查看Clock Configuration和实际板卡时钟来源。若工程TIM2时钟不是72MHz，重新计算参数；不要为套公式盲目改晶振或PLL。</li><li>TIM2 → Clock Source选Internal Clock；Counter Mode选Up，Prescaler=71，Counter Period=999，Clock Division保持默认。启用TIM2 global interrupt。</li><li>生成后检查MX_TIM2_Init及stm32f1xx_it.c中的TIM2_IRQHandler调用HAL_TIM_IRQHandler(&amp;htim2)。</li></ol>
<pre class="code"><code>/* main.c USER CODE BEGIN PV */
volatile uint32_t timer_updates;
/* main.c USER CODE BEGIN 2：MX_TIM2_Init之后 */
HAL_TIM_Base_Start_IT(&amp;htim2);
/* main.c USER CODE BEGIN 4：文件作用域 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim-&gt;Instance == TIM2) ++timer_updates;
}</code></pre>
<p>分文件工程包含tim.h；若已有PeriodElapsedCallback，应合并分支，不要重复定义。代码片段按注释分开放置，回调不能嵌在while或main内部。普通Base_Start只启动计数，不等于启动更新中断。</p>
<h3>4. 周期恰好差一倍</h3><p>先核对APB1预分频和TIM2输入时钟，再核对PSC、ARR的加一关系。不要仅把ARR减半来掩盖时钟理解错误。回调计数还依赖NVIC和CPU及时服务；更新标志不是无限队列，长时间屏蔽可能使多次更新合并。</p>
<ul><li>检查编译、下载、Run状态，确认启动函数返回HAL_OK。</li><li>无需外接电路即可观察timer_updates；若用引脚测时，先确认引脚没有板载冲突再连接测量设备。</li><li>约一秒累计约1000次仅作初查；暂停调试可能影响计时，准确周期用实际时钟和测量设备验证。网页不模拟晶振误差或中断开销。</li></ul>
${source('RCC时钟树与TIM2–TIM5通用定时器')}`},
 {id:'pwm',title:'把引脚占空比换算成LED导通时间',kicker:'实验 06 · TIM3_CH1 / PA6 · 低电平点亮',html:`
<div class="course-intro"><span class="course-number">实验 06</span><p><b>任务：</b>在PWM模式1下区分引脚高电平占空比和低有效LED导通比例，并修改比较值。</p><dl><div><dt>条件</dt><dd>NANO STM32F103RCT6；TIM3_CH1默认映射PA6，外接低有效LED教学支路</dd></div><div><dt>完成证据</dt><dd>ARR=999、CCR=250时，解释引脚高25%、LED导通75%</dd></div></dl></div>
<p class="course-assumption">教学接法为VDD → 限流电阻 → LED → PA6，尚未核对实物原理图。先确认PA6没有其他驱动、LED极性和电阻选择，再断电接线。不能因前课PC0能点灯，就认为PC0可输出TIM3_CH1。</p>
<h3>1. 分开观察引脚和LED</h3><p>先用默认极性预测CCR=250的结果，再改变比较值和极性。观察的是每周期导通比例；网页不计算电流或校准亮度，人眼亮度也不与占空比严格成正比。</p>
<div data-widget="pwm-workshop"></div>
<h3>2. PWM模式和有效极性共同决定电平</h3><p>向上计数、PWM mode 1、输出极性High时，CNT小于CCR则引脚高。ARR=999共有1000个计数节拍，CCR=250使高电平占25%；低有效LED在其余75%时间导通。把极性改为Low会反转引脚波形，必须重新判断LED。CCR=0为恒低；本例CCR=1000可得到恒高，不要把CCR=ARR误当严格100%。TIM3的CCR为16位；当ARR=65535时，ARR+1超出CCR范围，不能用这一方法得到100%。</p>
<h3>3. CubeMX与HAL落地</h3><ol class="steps"><li>TIM3选择Internal Clock，Channel1选PWM Generation CH1，确认PA6为TIM3_CH1默认映射且没有重映射冲突。</li><li>在TIM3时钟72MHz的课程条件下，PSC=71、ARR=999得到1kHz；若实际时钟不同，按fPWM=fTIM÷(PSC+1)÷(ARR+1)重算。</li><li>通道设PWM mode 1、Pulse=250、Polarity=High；检查生成的PA6复用推挽GPIO及TIM3时钟。PWM由硬件输出，本例无需开启周期中断。</li></ol>
<pre class="code"><code>/* main.c USER CODE BEGIN 2：MX_GPIO_Init、MX_TIM3_Init之后 */
__HAL_TIM_SET_COMPARE(&amp;htim3, TIM_CHANNEL_1, 250);
HAL_TIM_PWM_Start(&amp;htim3, TIM_CHANNEL_1);
/* 运行中需要改变导通比例时，在主循环的业务条件中调用 */
__HAL_TIM_SET_COMPARE(&amp;htim3, TIM_CHANNEL_1, 750);</code></pre>
<p>分文件工程包含tim.h。最后一行应放在实际调节条件中，不要无条件紧接启动执行，否则250只会维持很短时间。若启用比较预装载，新CCR通常在更新事件生效；本课不模拟所有寄存器更新细节。</p>
<h3>4. 数字增大，灯却变暗</h3><p>先测PA6高电平比例是否增加：若增加，定时器可能正按预期工作。再核对低有效接法，CCR增大意味着低电平导通时间减少。不要立即更改输出极性来“修正”一个正确波形；先决定界面表达的是引脚高比例还是LED导通比例。</p>
<ul><li>接板或外部电路前先确认极性、允许电压、限流与共地，避免多个输出相连。</li><li>编译、下载并Run，确认PWM_Start返回HAL_OK；用示波器或逻辑分析仪核对PA6周期和高电平比例。</li><li>检查0、250、750、1000四个比较值；只凭肉眼不能验证精确占空比、电流或安全负载能力。网页也不代表实物LED亮度标定。</li></ul>
${source('TIM3输出比较、PWM模式、通道极性与GPIO复用映射')}`}
];

