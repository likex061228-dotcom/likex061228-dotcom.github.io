// C 语言第一课：按社团培训讲义整理成文档式教学页。
// 内容覆盖：计算机基础、基本框架、输入输出、数据类型、变量、分支、循环、运算与练习。
// 代码示例保留讲义中的例子，但补上了"运行结果"与"常见坑"，方便课后自学。

const esc = s => String(s).trim().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const code = s => '<pre class="code"><code>' + esc(s) + '</code></pre>';
const out = s => `<div class="c-output"><b>运行结果</b><pre>${esc(s)}</pre></div>`;

export const C_LESSON = {
  id: 'c-first',
  group: 'C 语言',
  title: 'C 语言第一课：从第一个程序到循环与运算',
  kicker: '程序 = 数据 + 加工 + 结果 · 社团培训讲义整理',
  sections: [
    {
      id: 'program',
      title: '计算机怎么跑程序：三个必须先建立的直觉',
      kicker: '冯·诺依曼、程序五性、编译与运行',
      html: `
<p>写 C 之前先弄清三件事：计算机由什么组成、程序是什么、你写的中文/英文代码是怎么变成机器能执行的指令的。这三件事想通了，后面很多"为什么必须这样写"就不再是死记。</p>
<h3>① 冯·诺依曼结构：五个部件</h3>
<table class="tbl"><thead><tr><th>部件</th><th>干什么</th><th>你写的代码和它的关系</th></tr></thead><tbody>
<tr><td>运算器</td><td>算术与逻辑运算</td><td><code>a + b</code>、比较大小最终都在这里完成</td></tr>
<tr><td>控制器</td><td>指挥各部件按指令工作</td><td>if/for 改变的就是"下一步执行哪条指令"</td></tr>
<tr><td>存储器</td><td>存放数据与程序</td><td>变量、数组就住在这里；程序本身也在这里</td></tr>
<tr><td>输入设备</td><td>把信息送进计算机</td><td>键盘 → <code>scanf</code>；传感器 → 单片机的输入引脚</td></tr>
<tr><td>输出设备</td><td>把结果送出</td><td>屏幕 → <code>printf</code>；LED → 输出引脚</td></tr>
</tbody></table>
<p>核心思想是 <b>存储程序</b>：程序和数据放在同一个存储器里，CPU 一条一条取指令执行。这也是后面学单片机时"程序烧进 Flash、变量放在 RAM"的由来。</p>

<h3>② 程序必须满足的五个条件</h3>
<ul>
<li><b>有穷性</b>：有限步结束。死循环不是"程序"，是故障（除非你故意让它一直跑，比如单片机的 <code>while(1)</code>）。</li>
<li><b>确定性</b>：每一步含义明确，不能"看心情"。</li>
<li><b>可行性</b>：每一步都能真正做出来。</li>
<li><b>输入性</b>：0 个或多个输入。</li>
<li><b>输出性</b>：至少 1 个输出，否则你无法知道它做了什么。</li>
</ul>
<div class="note tip"><strong>用这五条检查作业：</strong>跑不完（不满足有穷性）、结果每次不一样（不满足确定性）、没有输出（不满足输出性），是最常见的三类扣分点。</div>

<h3>③ 从 .c 到 .exe：编译的四个阶段</h3>
<p>电脑只认 0 和 1。你写的 C 代码要经过"翻译"才能执行，这个翻译过程叫<b>编译</b>。完整链条是：</p>
<div class="flow">
<div><b>预处理</b><span>展开 <code>#include</code>、替换宏，得到 .i 文件</span></div>
<div><b>编译</b><span>C 代码 → 汇编代码 .s</span></div>
<div><b>汇编</b><span>汇编 → 机器码目标文件 .o</span></div>
<div><b>链接</b><span>把多个 .o 和库拼成 .exe</span></div>
</div>
<p>所以一个工程里可以有多个 <code>.c</code>：<code>main.c</code>、<code>calc.c</code> 各自编译成 <code>.o</code>，最后链接成一个可执行文件。<code>.h</code> 头文件不参与编译成 .o，它只是在预处理阶段被"文本插入"到包含它的 .c 里。</p>
<div class="note warn"><strong>新手最常见的误解：</strong>"我改了 .h，为什么没生效？"——因为所有包含它的 .c 都要重新编译。IDE 有时不会自动帮你做，点一次"全部重新编译"。</div>
<p>我们常用的 Dev-C++、VS Code（配 GCC）、Keil 都属于"编译器 + 编辑器"的组合。Keil 针对单片机，生成的是烧进 Flash 的固件而不是 Windows 的 .exe，但"预处理 → 编译 → 汇编 → 链接"的流程完全一样。</p>`
    },
    {
      id: 'first',
      title: '第一个程序：每一行在做什么',
      kicker: 'include / main / printf / return',
      html: `
<p>先看完整代码，再逐行拆：</p>
${code(`#include <stdio.h>          /* 把标准输入输出库的函数声明拿进来 */
int main()                  /* 主函数：程序从这里开始执行 */
{
    printf("hello world\\n");
    return 0;               /* 返回 0 表示正常结束 */
}`)}
${out('hello world')}
<table class="tbl"><thead><tr><th>部分</th><th>含义</th><th>不写会怎样</th></tr></thead><tbody>
<tr><td><code>#include &lt;stdio.h&gt;</code></td><td>引入 printf/scanf 的声明</td><td>编译器不知道 printf 是什么，报"隐式声明"或链接错误</td></tr>
<tr><td><code>int main()</code></td><td>程序入口，有且只有一个</td><td>没有入口，链接失败</td></tr>
<tr><td><code>{ }</code></td><td>函数体，语句都写在里面</td><td>语法错误</td></tr>
<tr><td><code>printf("...")</code></td><td>把字符串输出到屏幕</td><td>没有输出</td></tr>
<tr><td><code>return 0;</code></td><td>告诉系统"正常结束"</td><td>能编译，但返回值不确定，不推荐</td></tr>
</tbody></table>
<h3>三个立刻能上手的改法</h3>
<ol class="steps">
<li>把 <code>hello world</code> 换成你的名字（英文/拼音，避免编码问题），重新编译运行。</li>
<li>再加一行 <code>printf("第二行\\n");</code>，观察换行位置。</li>
<li>故意删掉一个分号，看编译器报什么错——认识报错信息比背语法重要。</li>
</ol>
<div class="note tip"><strong>编译报错怎么读：</strong>先看第一条错误（后面的常常是连锁反应），再看行号。中文乱码/找不到文件通常是编码或路径问题，不是代码逻辑问题。</div>`
    },
    {
      id: 'output',
      title: '输出：转义字符与格式控制',
      kicker: 'printf 的 \\n \\t \\r、%d %f %c 与宽度精度',
      html: `
<p><code>printf</code> 有两种东西：<b>普通字符</b>原样输出，<b>转义字符</b>和<b>格式占位符</b>有特殊含义。</p>
<h3>① 转义字符：想输出"有特殊含义的字符"</h3>
<table class="tbl"><thead><tr><th>写法</th><th>效果</th><th>典型用途</th></tr></thead><tbody>
<tr><td><code>\\n</code></td><td>换行</td><td>每行输出结束</td></tr>
<tr><td><code>\\t</code></td><td>跳到下一个制表位（对齐）</td><td>打印表格：Name\\tAge\\tScore</td></tr>
<tr><td><code>\\r</code></td><td>回到本行开头（再输出会覆盖）</td><td>进度条、覆盖刷新同一行</td></tr>
<tr><td><code>\\\\</code></td><td>输出一个反斜线</td><td>路径、转义本身</td></tr>
<tr><td><code>\\"</code></td><td>输出双引号</td><td>字符串里包含引号</td></tr>
<tr><td><code>%%</code></td><td>输出一个百分号</td><td>打印 "50%" 这种内容</td></tr>
</tbody></table>
${code(`printf("Name\\tAge\\tScore\\n");
printf("Tom\\t18\\t90\\n");
printf("Alice\\t20\\t95\\n");`)}
${out('Name	Age	Score\nTom	18	90\nAlice	20	95')}
<div class="note warn"><strong>\\r 和 \\n 别混：</strong>\\n 是"换到下一行"，\\r 是"回到本行开头"。Windows 记事本里的换行其实是 \\r\\n 两个字符。</div>

<h3>② 格式字符（占位符）：告诉 printf "这里要填什么"</h3>
<table class="tbl"><thead><tr><th>占位符</th><th>填什么</th><th>例子</th><th>输出</th></tr></thead><tbody>
<tr><td><code>%d</code></td><td>整数</td><td><code>printf("%d", 12)</code></td><td>12</td></tr>
<tr><td><code>%x</code></td><td>十六进制（小写）</td><td><code>printf("%x", 12)</code></td><td>c</td></tr>
<tr><td><code>%f</code></td><td>浮点数，默认 6 位小数</td><td><code>printf("%f", 1.2)</code></td><td>1.200000</td></tr>
<tr><td><code>%c</code></td><td>单个字符</td><td><code>printf("%c", 'a')</code></td><td>a</td></tr>
<tr><td><code>%s</code></td><td>字符串</td><td><code>printf("%s", "abc")</code></td><td>abc</td></tr>
<tr><td><code>%p</code></td><td>地址</td><td><code>printf("%p", &amp;a)</code></td><td>类似 0061FF1C</td></tr>
</tbody></table>
<p>占位符和后面的参数必须<b>一一对应</b>：几个 % 就接几个值，类型也要匹配。类型不匹配是"能编译但结果离谱"的典型来源。</p>

<h3>③ 宽度与精度：让输出对齐</h3>
<table class="tbl"><thead><tr><th>写法</th><th>含义</th><th>例子（值 123）</th></tr></thead><tbody>
<tr><td><code>%5d</code></td><td>总宽 5，右对齐，左边补空格</td><td><code>&nbsp;&nbsp;123</code></td></tr>
<tr><td><code>%-5d</code></td><td>总宽 5，左对齐，右边补空格</td><td><code>123&nbsp;&nbsp;</code></td></tr>
<tr><td><code>%.2f</code></td><td>保留 2 位小数</td><td>3.14</td></tr>
<tr><td><code>%8.3f</code></td><td>总宽 8、3 位小数</td><td><code>&nbsp;&nbsp;&nbsp;3.142</code></td></tr>
</tbody></table>
${code(`float a = 3.1415926;
printf("a=%10.3f", a);`)}
${out('a=     3.142')}
<div class="note tip"><strong>乘法表/成绩单</strong>这类对齐需求，用宽度修饰符比手工敲空格稳得多。下面的小工具可以直接试不同写法。</div>
<div data-widget="printf-lab"></div>`
    },
    {
      id: 'input',
      title: '输入：scanf 的格式控制与五个坑',
      kicker: '%3d、%d:%d、%d%c%d、回车与 &',
      html: `
<p><code>scanf</code> 负责从键盘读数，格式串决定"怎么解析输入"。</p>
${code(`int a;
scanf("%d", &a);        /* 读一个整数到 a 的地址 */`)}
<div class="note warn"><strong>为什么有 &：</strong>scanf 需要知道"存到哪"，所以要传变量的地址。漏写 & 是最常见的崩溃原因之一。</div>

<h3>① 位宽：只读前几位</h3>
${code(`scanf("%3d", &b);   /* 输入 123456，只会读进 123 */`)}
<h3>② 一次读多个</h3>
${code(`scanf("%d%d", &a, &b);   /* 输入 3 回车 5，a=3 b=5 */`)}
<h3>③ 带分隔符：读时间</h3>
${code(`int h, m;
scanf("%d:%d", &h, &m);   /* 输入 12:30 → h=12 m=30 */`)}
<p>格式串里的 <code>:</code> 会去匹配输入里的冒号，所以冒号本身不会被读进变量。</p>
<h3>④ 数字中间夹字符：做一个简易计算器</h3>
${code(`int a, c;
char op;
scanf("%d%c%d", &a, &op, &c);   /* 输入 1+2 → a=1 op='+' c=2 */`)}
<h3>⑤ 最经典的坑：%c 把回车吃掉了</h3>
${code(`int a, c;
char b;
scanf("%d", &a);     /* 输入 3 后按回车 */
scanf("%c", &b);     /* 这里读到的是回车，不是你想输入的字符 */
scanf("%d", &c);`)}
<p>原因：<code>%d</code> 读完数字就停，回车还留在输入缓冲区；<code>%c</code> 不跳过空白，直接读下一个字符，于是把 <code>'\\n'</code> 读走了。</p>
<div class="two-col">
<div><b>解法一：先吃掉回车</b>
${code(`scanf("%d", &a);
getchar();          /* 读走回车 */
scanf("%c", &b);`)}</div>
<div><b>解法二：在 %c 前加空格</b>
${code(`scanf("%d", &a);
scanf(" %c", &b);   /* 空格表示跳过空白 */
scanf("%d", &c);`)}</div>
</div>
<p>规律：<code>%d</code>、<code>%f</code>、<code>%s</code> 会自动跳过前导空白；<code>%c</code> 不会。记住这一条，大部分"读字符读错"的问题都能自己解释。</p>
<h3>其他新手错误</h3>
<table class="tbl"><thead><tr><th>写法</th><th>问题</th><th>正确写法</th></tr></thead><tbody>
<tr><td><code>scanf("%7.2f", &amp;a)</code></td><td>scanf 不能限制小数精度</td><td><code>scanf("%f", &amp;a)</code>，精度交给 printf</td></tr>
<tr><td><code>scanf("%f\\n", &amp;a)</code></td><td>格式串里加 \\n 会等额外输入</td><td>删掉 \\n</td></tr>
<tr><td><code>scanf("%f", a)</code></td><td>漏了 &amp;</td><td><code>scanf("%f", &amp;a)</code></td></tr>
<tr><td><code>scanf("%d", &amp;a)</code> 里用错类型</td><td>%d 配 float 会读错</td><td>int 用 %d，float 用 %f</td></tr>
</tbody></table>`
    },
    {
      id: 'types',
      title: '数据类型：字节、整数、字符与小数',
      kicker: '内存多大、能存多少、为什么会溢出',
      html: `
<h3>① 字节：内存的计量单位</h3>
<p>1 B（字节）= 8 bit（位），每个 bit 只能是 0 或 1。换算：1 KB = 1024 B，1 MB = 1024 KB，1 GB = 1024 MB（因为 2<sup>10</sup> = 1024）。</p>
<p>一个 4 字节的 <code>int</code> 有 32 个 bit，能表示 2<sup>32</sup> 种组合；其中一半给负数，所以有符号 int 的范围是 −2<sup>31</sup> ~ 2<sup>31</sup>−1，即 −2147483648 ~ 2147483647。超了就叫<b>溢出</b>，结果会"绕回去"变成负数或别的值。</p>

<h3>② 常用整数与字符类型</h3>
<table class="tbl"><thead><tr><th>类型</th><th>典型大小</th><th>范围</th><th>用途</th></tr></thead><tbody>
<tr><td><code>char</code></td><td>1 字节</td><td>−128 ~ 127</td><td>字符（本质是 0–127 的编号）</td></tr>
<tr><td><code>unsigned char</code></td><td>1 字节</td><td>0 ~ 255</td><td>字节数据、原始二进制</td></tr>
<tr><td><code>short</code></td><td>2 字节</td><td>−32768 ~ 32767</td><td>省内存的小整数</td></tr>
<tr><td><code>int</code></td><td>4 字节（常见）</td><td>−2147483648 ~ 2147483647</td><td>默认整数类型</td></tr>
<tr><td><code>unsigned int</code></td><td>4 字节</td><td>0 ~ 4294967295</td><td>计数、寄存器值</td></tr>
<tr><td><code>long long</code></td><td>8 字节</td><td>约 ±9.2×10<sup>18</sup></td><td>大整数</td></tr>
</tbody></table>
<div class="note tip"><strong>单片机上的差异：</strong>STM32 的 <code>int</code> 是 4 字节，但 51 单片机上 int 常是 2 字节。跨平台代码不要假设"int 一定是 4 字节"，需要固定宽度时用 <code>stdint.h</code> 的 <code>uint8_t / int32_t</code>。</div>

<h3>③ 字符其实就是数字：ASCII</h3>
<p><code>char a = 'b';</code> 存的不是"字母 b"，而是 b 在 ASCII 表里的编号 98。关键几行：<code>'0'</code>=48，<code>'A'</code>=65，<code>'a'</code>=97，而且<b>大写 + 32 = 对应小写</b>。</p>
${code(`char c = 'A';
printf("%c 的编号是 %d\\n", c, c);   /* A 的编号是 65 */
printf("%c\\n", c + 32);              /* a */`)}
<div class="note tip"><strong>大小写转换就这么简单：</strong>'A'~'Z' 加 32 变小写，'a'~'z' 减 32 变大写。但记得先判断输入是不是字母，否则 114514 这种输入会被算成乱码字符。</div>

<h3>④ 小数：float 与 double</h3>
<table class="tbl"><thead><tr><th>类型</th><th>大小</th><th>有效数字</th><th>什么时候用</th></tr></thead><tbody>
<tr><td><code>float</code></td><td>4 字节</td><td>约 6–7 位</td><td>单片机省内存、精度要求不高</td></tr>
<tr><td><code>double</code></td><td>8 字节</td><td>约 15 位</td><td>PC 上默认、需要更高精度</td></tr>
</tbody></table>
${code(`float f = 3.1415926f;
printf("%.2f\\n", f);    /* 3.14，只打印需要的位数 */
printf("%.10f\\n", f);   /* 后面的位数是噪声，没有意义 */`)}
<div class="note warn"><strong>别打印超出精度的位数。</strong>float 只有约 6–7 位有效数字，<code>%.10f</code> 后面几位不是"更精确"，而是存储误差。</div>`
    },
    {
      id: 'vars',
      title: '变量：先定义、再初始化、别用垃圾值',
      kicker: '命名规则、定义格式、初始化与声明',
      html: `
<p>变量是内存里一块"有名字、可修改"的存储区。定义变量要做两件事：<b>告诉编译器类型</b>（占多大、怎么解释这串 0/1）和<b>起一个名字</b>。</p>
<h3>命名规则</h3>
<ul>
<li>只能由字母、数字、下划线组成，且不能以数字开头。</li>
<li>C 区分大小写：<code>sum</code> 和 <code>Sum</code> 是两个变量。</li>
<li>不能用关键字（<code>int</code>、<code>for</code>、<code>return</code>…）。</li>
<li>名字要有意义：<code>count</code> 比 <code>a1</code> 好，<code>sum</code> 比 <code>x</code> 好。</li>
</ul>
<h3>定义与初始化</h3>
${code(`int a;              /* 定义，但没赋值：里面是"垃圾值" */
int x = 10;         /* 定义并初始化 */
float pi = 3.14f;
char ch = 'A';
int d = 3, f = 5;   /* 一行定义多个 */

int y;              /* 先定义 */
y = 10;             /* 再赋值 */`)}
<div class="note warn"><strong>局部变量不初始化就是垃圾值。</strong>它不会自动等于 0，而是内存里上一次留下的内容。用它参与计算，结果不可预测——这也是"程序有时对有时错"的常见原因。</div>
<h3>声明与定义的区别（了解）</h3>
<p><code>int a;</code> 是定义，会分配空间；<code>extern int a;</code> 是声明，只告诉编译器"这个变量在别的文件里定义了"，不分配空间。多文件工程里用头文件 + extern 共享全局变量时会遇到。</p>
<div class="note tip"><strong>好习惯：</strong>定义时就给初值；变量名用英文小写+下划线；一行只定义一个，注释写清用途。</div>`
    },
    {
      id: 'branch',
      title: '选择：if / else、比较运算与 switch',
      kicker: '== 与 =、&& 与 ||、break 与 default',
      html: `
<h3>① if / else：让程序做判断</h3>
${code(`if (a >= b) {
    c = a;
} else {
    c = b;
}`)}
<p>结构要点：<code>if</code> 后面必须有括号，条件成立执行花括号里的内容；不写花括号时只对"下一句"生效——这就是新手最容易踩的坑。</p>
${code(`if (a >= b)
    c = a;
    printf("%d", c);   /* 这行不受 if 控制，永远执行！ */`)}
<h3>② 比较运算符：C 的写法 ≠ 数学写法</h3>
<table class="tbl"><thead><tr><th>数学</th><th>C 语言</th><th>易错点</th></tr></thead><tbody>
<tr><td>=</td><td><code>==</code></td><td>写成 <code>=</code> 是赋值，不是比较，条件恒真</td></tr>
<tr><td>≠</td><td><code>!=</code></td><td>不要写成 &lt;&gt;</td></tr>
<tr><td>≤ ≥</td><td><code>&lt;=</code> <code>&gt;=</code></td><td>不能输入数学符号 ≤ ≥</td></tr>
</tbody></table>
<div class="note warn"><strong>if (a = 5) 是赋值：</strong>它会把 5 赋给 a，然后判断 5 是否为真（非 0 即真），于是条件永远成立。编译器通常只给个警告，不报错。</div>
<h3>③ 多条件：&& 与 ||</h3>
${code(`if (a > b && a > c)  { /* a 比 b 大，而且 a 比 c 大 */ }
if (a > b || a > c)  { /* 至少一个成立 */ }
if (!(a > b))        { /* 取反：a 不大于 b */ }`)}
<p>比较运算的结果只有 0（假）和 1（真），所以 <code>printf("%d", 2 &gt; 1)</code> 会输出 1。</p>
<h3>④ switch / case：一个值对多种情况</h3>
${code(`switch (mark) {
case 5:
    printf("太强了");
    break;
case 4:
    printf("不错，继续");
    break;
default:
    printf("输入不在 1-5");
}`)}
<ul>
<li><code>case</code> 后面是冒号，不是分号；每个 case 结束要 <code>break</code>。</li>
<li>少了 <code>break</code> 会"贯穿"到下一个 case，把后面的语句也执行了——偶尔是特性，多数是 bug。</li>
<li><code>default</code> 不是必须的，但建议写，用来处理意外输入。</li>
</ul>
<div class="note tip"><strong>什么时候用 switch：</strong>判断"一个变量等于几个固定值"时比一串 else if 清爽；判断范围（如 60–70 分）还是用 if。</div>`
    },
    {
      id: 'loop',
      title: '循环：for、while、break 与两层的坑',
      kicker: '三要素、累加、continue、flag、goto',
      html: `
<h3>① for 与 while 只是"三要素放在哪"的区别</h3>
${code(`for (int i = 0; i < 10; i++) {   /* 起点；条件；每轮推进 */
    printf("乌拉乌拉\\n");
}

int i = 0;
while (i < 10) {
    printf("乌拉乌拉\\n");
    i++;                            /* 推进放在循环体里 */
}`)}
<table class="tbl"><thead><tr><th>要素</th><th>for 的位置</th><th>while 的位置</th></tr></thead><tbody>
<tr><td>从哪开始</td><td>第一段</td><td>循环之前</td></tr>
<tr><td>什么时候停</td><td>第二段</td><td>while 的括号里</td></tr>
<tr><td>每轮怎么推进</td><td>第三段</td><td>循环体里</td></tr>
</tbody></table>
<p><b>选择标准：</b>次数已知（1 到 100）用 for；次数未知、靠条件停（一直读到没有输入）用 while。</p>
<h3>② 累加：1 到 100 的和</h3>
${code(`int sum = 0;
for (int i = 1; i <= 100; i++) {
    sum += i;
}
printf("%d", sum);      /* 5050 */`)}
<div class="note warn"><strong>sum 必须初始化成 0。</strong>局部变量不初始化是垃圾值，累加结果会随机。</div>
<h3>③ break 与 continue</h3>
<table class="tbl"><thead><tr><th>语句</th><th>作用</th><th>经典场景</th></tr></thead><tbody>
<tr><td><code>break</code></td><td>跳出整个循环</td><td>找到目标就停</td></tr>
<tr><td><code>continue</code></td><td>跳过本轮剩余语句，进入下一轮</td><td>跳过偶数/3 的倍数</td></tr>
</tbody></table>
${code(`/* 1 到 10 里的奇数 */
for (int i = 1; i <= 10; i++) {
    if (i % 2 == 0) continue;
    printf("%d ", i);
}`)}
${out('1 3 5 7 9')}
<p>综合例子：i 从 1 开始累加，遇到 3 的倍数跳过，和超过 20 就停：</p>
${code(`int sum = 0;
for (int i = 1; ; i++) {
    if (i % 3 == 0)      continue;
    else if (sum > 20)   break;
    else                 sum += i;
}
printf("%d", sum);      /* 27 */`)}
<h3>④ 跳出两层循环：两个 break 是不够的</h3>
<p>内层 break 只能跳出内层。常见两种做法：</p>
<div class="two-col">
<div><b>flag 标志变量</b>
${code(`int flag = 0;
for (int i = 0; ; i++) {
    for (int j = 0; j <= 5; j++) {
        if (i + j == 10) { flag = 1; break; }
    }
    if (flag) break;
}`)}</div>
<div><b>goto 直接跳出去</b>
${code(`for (int i = 0; ; i++) {
    for (int j = 0; j <= 5; j++) {
        if (i + j == 10) goto out;
    }
}
out: ;`)}</div>
</div>
<p>flag 的代价是层数越多检查越多、越容易漏；goto 一次跳到位，但滥用会让流程难读。原则：<b>能用函数返回解决就不用 goto</b>；真需要多层跳出时，goto 到函数末尾是相对克制的用法。</p>`
    },
    {
      id: 'operators',
      title: '运算：整数除法、取余、自增与位运算',
      kicker: '5/2 为什么等于 2、++i 与 i++、& 与 <<',
      html: `
<h3>① 整数除法：5 / 2 = 2，不是 2.5</h3>
${code(`float a = 5 / 2;
printf("%f", a);        /* 2.000000 —— 先算整数除法，再转 float */`)}
<p>两个 int 相除，结果还是 int（小数部分直接截断），然后才赋给 float。要得到 2.5，至少让一边是小数：</p>
${code(`float a = 5.0 / 2;      /* 2.500000 */
float b = 5 / 2.0;      /* 2.500000 */
float c = (float)5 / 2; /* 强制转换，2.500000 */`)}
<p>类型提升顺序：<code>double &gt; float &gt; long &gt; int &gt; short &gt; char</code>。混合运算时低精度会向高精度看齐；反过来强制降精度可能丢信息。</p>
<div class="note tip"><strong>常见用途：</strong>想保留整数部分（去掉小数），可以 <code>(int)3.9</code> 得到 3——注意这是截断，不是四舍五入。</div>
<h3>② % 取余：判断奇偶、取位、进制转换</h3>
${code(`if (n % 2 == 0) printf("偶数");
int lastDigit = n % 10;     /* 个位 */`)}
<p>% 只能用于整数，不能对 float 取余。</p>
<h3>③ ++ 与 --：i++ 和 ++i 的区别</h3>
${code(`int i = 1, j;
j = ++i;    /* 先加，再赋值：i=2, j=2 */
j = i++;    /* 先赋值，再加：j=2, i=3 */`)}
<p>单独写 <code>i++;</code> 时两者没区别。只有当"自增"和"取值"出现在同一条语句里才有差别，日常代码建议拆开写。</p>
<h3>④ 条件运算与逻辑</h3>
<table class="tbl"><thead><tr><th>运算符</th><th>含义</th><th>例子</th><th>结果</th></tr></thead><tbody>
<tr><td><code>&amp;&amp;</code></td><td>与：都真才真</td><td><code>2&gt;1 &amp;&amp; 3&gt;2</code></td><td>1</td></tr>
<tr><td><code>||</code></td><td>或：一个真就真</td><td><code>2&lt;1 || 3&gt;2</code></td><td>1</td></tr>
<tr><td><code>!</code></td><td>非：取反</td><td><code>!(2&gt;1)</code></td><td>0</td></tr>
<tr><td><code>?:</code></td><td>三目：条件 ? 真值 : 假值</td><td><code>a&gt;b ? a : b</code></td><td>较大的数</td></tr>
</tbody></table>
<h3>⑤ 位运算：直接操作二进制（了解）</h3>
<table class="tbl"><thead><tr><th>运算符</th><th>含义</th><th>例子</th></tr></thead><tbody>
<tr><td><code>&amp;</code></td><td>按位与</td><td><code>1010 &amp; 1100 = 1000</code></td></tr>
<tr><td><code>|</code></td><td>按位或</td><td><code>1010 | 1100 = 1110</code></td></tr>
<tr><td><code>^</code></td><td>按位异或</td><td><code>1010 ^ 1100 = 0110</code></td></tr>
<tr><td><code>~</code></td><td>按位取反</td><td><code>~0 = -1</code></td></tr>
<tr><td><code>&lt;&lt;</code></td><td>左移</td><td><code>1 &lt;&lt; 3 = 8</code></td></tr>
<tr><td><code>&gt;&gt;</code></td><td>右移</td><td><code>10101110 &gt;&gt; 2 = 101011</code></td></tr>
</tbody></table>
<p>位运算后面在单片机里会大量用到：置位（<code>|=</code>）、清零（<code>&amp;= ~</code>）、判断（<code>&amp;</code>）、翻转（<code>^=</code>）——寄存器操作全靠它。</p>
<h3>⑥ 优先级：记不住就加括号</h3>
<ol class="steps">
<li>括号 <code>()</code> 最高。</li>
<li>单目运算符：<code>++ -- ! ~</code> 和取负号。</li>
<li>先乘除取余 <code>* / %</code>，再加减 <code>+ -</code>。</li>
<li>然后是比较 <code>&gt; &gt;= &lt; &lt;=</code>、相等 <code>== !=</code>、位运算、逻辑运算。</li>
<li>赋值 <code>= +=</code> 很靠后，所以 <code>a = 1 + 2 * 3</code> 先算右边。</li>
</ol>
<div class="note tip"><strong>口诀：</strong>括号是老大，贴着的符号其次，先乘除后加减，先算后判断，最后赋值。实在不确定就加括号——可读性比"炫技"重要。</div>
<h3>⑦ math.h 与随机数</h3>
${code(`#include <math.h>
double r = sqrt(2.0);       /* 开方 */
double p = pow(2, 10);      /* 2 的 10 次方 = 1024 */
double c = ceil(1.2);       /* 向上取整 2 */

#include <stdlib.h>
#include <time.h>
srand(time(0));             /* 用时间做种子，每次运行不同 */
int n = rand() % 100 + 1;   /* 1 到 100 */`)}
<p><code>rand()</code> 如果不定种子（<code>srand</code>），每次运行序列都一样。想要"真随机"在 PC 上可以用时间做种子；在单片机上通常用定时器计数或 ADC 噪声。</p>`
    },
    {
      id: 'practice',
      title: '练习与易错清单',
      kicker: '六个动手题 + 第一课必须记住的坑',
      html: `
<h3>动手题（建议按顺序做）</h3>
<ol class="steps">
<li><b>输出练习：</b>用一行 printf 输出 <code>Name  Age  Score</code> 表头，再用 \\t 对齐打印三行数据。</li>
<li><b>输入练习：</b>读入两个整数，输出它们的和、差、积、整数商与余数。</li>
<li><b>字符练习：</b>读入一个字符，是字母就大小写互换，不是字母就提示"输入有误"。</li>
<li><b>分支练习：</b>输入 1–5 的评分，用 switch 输出不同评语，输入其他数字走 default。</li>
<li><b>循环练习：</b>求 1 到 100 里所有奇数的和；再用 continue 写一遍，比较两种写法。</li>
<li><b>综合练习：</b>猜数字游戏：<code>srand(time(0))</code> 生成 1–100，循环读入猜测，提示"大了/小了"，猜中输出次数。</li>
</ol>
<div class="note tip"><strong>做题方法：</strong>先写伪代码（几步、每步做什么），再翻译成 C；每写完一小段就编译运行一次，别一次写一百行再调。</div>
<h3>第一课易错清单</h3>
<table class="tbl"><thead><tr><th>坑</th><th>正确做法</th></tr></thead><tbody>
<tr><td><code>if (a = 1)</code></td><td>比较用 <code>==</code></td></tr>
<tr><td>if 后不写花括号，却写了多条语句</td><td>多条语句必须加 <code>{ }</code></td></tr>
<tr><td>变量不初始化就累加</td><td><code>int sum = 0;</code></td></tr>
<tr><td><code>5 / 2</code> 想得到 2.5</td><td>写成 <code>5.0 / 2</code> 或强制转换</td></tr>
<tr><td><code>scanf("%c")</code> 读到回车</td><td>前面加空格或先 <code>getchar()</code></td></tr>
<tr><td><code>scanf("%d", a)</code> 漏 &amp;</td><td><code>scanf("%d", &amp;a)</code></td></tr>
<tr><td>switch 的 case 忘写 break</td><td>每个 case 结束加 <code>break</code></td></tr>
<tr><td>for 里 <code>i &lt;= 10</code> 写成 <code>i &lt; 10</code></td><td>想清楚边界：含不含 10</td></tr>
<tr><td>数组/字符串越界（后面会讲）</td><td>先记住：下标从 0 开始</td></tr>
</tbody></table>
<h3>和后续课程的连接</h3>
<p>这一课只讲"语言本身"。到了 STM32 实验课，你会看到 CubeMX 生成的代码里全是这些元素：<code>if</code> 判断、<code>for</code> 循环、<code>uint8_t</code> 类型、<code>&amp;</code> 取地址、位运算改寄存器。先把这里练熟，再去看 HAL 代码会轻松很多。</p>
<p><a href="#/lessons/led">→ 去实验课：控制一只 LED</a></p>`
    }
  ]
};
