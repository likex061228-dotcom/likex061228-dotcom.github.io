export const GPIO_LESSON={
 id:'lessons',group:'实验课',title:'实验一：控制一只LED',kicker:'NANO STM32F1 · PC0 · CubeMX与HAL',sections:[{
 id:'led',title:'控制一只LED',html:`
<div class="course-intro"><span class="course-number">实验 01</span><p>用同一个引脚，解释灯为什么亮、为什么灭，以及写了代码却没变化时该查什么。</p><dl><div><dt>课程板卡</dt><dd>NANO STM32F1 / STM32F103RCT6</dd></div><div><dt>本课目标</dt><dd>根据LED接法选择电平，并用代码和寄存器核对</dd></div><div><dt>需要的基础</dt><dd>知道高、低电平与GPIO的含义；不会也可以从下图开始</dd></div></dl></div>
<h3 id="led-wiring">1. 先看LED接在哪里</h3>
<p>这节用 <code>VDD → 限流电阻 → LED → PC0</code> 的接法。PC0拉低时，电流流入引脚，LED点亮；PC0驱动高时，LED熄灭。<b>“写1”不等于“灯亮”。</b></p>
<p class="course-assumption">PC0对应课程资料中的LED0。下图是低电平点亮的<strong>教学接法</strong>，不是实物原理图；上板前需对照你这块板的LED方向、限流电阻和跳线。本页只计算离散逻辑，不运行固件，也不计算电压、电流大小。</p>
<h3 id="led-experiment">2. 预测，再应用配置</h3>
<p>先保持推挽输出和时钟开启，分别试一次写0和写1。选择你预计的LED状态，再点“应用”。改面板参数不会立即改电路，代码和寄存器也始终对应<strong>已应用</strong>的配置。</p>
<div data-widget="led-lesson"></div>
<h3 id="led-understand">3. 用三个问题检查理解</h3>
<ol><li>LED点亮时，电流是从引脚流出，还是流入引脚？<details><summary>核对解释</summary><p>从VDD流过LED，进入PC0，再到地。这是引脚吸收电流（常称灌电流）；高电平源出电流常称拉电流。</p></details></li><li>为什么开漏写1不能直接当作“输出高”？<details><summary>核对解释</summary><p>开漏写1关闭下拉管，输出级释放。若有独立上拉，逻辑电平可确定为高；仅有LED支路时，本课不推断漏电和微亮，因此标为不确定。</p></details></li><li>输入模式下，ODR为0能说明引脚为低吗？<details><summary>核对解释</summary><p>不能。先看MODE是不是输出；输出锁存和输出驱动是不同的事。浮空输入时，写ODR不会使输出级拉低。</p></details></li></ol>
<h3 id="led-cubemx">4. 在CubeMX配置PC0</h3>
<ol class="steps"><li>芯片选择 <code>STM32F103RCT6</code>，System Core → SYS → Debug 选 <code>Serial Wire</code>，保留SWD调试引脚。</li><li>选PC0为 <code>GPIO_Output</code>。GPIO设置：Output Push Pull、No pull、Low speed；初始输出Level选Low。低速是输出边沿档位，不是灯的闪烁频率。</li><li>Project Manager选择MDK-ARM，按课程约定生成外设独立.c/.h；Generate Code。若未分文件，GPIO初始化可能仍在main.c中。</li><li>检查 <code>MX_GPIO_Init()</code>：应包含GPIOC时钟、PC0初始输出值、推挽模式和初始化调用。核对函数确实在main中被调用。</li></ol>
<p>本课是静态GPIO，不要求把系统时钟设到72MHz。已有课程工程的时钟配置可以保留；晶振与PLL参数要按板卡材料设置，不用为点灯盲目改时钟树。</p>
<h3 id="led-keil">5. 在Keil编译、下载和验证</h3>
<p>确认基础工程能编译后，在 <code>main.c</code> 的 <code>/* USER CODE BEGIN 3 */</code> 与对应END标记之间加入下面两行（该区域在while循环内）。不要重复粘贴整套GPIO初始化。</p>
<pre class="code"><code>HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_0);
HAL_Delay(500);</code></pre>
<p>这个例子每500ms翻转一次，完整明灭周期约1s。它依赖GPIO初始化、HAL时基正常以及程序没有停在断点；网页没有编译或执行这段代码。</p>
<ol class="steps"><li><b>编译：</b>Build，确认0 errors。编译只生成程序文件，不会修改板子。</li><li><b>下载：</b>Options for Target → Debug选择实际下载器，核对SWD连接；Flash Download设置中的复位/运行选项以下载器版本为准，然后Download。</li><li><b>运行：</b>退出暂停状态或复位板子，观察LED0。若进入Debug后停在入口，需要Run才能继续。</li><li><b>核对：</b>灯亮时在写低语句之后暂停，观察GPIOC的ODR第0位；同时核对CRL第0–3位为0010（低速推挽）。调试界面能否显示外设取决于芯片包，也可在Watch读取表达式。</li></ol>
<h3 id="led-troubleshoot">6. 灯没有按预期变化，按顺序查</h3>
<table class="tbl"><thead><tr><th>你看到什么</th><th>下一步查什么</th><th>查到后再决定</th></tr></thead><tbody>
<tr><td>编译报错</td><td>先看第一条错误和文件行号</td><td>函数是否在正确作用域，gpio.h/HAL头文件是否已包含；不要先反复下载</td></tr>
<tr><td>编译成功，下载失败</td><td>下载器、供电、SWD线序与目标选择</td><td>先建立连接，不用改LED极性</td></tr>
<tr><td>下载成功，灯不变</td><td>是否Run、是否停在断点；MX_GPIO_Init与循环是否执行</td><td>再查GPIOC时钟、PC0模式与输出位</td></tr>
<tr><td>ODR按时改变，LED不变</td><td>实际LED引脚、板载跳线和电路接法</td><td>ODR只能证明输出锁存改变，不证明实物LED连接正确</td></tr>
<tr><td>现象和网页相反</td><td>实物LED极性是否与教学接法一致</td><td>以板卡原理图和实测为准，不为符合网页而改接危险电路</td></tr>
</tbody></table>
<p class="lesson-source">依据：<a href="https://www.st.com/resource/en/reference_manual/cd00171190-stm32f101xx-stm32f102xx-stm32f103xx-stm32f105xx-and-stm32f107xx-advanced-armbased-32bit-mcus-stmicroelectronics.pdf" target="_blank" rel="noopener">ST RM0008，GPIO章节</a>；<a href="https://www.st.com/resource/en/application_note/DM00315319-.pdf" target="_blank" rel="noopener">ST AN4899，输出电流与GPIO结构</a>。需要查其他模式时，使用左侧GPIO参考章节。</p>`
 }]};
