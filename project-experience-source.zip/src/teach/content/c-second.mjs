// C 语言第二课：函数、数组、排序、二维数组、递归、作用域、数组传参、字符串。
// 结构沿用第一课的讲义风格：学习目标 → 讲解 → 代码/运行结果 → 交互 → 常见坑 → 随堂小测。

const esc = s => String(s).trim().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const code = (src, name = 'main.c') => `
<div class="c-code">
  <div class="c-code-bar"><i></i><i></i><i></i><b>${name}</b><button type="button" data-copy>复制</button></div>
  <pre><code>${esc(src)}</code></pre>
</div>`;

const out = t => `<div class="c-out"><span>运行结果 / 控制台</span><pre>${esc(t)}</pre></div>`;
const goals = (...items) => `<div class="c-goals">${items.map(([k, v]) => `<div><small>${k}</small><b>${v}</b></div>`).join('')}</div>`;
const quick = id => `<div data-widget="c-quick" data-check="${id}"></div>`;
const next = (href, label, hint) => `<div class="note tip"><a href="${href}"><strong>下一节：${label} →</strong></a>　${hint}</div>`;

export const C_SECOND = {
  id: 'c-second',
  group: 'C 语言',
  title: 'C 语言第二课：函数、数组、排序与字符串',
  kicker: '从"一段代码"到"一组数据" · 指针之前必须打牢的部分',
  sections: [
    {
      id: 'functions',
      title: '函数：把一段逻辑装进一个名字里',
      kicker: '声明、定义、调用与值传递',
      html: `
${goals(['能写', '声明 + 定义 + 调用三件套'], ['能解释', '形参与实参、值传递'], ['能排查', '声明不一致、忘记声明'])}
<p>如果"比较两个数"要写七八遍，程序会又长又难改。函数就是把这段逻辑封起来，起个名字，需要时调用：</p>
<div class="note"><strong>读代码前的小提醒：</strong>本章有些片段为了聚焦语法省略了 <code>#include &lt;stdio.h&gt;</code>；自己复制去编译时记得补上，否则 printf/scanf 会报隐式声明。</div>
${code(`#include <stdio.h>

int max(int a, int b)
{
    return a > b ? a : b;
}

int main(void)
{
    printf("%d\\n", max(3, 5));   /* 5 */
    return 0;
}`, 'main.c')}
<h3>声明、定义、调用</h3>
<table class="tbl"><thead><tr><th>概念</th><th>写法</th><th>作用</th></tr></thead><tbody>
<tr><td>声明（原型）</td><td><code>int max(int a, int b);</code></td><td>告诉编译器"有这么一个函数"，让调用处能通过检查</td></tr>
<tr><td>定义</td><td><code>int max(int a, int b) { … }</code></td><td>给出真正实现</td></tr>
<tr><td>调用</td><td><code>max(a, b)</code></td><td>执行函数，把结果用在表达式里</td></tr>
</tbody></table>
<div class="note tip"><strong>为什么可以先声明、后定义：</strong>编译器从上往下读，遇到调用时要先知道"返回什么类型、要几个参数"。把定义放在 main 后面时，必须在前面补一行声明。</div>
<h3>形参与实参：值传递</h3>
<p><code>max(a, b)</code> 里的 <code>a</code>、<code>b</code> 是实参；函数头里的 <code>x</code>、<code>y</code> 是形参。调用时做的是<b>复制值</b>，函数里改形参不会影响外面的变量。</p>
<div data-widget="c-trace" data-trace="pass"></div>
<p>这也是为什么后面需要"传地址"：想改调用处的变量，就得让函数拿到它的地址（指针）。</p>
<h3>常见错误</h3>
<table class="tbl"><thead><tr><th>现象</th><th>原因</th><th>修法</th></tr></thead><tbody>
<tr><td>隐式声明警告 / 结果离谱</td><td>定义在调用之后，又没声明</td><td>在 main 前加函数原型</td></tr>
<tr><td>调用时写了 <code>max(int a, int b);</code></td><td>把定义形式当调用</td><td>调用只写 <code>max(a, b)</code></td></tr>
<tr><td>链接错误 / 返回类型不匹配</td><td>声明与定义不一致</td><td>返回类型、参数类型和个数保持一致</td></tr>
<tr><td>改了函数里的参数，外面没变</td><td>值传递，改的是副本</td><td>需要改变外面就用返回值或传地址</td></tr>
</tbody></table>
${quick('functions')}
${next('#/c-second/array1', '一维数组', '同类型数据排成一排。')}`
    },
    {
      id: 'array1',
      title: '一维数组：连续的一排格子',
      kicker: '定义、下标、越界、遍历与 sizeof',
      html: `
${goals(['记住', '下标从 0 开始，长度不是下标'], ['会算', 'sizeof(a)/sizeof(a[0])'], ['避免', '越界与整体比较'])}
<p>数组是一组<b>同类型</b>数据，在内存里连续排列。定义 <code>int a[5];</code> 就是申请了 5 个 int 的连续空间。</p>
${code(`int a[5] = {12, 34, 56, 78, 9};
int b[5] = {12, 34};            /* 其余补 0：{12,34,0,0,0} */
int c[]  = {11, 22, 33};        /* 让编译器数长度：3 */
printf("%d", a[0]);             /* 第一个元素，不是 a[1] */`)}
<div data-widget="c-array"></div>
<h3>越界：C 不会替你检查</h3>
<p>长度为 5 的数组，合法下标是 0–4。<code>a[5]</code> 已经越界，但编译器通常不报错：读可能读到别的变量，写可能改坏程序。这是 C 里最危险、也最常见的 bug 之一。</p>
${code(`int a[5];
a[5] = 1;              /* 越界写：行为未定义 */
for (int i = 0; i < 5; i++)
    a[i] = i;          /* 正确：i < 长度，不是 i <= 长度 */`)}
<h3>sizeof：字节数不是元素个数</h3>
${code(`int a[5] = {1, 2, 3, 4, 5};
int length = sizeof(a) / sizeof(a[0]);   /* 20 / 4 = 5 */`)}
<p><code>sizeof(a)</code> 是整个数组的字节数（5 × 4 = 20），除以单个元素大小才是元素个数。写成 <code>sizeof(a)/sizeof(a[0])</code> 比写死 <code>4</code> 更稳，因为换类型时不用改。</p>
<div class="note warn"><strong>两个高频错误：</strong>把 <code>sizeof(a)</code> 当成元素个数；用 <code>if (a == b)</code> 比较两个数组——数组名比较的是地址，不是内容。比较内容要逐元素循环或用 <code>memcmp</code>。</div>
${quick('array1')}
${next('#/c-second/algorithms', '数组算法', '找最值、三种排序。')}`
    },
    {
      id: 'algorithms',
      title: '数组算法：找最值与三种排序',
      kicker: '冒泡 / 选择 / 插入，每一步都能看见',
      html: `
${goals(['会写', '最值扫描与手写交换'], ['能说清', '三种排序每轮在做什么'], ['能判断', '什么时候用哪种'])}
<h3>找最大值和最小值</h3>
<p>把第一个元素同时当作当前最大和最小，然后从第二个开始扫：</p>
${code(`int max = a[0], min = a[0];
for (int i = 1; i < n; i++) {
    if (a[i] > max) max = a[i];
    if (a[i] < min) min = a[i];
}`)}
<div class="note warn"><strong>别把 max/min 初始化成 0：</strong>如果数组全是负数，0 会让结果错。用第一个元素初始化才稳。</div>
<h3>三种排序：看它们"每一轮在做什么"</h3>
<p>排序不用背代码，先记住每轮的策略：</p>
<table class="tbl"><thead><tr><th>算法</th><th>每一轮做什么</th><th>特点</th></tr></thead><tbody>
<tr><td>冒泡</td><td>相邻两两比较，大的往后换</td><td>每轮末尾就位；可提前结束</td></tr>
<tr><td>选择</td><td>找最小值，和本轮起点交换</td><td>交换次数少；比较次数固定</td></tr>
<tr><td>插入</td><td>把右边元素插进左边已排好的部分</td><td>近乎有序时很快</td></tr>
</tbody></table>
<div data-widget="c-sort"></div>
${code(`/* 冒泡排序核心：注意 j < n-1-i，防止 a[j+1] 越界 */
for (int i = 0; i < n - 1; i++) {
    for (int j = 0; j < n - 1 - i; j++) {
        if (a[j] > a[j + 1]) {
            int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t;
        }
    }
}`)}
<div class="note tip"><strong>交换必须用临时变量：</strong>直接写 <code>a[j] = a[j+1]; a[j+1] = a[j];</code> 会让两个位置变成同一个值——第一个赋值已经把原来的值覆盖了。</div>
<p>三种排序的时间复杂度都是 O(n²)，教学阶段重点不在"更快"，而在"把循环边界和交换写对"。真正要排序时，工程里直接用 <code>qsort</code>。</p>
${quick('algorithms')}
${next('#/c-second/array2', '二维数组', '行和列，以及按行存放。')}`
    },
    {
      id: 'array2',
      title: '二维数组：表格、行列与按行存放',
      kicker: '定义、初始化、遍历、平均分',
      html: `
${goals(['会定义', 'int a[行][列]'], ['会遍历', '双层循环与行列边界'], ['能理解', '内存里是"一行接一行"'])}
<p><code>int a[3][4];</code> 表示 3 行 4 列，共 12 个元素。行下标 0–2，列下标 0–3。</p>
${code(`int a[3][4] = {
    {0, 1, 2, 3},
    {4, 5, 6, 7},
    {8, 9, 10, 11}
};

/* 也可以连续写：{0,1,2,3,4,5,6,7,8,9,10,11} */
/* 省略第一维可以，省略列数不行：int a[][3] = {...}; */`)}
<div data-widget="c-grid"></div>
<p>点任意一格，看 <code>a[i][j]</code> 的行列含义，以及它在内存里的位置。二维数组本质是"元素本身又是一维数组"的数组，内存里按行连续存放：<code>a[0][0] a[0][1] … a[1][0] …</code>。</p>
<h3>遍历与"每科平均分"</h3>
${code(`for (int i = 0; i < 3; i++) {
    int sum = 0;                       /* 每科重新清零 */
    for (int j = 0; j < 5; j++) {
        scanf("%d", &score[i][j]);
        sum += score[i][j];
    }
    subject_average[i] = (double)sum / 5;   /* 注意强制转换 */
}`)}
<div class="note warn"><strong>三个高频错误：</strong>写成 <code>a[1, 2]</code>（逗号表达式，不是二维下标）；内层循环没有从 0 开始（会漏元素）；求平均时 <code>sum / 5</code> 用整数除法（小数被截断）。</div>
${quick('array2')}
${next('#/c-second/recursion', '递归', '函数调用自己，栈会怎么变。')}`
    },
    {
      id: 'recursion',
      title: '递归：函数调用自己，栈里发生了什么',
      kicker: '阶乘、斐波那契、三要素与调用栈',
      html: `
${goals(['能写', '带终止条件的递归'], ['能看懂', '调用栈的压入与返回'], ['能判断', '何时该用迭代'])}
<p>递归 = 函数调用自己。求 <code>n!</code> 可以先求 <code>(n-1)!</code>，再乘 <code>n</code>：</p>
${code(`int fact(int n)
{
    if (n == 0) return 1;      /* 终止条件 */
    return fact(n - 1) * n;    /* 递归关系 + 逼近终止 */
}`)}
<div data-widget="c-recursion"></div>
<p>点"下一步"看每一次调用怎么压栈、怎么返回。递归不是"跳回去重新开始"，而是<b>每次调用都有自己的局部变量和返回地址</b>，存在栈上。</p>
<h3>三要素，缺一不可</h3>
<ol class="steps">
<li><b>终止条件：</b>什么时候直接返回，例如 <code>fact(0) = 1</code>。</li>
<li><b>递归关系：</b>大问题怎么用小问题表示，例如 <code>n! = (n-1)! × n</code>。</li>
<li><b>不断逼近：</b>每次调用都离终止条件更近，例如 <code>n-1</code>。</li>
</ol>
<div class="note warn"><strong>两个经典死法：</strong>忘了终止条件；递归时传的还是 <code>n</code>（没有变小）。两者都会导致栈溢出（Stack Overflow）。</div>
<h3>斐波那契：递归很直观，但很慢</h3>
${code(`int fib(int n)
{
    if (n == 0) return 0;
    if (n == 1) return 1;
    return fib(n - 1) + fib(n - 2);
}`)}
<p><code>fib(30)</code> 会把同样的子问题重复算很多次。理解递归用它很好，真正计算要用迭代或记忆化。</p>
<h3>迭代写法（阶乘）</h3>
${code(`int result = 1;
for (int i = 1; i <= n; i++) result *= i;`)}
<div class="note tip"><strong>怎么选：</strong>问题天然是"大问题 = 小问题 + 一步"（树、汉诺塔、分治）用递归；只是"重复做 n 次"（累加、阶乘）用迭代。递归代码短，但每层调用都有栈开销。</div>
${quick('recursion')}
${next('#/c-second/scope', '局部与全局', '同名变量谁优先。')}`
    },
    {
      id: 'scope',
      title: '局部变量与全局变量：作用域与遮蔽',
      kicker: '谁能看见谁，同名时谁优先',
      html: `
${goals(['分清', '局部 / 全局的作用范围'], ['理解', '同名遮蔽'], ['知道', '为什么少用全局变量'])}
<p><b>局部变量</b>定义在函数或代码块里，出了这块就不存在；<b>全局变量</b>定义在所有函数之外，整个文件都能用。</p>
${code(`int sum = 0;              /* 全局 */

void add(int a, int b)
{
    int sum = a + b;      /* 局部：遮蔽了同名全局变量 */
}

int main(void)
{
    add(2, 5);
    printf("%d", sum);    /* 0，不是 7 */
}`)}
<div data-widget="c-trace" data-trace="shadow"></div>
<p>同名时"近的赢"：函数内使用的是局部变量，全局那个完全没被碰到。</p>
<h3>什么时候用全局</h3>
<table class="tbl"><thead><tr><th>场景</th><th>建议</th></tr></thead><tbody>
<tr><td>函数之间共享状态</td><td>优先用参数和返回值，别用全局</td></tr>
<tr><td>常量、配置</td><td>可以用全局 <code>const</code></td></tr>
<tr><td>中断和主循环共享的标志</td><td>单片机会用，但要加 <code>volatile</code></td></tr>
</tbody></table>
<div class="note warn"><strong>全局变量的问题：</strong>谁都能改，出 bug 很难定位；函数之间产生隐式依赖。初学阶段尽量"数据从参数进、结果从返回值出"。</div>
${quick('scope')}
${next('#/c-second/passarray', '向函数传数组', '为什么函数里 sizeof 不对。')}`
    },
    {
      id: 'passarray',
      title: '向函数传递数组：为什么必须再传长度',
      kicker: '数组名退化为指针、sizeof 陷阱',
      html: `
${goals(['会写', 'int f(int a[], int n)'], ['能解释', '为什么 sizeof 失效'], ['能避免', '把 a[8] 当数组传'])}
<p>把数组传给函数时，传的是首地址，不是"整个数组的副本"：</p>
${code(`#include <stdio.h>

int max_search(int a[], int length)   /* 形参 int a[] 等价于 int *a */
{
    int max = a[0];
    for (int i = 1; i < length; i++)
        if (a[i] > max) max = a[i];
    return max;
}

int main(void)
{
    int a[8] = {5, 6, 7, 2, 5, 7, 8, 2};
    int length = sizeof(a) / sizeof(a[0]);   /* 在 main 里算，8 */
    printf("%d\\n", max_search(a, length));
    return 0;
}`)}
<div data-widget="c-array"></div>
<p>在上面的数组卡片里勾选"假设在函数里"，看 <code>sizeof(a)</code> 从 20 变成 8：因为函数里的 <code>a</code> 已经是指针了。</p>
<div class="note warn"><strong>三个高频错误：</strong>调用时写 <code>max_search(a[8], length)</code>（那是越界元素，不是数组）；忘了传长度；在函数里用 <code>sizeof(a)/sizeof(a[0])</code> 求元素个数。</div>
<p>因为函数拿到的是地址，函数里<b>修改数组元素会影响原数组</b>——这和普通参数的值传递不同，也是后面指针章节的入口。</p>
${quick('passarray')}
${next('#/c-second/strings', '字符串', '\\0 到底在哪。')}`
    },
    {
      id: 'strings',
      title: '字符串：一切问题先问"\\0 在哪"',
      kicker: '\\0 终止符、输入输出、string.h 与手写 strlen',
      html: `
${goals(['记住', '字符串以 \\0 结尾'], ['会算', '数组大小 = 字符数 + 1'], ['会用', 'strlen / strcmp / strcpy / strcat'])}
<p>C 没有独立的"字符串类型"，字符串就是字符数组，并以 <code>'\\0'</code>（编号 0）结尾。所有字符串函数都靠它找结尾。</p>
${code(`char s[6] = "hello";   /* 5 个字符 + 1 个 '\\0' */
char t[]  = "China";    /* 编译器自动算长度：6 */

/* 下标： 0  1  2  3  4  5
   内容： h  e  l  l  o  \\0 */`)}
<div data-widget="c-string"></div>
<p>改字符串、点"读下一个字符"：看指针走到 <code>\\0</code> 就停。<code>strlen</code> 返回 5，不把终止符算进去。</p>
<h3>输入输出</h3>
${code(`char text[20];
scanf("%19s", text);    /* 最多 19 个字符，留 1 个给 '\\0' */
printf("%s\\n", text);   /* 数组名就是首地址，不用加 & */`)}
<div class="note warn"><strong>%s 遇到空格就停：</strong>输入 "Zhang San" 只会读到 "Zhang"。要读整行，后面用 <code>fgets</code>。另外 <code>scanf("%s", &amp;text)</code> 是错的，<code>%s</code> 要的是首地址。</div>
<h3>string.h 常用函数</h3>
<table class="tbl"><thead><tr><th>函数</th><th>作用</th><th>注意</th></tr></thead><tbody>
<tr><td><code>strlen(s)</code></td><td>长度</td><td>不计 <code>'\\0'</code></td></tr>
<tr><td><code>strcpy(dst, src)</code></td><td>复制</td><td>dst 必须装得下 src + <code>'\\0'</code></td></tr>
<tr><td><code>strcmp(a, b)</code></td><td>比较内容</td><td>返回 0 才相等；不要用 == 比较数组</td></tr>
<tr><td><code>strcat(dst, src)</code></td><td>拼接</td><td>dst 剩余空间要够</td></tr>
</tbody></table>
<h3>手写 strlen</h3>
${code(`int str_len(const char *s)
{
    int len = 0;
    while (s[len] != '\\0') len++;   /* 别忘记 len++ */
    return len;
}`)}
<div class="note tip"><strong>我自己的一条经验：</strong>看到字符串相关的 bug，先按顺序问三个问题——① 数组够不够大（字符数 + 1）？② <code>'\\0'</code> 还在吗（有没有被覆盖）？③ 用的是 <code>%s</code> 还是 <code>%c</code>？这三问能解决初学阶段绝大多数乱码和越界。</div>
${quick('strings')}
<div class="note tip"><strong>第二课到这里。</strong>下一课进入指针：为什么函数改不了外面的变量、为什么数组能"传进去改"，答案都在地址里。<a href="#/lessons/led">也可以先去实验课，把 C 用到板子上 →</a></div>`
    }
  ]
};
