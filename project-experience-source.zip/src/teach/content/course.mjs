export const COURSE={id:'course',group:'课程入口',title:'嵌入式实验手册',kicker:'Like_x · 普中精灵1 / CubeMX / HAL',sections:[{id:'start',title:'嵌入式实验手册',html:`
<div class="manual-opening"><p class="manual-lead">六个实验，从配置到检查。</p><p>六个小实验，把配置、电平、时序和代码放在一起。先观察，再修改一个条件，最后带着检查清单回到板子上。</p><p class="manual-board">课程主线：普中精灵1 STM32F103C8T6 · CubeMX + Keil · HAL。厂商例程采用标准外设库；本课以CubeMX＋HAL改写，不混用API。其他芯片的寄存器差异留在参考章节。</p></div>
<div data-widget="workshop-home"></div>
<h3>手边放什么</h3><div class="manual-preparation"><div><b>先在网页里试</b><p>浏览器即可。不连接你的硬件，不上传代码或学习记录。</p></div><div><b>准备上板时</b><p>学习板、适配的下载器与数据线；确认供电、引脚和原理图。软件用合法授权版本，网页不分发安装包。</p></div></div>
<h3>遇到问题，从证据开始</h3><p>编译失败、下载失败、运行结果不对，是三条不同的排查路径。每课都保留了关键代码位置、应观察的信号和常见故障；<a href="#/faq/faq-all">常见问题索引</a>供随时查阅。参考章节仍可从左侧直接打开。</p>
<details class="manual-boundary"><summary>这些模型能说明什么</summary><p>网页按明确的GPIO、采样、挂起位、调度和计数规则计算教学结果，不执行STM32固件，也不做模拟电路或真实时序求解。输入波形、外设时钟和处理时长均为课程条件。课程引脚已核对精灵1核心板/底板原理图与例程；上板仍须确认实物版本、模块连接、极性与时钟。记录完成一次网页操作，不等于掌握，更不等于硬件验收。</p></details>`}]};
