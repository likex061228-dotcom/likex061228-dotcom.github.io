import {loadChecks,esc} from './workshop-ui.mjs';
const rows=[
 ['led','01','电平与电路','控制一只LED','区分输出锁存、引脚驱动与低电平点亮。',3],
 ['button','02','输入与采样','确认一次按键','同一串接点电平，采样策略会改变确认结果。',3],
 ['exti','03','请求与服务','跟踪一次EXTI请求','边沿、挂起位与回调，分别发生在什么地方。',3],
 ['nvic','04','等待与抢占','排出中断的执行顺序','改分组和优先级，逐事件查看CPU交给了谁。',2],
 ['timer','05','时钟与计数','推导一次定时更新','停在ARR附近，单步看CNT归零。',2],
 ['pwm','06','比较与输出','看懂PWM和LED','同一条波形，引脚高比例与LED导通比例不同。',3]
];
function done(id){if(id!=='led')return loadChecks(id).size;try{const s=JSON.parse(localStorage.getItem('Like_x.teach.puzhong.led-checks.v1')||'{}');return ['low','high','fault'].filter(k=>s[k]===true).length;}catch{return 0;}}
export function workshopHome(host){
 let last='';try{last=localStorage.getItem('Like_x.teach.puzhong.lastLesson.v1')||'';}catch{}
 const resume=rows.find(r=>r[0]===last);
 host.innerHTML=`${resume?`<a class="manual-resume" href="#/lessons/${resume[0]}"><span>上次停在</span><b>${resume[1]} · ${resume[3]}</b><span>继续 →</span></a>`:''}<ol class="manual-lessons">${rows.map(([id,n,topic,title,summary,total])=>{const count=Math.min(total,done(id));return `<li><a href="#/lessons/${id}"><span class="manual-number">${n}</span><div class="manual-lesson-main"><small>${esc(topic)}</small><h3>${esc(title)}</h3><p>${esc(summary)}</p></div><div class="manual-lesson-status"><span>${count?`${count}/${total}项网页检查`:'开始实验'}</span><b aria-hidden="true">↗</b></div></a></li>`;}).join('')}</ol><p class="manual-storage-note">检查记录只在这个浏览器里。打开课文不会自动算作完成。</p>`;
}
