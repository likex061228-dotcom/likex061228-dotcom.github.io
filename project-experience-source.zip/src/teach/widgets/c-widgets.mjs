// C 语言课专用交互组件：逐行执行、内存盒子、ASCII、scanf 缓冲区、格式实验、随堂小测。
import { formatOne, FORMAT_PRESETS } from '../model/format.mjs';

const visible = s => /^\s|\s$/.test(String(s)) ? String(s).replace(/ /g, '␣') : String(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* ---------------- 逐行执行 ---------------- */
function buildSumTrace() {
  const code = ['int sum = 0;', 'for (int i = 1; i <= 5; i++) {', '    sum += i;', '}', 'printf("%d", sum);'];
  const steps = [{ line: 0, vars: { sum: '0', i: '—' }, out: '', note: 'sum 初始化为 0' }];
  let sum = 0;
  for (let i = 1; i <= 5; i++) {
    steps.push({ line: 1, vars: { sum: String(sum), i: String(i) }, out: '', note: `进入循环：i = ${i}，i <= 5 成立` });
    sum += i;
    steps.push({ line: 2, vars: { sum: String(sum), i: String(i) }, out: '', note: `sum = ${sum - i} + ${i} = ${sum}` });
    steps.push({ line: 1, vars: { sum: String(sum), i: String(i + 1) }, out: '', note: i < 5 ? `i++ 后 i = ${i + 1}` : 'i++ 后 i = 6，条件不成立，退出循环' });
  }
  steps.push({ line: 4, vars: { sum: String(sum), i: '6' }, out: String(sum), note: `循环结束，输出 ${sum}` });
  return { title: '求 1 到 5 的和', code, steps };
}

const TRACES = {
  sum: buildSumTrace(),
  inc: {
    title: '前自增与后自增',
    code: ['int i = 1;', 'int a = ++i;', 'int b = i++;', 'printf("%d %d %d", i, a, b);'],
    steps: [
      { line: 0, vars: { i: '1', a: '未定义', b: '未定义' }, out: '', note: 'i 初始化为 1' },
      { line: 1, vars: { i: '2', a: '2', b: '未定义' }, out: '', note: '++i：先把 i 加到 2，再赋给 a' },
      { line: 2, vars: { i: '3', a: '2', b: '2' }, out: '', note: 'i++：先把 2 赋给 b，再把 i 加到 3' },
      { line: 3, vars: { i: '3', a: '2', b: '2' }, out: '3 2 2', note: '输出 i、a、b' }
    ]
  }
};

function cTrace(host) {
  const trace = TRACES[host.dataset.trace] || TRACES.sum;
  let step = 0;
  host.innerHTML = `
    <div class="ctrace">
      <div class="ctrace-head"><b>逐行执行</b><span>${esc(trace.title)}</span></div>
      <div class="ctrace-body">
        <div class="ctrace-code" role="list">
          ${trace.code.map((line, i) => `<div class="ctrace-line" data-line="${i}"><i>${i + 1}</i><code>${esc(line)}</code></div>`).join('')}
        </div>
        <div class="ctrace-side">
          <table class="ctrace-vars"><thead><tr><th>变量</th><th>值</th></tr></thead><tbody></tbody></table>
          <div class="ctrace-console"><span>输出</span><pre></pre></div>
        </div>
      </div>
      <div class="ctrace-note"></div>
      <div class="ctrace-controls">
        <button type="button" data-act="reset">↺ 重置</button>
        <button type="button" data-act="prev">← 上一步</button>
        <button type="button" data-act="next">下一步 →</button>
        <button type="button" data-act="play">▶ 自动播放</button>
        <span class="ctrace-progress"></span>
      </div>
    </div>`;

  const lines = host.querySelectorAll('.ctrace-line');
  const tbody = host.querySelector('.ctrace-vars tbody');
  const consoleEl = host.querySelector('.ctrace-console pre');
  const noteEl = host.querySelector('.ctrace-note');
  const progress = host.querySelector('.ctrace-progress');
  let timer = null;

  function render() {
    const s = trace.steps[step];
    lines.forEach((el, i) => el.classList.toggle('active', i === s.line));
    tbody.innerHTML = Object.entries(s.vars).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join('');
    consoleEl.textContent = s.out || '（还没有输出）';
    noteEl.textContent = s.note;
    progress.textContent = `第 ${step + 1} / ${trace.steps.length} 步`;
  }
  function stop() { if (timer) { clearInterval(timer); timer = null; host.querySelector('[data-act="play"]').textContent = '▶ 自动播放'; } }

  host.querySelector('[data-act="next"]').onclick = () => { stop(); step = Math.min(trace.steps.length - 1, step + 1); render(); };
  host.querySelector('[data-act="prev"]').onclick = () => { stop(); step = Math.max(0, step - 1); render(); };
  host.querySelector('[data-act="reset"]').onclick = () => { stop(); step = 0; render(); };
  host.querySelector('[data-act="play"]').onclick = e => {
    if (timer) { stop(); return; }
    if (step >= trace.steps.length - 1) step = 0;
    e.currentTarget.textContent = '⏸ 暂停';
    timer = setInterval(() => {
      if (step >= trace.steps.length - 1) { stop(); return; }
      step++; render();
    }, 900);
  };
  host._cleanup = stop;
  render();
}

/* ---------------- 内存盒子 ---------------- */
function cMemory(host) {
  const mode = host.dataset.type || 'int';
  let value = mode === 'char' ? 65 : 42;

  function bitsOf(v, width) {
    const out = [];
    for (let i = width - 1; i >= 0; i--) out.push((v >> BigInt(i)) & 1n ? '1' : '0');
    return out;
  }

  function render() {
    const width = mode === 'char' ? 8 : 32;
    const big = BigInt(Math.trunc(value));
    const masked = width === 8 ? BigInt.asUintN(8, big) : BigInt.asUintN(32, big);
    const bits = bitsOf(masked, width);
    const byteCount = width / 8;
    const bytes = [];
    for (let i = 0; i < byteCount; i++) bytes.push(bits.slice(i * 8, i * 8 + 8));
    const signed = mode === 'char' ? [-(2 ** 7), 2 ** 7 - 1] : [-(2 ** 31), 2 ** 31 - 1];
    const unsigned = mode === 'char' ? [0, 2 ** 8 - 1] : [0, 2 ** 32 - 1];
    const isNegative = bits[0] === '1' && mode !== 'uint';

    host.innerHTML = `
      <div class="cmem">
        <div class="cmem-head">
          <b>内存里的样子</b>
          <label>值 <input type="number" data-k="value" value="${value}" ${mode === 'char' ? 'min="-128" max="255"' : ''}></label>
        </div>
        <div class="cmem-bytes">
          ${bytes.map((b, i) => `<div class="cmem-byte"><small>字节 ${i + 1}</small>${b.map((bit, j) => `<i class="${i === 0 && j === 0 ? 'sign' : ''}">${bit}</i>`).join('')}</div>`).join('')}
        </div>
        <div class="cmem-readout">
          <div><small>十进制</small><b>${value}</b></div>
          <div><small>十六进制</small><b>0x${masked.toString(16).toUpperCase().padStart(byteCount * 2, '0')}</b></div>
          <div><small>${mode === 'char' ? 'char 范围' : 'int 范围'}</small><b>${signed[0]} ~ ${signed[1]}</b></div>
          <div><small>${mode === 'uint' ? 'unsigned' : '符号位'}</small><b>${isNegative ? '1（负数）' : bits[0] === '1' && mode === 'uint' ? '1（无符号，仍是正数）' : '0（非负）'}</b></div>
        </div>
        <p class="cmem-note">${mode === 'char' ? 'char 只有 8 位：最高位当符号位时范围是 −128~127，加 1 就溢出。' : 'int 32 位：最高位是符号位。负数在内存里用补码存储，所以 -1 全是 1。'}</p>
      </div>`;

    host.querySelector('input').oninput = e => {
      value = Number(e.target.value) || 0;
      const lim = mode === 'char' ? [-(2 ** 7), 2 ** 8 - 1] : [-(2 ** 31), 2 ** 32 - 1];
      if (value < lim[0]) value = lim[0];
      if (value > lim[1]) value = lim[1];
      render();
    };
  }
  render();
}

/* ---------------- ASCII 实验 ---------------- */
function cAscii(host) {
  let ch = 'A';
  host.innerHTML = `
    <div class="cascii">
      <div class="cascii-row">
        <label>输入一个字符<input type="text" maxlength="1" value="A" data-k="ch"></label>
        <button type="button" data-act="swap">大小写互换</button>
      </div>
      <div class="cascii-cards">
        <div><small>字符</small><b data-out="ch">A</b></div>
        <div><small>十进制</small><b data-out="dec">65</b></div>
        <div><small>十六进制</small><b data-out="hex">0x41</b></div>
        <div><small>二进制</small><b data-out="bin">01000001</b></div>
      </div>
      <div class="cascii-bar"><div class="cascii-scale"></div><i data-out="marker"></i>
        <span class="tick" style="left:1%">0</span><span class="tick" style="left:37.5%">48</span>
        <span class="tick" style="left:50.8%">65</span><span class="tick" style="left:75.8%">97</span>
        <span class="tick" style="left:97%">127</span>
      </div>
      <p class="cascii-note" data-out="note"></p>
    </div>`;
  function render() {
    const code = ch.charCodeAt(0);
    host.querySelector('[data-out="ch"]').textContent = ch;
    host.querySelector('[data-out="dec"]').textContent = code;
    host.querySelector('[data-out="hex"]').textContent = '0x' + code.toString(16).toUpperCase();
    host.querySelector('[data-out="bin"]').textContent = code.toString(2).padStart(8, '0');
    host.querySelector('[data-out="marker"]').style.left = Math.min(99, (code / 127) * 100) + '%';
    let note = '';
    if (/[A-Z]/.test(ch)) note = '大写字母。加 32 就是小写：' + String.fromCharCode(code + 32);
    else if (/[a-z]/.test(ch)) note = '小写字母。减 32 就是大写：' + String.fromCharCode(code - 32);
    else if (/[0-9]/.test(ch)) note = '数字字符的编号连续：\'0\' 是 48，\'9\' 是 57。转成数值要减 48。';
    else note = '不是字母或数字。ASCII 里标点、空格也各有一个编号。';
    host.querySelector('[data-out="note"]').textContent = note;
  }
  host.querySelector('input').oninput = e => { ch = (e.target.value || 'A').slice(-1); render(); };
  host.querySelector('[data-act="swap"]').onclick = () => {
    const code = ch.charCodeAt(0);
    if (code >= 65 && code <= 90) ch = String.fromCharCode(code + 32);
    else if (code >= 97 && code <= 122) ch = String.fromCharCode(code - 32);
    host.querySelector('input').value = ch;
    render();
  };
  render();
}

/* ---------------- scanf 缓冲区 ---------------- */
function cBuffer(host) {
  const scenario = {
    input: ['3', '⏎', 'A', '⏎', '5', '⏎'],
    wrong: [
      { line: 0, buf: ['3', '⏎', 'A', '⏎', '5', '⏎'], vars: { a: '未定义', b: '未定义', c: '未定义' }, note: '输入缓冲里是：3 ⏎ A ⏎ 5 ⏎' },
      { line: 0, buf: ['⏎', 'A', '⏎', '5', '⏎'], vars: { a: '3', b: '未定义', c: '未定义' }, note: '%d 读走 3，回车还留在缓冲里' },
      { line: 1, buf: ['A', '⏎', '5', '⏎'], vars: { a: '3', b: "'\\n'", c: '未定义' }, note: '%c 不跳过空白，把回车读给了 b' },
      { line: 2, buf: ['A', '⏎', '5', '⏎'], vars: { a: '3', b: "'\\n'", c: '失败' }, note: '%d 遇到 A 没法解析，读取失败，c 还是原值' }
    ],
    fixed: [
      { line: 0, buf: ['3', '⏎', 'A', '⏎', '5', '⏎'], vars: { a: '未定义', b: '未定义', c: '未定义' }, note: '同样一段输入' },
      { line: 0, buf: ['⏎', 'A', '⏎', '5', '⏎'], vars: { a: '3', b: '未定义', c: '未定义' }, note: '%d 读走 3' },
      { line: 1, buf: ['A', '⏎', '5', '⏎'], vars: { a: '3', b: '未定义', c: '未定义' }, note: '" %c" 里的空格先跳过回车，再读字符' },
      { line: 2, buf: ['⏎', '5', '⏎'], vars: { a: '3', b: "'A'", c: '未定义' }, note: 'b 读到 A' },
      { line: 3, buf: ['⏎', '5', '⏎'], vars: { a: '3', b: "'A'", c: '5' }, note: '%d 自动跳过空白，读到 5' }
    ]
  };
  let fixed = false;
  const codeWrong = ['scanf("%d", &a);', 'scanf("%c", &b);', 'scanf("%d", &c);', 'printf("%d%c%d", a, b, c);'];
  const codeFixed = ['scanf("%d", &a);', 'scanf(" %c", &b);', 'scanf("%d", &c);', 'printf("%d%c%d", a, b, c);'];
  let step = 0;

  host.innerHTML = `
    <div class="cbuf">
      <div class="cbuf-head">
        <b>输入缓冲区</b>
        <label class="cbuf-toggle"><input type="checkbox" data-k="fixed"> 用 " %c" 修复</label>
      </div>
      <div class="cbuf-code"></div>
      <div class="cbuf-playfield">
        <div class="cbuf-queue"><small>缓冲区（左端先被读）</small><div class="cbuf-cells"></div></div>
        <div class="cbuf-vars"></div>
      </div>
      <div class="cbuf-note"></div>
      <div class="cbuf-controls">
        <button type="button" data-act="reset">↺ 重置</button>
        <button type="button" data-act="next">下一步 →</button>
        <span class="cbuf-progress"></span>
      </div>
    </div>`;

  function currentSteps() { return fixed ? scenario.fixed : scenario.wrong; }
  function render() {
    const steps = currentSteps();
    const s = steps[Math.min(step, steps.length - 1)];
    const code = fixed ? codeFixed : codeWrong;
    host.querySelector('.cbuf-code').innerHTML = code.map((l, i) => `<div class="cbuf-line ${i === s.line ? 'active' : ''}"><i>${i + 1}</i><code>${esc(l)}</code></div>`).join('');
    host.querySelector('.cbuf-cells').innerHTML = s.buf.length
      ? s.buf.map((c, i) => `<span class="cbuf-cell ${i === 0 ? 'front' : ''}">${c === '⏎' ? '⏎' : esc(c)}</span>`).join('')
      : '<span class="cbuf-empty">空</span>';
    host.querySelector('.cbuf-vars').innerHTML = Object.entries(s.vars).map(([k, v]) => `<div><small>${k}</small><b>${esc(v)}</b></div>`).join('');
    host.querySelector('.cbuf-note').textContent = s.note;
    host.querySelector('.cbuf-progress').textContent = `第 ${Math.min(step + 1, steps.length)} / ${steps.length} 步`;
  }
  host.querySelector('[data-k="fixed"]').onchange = e => { fixed = e.target.checked; step = 0; render(); };
  host.querySelector('[data-act="next"]').onclick = () => { const n = currentSteps().length; step = Math.min(n - 1, step + 1); render(); };
  host.querySelector('[data-act="reset"]').onclick = () => { step = 0; render(); };
  render();
}

/* ---------------- 格式实验 ---------------- */
function cFormat(host) {
  let spec = '%8.3f';
  let value = '3.14159';
  let showSpaces = true;
  host.innerHTML = `
    <div class="cfmt">
      <div class="cfmt-inputs">
        <label>格式串<input type="text" data-k="spec" value="${esc(spec)}" spellcheck="false"></label>
        <label>值<input type="text" data-k="value" value="${esc(value)}" spellcheck="false"></label>
        <label class="cfmt-check"><input type="checkbox" data-k="spaces" ${showSpaces ? 'checked' : ''}> 用 · 标出空格</label>
      </div>
      <div class="cfmt-presets">${FORMAT_PRESETS.map(p => `<button type="button" data-preset="${esc(p)}">${esc(p)}</button>`).join('')}</div>
      <div class="cfmt-screen"><span class="cfmt-dots"></span><pre data-out="result"></pre><p data-out="note"></p></div>
    </div>`;
  const out = host.querySelector('[data-out="result"]');
  const note = host.querySelector('[data-out="note"]');
  function render() {
    const r = formatOne(spec, value);
    if (!r.ok) { out.textContent = r.error; out.classList.add('bad'); note.textContent = ''; return; }
    out.classList.remove('bad');
    out.textContent = showSpaces ? r.output.replace(/ /g, '·') : r.output;
    note.textContent = r.note;
  }
  host.querySelectorAll('[data-k]').forEach(el => el.oninput = () => {
    const k = el.dataset.k;
    if (k === 'spec') spec = el.value; else if (k === 'value') value = el.value; else showSpaces = el.checked;
    render();
  });
  host.querySelectorAll('[data-preset]').forEach(b => b.onclick = () => {
    spec = b.dataset.preset;
    host.querySelector('input[data-k="spec"]').value = spec;
    render();
  });
  render();
}

/* ---------------- 随堂小测 ---------------- */
const CHECKS = {
  program: { q: '预处理阶段做的事是？', opts: ['把 C 翻译成汇编', '展开 #include 和宏', '把 .o 链接成 .exe', '执行程序'], answer: 1, why: '#include 是文本插入，宏是文本替换，都发生在预处理；汇编和链接在后面。' },
  first: { q: 'main 函数的返回值 0 表示？', opts: ['程序出错', '正常结束', '循环 0 次', '没有返回值'], answer: 1, why: 'return 0 告诉系统程序正常结束；非 0 通常表示异常。' },
  output: { q: 'printf("%5d", 42) 的输出是？', opts: ['42', '   42', '42   ', '00042'], answer: 1, why: '%5d 是右对齐、总宽 5，所以左边补 3 个空格。' },
  input: { q: 'scanf("%d", &a) 里的 & 作用是？', opts: ['取变量地址', '取绝对值', '按位与', '没有作用'], answer: 0, why: 'scanf 需要知道把值写到哪，所以传变量地址。' },
  types: { q: 'char 类型通常占几个字节？', opts: ['1', '2', '4', '8'], answer: 0, why: 'char 是 1 字节 8 位，范围 −128~127。' },
  vars: { q: '局部变量只定义不初始化，它的值是？', opts: ['0', '随机的（垃圾值）', '编译错误', 'null'], answer: 1, why: 'C 不会自动清零局部变量，里面是内存残留的内容。' },
  branch: { q: 'if (a = 5) 的实际效果是？', opts: ['判断 a 是否等于 5', '把 5 赋给 a，条件恒真', '语法错误', '判断 5 是否等于 a'], answer: 1, why: '= 是赋值，表达式值为 5（非 0 即真）。比较要用 ==。' },
  loop: { q: 'continue 的作用是？', opts: ['跳出整个循环', '跳过本轮，进入下一轮', '结束程序', '重新开始循环变量'], answer: 1, why: 'continue 只结束本轮；循环的推进（如 i++）仍会执行。' },
  operators: { q: 'float a = 5 / 2; 之后 a 的值是？', opts: ['2.5', '2.0', '2', '编译错误'], answer: 1, why: '两个 int 先做整数除法得到 2，再转成 float，所以是 2.0。' },
  practice: { q: '想让 5/2 得到 2.5，下面哪种写法可行？', opts: ['5 / 2', '(float)(5 / 2)', '5.0 / 2', '(int)5 / 2'], answer: 2, why: '只要有一个操作数是浮点，就会做浮点除法。(float)(5/2) 是先算整数再转，仍是 2.0。' }
};

function cQuick(host) {
  const id = host.dataset.check || 'first';
  const item = CHECKS[id];
  if (!item) { host.remove(); return; }
  let picked = null;
  host.innerHTML = `
    <div class="cquick">
      <div class="cquick-head"><b>随堂小测</b><span>${item.opts.some(o => /^\s|\s$/.test(o)) ? "␣ 表示空格 · " : ""}选完立刻看解释</span></div>
      <p class="cquick-q">${esc(item.q)}</p>
      <div class="cquick-opts">${item.opts.map((o, i) => `<button type="button" data-k="${i}">${esc(visible(o))}</button>`).join('')}</div>
      <p class="cquick-why" hidden></p>
    </div>`;
  host.querySelectorAll('[data-k]').forEach(b => b.onclick = () => {
    picked = Number(b.dataset.k);
    const ok = picked === item.answer;
    host.querySelectorAll('[data-k]').forEach(x => {
      x.classList.toggle('picked', Number(x.dataset.k) === picked);
      x.classList.toggle('right', Number(x.dataset.k) === item.answer);
    });
    const why = host.querySelector('.cquick-why');
    why.hidden = false;
    why.className = 'cquick-why ' + (ok ? 'ok' : 'bad');
    why.textContent = (ok ? '✓ 正确。' : '✗ 再想想。') + item.why;
  });
}

export const C_WIDGETS = {
  'c-trace': cTrace,
  'c-memory': cMemory,
  'c-ascii': cAscii,
  'c-buffer': cBuffer,
  'c-format': cFormat,
  'c-quick': cQuick
};
