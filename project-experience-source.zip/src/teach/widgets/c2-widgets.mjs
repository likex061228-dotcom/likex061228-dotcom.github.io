// C 语文第二课交互：数组、排序（代码+状态同步）、二维表格、递归调用栈、字符串。
import { bubbleSteps, selectionSteps, insertionSteps, factTrace, strlenTrace, stringCells, manualStrlen, compareStrings } from '../model/c2.mjs';

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

/* ---------------- 一维数组 ---------------- */
function cArray(host) {
  const values = [12, 34, 56, 78, 9];
  const LOOP_CODE = [
    'for (int i = 0; i < 5; i++) {',
    '    printf("%d ", a[i]);',
    '}'
  ];
  let inFunction = false;
  let selected = 0;
  let trace = 0;

  function render() {
    const bytes = values.length * 4;
    const n = values.length;
    const line = trace === 0 ? 0 : (trace >= n * 2 ? 2 : (trace % 2 === 1 ? 0 : 1));
    const idx = Math.min(n, Math.floor(trace / 2));
    const out = values.slice(0, Math.min(idx, n)).join(' ');

    host.innerHTML = `
      <div class="carr">
        <div class="carr-head">
          <b>int a[5] = {12, 34, 56, 78, 9};</b>
          <label class="carr-toggle"><input type="checkbox" data-k="fn" ${inFunction ? 'checked' : ''}> 假设在函数里</label>
        </div>
        <div class="carr-cells">
          ${values.map((v, i) => `<button type="button" class="carr-cell ${selected === i && trace === 0 ? 'on' : ''} ${trace > 0 && i === idx && idx < n ? 'trace' : ''}" data-i="${i}">
            <small>a[${i}]</small><b>${v}</b><i>${i === 0 ? '首地址' : '&nbsp;'}</i>
          </button>`).join('')}
          <button type="button" class="carr-cell danger" data-oob="1"><small>a[5]</small><b>?</b><i>越界</i></button>
        </div>
        <div class="carr-readout">
          <div><small>元素个数</small><b>${inFunction ? '不能用 sizeof 求' : values.length}</b></div>
          <div><small>sizeof(a)</small><b>${inFunction ? '8（指针大小）' : bytes + ' 字节'}</b></div>
          <div><small>sizeof(a[0])</small><b>4 字节</b></div>
          <div><small>合法下标</small><b>0 ~ ${values.length - 1}</b></div>
        </div>
        <p class="carr-note">${inFunction
          ? '数组传进函数后，形参 int a[] 会退化成指针：此时 sizeof(a) 得到的是指针大小（64 位下 8 字节），不是整个数组。所以函数里要额外传长度。'
          : '在定义数组的作用域里，sizeof(a) 才是整个数组的字节数：5 × 4 = 20。元素个数 = sizeof(a) / sizeof(a[0])。'}</p>

        <div class="carr-loop">
          <div class="carr-loop-head"><b>遍历：for + a[i]</b><span>${trace === 0 ? '点"下一步"开始' : (idx >= n ? '循环结束' : 'i = ' + idx)}</span></div>
          <div class="cviz">
            <div class="cviz-code">${LOOP_CODE.map((l, i) => `<div class="cviz-line ${i === line && trace > 0 ? 'active' : ''}"><i>${i + 1}</i><code>${l.replace(/</g, '&lt;')}</code></div>`).join('')}</div>
            <div>
              <div class="carr-out"><small>输出</small><pre>${out || '（还没有输出）'}</pre></div>
              <div class="cviz-vars"><span><small>i</small><b>${idx >= n ? '5' : idx}</b></span><span><small>a[i]</small><b>${idx < n ? values[idx] : '—'}</b></span></div>
            </div>
          </div>
          <div class="carr-loop-controls">
            <button type="button" data-act="reset">↺ 重置</button>
            <button type="button" data-act="next">下一步 →</button>
            <span class="carr-progress">第 ${Math.min(trace + 1, n * 2 + 1)} / ${n * 2 + 1} 步</span>
          </div>
        </div>
      </div>`;

    host.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { selected = Number(b.dataset.i); render(); });
    host.querySelector('[data-oob]').onclick = () => {
      host.querySelector('.carr-note').textContent = 'a[5] 越界：合法下标是 0–4。C 不会替你检查，读到的可能是别的变量的内容，写进去可能改坏程序。';
    };
    host.querySelector('[data-k="fn"]').onchange = e => { inFunction = e.target.checked; render(); };
    host.querySelector('[data-act="next"]').onclick = () => { trace = Math.min(n * 2, trace + 1); render(); };
    host.querySelector('[data-act="reset"]').onclick = () => { trace = 0; render(); };
  }
  render();
}

/* ---------------- 排序：代码 + 状态同步 ---------------- */
const ALGOS = {
  bubble: { label: '冒泡排序', fn: bubbleSteps, hint: '相邻比较，大的往后换' },
  selection: { label: '选择排序', fn: selectionSteps, hint: '每轮找最小值，和本轮起点交换' },
  insertion: { label: '插入排序', fn: insertionSteps, hint: '把左边当已排序，右边元素逐个插入' }
};

function codePane(code, activeLine) {
  return code.map((line, i) => `<div class="cviz-line ${i === activeLine ? 'active' : ''}"><i>${i + 1}</i><code>${esc(line)}</code></div>`).join('');
}

function cSort(host) {
  let algo = 'bubble';
  let step = 0;
  let timer = null;
  const base = [6, 3, 2, 7, 5];

  host.innerHTML = `
    <div class="csort">
      <div class="csort-head">
        <b>排序过程</b>
        <div class="csort-tabs">${Object.entries(ALGOS).map(([k, v]) => `<button type="button" data-algo="${k}" class="${k === algo ? 'on' : ''}">${v.label}</button>`).join('')}</div>
      </div>
      <div class="cviz">
        <div class="cviz-code" data-pane="code"></div>
        <div class="cviz-side">
          <div class="csort-bars"></div>
          <div class="csort-cells"></div>
          <div class="cviz-vars" data-pane="vars"></div>
        </div>
      </div>
      <div class="csort-note"></div>
      <div class="csort-stats"></div>
      <div class="csort-controls">
        <button type="button" data-act="reset">↺ 重置</button>
        <button type="button" data-act="prev">← 上一步</button>
        <button type="button" data-act="next">下一步 →</button>
        <button type="button" data-act="play">▶ 自动播放</button>
        <span class="csort-progress"></span>
      </div>
    </div>`;

  function data() { return ALGOS[algo].fn(base); }
  function stop() { if (timer) { clearInterval(timer); timer = null; host.querySelector('[data-act="play"]').textContent = '▶ 自动播放'; } }

  function render() {
    const d = data();
    const s = d.steps[Math.min(step, d.steps.length - 1)];
    host.querySelector('[data-pane="code"]').innerHTML = codePane(d.code, s.line);
    host.querySelector('[data-pane="vars"]').innerHTML = Object.entries(s.vars)
      .filter(([k]) => k !== 'n')
      .map(([k, v]) => `<span><small>${esc(k)}</small><b>${esc(v)}</b></span>`).join('');
    host.querySelector('.csort-bars').innerHTML = s.arr.map((v, i) => {
      const cls = s.highlight.includes(i) ? (s.kind === 'swap' || s.kind === 'temp' ? 'swap' : 'compare') : '';
      return `<div class="csort-bar ${cls}"><i style="height:${(v / Math.max(...base)) * 100}%"></i><span>${v}</span></div>`;
    }).join('');
    host.querySelector('.csort-cells').innerHTML = s.arr.map((v, i) => `<span class="${s.highlight.includes(i) ? 'on' : ''}">${v}</span>`).join('');
    host.querySelector('.csort-note').textContent = s.note;
    const stat = algo === 'insertion'
      ? `比较 ${d.comparisons} 次 · 移动 ${d.shifts} 次`
      : `比较 ${d.comparisons} 次 · 交换 ${d.swaps} 次`;
    host.querySelector('.csort-stats').textContent = stat;
    host.querySelector('.csort-progress').textContent = `第 ${Math.min(step + 1, d.steps.length)} / ${d.steps.length} 步`;
    host.querySelectorAll('[data-algo]').forEach(b => b.classList.toggle('on', b.dataset.algo === algo));
  }

  host.querySelectorAll('[data-algo]').forEach(b => b.onclick = () => { stop(); algo = b.dataset.algo; step = 0; render(); });
  host.querySelector('[data-act="next"]').onclick = () => { stop(); step = Math.min(data().steps.length - 1, step + 1); render(); };
  host.querySelector('[data-act="prev"]').onclick = () => { stop(); step = Math.max(0, step - 1); render(); };
  host.querySelector('[data-act="reset"]').onclick = () => { stop(); step = 0; render(); };
  host.querySelector('[data-act="play"]').onclick = e => {
    if (timer) { stop(); return; }
    if (step >= data().steps.length - 1) step = 0;
    e.currentTarget.textContent = '⏸ 暂停';
    timer = setInterval(() => {
      if (step >= data().steps.length - 1) { stop(); return; }
      step++; render();
    }, 650);
  };
  host._cleanup = stop;
  render();
}

/* ---------------- 二维数组 ---------------- */
function cGrid(host) {
  const rows = [[0, 1, 2, 3], [4, 5, 6, 7], [8, 9, 10, 11]];
  let cell = { i: 1, j: 2 };
  host.innerHTML = `
    <div class="cgrid">
      <div class="cgrid-head"><b>int a[3][4]</b><span data-out="label"></span></div>
      <div class="cgrid-table" role="grid"></div>
      <div class="cgrid-foot" data-out="foot"></div>
    </div>`;
  function render() {
    const table = host.querySelector('.cgrid-table');
    table.innerHTML = `<div class="cgrid-corner">i\\j</div>${[0, 1, 2, 3].map(j => `<div class="cgrid-headcell">${j}</div>`).join('')}` +
      rows.map((row, i) => `<div class="cgrid-rowlabel">${i}</div>` + row.map((v, j) => `<button type="button" class="cgrid-cell ${cell.i === i && cell.j === j ? 'on' : ''} ${cell.i === i ? 'row' : ''} ${cell.j === j ? 'col' : ''}" data-i="${i}" data-j="${j}">${v}</button>`).join('')).join('');
    const v = rows[cell.i][cell.j];
    host.querySelector('[data-out="label"]').textContent = `a[${cell.i}][${cell.j}] = ${v}`;
    host.querySelector('[data-out="foot"]').textContent = `第 ${cell.i + 1} 行、第 ${cell.j + 1} 列；内存里按行连续存放：` + rows.flat().join(' ');
    table.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { cell = { i: Number(b.dataset.i), j: Number(b.dataset.j) }; render(); });
  }
  render();
}

/* ---------------- 递归：代码 + 调用栈 ---------------- */
function cRecursion(host) {
  const trace = factTrace(5);
  let step = 0, timer = null;
  host.innerHTML = `
    <div class="crec">
      <div class="crec-head"><b>fact(5) 的调用栈</b><span class="crec-result"></span></div>
      <div class="cviz">
        <div class="cviz-code" data-pane="code"></div>
        <div class="crec-stack"></div>
      </div>
      <div class="crec-note"></div>
      <div class="crec-controls">
        <button type="button" data-act="reset">↺ 重置</button>
        <button type="button" data-act="next">下一步 →</button>
        <button type="button" data-act="play">▶ 自动播放</button>
        <span class="crec-progress"></span>
      </div>
    </div>`;
  function stop() { if (timer) { clearInterval(timer); timer = null; host.querySelector('[data-act="play"]').textContent = '▶ 自动播放'; } }
  function render() {
    const s = trace.steps[step];
    host.querySelector('[data-pane="code"]').innerHTML = codePane(trace.code, s.line);
    host.querySelector('.crec-stack').innerHTML = s.stack.length
      ? s.stack.map((f, i) => `<div class="crec-frame ${i === s.stack.length - 1 ? 'top' : ''}">
          <span>fact(${f.arg})</span>
          <small>${f.value === null ? '等待子调用返回' : '返回 ' + f.value}</small>
        </div>`).join('')
      : '<div class="crec-empty">栈已清空，回到 main</div>';
    host.querySelector('.crec-note').textContent = s.note;
    host.querySelector('.crec-result').textContent = step === trace.steps.length - 1 ? '结果 120' : '';
    host.querySelector('.crec-progress').textContent = `第 ${step + 1} / ${trace.steps.length} 步 · 栈深 ${s.stack.length}`;
  }
  host.querySelector('[data-act="next"]').onclick = () => { stop(); step = Math.min(trace.steps.length - 1, step + 1); render(); };
  host.querySelector('[data-act="reset"]').onclick = () => { stop(); step = 0; render(); };
  host.querySelector('[data-act="play"]').onclick = e => {
    if (timer) { stop(); return; }
    if (step >= trace.steps.length - 1) step = 0;
    e.currentTarget.textContent = '⏸ 暂停';
    timer = setInterval(() => {
      if (step >= trace.steps.length - 1) { stop(); return; }
      step++; render();
    }, 800);
  };
  host._cleanup = stop;
  render();
}

/* ---------------- 字符串：代码 + 长度遍历 ---------------- */
function cString(host) {
  let text = 'hello';
  let other = 'help!';
  let step = 0;
  host.innerHTML = `
    <div class="cstr">
      <div class="cstr-head">
        <label>字符串 <input type="text" data-k="text" value="${esc(text)}" maxlength="16" spellcheck="false"></label>
        <label>比较对象 <input type="text" data-k="other" value="${esc(other)}" maxlength="16" spellcheck="false"></label>
      </div>
      <div class="cviz">
        <div class="cviz-code" data-pane="code"></div>
        <div>
          <div class="cstr-cells"></div>
          <div class="cstr-readout"></div>
        </div>
      </div>
      <div class="cstr-note"></div>
      <div class="cstr-controls"><button type="button" data-act="next">读下一个字符 →</button><button type="button" data-act="reset">↺ 重来</button><span class="cstr-progress"></span></div>
    </div>`;
  function render() {
    const trace = strlenTrace(text);
    const s = trace.steps[Math.min(step, trace.steps.length - 1)];
    host.querySelector('[data-pane="code"]').innerHTML = codePane(trace.code, s.line);
    host.querySelector('.cstr-cells').innerHTML = stringCells(text).map(c => `<span class="cstr-cell ${c.terminator ? 'term' : ''} ${c.index === s.len && !(c.terminator && s.len !== trace.length) ? 'on' : ''}"><small>${c.index}</small>${c.terminator ? '\\0' : esc(c.ch)}</span>`).join('');
    const cmp = compareStrings(text, other);
    host.querySelector('.cstr-readout').innerHTML = `
      <div><small>strlen</small><b>${trace.length}</b></div>
      <div><small>数组至少要</small><b>${trace.length + 1} 个 char</b></div>
      <div><small>strcmp</small><b>${cmp === 0 ? '0（相等）' : (cmp < 0 ? '负数（前者小）' : '正数（前者大）')}</b></div>`;
    host.querySelector('.cstr-note').textContent = s.note;
    host.querySelector('.cstr-progress').textContent = `第 ${Math.min(step + 1, trace.steps.length)} / ${trace.steps.length} 步`;
  }
  host.querySelectorAll('input').forEach(el => el.oninput = () => {
    if (el.dataset.k === 'text') text = el.value; else other = el.value;
    step = 0;
    render();
  });
  host.querySelector('[data-act="next"]').onclick = () => {
    const n = strlenTrace(text).steps.length;
    step = Math.min(n - 1, step + 1);
    render();
  };
  host.querySelector('[data-act="reset"]').onclick = () => { step = 0; render(); };
  render();
}

export const C2_WIDGETS = {
  'c-array': cArray,
  'c-sort': cSort,
  'c-grid': cGrid,
  'c-recursion': cRecursion,
  'c-string': cString
};
