import {DEFAULT_LED,evaluateLed,FAULTS,diagnoseFault} from '../model/led-lesson.mjs';
import {registers,halCode} from '../model/gpio.mjs';
import {getChip} from '../data/chips.mjs';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const names={on:'亮',off:'灭',unknown:'不确定'};
const padNames={LOW:'低',HIGH:'高',UNKNOWN:'未确定',CONFLICT:'驱动冲突'};
const KEY='Like_x.teach.puzhong.led-checks.v1';
const chip=getChip('f103c8');
export function ledLesson(host){
 let draft={...DEFAULT_LED},active={...DEFAULT_LED},prediction='',feedback='',fault=null,diagnosed=false;
 let checks={low:false,high:false,fault:false};
 try{const raw=JSON.parse(localStorage.getItem(KEY)||'{}');for(const k of Object.keys(checks))checks[k]=raw[k]===true;}catch{}
 const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(checks));}catch{}};
 function render(){
  const focused=host.contains(document.activeElement)?document.activeElement:null;
  const focus=focused?.getAttribute('name'), buttonFocus=focused?.getAttribute('data-focus');
  const codeOpen=host.querySelector('.lesson-code')?.open===true;
  const r=evaluateLed(active),cfg={mode:active.mode,pull:'none',speed:'low',level:active.level};
  const regs=registers(chip,'PC13',cfg),dirty=JSON.stringify(draft)!==JSON.stringify(active);
  const init=halCode(chip,'PC13',cfg).replace('/* 1. 先开时钟，不开时钟后面写什么都无效 */','/* GPIOC 初始化片段：由 CubeMX 生成或配置 */').replace('/* 2. 填参数并初始化 */','/* PC13，低速；只展示本课相关配置 */').replace('/* 3. 输出电平：SET 为高，RESET 为低 */','/* 用户操作：SET 写1，RESET 写0 */');
  const latchWrite=active.mode==='input'?`\n\n/* 比较输出锁存与驱动：浮空输入下写ODR不会驱动PC13 */\nHAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, ${active.level==='high'?'GPIO_PIN_SET':'GPIO_PIN_RESET'});`:'';
  const code=(active.clock?init:init.replace('__HAL_RCC_GPIOC_CLK_ENABLE();','/* 缺失：__HAL_RCC_GPIOC_CLK_ENABLE(); */'))+latchWrite;
  host.innerHTML=`<section class="led-lesson" aria-label="PC13与LED教学电路">
   <div class="lesson-instrument-head"><span>PC13 / D2 · 离散逻辑教学模型</span><strong>${dirty?'配置待应用':'当前已应用配置'}</strong></div>
   <div class="lesson-workspace"><div class="lesson-circuit">
    <svg viewBox="0 0 600 320" role="img" aria-label="${esc('教学接法：VDD经限流电阻和LED到PC13；当前LED'+names[r.led]+'，引脚'+padNames[r.pad])}">
     <defs><marker id="lesson-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto"><path d="M0 0 L10 5 L0 10Z" fill="#e6b85c"/></marker></defs>
     <text x="32" y="37" class="svg-label">教学负载</text><text x="344" y="37" class="svg-label">GPIO 输出级（功能示意）</text>
     <path d="M62 82 H100 M158 82 H202 M248 82 H318 V174 H376" class="wire ${r.currentPath?'conducting':''}"/>
     <text x="30" y="70">VDD</text><rect x="100" y="71" width="58" height="22" rx="2" class="resistor"/><text x="100" y="116">10kΩ（原理图R13）</text>
     <path d="M202 63 L202 101 L237 82 Z M244 63 V101" class="led-symbol ${r.led==='on'?'lit':''}"/><text x="197" y="116">D2 · ${names[r.led]}</text>
     <circle cx="318" cy="174" r="5" class="pad-dot"/><text x="252" y="201">PC13：${padNames[r.pad]}</text>
     <path d="M376 60 V112 M376 143 V174 M376 174 V210 M376 245 V278" class="wire"/>
     <path d="M376 112 ${r.drive==='HIGH'?'V143':'L395 135'} M376 210 ${r.drive==='LOW'?'V245':'L395 236'}" class="gate ${r.drive==='LOW'||r.drive==='HIGH'?'active':''}"/>
     <text x="388" y="67">VDD</text><text x="409" y="130">上管 ${r.drive==='HIGH'?'导通':'关闭'}</text><text x="409" y="232">下管 ${r.drive==='LOW'?'导通':'关闭'}</text><text x="390" y="282">GND</text>
     ${active.pullup?'<path d="M318 174 H290 V142" class="pull-wire"/><text x="185" y="150">外部上拉接VDD</text>':''}
     ${r.currentPath?'<path d="M70 52 H270" class="flow-arrow" marker-end="url(#lesson-arrow)"/><text x="62" y="298" class="current-note">电流方向：电源 → LED → 引脚 → 地</text>':'<text x="40" y="298" class="current-note">不计算电压、电流大小或微亮现象</text>'}
    </svg>
    <p class="lesson-observation" role="status">${esc(r.reason)}</p>
    <dl class="lesson-evidence"><div><dt>输出锁存 ODR[13]</dt><dd>${r.odr===null?'未应用':r.odr}</dd></div><div><dt>输出级</dt><dd>${r.drive==='Z'?'释放 / 高阻':r.drive==='LOW'?'拉低':'驱动高'}</dd></div><div><dt>LED状态</dt><dd>${names[r.led]}</dd></div></dl>
   </div><form class="lesson-controls">
    <h3>改一个条件，再观察</h3>
    <label>PC13模式<select name="mode" aria-label="PC13模式"><option value="output-pp" ${draft.mode==='output-pp'?'selected':''}>推挽输出</option><option value="output-od" ${draft.mode==='output-od'?'selected':''}>开漏输出</option><option value="input" ${draft.mode==='input'?'selected':''}>浮空输入</option></select></label>
    <label>准备写入 ODR[13]<select name="level" aria-label="准备写入 ODR[13]"><option value="high" ${draft.level==='high'?'selected':''}>1 / SET</option><option value="low" ${draft.level==='low'?'selected':''}>0 / RESET</option></select></label>
    <label class="lesson-check"><input type="checkbox" name="clock" ${draft.clock?'checked':''}>开启 GPIOC 时钟</label>
    <label class="lesson-check"><input type="checkbox" name="pullup" ${draft.pullup?'checked':''}>接入独立的外部上拉</label>
    <p class="lesson-control-note">这是本课的逻辑配置，不会修改你的板子。输入模式写ODR不等于驱动引脚；本课不配置内部上下拉。</p>
    <label>你预计应用后，LED会怎样？<select name="prediction" aria-label="你预计应用后，LED会怎样？"><option value="">先选一个结果</option>${Object.entries(names).map(([k,v])=>`<option value="${k}" ${prediction===k?'selected':''}>${v}</option>`).join('')}</select></label>
    <button type="submit" data-focus="apply" class="lesson-apply" ${prediction?'':'disabled'}>应用配置，检查预测</button>
   </form></div>
   <div class="lesson-feedback" role="status" tabindex="-1">${esc(feedback||'先预测，再应用。面板和电路始终显示已应用的状态。')}</div>
   <details class="lesson-code" ${codeOpen?'open':''}><summary>查看这次操作的 HAL 代码与寄存器</summary><p>代码是与已应用配置对应的说明片段，不在网页执行。CRH只展示PC13的位，其余位不作为芯片快照；ODR只展示第13位。独立外部上拉是接线，不是GPIO_PULLUP。</p><pre><code>${esc(code)}</code></pre><dl>${regs.rows.map(row=>`<div><dt>${esc(row.name)}</dt><dd>${r.applied?esc(row.name.endsWith('ODR')?'0x'+((r.odr<<13)>>>0).toString(16).toUpperCase().padStart(8,'0'):row.value):'本次未应用，不能由这段初始化推断'}</dd></div>`).join('')}</dl></details>
   <section class="lesson-faults" aria-label="LED故障排查"><h3>排错：目标是让 LED 亮</h3><p>载入一个故障，先选检查依据，再决定怎样修。更换练习会替换本课配置。</p>
    <div class="lesson-fault-buttons">${FAULTS.map(f=>`<button type="button" data-fault="${f.id}" data-focus="fault-${f.id}" aria-pressed="${fault?.id===f.id}">${f.name}</button>`).join('')}</div>
    ${fault?`<p>当前练习：${esc(fault.name)}。观察上方电路，再打开代码与寄存器核对。</p><div class="lesson-diagnose">${[['clock','检查GPIOC时钟'],['mode','检查CRH中的MODE'],['path','对照LED电流路径']].map(([id,label])=>`<button type="button" data-check="${id}" data-focus="check-${id}">${label}</button>`).join('')}</div><p class="lesson-diagnosis" role="status">${esc(diagnosed?fault.evidence:'选择能解释现象的检查依据。')}</p>${diagnosed?'<button type="button" data-repair="yes" data-focus="repair">把修正配置填入面板</button><p>填入后仍需选择预测并应用，才会改变电路。</p>':''}`:''}
   </section>
   <div class="lesson-checks"><h3>本课检查记录</h3><ul><li>${checks.low?'✓':'○'} 正确预测并验证推挽写0点亮</li><li>${checks.high?'✓':'○'} 正确预测并验证推挽写1熄灭</li><li>${checks.fault?'✓':'○'} 找到一种故障的依据，并验证修复后点亮</li></ul><p>${Object.values(checks).every(Boolean)?'本课三项网页检查已完成。上板结果请继续按下方清单核对。':'这些记录只表示做过本课操作，不等于已经掌握；保存在当前浏览器。'}</p><button type="button" data-reset="yes" data-focus="reset">重新开始本课（清除检查记录）</button></div>
  </section>`;
  host.querySelectorAll('[name]').forEach(el=>el.onchange=()=>{
   if(el.name==='prediction')prediction=el.value;
   else{draft[el.name]=el.type==='checkbox'?el.checked:el.value;prediction='';feedback='配置尚未应用。选择预测后再执行；电路仍显示上一次结果。';}
   render();host.querySelector(`[name="${el.name}"]`)?.focus({preventScroll:true});
  });
  host.querySelector('form').onsubmit=e=>{e.preventDefault();if(!prediction)return;active={...draft};const result=evaluateLed(active);const right=prediction===result.led;
   feedback=(right?'预测正确。':'预测与结果不同。')+`应用后LED${names[result.led]}。`+result.reason;
   if(right&&active.clock&&active.mode==='output-pp'&&!active.pullup){if(active.level==='low')checks.low=true;else checks.high=true;}
   if(fault&&diagnosed&&result.led==='on'){checks.fault=true;feedback+=' 已验证本次修复。';}save();prediction='';render();};
  host.querySelectorAll('[data-fault]').forEach(b=>b.onclick=()=>{fault=FAULTS.find(f=>f.id===b.dataset.fault);diagnosed=false;active={...fault.config};draft={...active};prediction='';feedback='故障已载入。目标是点亮LED，请先检查依据。';render();});
  host.querySelectorAll('[data-check]').forEach(b=>b.onclick=()=>{const d=diagnoseFault(fault.id,b.dataset.check);diagnosed=d.correct;render();host.querySelector('.lesson-diagnosis').textContent=d.evidence;});
  host.querySelector('[data-repair]')?.addEventListener('click',()=>{draft={...fault.repaired};prediction='';feedback='修正配置已填入，尚未应用。请预测后执行。';render();});
  host.querySelector('[data-reset]').onclick=()=>{checks={low:false,high:false,fault:false};save();draft={...DEFAULT_LED};active={...draft};fault=null;diagnosed=false;prediction='';feedback='本课已复位。';render();};
  if(focus)host.querySelector(`[name="${focus}"]`)?.focus({preventScroll:true});
  else if(buttonFocus){const button=host.querySelector(`[data-focus="${buttonFocus}"]`);if(button&&!button.disabled)button.focus({preventScroll:true});else host.querySelector('.lesson-feedback')?.focus({preventScroll:true});}
 }
 render();
}
