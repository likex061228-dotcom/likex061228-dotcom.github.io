export const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const STORE='Like_x.teach.workshops.v1';
export function loadChecks(id){try{const a=JSON.parse(localStorage.getItem(STORE)||'{}');const row=a&&typeof a==='object'?a[id]:null;return Array.isArray(row)?new Set(row.filter(s=>typeof s==='string'&&s.length<80)):new Set();}catch{return new Set();}}
export function markCheck(id,check){try{let a=JSON.parse(localStorage.getItem(STORE)||'{}');if(!a||Array.isArray(a)||typeof a!=='object')return;const set=loadChecks(id);set.add(check);a[id]=[...set];localStorage.setItem(STORE,JSON.stringify(a));}catch{}}
export function clearChecks(id){try{const a=JSON.parse(localStorage.getItem(STORE)||'{}');if(a&&!Array.isArray(a)&&typeof a==='object'){delete a[id];localStorage.setItem(STORE,JSON.stringify(a));}}catch{}}
export function checklist(id,goals){const saved=loadChecks(id);return `<div class="ws-checks"><h4>操作检查</h4><ul>${goals.map(([key,title])=>`<li>${saved.has(key)?'✓':'○'} ${esc(title)}</li>`).join('')}</ul><p>只记录做过的网页检查，不代表掌握或上板通过。记录留在当前浏览器。</p></div>`;}
export function numberControl(name,label,value,min,max,step=1){return `<label>${esc(label)}<input name="${name}" aria-label="${esc(label)}" type="number" value="${value}" min="${min}" max="${max}" step="${step}" required></label>`;}
export function selectControl(name,label,value,options){return `<label>${esc(label)}<select name="${name}" aria-label="${esc(label)}">${options.map(([key,title])=>`<option value="${key}" ${String(value)===String(key)?'selected':''}>${esc(title)}</option>`).join('')}</select></label>`;}
export function readControls(form){const result={};form.querySelectorAll('[name]').forEach(el=>{result[el.name]=el.type==='number'?Number(el.value):el.type==='checkbox'?el.checked:el.value;});return result;}
export function setControls(form,config){for(const [key,value]of Object.entries(config)){const el=form.querySelector(`[name="${key}"]`);if(el){if(el.type==='checkbox')el.checked=!!value;else el.value=String(value);}}}
export function instrument(host,title,intro,body){host.classList.add('workshop-host');host.innerHTML=`<section class="workshop" aria-label="${esc(title)}"><header class="ws-header"><span>教学模型 / 本机运算</span><h3>${esc(title)}</h3><p>${esc(intro)}</p></header>${body}<p class="ws-error" role="alert"></p></section>`;return host.querySelector('.workshop');}
export function status(host,text){host.querySelector('.ws-error').textContent=text;}
export const readouts=values=>`<dl class="ws-readouts">${values.map(([name,value,unit=''])=>`<div><dt>${esc(name)}</dt><dd>${esc(value)} <small>${esc(unit)}</small></dd></div>`).join('')}</dl>`;
export function waveSvg(channels,total,cursor,markers=[]){
  const W=800,left=100,right=770,row=66,H=channels.length*row+64,span=Math.max(Number.EPSILON,total),x=t=>left+Math.max(0,Math.min(1,t/span))*(right-left);
 let svg=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="信号随教学时间变化，当前 ${Number(cursor).toFixed(1)} 毫秒"><rect width="800" height="${H}" fill="#15232a"/>`;
 for(let n=0;n<=4;n++){const t=total*n/4;svg+=`<path d="M${x(t)} 18 V${H-33}" stroke="#30424b"/><text x="${x(t)}" y="${H-12}" text-anchor="middle">${total<1?(t*1000).toFixed(1):Number(t.toFixed(2))} ${total<1?'µs':'ms'}</text>`;}
 channels.forEach((c,i)=>{const y=28+i*row,yv=v=>y+(v?4:35);let d='';const points=[...c.points];if(points.length&&points.at(-1).t<total)points.push({t:total,v:points.at(-1).v});points.forEach((p,j)=>{d+=j?` H${x(p.t)} V${yv(p.v)}`:`M${x(p.t)} ${yv(p.v)}`;});svg+=`<text x="12" y="${y+19}" fill="${c.color||'#c4d7bd'}">${esc(c.name)}</text><path d="${d}" fill="none" stroke="${c.color||'#c4d7bd'}" stroke-width="2.5"/>`;});
 for(const m of markers.filter(m=>m.t<=cursor))svg+=`<path d="M${x(m.t)} 15 V${H-34}" stroke="#e5ae66" stroke-dasharray="3 5"/>`;
 svg+=`<path d="M${x(cursor)} 12 V${H-30}" stroke="#f1eee0" stroke-width="1.5"/><circle cx="${x(cursor)}" cy="12" r="4" fill="#d37c48"/></svg>`;return svg;
}
export function eventTable(rows,columns=['时刻 / ms','事件']){return `<details class="ws-event-table"><summary>查看事件记录（${rows.length}条）</summary><table><thead><tr>${columns.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${row.map(v=>`<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></details>`;}
export function updateEvents(target,rows,columns=['时刻 / ms','事件']){
 if(!target.querySelector('details'))target.innerHTML=eventTable([],columns);
 target.querySelector('summary').textContent=`查看事件记录（${rows.length}条）`;
 target.querySelector('tbody').innerHTML=rows.map(row=>`<tr>${row.map(v=>`<td>${esc(v)}</td>`).join('')}</tr>`).join('');
}
// Uses one requestAnimationFrame per mounted lesson; never leaves playback running after routing away.
export function playback(host,{end,step,onFrame,scale=()=>1}){
 let t=0,running=false,last=0,raf=0;const play=host.querySelector('[data-play]');
 function update(){onFrame(t);play.textContent=running?'暂停':'播放过程';}
 function stop(){running=false;last=0;cancelAnimationFrame(raf);update();}
 function tick(now){if(!running)return;if(last)t=Math.min(end(),t+Math.min(80,now-last)*Number(host.querySelector('[data-speed]')?.value||1)/scale());last=now;update();if(t>=end()){stop();return;}raf=requestAnimationFrame(tick);}
 play.onclick=()=>{if(running){stop();return;}if(t>=end())t=0;running=true;last=0;update();raf=requestAnimationFrame(tick);};
 host.querySelector('[data-step]').onclick=()=>{stop();t=Math.min(end(),t+step());update();};
 host.querySelector('[data-rewind]').onclick=()=>{stop();t=0;update();};
 const visibility=()=>{if(document.hidden&&running)stop();};document.addEventListener('visibilitychange',visibility);
 host._cleanup=()=>{running=false;cancelAnimationFrame(raf);document.removeEventListener('visibilitychange',visibility);};
 return {reset(){t=0;stop();},seek(value){t=value;stop();},at(){return t;},refresh:update};
}
export const transport=`<div class="ws-transport"><button type="button" data-play>播放过程</button><button type="button" data-step>单步</button><button type="button" data-rewind>回到起点</button><label>教学时间倍率<select data-speed aria-label="教学时间倍率"><option value="0.25">0.25×</option><option value="1" selected>1×</option><option value="2">2×</option></select></label></div>`;

export function codeStrip(lines, active) {
  return '<div class="ws-code">' + lines.map((line, i) =>
    `<div class="cviz-line ${i === active ? 'active' : ''}"><i>${i + 1}</i><code>${esc(line)}</code></div>`).join('') + '</div>';
}
