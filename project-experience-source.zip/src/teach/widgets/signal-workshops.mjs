import {runButton,extiSequence,advanceExti,nvicGrouped} from '../model/workshop.mjs';
import {esc,instrument,numberControl as number,selectControl as select,readControls,setControls,status,readouts,waveSvg,updateEvents,playback,transport,checklist,markCheck,codeStrip} from './workshop-ui.mjs';
const transitions=samples=>samples.filter((s,i)=>i===0||s.stable!==samples[i-1].stable).map(s=>({t:s.t,v:s.stable}));
const eventNames={press:'确认按下',release:'确认松开',click:'报告单击',long:'报告长按'};
export function buttonWorkshop(host){
 const goals=[['click','观察一次消抖后的单击'],['long','观察一次松开后判定的长按'],['filtered','验证短脉冲没有形成完整按键']];
 let config={pressMs:260,bounceMs:9,sampleMs:10,need:3,longMs:800,seed:7},result=runButton(config),stablePoints=transitions(result.samples);
 instrument(host,'一只按键，三层信号','比较接点、定时采样和确认事件。抖动由固定种子构造，用于重复实验，不是硬件测量。',`
 <div class="ws-presets"><button data-preset="click">单击样例</button><button data-preset="long">长按样例</button><button data-preset="short">4ms短脉冲</button></div>
 <div class="ws-plot"></div>${transport}<p class="ws-cursor" role="status"></p><div class="ws-results"></div>
 <form class="ws-params">${number('pressMs','接点按住时间 / ms',260,1,10000)}${number('bounceMs','抖动区间 / ms',9,0,100)}${number('sampleMs','采样周期 / ms',10,.1,1000,.1)}${number('need','连续一致样本数',3,1,100)}${number('longMs','长按阈值 / ms',800,1,10000)}${number('seed','抖动样例种子',7,0,4294967295)}<button type="submit">应用参数并回到起点</button></form><div class="ws-events"></div><div class="ws-record"></div>`);
 const frame=t=>{
  const sample=result.samples.findLast(s=>s.t<=t)||result.samples[0],events=result.events.filter(e=>e.t<=t);
  host.querySelector('.ws-plot').innerHTML=waveSvg([{name:'原始接点',points:result.raw,color:'#77b7c7'},{name:'确认电平',points:stablePoints,color:'#dfbd71'}],result.total,t,result.events);
  host.querySelector('.ws-cursor').textContent=`t = ${t.toFixed(1)} ms · 本次到达 ${events.length} 个确认事件 · ${t>=result.total?result.verdict:'沿时间轴逐步观察'}`;
  host.querySelector('.ws-results').innerHTML=readouts([['采样读数',sample?.raw??1],['确认电平',sample?.stable??1],['已报告',events.filter(e=>e.type==='click'||e.type==='long').map(e=>eventNames[e.type]).join('、')||'尚未报告']]);
  updateEvents(host.querySelector('.ws-events'),events.map(e=>[e.t,eventNames[e.type]||e.type,e.held===undefined?'—':`${e.held} ms`]),['时刻 / ms','事件','确认按住时长']);
  if(t>=result.total){if(result.verdict==='单击')markCheck('button','click');if(result.verdict==='长按')markCheck('button','long');if(config.pressMs===4&&result.events.length===0)markCheck('button','filtered');}
  host.querySelector('.ws-record').innerHTML=checklist('button',goals);
 };
 const player=playback(host,{end:()=>result.total,step:()=>config.sampleMs,onFrame:frame});
 const apply=values=>{try{const next=runButton(values);config=values;result=next;stablePoints=transitions(result.samples);setControls(host.querySelector('form'),config);player.reset();status(host,'参数已应用，旧过程已复位。长按仅在确认松开时分类。');}catch(e){status(host,e.message);}};
 host.querySelector('form').onsubmit=e=>{e.preventDefault();apply(readControls(e.currentTarget));};host.querySelector('form').oninput=()=>status(host,'参数尚未应用，图表仍显示上一组条件。');
 host.querySelectorAll('[data-preset]').forEach(b=>b.onclick=()=>apply({longMs:800,seed:7,pressMs:b.dataset.preset==='long'?1000:b.dataset.preset==='short'?4:260,bounceMs:b.dataset.preset==='short'?0:9,sampleMs:10,need:3}));
 player.refresh();
}

export function extiWorkshop(host){
 let config={edge:'falling',filter:'raw',mapped:'C'},result=extiSequence({edge:'falling',filter:false}),index=0,time=0,state={pending:false,nvicPending:false,services:0,callbacks:0,coalesced:0,enabled:true,unmasked:true},log=[],activeLine=0;
 const goals=[['service','从一个挂起位执行一次服务'],['coalesce','观察多个边沿合并为一个挂起位'],['disabled','观察NVIC关闭时仍可挂起']];
 instrument(host,'从PC8边沿到回调','分别观察EXTI_PR和NVIC挂起：屏蔽请求不撤回已锁存的NVIC请求；只清PR后仍可能进入一次没有回调的IRQ。省略进入延迟与执行时长。',`
 <div class="ws-code-host"></div><form class="ws-params">${select('edge','触发边沿','falling',[['falling','下降沿'],['rising','上升沿'],['both','双边沿']])}${select('filter','输入序列','raw',[['raw','原始抖动接点'],['stable','经过理想软件消抖的输入']])}${select('mapped','EXTI8端口映射','C',[['C','GPIOC → PC8'],['A','GPIOA → PA8（与PC8不匹配）']])}<button type="submit">应用条件并复位</button></form>
 <div class="ws-plot"></div><div class="ws-transport"><button data-edge>下一个输入边沿</button><button data-service>执行一次IRQ服务</button><button data-clear>仅清除挂起位</button></div>
 <div class="ws-gates"><button data-enable aria-pressed="true">NVIC服务：开启</button><button data-mask aria-pressed="true">EXTI请求：未屏蔽</button></div>
 <p class="ws-cursor" role="status"></p><div class="ws-results"></div><div class="ws-events"></div><div class="ws-record"></div>`);
 function draw(){
  host.querySelector('.ws-plot').innerHTML=waveSvg([{name:config.filter==='raw'?'抖动接点':'软件消抖输入',points:result.points,color:'#77b7c7'}],result.total,time,result.edges.slice(0,index).map(t=>({t})));
  host.querySelector('.ws-code-host').innerHTML=codeStrip([
   '/* 硬件：边沿到达 → EXTI_PR[8] = 1 */',
   'HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);',
   'HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);',
   'void EXTI9_5_IRQHandler(void) {',
   '    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_8);  /* 清 PR → 回调 */',
   '}',
   'void HAL_GPIO_EXTI_Callback(uint16_t pin) { ... }'
  ],activeLine);
  host.querySelector('.ws-cursor').textContent=`已推进 ${index}/${result.edges.length} 个输入边沿，t = ${time.toFixed(1)} ms。${config.mapped==='A'?'EXTI8选中PA8，本课PC8输入不进入该线。':''}`;
  host.querySelector('.ws-results').innerHTML=readouts([['EXTI_PR[8]',state.pending?1:0],['NVIC挂起',state.nvicPending?1:0],['IRQ进入',state.services,'次'],['已执行回调',state.callbacks,'次'],['挂起期间合并边沿',state.coalesced,'个']]);
  host.querySelector('[data-edge]').disabled=index>=result.edges.length;
  host.querySelector('[data-service]').disabled=!state.nvicPending||!state.enabled;
  host.querySelector('[data-clear]').disabled=!state.pending;
  const enable=host.querySelector('[data-enable]'),mask=host.querySelector('[data-mask]');enable.textContent=`NVIC服务：${state.enabled?'开启':'关闭'}`;enable.setAttribute('aria-pressed',String(state.enabled));mask.textContent=`EXTI请求：${state.unmasked?'未屏蔽':'已屏蔽'}`;mask.setAttribute('aria-pressed',String(state.unmasked));
  updateEvents(host.querySelector('.ws-events'),log,['时刻 / ms','操作与观察']);
  if(state.callbacks)markCheck('exti','service');if(state.coalesced)markCheck('exti','coalesce');if(state.pending&&!state.enabled)markCheck('exti','disabled');host.querySelector('.ws-record').innerHTML=checklist('exti',goals);
 }
 host.querySelector('[data-edge]').onclick=()=>{if(index>=result.edges.length)return;time=result.edges[index++];activeLine=0;if(config.mapped==='C')state=advanceExti(state,{type:'edge',time});log.push([time.toFixed(1),config.mapped==='C'?'输入边沿到达，检查PR与请求门控':'PC8边沿；EXTI8映射不匹配']);draw();};
 host.querySelector('[data-service]').onclick=()=>{activeLine=4;const before=state.callbacks;state=advanceExti(state,{type:'service',time});log.push([time.toFixed(1),state.callbacks>before?'进入IRQ：HAL检查PR，清PR并执行回调':'进入IRQ：PR已清除，HAL不执行回调']);draw();};
 host.querySelector('[data-clear]').onclick=()=>{activeLine=4;state=advanceExti(state,{type:'clear',time});log.push([time.toFixed(1),'只清PR；已锁存的NVIC挂起仍保留']);draw();};
 host.querySelector('[data-enable]').onclick=()=>{activeLine=2;state=advanceExti({...state,enabled:!state.enabled},{type:'sync',time});log.push([time.toFixed(1),`NVIC服务${state.enabled?'开启':'关闭'}；PR不因此清除`]);draw();};
 host.querySelector('[data-mask]').onclick=()=>{activeLine=0;state=advanceExti({...state,unmasked:!state.unmasked},{type:'sync',time});log.push([time.toFixed(1),`EXTI请求${state.unmasked?'未屏蔽':'屏蔽'}；边沿仍可置PR`]);draw();};
 host.querySelector('form').onsubmit=e=>{e.preventDefault();config=readControls(e.currentTarget);result=extiSequence({edge:config.edge,filter:config.filter==='stable'});index=0;time=0;log=[];state={pending:false,nvicPending:false,services:0,callbacks:0,coalesced:0,enabled:true,unmasked:true};status(host,'条件已应用，过程已复位。软件消抖输入是教学比较，不是EXTI内置消抖功能。');draw();};draw();
}

export function nvicWorkshop(host){
 const tasks=()=>[
  {id:'tim',name:'TIM2',irq:28,preempt:config.timP,sub:config.timS,arrive:0,duration:config.timD},
  {id:'exti',name:'EXTI9_5',irq:23,preempt:config.extiP,sub:config.extiS,arrive:config.extiAt,duration:config.extiD},
  {id:'uart',name:'USART1',irq:37,preempt:config.uartP,sub:config.uartS,arrive:config.uartAt,duration:config.uartD}
 ];
 let config={group:'g2',timP:2,timS:0,timD:6,extiP:1,extiS:0,extiAt:2,extiD:4,uartP:0,uartS:0,uartAt:3,uartD:3},result=nvicGrouped(tasks(),'g2');
 const goals=[['nested','播放一个出现抢占的过程'],['queued','播放一个只能排队的过程']];
 instrument(host,'三个请求，谁占用CPU？','编辑到达时刻与优先级，逐事件检查等待和恢复。时间为示意毫秒，不含入栈、退出、尾链开销。',`
 <div class="ws-presets"><button data-preset="nested">高优先级逐次到达</button><button data-preset="queue">相同抢占级：只能排队</button><button data-preset="same">同刻到达：先仲裁</button></div>
 <div class="ws-plot"></div>${transport}<p class="ws-cursor" role="status"></p><div class="ws-results"></div>
 <form class="ws-params ws-nvic-params">${select('group','优先级分组','g2',[['g4','4位抢占 / 0位子优先级'],['g3','3位抢占 / 1位子优先级'],['g2','2位抢占 / 2位子优先级'],['g1','1位抢占 / 3位子优先级'],['g0','0位抢占 / 4位子优先级']])}
 ${[['tim','TIM2',0,6,2],['exti','EXTI9_5',2,4,1],['uart','USART1',3,3,0]].map(([id,name,at,d,p])=>`<fieldset><legend>${name}</legend>${id==='tim'?'<p>固定t=0到达</p>':number(id+'At','到达时刻 / ms',at,0,30)}${number(id+'D','执行时长 / ms',d,1,30)}${number(id+'P','抢占优先级',p,0,15)}${number(id+'S','子优先级',0,0,15)}</fieldset>`).join('')}<button type="submit">应用调度条件并复位</button></form><div class="ws-events"></div><div class="ws-record"></div>`);
 function frame(t){
  const names=['tim','exti','uart'],labels=['TIM2','EXTI9_5','USART1'],colors=['#7bbccc','#e5b978','#bfa8d6'],end=result.end||1;
  let svg='<svg viewBox="0 0 800 290" role="img" aria-label="三个中断占用CPU的教学时间轴"><rect width="800" height="290" fill="#15232a"/>';
  names.forEach((id,i)=>{const y=42+i*66;svg+=`<text x="10" y="${y+23}">${labels[i]}</text><path d="M110 ${y+40} H770" stroke="#344851"/>`;result.timeline.filter(s=>s.id===id&&s.start<t).forEach(s=>{const start=110+s.start/end*660,width=Math.max(0,(Math.min(t,s.end)-s.start)/end*660);svg+=`<rect x="${start}" y="${y}" width="${width}" height="32" rx="3" fill="${colors[i]}"/>`;});});
  for(let i=0;i<=4;i++)svg+=`<text x="${110+i*165}" y="270" text-anchor="middle">${(end*i/4).toFixed(1)} ms</text>`;
  svg+=`<path d="M${110+t/end*660} 20 V238" stroke="#f1eee0"/></svg>`;host.querySelector('.ws-plot').innerHTML=svg;
  const active=result.timeline.find(s=>s.start<=t&&s.end>t);host.querySelector('.ws-cursor').textContent=`t = ${t.toFixed(1)} ms · ${t>=end?'全部完成':active?'正在执行 '+active.name:'CPU空闲'} · 教学慢放：1ms调度时间约用0.25s展示`;
  host.querySelector('.ws-results').innerHTML=readouts(result.latency.map(l=>{const arrival=tasks().find(a=>a.id===l.id).arrive,first=result.timeline.find(s=>s.id===l.id);return[l.name+' 首次等待',t<arrival?'尚未到达':t<first.start?`${(t-arrival).toFixed(1)}（等待中）`:l.latency,'ms'];}));
  const events=result.events.filter(e=>e.t<=t);updateEvents(host.querySelector('.ws-events'),events.map(e=>[e.t,e.name,({queue:'到达/挂起',start:'开始或恢复',preempt:'被 '+e.by+' 抢占',finish:'完成'})[e.type]||e.type]),['时刻 / ms','请求','事件']);
  if(t>=end)markCheck('nvic',result.preemptions?'nested':'queued');host.querySelector('.ws-record').innerHTML=checklist('nvic',goals);
 }
 const player=playback(host,{end:()=>result.end,step:()=>{const t=player.at();return (result.events.find(e=>e.t>t)?.t??result.end)-t;},scale:()=>250,onFrame:frame});
 host.querySelector('[data-step]').textContent='下一个调度事件';
 const apply=values=>{const previous=config;try{config=values;result=nvicGrouped(tasks(),config.group);setControls(host.querySelector('form'),config);player.reset();status(host,`已应用：${result.group.preemptBits}位抢占、${result.group.subBits}位子优先级。数字越小，优先级越高。`);}catch(e){config=previous;status(host,'没有应用这组条件：'+e.message+'。请检查分组允许的优先级范围。');}};
 host.querySelector('form').onsubmit=e=>{e.preventDefault();apply(readControls(e.currentTarget));};host.querySelector('form').oninput=()=>status(host,'参数尚未应用，图表仍显示上一组条件。');
 host.querySelectorAll('[data-preset]').forEach(b=>b.onclick=()=>apply({timD:6,extiD:4,uartD:3,group:'g2',timP:b.dataset.preset==='queue'?0:2,extiP:b.dataset.preset==='queue'?0:1,uartP:0,timS:0,extiS:0,uartS:0,extiAt:b.dataset.preset==='same'?0:2,uartAt:b.dataset.preset==='same'?0:3}));player.refresh();
}
