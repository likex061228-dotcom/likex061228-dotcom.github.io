// 嵌入式参考章节：HAL 代码 → 寄存器 → 引脚/LED 的三联动可视化。
import { getChip } from '../data/chips.mjs';
import { registers, pinLevel, ledOn, f1Nibble } from '../model/gpio.mjs';

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const OUTPUT_CODE = [
  '__HAL_RCC_GPIOC_CLK_ENABLE();          /* 先开时钟 */',
  'GPIO_InitTypeDef gpio = {0};',
  'gpio.Pin   = GPIO_PIN_13;',
  'gpio.Mode  = GPIO_MODE_OUTPUT_PP;',
  'gpio.Pull  = GPIO_NOPULL;',
  'gpio.Speed = GPIO_SPEED_FREQ_LOW;',
  'HAL_GPIO_Init(GPIOC, &gpio);            /* 写 CRH */',
  'HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);  /* ODR=0 */'
];

const INPUT_CODE = [
  '__HAL_RCC_GPIOA_CLK_ENABLE();          /* 先开时钟 */',
  'GPIO_InitTypeDef gpio = {0};',
  'gpio.Pin   = GPIO_PIN_12;',
  'gpio.Mode  = GPIO_MODE_INPUT;',
  'gpio.Pull  = GPIO_PULLUP;              /* 内部上拉 */',
  'HAL_GPIO_Init(GPIOA, &gpio);            /* CRH + ODR */',
  'uint8_t s = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12);  /* 读 IDR */'
];

export function mcuCodeviz(host) {
  const mode = host.dataset.mode === 'input' ? 'input' : 'output';
  const chip = getChip(host.dataset.chip || 'f103c8');
  let step = 0;
  let pressed = false;

  const cfgOut = { mode: 'output-pp', pull: 'none', speed: 'low', level: 'low' };
  const cfgIn = { mode: 'input', pull: 'up', speed: 'low', level: 'high' };

  const steps = mode === 'output'
    ? [
        { line: 0, note: '打开 GPIOC 时钟。时钟没开时，后面写寄存器不会生效。', crl: null, odr: null },
        { line: 1, note: '准备一个结构体描述引脚。初始化 {0} 避免残留值。', crl: null, odr: null },
        { line: 2, note: '选择第13号引脚（PC13，精灵1核心板D2）。', crl: null, odr: null },
        { line: 3, note: '模式选推挽输出：既能拉高也能拉低。', crl: { mode: 'output-pp' }, odr: null },
        { line: 4, note: '输出模式一般不用内部上下拉。', crl: { mode: 'output-pp' }, odr: null },
        { line: 5, note: '低速档就够点 LED，没必要选 50 MHz。', crl: { mode: 'output-pp', speed: 'low' }, odr: null },
        { line: 6, note: 'HAL_GPIO_Init 把配置写进 CRH：PC13 的 4 位 = 0b0010。', crl: { mode: 'output-pp', speed: 'low' }, odr: null },
        { line: 7, note: '写 ODR13 = 0：引脚变低，LED 串联在 3.3V 与引脚之间，因此点亮。', crl: { mode: 'output-pp', speed: 'low' }, odr: 0 }
      ]
    : [
        { line: 0, note: '打开 GPIOA 时钟，否则输入读不到。', crl: null, odr: null },
        { line: 1, note: '准备结构体。', crl: null, odr: null },
        { line: 2, note: '选择 PA12（精灵1底板KEY4）。', crl: null, odr: null },
        { line: 3, note: '输入模式：引脚只测量外部电平，不主动驱动。', crl: { mode: 'input', pull: 'up' }, odr: null },
        { line: 4, note: '内部上拉：松开时读到高，按下（接 GND）读到低。', crl: { mode: 'input', pull: 'up' }, odr: 1 },
        { line: 5, note: '写 CRH（输入编码 0b1000），同时 ODR 位选择上拉。', crl: { mode: 'input', pull: 'up' }, odr: 1 },
        { line: 6, note: pressed ? '按键按下：引脚被拉到 GND，IDR12 = 0。' : '没按：上拉让引脚保持高，IDR12 = 1。', crl: { mode: 'input', pull: 'up' }, odr: 1 }
      ];

  function regRows(config, odr) {
    if (!config) return '<p class="mcu-note">还没写到寄存器：前面的语句只在准备参数。</p>';
    const pin = mode === 'output' ? 'PC13' : 'PA12';
    const regs = registers(chip, pin, config);
    return regs.rows.map(row => {
      let value = row.value;
      if (row.name.endsWith('ODR') && odr !== null) {
        value = '0x' + ((odr << (mode === 'output' ? 13 : 12)) >>> 0).toString(16).toUpperCase().padStart(8, '0');
      }
      return `<div class="mcu-reg"><code>${esc(row.name)}</code><b>${esc(value)}</b></div>`;
    }).join('');
  }

  function render() {
    const code = mode === 'output' ? OUTPUT_CODE : INPUT_CODE;
    const s = steps[step];
    const note = (mode === 'input' && step === steps.length - 1)
      ? (pressed ? '按键按下：引脚被拉到 GND，IDR 对应位 = 0，读到低电平。' : '没按：内部上拉让引脚保持高，IDR 对应位 = 1，读到高电平。')
      : s.note;
    const cfg = s.crl ? { ...(mode === 'output' ? cfgOut : cfgIn), ...s.crl } : null;
    const level = cfg ? (mode === 'input' ? (pressed ? 'LOW' : 'HIGH') : pinLevel(cfg, 'none')) : '—';
    const led = cfg && mode === 'output' ? ledOn(chip, level) : null;
    const pinName = mode === 'output' ? 'PC13' : 'PA12';

    host.innerHTML = `
      <div class="mcu-viz">
        <div class="mcu-head"><b>${mode === 'output' ? 'PC13 点灯' : 'PA12 读按键'}：代码 → 寄存器 → 引脚</b>
          ${mode === 'input' ? `<label class="mcu-toggle"><input type="checkbox" data-k="press" ${pressed ? 'checked' : ''}> 按下按键</label>` : ''}
        </div>
        <div class="cviz">
          <div class="cviz-code">${code.map((line, i) => `<div class="cviz-line ${i === s.line ? 'active' : ''}"><i>${i + 1}</i><code>${esc(line)}</code></div>`).join('')}</div>
          <div>
            <div class="mcu-regs">${regRows(cfg, s.odr)}</div>
            <div class="mcu-state">
              <div><small>引脚</small><b>${esc(pinName)}</b></div>
              <div><small>电平</small><b>${level === 'LOW' ? '低' : level === 'HIGH' ? '高' : level === 'FLOATING' ? '浮空' : '—'}</b></div>
              <div><small>${mode === 'output' ? 'LED' : 'IDR'}</small><b>${mode === 'output' ? (led === null ? '—' : led ? '亮' : '灭') : (cfg ? (pressed ? '0' : '1') : '—')}</b></div>
            </div>
          </div>
        </div>
        <p class="mcu-note">${esc(note)}</p>
        <div class="mcu-controls">
          <button type="button" data-act="reset">↺ 重置</button>
          <button type="button" data-act="prev">← 上一步</button>
          <button type="button" data-act="next">下一步 →</button>
          <button type="button" data-act="play">▶ 自动播放</button>
          <span class="mcu-progress">第 ${step + 1} / ${steps.length} 步</span>
        </div>
      </div>`;

    host.querySelector('[data-act="next"]').onclick = () => { stop(); step = Math.min(steps.length - 1, step + 1); render(); };
    host.querySelector('[data-act="prev"]').onclick = () => { stop(); step = Math.max(0, step - 1); render(); };
    host.querySelector('[data-act="reset"]').onclick = () => { stop(); step = 0; render(); };
    host.querySelector('[data-act="play"]').onclick = e => {
      if (timer) { stop(); return; }
      if (step >= steps.length - 1) step = 0;
      e.currentTarget.textContent = '⏸ 暂停';
      timer = setInterval(() => {
        if (step >= steps.length - 1) { stop(); return; }
        step++; render();
      }, 900);
    };
    const press = host.querySelector('[data-k="press"]');
    if (press) press.onchange = e => { pressed = e.target.checked; render(); };
  }
  let timer = null;
  function stop() { if (timer) { clearInterval(timer); timer = null; } }
  host._cleanup = stop;
  render();
}

export const MCU_WIDGETS = { 'mcu-codeviz': mcuCodeviz };
