import {counterState} from '../model/workshop.mjs';
import {instrument,numberControl as number,selectControl as select,readControls,setControls,status,readouts,playback,transport,checklist,markCheck,waveSvg} from './workshop-ui.mjs';
const cfgValues=(c,counts=0)=>({timerHz:c.timerMHz*1e6,psc:c.psc,arr:c.arr,ccr:c.ccr??250,polarity:c.polarity??'high',counts});
const fmt=(n,d=3)=>Number(n.toFixed(d)).toString();
function applyForm(host,apply){const form=host.querySelector('.ws-params');form.onsubmit=e=>{e.preventDefault();apply(readControls(form));};form.oninput=()=>status(host,'参数尚未应用，图表仍显示上一组条件。');}

export function timerWorkshop(host){
 let config={timerMHz:72,psc:71,arr:999},model=counterState(cfgValues(config)),counts=0,limit=3000,player;
 const goals=[['overflow','推进经过ARR，观察CNT归零与更新次数'],['onekhz','配置1kHz更新并实际推进计数']];
 instrument(host,'把计数器停在某一拍','演示向上计数、PSC与ARR已生效且CNT从0开始的理想过程。不模拟预装载、UG和初始化瞬态。',`
 <div class="ws-counter-diagram"></div><div class="ws-results"></div>
 ${transport}<p class="ws-cursor" role="status"></p>
 <div class="ws-seek">${select('stepCounts','单步推进的计数节拍',1,[[1,'1拍'],[10,'10拍'],[100,'100拍'],[1000,'1000拍']])}${number('seekCounts','定位到累计节拍',0,0,1000000000)}<button data-seek>定位</button></div>
 <form class="ws-params">${number('timerMHz','TIM2输入时钟 / MHz',72,1,72)}${number('psc','PSC（0—65535）',71,0,65535)}${number('arr','ARR（0—65535）',999,0,65535)}<button type="submit">应用参数，CNT回到0</button></form><div class="ws-equation"></div><div class="ws-record"></div>`);
 const draw=t=>{
  counts=Math.floor(t);model=counterState(cfgValues(config,counts));const pos=110+model.cnt/Math.max(1,config.arr)*600;
  host.querySelector('.ws-counter-diagram').innerHTML=`<svg viewBox="0 0 800 200" role="img" aria-label="CNT为${model.cnt}，累计更新${model.updates}次"><rect width="800" height="200" fill="#15232a"/><text x="30" y="36">TIM2 · 向上计数</text><path d="M110 100 H710" stroke="#526474" stroke-width="4"/><path d="M110 100 H${pos}" stroke="#d5a365" stroke-width="5"/><circle cx="${pos}" cy="100" r="10" fill="#edcfa1"/><text x="110" y="145">0</text><text x="710" y="145" text-anchor="end">ARR=${config.arr}</text><text x="${Math.max(150,Math.min(670,pos))}" y="78" text-anchor="middle">CNT=${model.cnt}</text><text x="30" y="183">经过ARR后下一拍归0；累计节拍=${counts}，更新事件=${model.updates}</text></svg>`;
  host.querySelector('.ws-results').innerHTML=readouts([['CNT',model.cnt],['更新事件',model.updates,'次'],['实际计数时间',fmt(counts*model.tickUs/1000),'ms'],['更新周期',fmt(model.periodUs/1000),'ms']]);
  host.querySelector('.ws-cursor').textContent=`教学慢放：每个完整计数周期用约2秒展示，与真实计时速度无关。当前已推进${counts}个分频后节拍。`;
  host.querySelector('.ws-equation').innerHTML=`<p><b>${config.timerMHz} MHz ÷ (${config.psc}+1) ÷ (${config.arr}+1) = ${fmt(model.frequencyHz)} Hz</b></p><p>一拍 ${fmt(model.tickUs)} μs；每周期 ${model.periodCounts} 拍。更新次数是理想计数器事件数，不等于CPU一定及时进入这么多次回调。</p>`;
  if(model.updates>0)markCheck('timer','overflow');if(counts>0&&model.frequencyHz===1000)markCheck('timer','onekhz');host.querySelector('.ws-record').innerHTML=checklist('timer',goals);
 };
 player=playback(host,{end:()=>limit,step:()=>Number(host.querySelector('[name="stepCounts"]').value),scale:()=>2000/model.periodCounts,onFrame:draw});
 host.querySelector('[data-seek]').onclick=()=>{const n=Number(host.querySelector('[name="seekCounts"]').value);try{counterState(cfgValues(config,n));limit=Math.min(1e9,n+model.periodCounts*3);player.seek(n);status(host,'已定位到累计节拍，可继续单步或慢放；计数值来自同一个模型。');}catch(e){status(host,e.message);}};
 applyForm(host,values=>{try{const next=counterState(cfgValues(values));config=values;model=next;limit=next.periodCounts*3;player.reset();status(host,'参数已应用，所有累计节拍与更新次数复位。');}catch(e){status(host,e.message);}});player.refresh();
}

export function pwmWorkshop(host){
 let config={timerMHz:72,psc:71,arr:999,ccr:250,polarity:'high'},result=counterState(cfgValues(config)),player;
 const goals=[['quarter','验证高25%与低有效LED导通75%'],['polarity','反转通道极性并观察电平'],['boundary','检查CCR=0或CCR=ARR+1的恒定输出']];
 instrument(host,'同一波形，两个比例','TIM3_CH1 / PA6，PWM模式1、向上计数；低有效LED为教学负载。只有导通时间比例，没有校准亮度。',`
 <div class="ws-presets"><button data-ccr="0">CCR=0</button><button data-ccr="250">CCR=250</button><button data-ccr="750">CCR=750</button><button data-ccr="full">CCR=ARR+1</button></div>
 <div class="ws-plot"></div>${transport}<p class="ws-cursor" role="status"></p><div class="ws-results"></div>
 <div class="ws-pwm-compare"><div class="ws-duty-bar"><span></span></div><p>上方波形分别显示引脚为高与LED导通，颜色仅帮助区分；不要把引脚高比例直接标成亮度。</p></div>
 <form class="ws-params">${number('timerMHz','TIM3输入时钟 / MHz',72,1,72)}${number('psc','PSC',71,0,65535)}${number('arr','ARR',999,0,65535)}${number('ccr','CCR1',250,0,65535)}${select('polarity','通道有效极性','high',[['high','High（有效时引脚高）'],['low','Low（有效时引脚低）']])}<button type="submit">应用并重启本周期</button></form><div class="ws-equation"></div><div class="ws-record"></div>`);
 const draw=t=>{
  const count=Math.floor(t);result=counterState(cfgValues(config,count));host.querySelector('[data-ccr="full"]').disabled=config.arr===65535;const ticks=result.periodCounts,high=[],lit=[];
  for(let cycle=0;cycle<3;cycle++){
   const start=cycle*ticks,first=counterState(cfgValues(config,start)).pinHigh?1:0;high.push({t:start,v:first});lit.push({t:start,v:1-first});
   if(config.ccr>0&&config.ccr<ticks){high.push({t:start+config.ccr,v:1-first});lit.push({t:start+config.ccr,v:first});}
  }
  // X axis in milliseconds is derived from the exact timer tick, independent from playback wall time.
  const toMs=p=>({t:p.t*result.tickUs/1000,v:p.v});
  host.querySelector('.ws-plot').innerHTML=waveSvg([{name:'PA6高电平',points:high.map(toMs),color:'#77b7c7'},{name:'LED导通',points:lit.map(toMs),color:'#dfbd71'}],ticks*3*result.tickUs/1000,count*result.tickUs/1000);
  host.querySelector('.ws-results').innerHTML=readouts([['CNT',result.cnt],['PA6当前',result.pinHigh?'高':'低'],['引脚高电平',fmt(result.highDuty*100,2),'%'],['低有效LED导通',fmt(result.litDuty*100,2),'%']]);
  host.querySelector('.ws-cursor').textContent=`教学慢放，每周期约2秒；当前 ${fmt(count*result.tickUs/1000)} ms，频率 ${fmt(result.frequencyHz)} Hz。${config.ccr>=ticks?'CCR≥ARR+1，比较条件始终有效。':''}`;
  host.querySelector('.ws-duty-bar span').style.width=(result.litDuty*100)+'%';
  host.querySelector('.ws-equation').innerHTML=`<p>PWM模式1：CNT &lt; CCR时有效。有效比例 = min(CCR, ARR+1) ÷ (ARR+1)。通道极性将有效/无效映射到高/低；低有效LED在引脚低时导通。</p>${config.arr===65535?'<p>ARR已到16位上限65535，CCR不能表示65536；已停用ARR+1预设。PWM模式1在此条件下最多有效65535/65536周期，不能宣称100%。</p>':''}`;
  if(count>0){if(result.highDuty===.25&&result.litDuty===.75)markCheck('pwm','quarter');if(config.polarity==='low')markCheck('pwm','polarity');if(config.ccr===0||config.ccr>=ticks)markCheck('pwm','boundary');}host.querySelector('.ws-record').innerHTML=checklist('pwm',goals);
 };
 player=playback(host,{end:()=>result.periodCounts*3,step:()=>Math.max(1,Math.floor(result.periodCounts/20)),scale:()=>2000/result.periodCounts,onFrame:draw});
 const apply=values=>{try{const next=counterState(cfgValues(values));config=values;result=next;setControls(host.querySelector('form'),config);player.reset();status(host,'新参数已生效，计数器回到0；本课假设预装载已经传递，不模拟写寄存器瞬态。');}catch(e){status(host,e.message);}};
 applyForm(host,apply);host.querySelectorAll('[data-ccr]').forEach(b=>b.onclick=()=>apply({...config,ccr:b.dataset.ccr==='full'?config.arr+1:Number(b.dataset.ccr)}));player.refresh();
}
