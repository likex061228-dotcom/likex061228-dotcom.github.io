import { CHIP_LIST, getChip, findPin } from '../data/chips.mjs';
import * as G from '../model/gpio.mjs';
import { simulateDebounce } from '../model/debounce.mjs';
import { simulateExti } from '../model/edge.mjs';
import { pwm, brightness, fmtFreq, fmtUs } from '../model/timer.mjs';
import { simulateNvic, scenario } from '../model/nvic.mjs';
import { formatOne, FORMAT_PRESETS } from '../model/format.mjs';
import { FAQ, FAQ_CATS } from '../data/faq.mjs';
import { QUIZ, gradeQuiz } from '../data/quiz.mjs';
import { drawDebounceCanvas, drawPwmCanvas, drawNvicCanvas, drawCntCanvas, drawExtiCanvas } from '../view/draw.mjs';
import { ledLesson } from './led-lesson.mjs';
import {buttonWorkshop,extiWorkshop,nvicWorkshop} from './signal-workshops.mjs';
import {timerWorkshop,pwmWorkshop} from './timer-workshops.mjs';
import {workshopHome} from './workshop-home.mjs';

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const h = (tag, html, cls) => {
  const el = document.createElement(tag);
  el.innerHTML = html;
  if (cls) el.className = cls;
  return el;
};
const range = (from, to, step = 1) => Array.from({ length: Math.floor((to - from) / step) + 1 }, (_, i) => from + i * step);

/* ---------------- 引脚实验台 ---------------- */
function pinLab(host) {
  const state = { chip: 'f103rc', pin: 'PC0', cfg: { ...G.DEFAULT_CONFIG } };
  state.cfg = { ...G.DEFAULT_CONFIG, mode: 'output-pp', level: getChip(state.chip).demo.ledActiveLow ? 'low' : 'high' };
  const chip = () => getChip(state.chip);
  const pin = () => findPin(chip(), state.pin);
  const cfgFor = name => {
    const c = chip();
    if (name === c.demo.ledPin) return { ...G.DEFAULT_CONFIG, mode: 'output-pp', level: c.demo.ledActiveLow ? 'low' : 'high' };
    if (name === c.demo.keyPin) return { ...G.DEFAULT_CONFIG, mode: 'input', pull: 'up' };
    return { ...G.DEFAULT_CONFIG };
  };

  function pins() {
    const c = chip();
    const ports = [...new Set(c.pins.map(p => p.port))];
    return ports.map(port => {
      const list = c.pins.filter(p => p.port === port);
      return `<div class="pin-row"><span class="pin-port">P${port}</span><div class="pin-cells">
        ${list.map(p => `<button type="button" class="pin ${p.name === state.pin ? 'on' : ''} ${p.warn ? 'warn' : ''}" data-pin="${p.name}" title="${esc(p.warn || p.roles.join(' / ') || '通用 IO')}"><span>${p.num}</span>${p.roles.length ? '<i></i>' : ''}</button>`).join('')}
      </div></div>`;
    }).join('');
  }

  function registersHtml(p, cfg) {
    const regs = G.registers(chip(), p.name, cfg);
    return regs.rows.map(row => {
      const total = 32;
      const value = parseInt(row.value, 16);
      const start = total - row.fieldAt - row.fieldWidth;
      let bits = '';
      for (let i = 0; i < total; i++) {
        const bit = (value >> (total - 1 - i)) & 1;
        bits += i >= start && i < start + row.fieldWidth ? `<b>${bit}</b>` : bit;
      }
      return `<div class="reg"><div class="reg-head"><code>${esc(row.name)}</code><b>${esc(row.value)}</b></div><div class="reg-bits"><code>${bits}</code></div><p>${esc(row.formula)}</p></div>`;
    }).join('');
  }

  function render() {
    const p = pin(), c = chip(), cfg = state.cfg;
    const isOutput = cfg.mode === 'output-pp' || cfg.mode === 'output-od';
    const level = G.pinLevel(cfg, 'none');
    const on = G.ledOn(c, level);
    const levelText = { HIGH: '高电平', LOW: '低电平', FLOATING: '高阻/浮空', ANALOG: '模拟', AF: '复用功能' }[level] || level;
    const warn = G.warnings(c, p, cfg);
    const roles = p.roles.length ? p.roles.join(' / ') : '通用 IO';

    host.innerHTML = `
      <div class="lab-chips">${CHIP_LIST.map(x => `<button type="button" class="${x.key === state.chip ? 'on' : ''}" data-chip="${x.key}"><strong>${esc(x.name)}</strong><small>${x.pkg} · ${x.maxMHz}MHz</small></button>`).join('')}</div>
      <p class="lab-note">${esc(c.board)}：${esc(c.note)}</p>
      <div class="pinwall">${pins()}</div>
      <div class="cfg-row">
        <label>模式<select data-cfg="mode">${G.MODES.map(m => `<option value="${m.id}" ${m.id === cfg.mode ? 'selected' : ''}>${m.label}</option>`).join('')}</select></label>
        <label>上下拉<select data-cfg="pull">${G.PULLS.map(m => `<option value="${m.id}" ${m.id === cfg.pull ? 'selected' : ''}>${m.label}</option>`).join('')}</select></label>
        <label>速度<select data-cfg="speed" ${isOutput ? '' : 'disabled'}>${G.SPEEDS.map(m => `<option value="${m.id}" ${m.id === cfg.speed ? 'selected' : ''}>${m.label}</option>`).join('')}</select></label>
        <div class="level-toggle ${isOutput ? '' : 'off'}"><span>输出电平</span>
          <button type="button" data-level="high" class="${cfg.level === 'high' ? 'on' : ''}" ${isOutput ? '' : 'disabled'}>高</button>
          <button type="button" data-level="low" class="${cfg.level === 'low' ? 'on' : ''}" ${isOutput ? '' : 'disabled'}>低</button>
        </div>
        <div class="led-demo"><div class="led ${on ? 'lit' : ''}"></div><div><small>${esc(p.name)} · ${esc(roles)}</small><strong>${esc(levelText)}${p.name === c.demo.ledPin ? (on ? ' · LED 亮' : ' · LED 灭') : ''}</strong></div></div>
      </div>
      ${warn.length ? `<ul class="warn-list">${warn.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}
      <div class="triple">
        <div><h4>① 配置摘要</h4><dl class="kv">
          <div><dt>模式</dt><dd>${esc(G.modeOf(cfg.mode).label)}（${esc(G.modeOf(cfg.mode).hal)}）</dd></div>
          <div><dt>上下拉</dt><dd>${esc(G.pullOf(cfg.pull).label)}</dd></div>
          <div><dt>速度</dt><dd>${esc(G.speedOf(cfg.speed).label)}</dd></div>
          <div><dt>电平</dt><dd>${isOutput ? (cfg.level === 'high' ? '高' : '低') : '由外部电路决定'}</dd></div>
        </dl></div>
        <div><h4>② 生成的 HAL 代码</h4><pre class="code"><code>${esc(G.halCode(c, p.name, cfg))}</code></pre></div>
        <div><h4>③ 寄存器位（只显示该引脚）</h4><p class="quiet">${esc(G.registers(c, p.name, cfg).model)}；加粗位属于所选引脚，其余按 0 显示。</p><div class="reg-list">${registersHtml(p, cfg)}</div></div>
      </div>`;

    host.querySelectorAll('[data-chip]').forEach(btn => btn.onclick = () => {
      state.chip = btn.dataset.chip;
      state.pin = chip().demo.ledPin;
      state.cfg = cfgFor(state.pin);
      render();
    });
    host.querySelectorAll('[data-pin]').forEach(btn => btn.onclick = () => {
      state.pin = btn.dataset.pin;
      state.cfg = cfgFor(state.pin);
      render();
    });
    host.querySelectorAll('select[data-cfg]').forEach(sel => sel.onchange = () => {
      state.cfg[sel.dataset.cfg] = sel.value;
      render();
    });
    host.querySelectorAll('[data-level]').forEach(btn => btn.onclick = () => {
      state.cfg.level = btn.dataset.level;
      render();
    });
  }
  render();
}

/* ---------------- EXTI 线映射 ---------------- */
function extiLine(host) {
  const options = [
    { port: 'PA0', chip: 'F103RCT6', note: 'NANO 板的 WK_UP' },
    { port: 'PB0', chip: 'F103C8T6', note: 'Blue Pill 无板载按键，可外接' },
    { port: 'PC0', chip: 'F103RCT6', note: 'NANO 板的 LED0 所在端口' }
  ];
  let selected = 0;
  function render() {
    host.innerHTML = `<div class="exti-line">
      <div class="exti-pins">${options.map((o, i) => `<button type="button" class="${i === selected ? 'on' : ''}" data-o="${i}"><b>${o.port}</b><small>${o.note}</small></button>`).join('')}</div>
      <div class="exti-flow">
        <div class="box">选中引脚<br><b>${options[selected].port}</b></div>
        <div class="arrow">→</div>
        <div class="box accent">边沿检测<br><b>EXTI0</b></div>
        <div class="arrow">→</div>
        <div class="box">NVIC<br><b>IRQ 0</b></div>
        <div class="arrow">→</div>
        <div class="box">CPU 跳转<br><b>EXTI0_IRQHandler</b></div>
      </div>
      <p class="quiet">EXTI 线按引脚编号分组：PA0、PB0、PC0… 共用 <b>EXTI0</b>，同一时刻只能选一个端口。换端口时必须改 AFIO（F1）/SYSCFG（F4）的 EXTICR，CubeMX 会自动生成这段配置。</p>
    </div>`;
    host.querySelectorAll('[data-o]').forEach(b => b.onclick = () => { selected = Number(b.dataset.o); render(); });
  }
  render();
}

/* ---------------- 抖动 / EXTI 计数 ---------------- */
function extiCount(host) {
  const state = { bounceMs: 12, pressMs: 300, edge: 'falling', debounce: false };
  host.innerHTML = `
    <div class="lab-grid">
      <div class="canvas-wrap"><canvas id="exti-canvas"></canvas></div>
      <div class="lab-controls">
        <label>抖动时长 <output>${state.bounceMs} ms</output><input type="range" min="0" max="24" value="${state.bounceMs}" data-k="bounceMs"></label>
        <label>按下时长 <output>${state.pressMs} ms</output><input type="range" min="60" max="800" step="10" value="${state.pressMs}" data-k="pressMs"></label>
        <label>触发边沿<select data-k="edge"><option value="falling">下降沿（按下）</option><option value="rising">上升沿（松开）</option><option value="both">双边沿</option></select></label>
        <label class="check"><input type="checkbox" data-k="debounce" ${state.debounce ? 'checked' : ''}> 先消抖再判边沿</label>
        <div class="big-count"><small>中断次数</small><strong id="exti-count">0</strong></div>
      </div>
    </div>`;
  const canvas = host.querySelector('#exti-canvas'), out = host.querySelector('#exti-count');
  function redraw() {
    const sim = simulateExti(state);
    drawExtiCanvas(canvas, sim);
    out.textContent = sim.isrCount;
    out.className = sim.isrCount > 1 && !state.debounce ? 'bad' : '';
  }
  host.querySelectorAll('[data-k]').forEach(el => {
    const key = el.dataset.k;
    el.oninput = () => {
      if (el.type === 'checkbox') state[key] = el.checked;
      else state[key] = el.type === 'range' ? Number(el.value) : el.value;
      const o = el.parentElement.querySelector('output');
      if (o) o.textContent = el.value + ' ms';
      redraw();
    };
  });
  redraw();
}

/* ---------------- 按键消抖 ---------------- */
function debounceLab(host) {
  const state = { pressMs: 260, bounceMs: 9, sampleMs: 10, need: 3, longMs: 800 };
  host.innerHTML = `
    <div class="lab-grid">
      <div class="canvas-wrap"><canvas id="deb-canvas"></canvas></div>
      <div class="lab-controls">
        <label>按下时长 <output>${state.pressMs} ms</output><input type="range" min="60" max="1400" step="10" value="${state.pressMs}" data-k="pressMs"></label>
        <label>抖动时长 <output>${state.bounceMs} ms</output><input type="range" min="0" max="30" value="${state.bounceMs}" data-k="bounceMs"></label>
        <label>采样周期 <output>${state.sampleMs} ms</output><input type="range" min="1" max="30" value="${state.sampleMs}" data-k="sampleMs"></label>
        <label>连续一致次数 <output>${state.need} 次</output><input type="range" min="1" max="8" value="${state.need}" data-k="need"></label>
        <label>长按阈值 <output>${state.longMs} ms</output><input type="range" min="300" max="1500" step="50" value="${state.longMs}" data-k="longMs"></label>
      </div>
    </div>
    <div class="lab-result" id="deb-result"></div>`;
  const canvas = host.querySelector('#deb-canvas');
  function redraw() {
    const sim = simulateDebounce({ ...state, pressAt: 140, releaseGapMs: 420, seed: 7 });
    drawDebounceCanvas(canvas, sim);
    const el = host.querySelector('#deb-result');
    const color = sim.verdict === '没识别到完整按键' ? 'bad' : 'ok';
    el.innerHTML = `<div><small>识别结果</small><strong class="${color}">${sim.verdict}</strong></div>
      <div><small>确认后的按下时长</small><strong>${Math.round(sim.heldMs)} ms</strong></div>
      <div><small>理论最短确认时间</small><strong>${sim.theoryMs} ms</strong></div>
      <div><small>怎么读这张图</small><p>上排是引脚真实电平，圆点是采样时刻，下排是"连续 N 次一致"之后的状态。</p></div>`;
  }
  host.querySelectorAll('[data-k]').forEach(el => el.oninput = () => {
    const key = el.dataset.k;
    state[key] = Number(el.value);
    const o = el.parentElement.querySelector('output');
    if (o) o.textContent = key === 'need' ? el.value + ' 次' : el.value + ' ms';
    redraw();
  });
  redraw();
}

/* ---------------- NVIC 时间轴 ---------------- */
function nvicLab(host) {
  const presets = [
    { label: '三个都设0：观察排队', preempt: [0, 0, 0], sub: [0, 0, 0] },
    { label: '分层：TIM=2, EXTI=1, USART=0', preempt: [2, 1, 0], sub: [0, 0, 0] },
    { label: '同抢占 0，用子优先级排队', preempt: [0, 0, 0], sub: [2, 1, 0] },
    { label: '同抢占同子优先级（等待与仲裁）', preempt: [1, 1, 1], sub: [0, 0, 0] }
  ];
  host.innerHTML = `
    <div class="preset-row">${presets.map((p, i) => `<button type="button" data-p="${i}">${esc(p.label)}</button>`).join('')}</div>
    <div class="canvas-wrap"><canvas id="nvic-canvas"></canvas></div>
    <div class="nvic-latency" id="nvic-latency"></div>`;
  const canvas = host.querySelector('#nvic-canvas');
  function draw(preempt, sub) {
    const tasks = scenario({ preempt, sub });
    const r = simulateNvic(tasks);
    drawNvicCanvas(canvas, r, tasks);
    host.querySelector('#nvic-latency').innerHTML = r.latency.map(l =>
      `<div><small>${esc(l.name)}<br>等待 / 完成</small><strong>${l.latency ?? '-'} / ${l.completion ?? '-'} ms</strong></div>`).join('') +
      `<div><small>嵌套次数</small><strong>${r.preemptions}</strong></div>`;
  }
  host.querySelectorAll('[data-p]').forEach(b => b.onclick = () => {
    const p = presets[Number(b.dataset.p)];
    draw(p.preempt, p.sub);
  });
  draw(presets[1].preempt, presets[1].sub);
}

/* ---------------- 计数器 ---------------- */
function cntLab(host) {
  const state = { psc: 71, arr: 999 };
  host.innerHTML = `
    <div class="lab-grid">
      <div class="canvas-wrap"><canvas id="cnt-canvas"></canvas></div>
      <div class="lab-controls">
        <label>PSC（预分频）<output>${state.psc}</output><input type="range" min="0" max="719" value="${state.psc}" data-k="psc"></label>
        <label>ARR（重装载）<output>${state.arr}</output><input type="range" min="9" max="4999" step="10" value="${state.arr}" data-k="arr"></label>
        <div class="cnt-readout" id="cnt-readout"></div>
      </div>
    </div>`;
  const canvas = host.querySelector('#cnt-canvas');
  const readout = host.querySelector('#cnt-readout');
  let raf = null, t0 = performance.now();
  function renderText() {
    const chip = getChip('f103rc');
    const r = pwm(chip, { psc: state.psc, arr: state.arr, ccr: 0 });
    readout.innerHTML = `<div><small>更新频率</small><strong>${fmtFreq(r.freqHz)}</strong></div>
      <div><small>更新周期</small><strong>${fmtUs(r.periodUs)}</strong></div>
      <div><small>单计数时间</small><strong>${fmtUs(r.tickUs)}</strong></div>`;
  }
  function loop(now) {
    const chip = getChip('f103rc');
    const r = pwm(chip, { psc: state.psc, arr: state.arr, ccr: 0 });
    const periodMs = r.periodUs / 1000;
    const elapsed = now - t0;
    const phase = (elapsed % periodMs) / periodMs;
    const cnt = Math.min(state.arr, Math.floor(phase * (state.arr + 1)));
    drawCntCanvas(canvas, { arr: state.arr, cnt, updateFlash: phase > 0.97 });
    raf = requestAnimationFrame(loop);
  }
  host.querySelectorAll('[data-k]').forEach(el => el.oninput = () => {
    state[el.dataset.k] = Number(el.value);
    el.parentElement.querySelector('output').textContent = el.value;
    renderText();
    t0 = performance.now();
  });
  renderText();
  raf = requestAnimationFrame(loop);
  host._cleanup = () => cancelAnimationFrame(raf);
}

/* ---------------- PWM ---------------- */
function pwmLab(host) {
  const state = { psc: 71, arr: 999, ccr: 250 };
  host.innerHTML = `
    <div class="lab-grid">
      <div class="canvas-wrap"><canvas id="pwm-canvas"></canvas></div>
      <div class="lab-controls">
        <label>PSC <output>${state.psc}</output><input type="range" min="0" max="999" value="${state.psc}" data-k="psc"></label>
        <label>ARR <output>${state.arr}</output><input type="range" min="9" max="4999" step="10" value="${state.arr}" data-k="arr"></label>
        <label>CCR <output>${state.ccr}</output><input type="range" min="0" max="4999" step="10" value="${state.ccr}" data-k="ccr"></label>
        <div class="pwm-led"><div class="led big" id="pwm-led"></div><span id="pwm-brightness"></span></div>
      </div>
    </div>
    <div class="pwm-readout" id="pwm-readout"></div>`;
  const canvas = host.querySelector('#pwm-canvas');
  function redraw() {
    const r = pwm(getChip('f103rc'), state);
    drawPwmCanvas(canvas, r);
    const b = brightness(r.duty) / 100;
    const led = host.querySelector('#pwm-led');
    led.style.background = `rgba(255,216,121,${(0.1 + 0.9 * b).toFixed(3)})`;
    led.style.boxShadow = b > 0.02 ? `0 0 ${Math.round(6 + 18 * b)}px ${Math.round(1 + 4 * b)}px rgba(255,216,121,${(0.15 + 0.45 * b).toFixed(3)})` : 'none';
    host.querySelector('#pwm-brightness').textContent = `高电平占空比 ${brightness(r.duty)}%（LED仅示意）`;
    host.querySelector('#pwm-readout').innerHTML = `
      <div><small>频率</small><strong>${fmtFreq(r.freqHz)}</strong><span>${r.freqHz.toFixed(1)} Hz</span></div>
      <div><small>周期</small><strong>${fmtUs(r.periodUs)}</strong><span>ARR+1 = ${r.periodTicks}</span></div>
      <div><small>占空比</small><strong>${(r.duty * 100).toFixed(1)}%</strong><span>CCR ${state.ccr} / ${r.periodTicks}</span></div>
      <div><small>单计数</small><strong>${fmtUs(r.tickUs)}</strong><span>(PSC+1) = ${r.prescaler}</span></div>
      ${r.overflow ? '<div class="warn-inline">CCR 大于 ARR：输出会一直是高电平，这是常见笔误。</div>' : ''}`;
  }
  host.querySelectorAll('[data-k]').forEach(el => el.oninput = () => {
    state[el.dataset.k] = Number(el.value);
    el.parentElement.querySelector('output').textContent = el.value;
    redraw();
  });
  redraw();
}

/* ---------------- FAQ ---------------- */
function faqList(host) {
  let cat = '全部';
  let q = '';
  host.innerHTML = `<div class="faq-toolbar">
      <input type="search" placeholder="搜索：下载 / 时钟 / 中断 / 中文 …" aria-label="搜索常见问题">
      <div class="faq-cats">${FAQ_CATS.map(c => `<button type="button" data-cat="${c}" class="${c === '全部' ? 'on' : ''}">${c}</button>`).join('')}</div>
    </div>
    <div class="faq-list" id="faq-list"></div>`;
  const list = host.querySelector('#faq-list');
  const input = host.querySelector('input');
  function render() {
    const kw = q.trim().toLowerCase();
    const items = FAQ.filter(item => (cat === '全部' || item.cat === cat) &&
      (!kw || (item.q + item.symptom + item.cause + item.steps.join(' ')).toLowerCase().includes(kw)));
    list.innerHTML = items.length ? items.map(item => `
      <details class="faq-item">
        <summary><span class="faq-cat">${esc(item.cat)}</span>${esc(item.q)}</summary>
        <div class="faq-body">
          <p><b>现象：</b>${esc(item.symptom)}</p>
          <p><b>原因：</b>${esc(item.cause)}</p>
          <ol>${item.steps.map(s => `<li>${esc(s)}</li>`).join('')}</ol>
        </div>
      </details>`).join('') : '<p class="quiet">没有匹配的条目，换个关键词试试。</p>';
    list.querySelectorAll('.faq-item').forEach(d => d.addEventListener('toggle', () => {
      if (d.open) list.querySelectorAll('.faq-item').forEach(o => { if (o !== d) o.open = false; });
    }));
  }
  input.oninput = () => { q = input.value; render(); };
  host.querySelectorAll('[data-cat]').forEach(b => b.onclick = () => {
    cat = b.dataset.cat;
    host.querySelectorAll('[data-cat]').forEach(x => x.classList.toggle('on', x === b));
    render();
  });
  render();
}

/* ---------------- 题库 ---------------- */
const QUIZ_KEY = 'Like_x.teach.quiz.v2';
function quizLab(host) {
  let answers = {};
  let filter = '全部';
  try { answers = JSON.parse(localStorage.getItem(QUIZ_KEY) || '{}') || {}; } catch { answers = {}; }
  const save = () => { try { localStorage.setItem(QUIZ_KEY, JSON.stringify(answers)); } catch { /* 忽略 */ } };
  const sections = ['全部', ...new Set(QUIZ.map(q => q.sec))];
  host.innerHTML = `<div class="quiz-toolbar">
      <div class="quiz-filter">${sections.map(s => `<button type="button" data-sec="${s}" class="${s === filter ? 'on' : ''}">${s}</button>`).join('')}</div>
      <div class="quiz-score" id="quiz-score"></div>
      <button type="button" class="button" id="quiz-reset">清空作答</button>
    </div>
    <div class="quiz-list" id="quiz-list"></div>`;
  function render() {
    const items = QUIZ.filter(q => filter === '全部' || q.sec === filter);
    host.querySelector('#quiz-list').innerHTML = items.map((q, i) => {
      const picked = answers[q.id];
      const done = Number.isInteger(picked);
      return `<article class="quiz-item ${done ? (picked === q.answer ? 'ok' : 'bad') : ''}">
        <header><span class="sec">${esc(q.sec)}</span><h3>${i + 1}. ${esc(q.q)}</h3></header>
        <div class="quiz-opts">${q.opts.map((opt, k) => `<button type="button" data-q="${q.id}" data-k="${k}" class="${done && picked === k ? 'picked' : ''} ${done && k === q.answer ? 'right' : ''}">${esc(opt)}</button>`).join('')}</div>
        ${done ? `<p class="quiz-why ${picked === q.answer ? 'ok' : 'bad'}">${picked === q.answer ? '✓ 正确。' : '✗ 再想想。'} ${esc(q.why)}</p>` : ''}
      </article>`;
    }).join('');
    host.querySelectorAll('[data-q]').forEach(b => b.onclick = () => {
      answers[b.dataset.q] = Number(b.dataset.k);
      save();
      render();
    });
    const { correct, total } = gradeQuiz(answers);
    const answered = Object.keys(answers).length;
    host.querySelector('#quiz-score').textContent = `已作答 ${answered} / ${total} · 正确 ${correct} · ${Math.round(answered / total * 100)}%`;
  }
  host.querySelectorAll('[data-sec]').forEach(b => b.onclick = () => {
    filter = b.dataset.sec;
    host.querySelectorAll('[data-sec]').forEach(x => x.classList.toggle('on', x === b));
    render();
  });
  host.querySelector('#quiz-reset').onclick = () => { answers = {}; save(); render(); };
  render();
}

/* ---------------- printf 格式实验 ---------------- */
function printfLab(host) {
  let spec = '%8.3f';
  let value = '3.14159';
  let showSpaces = true;

  host.innerHTML = `
    <div class="printf-lab">
      <div class="printf-inputs">
        <label>格式串<input type="text" data-k="spec" value="${esc(spec)}" spellcheck="false"></label>
        <label>值<input type="text" data-k="value" value="${esc(value)}" spellcheck="false"></label>
        <label class="check"><input type="checkbox" data-k="spaces" ${showSpaces ? 'checked' : ''}> 用 · 标出空格</label>
      </div>
      <div class="printf-presets">${FORMAT_PRESETS.map(p => `<button type="button" data-preset="${esc(p)}">${esc(p)}</button>`).join('')}</div>
      <div class="printf-out" id="printf-out"></div>
      <p class="quiet" id="printf-note"></p>
    </div>`;

  const outEl = host.querySelector('#printf-out');
  const noteEl = host.querySelector('#printf-note');

  function render() {
    const r = formatOne(spec, value);
    if (!r.ok) {
      outEl.innerHTML = `<pre class="bad">${esc(r.error)}</pre>`;
      noteEl.textContent = '';
      return;
    }
    const shown = showSpaces ? r.output.replace(/ /g, '·') : r.output;
    outEl.innerHTML = `<pre>${esc(shown)}</pre>`;
    noteEl.textContent = r.note;
  }

  host.querySelectorAll('[data-k]').forEach(el => {
    el.oninput = () => {
      const key = el.dataset.k;
      if (key === 'spaces') showSpaces = el.checked; else if (key === 'spec') spec = el.value; else value = el.value;
      render();
    };
  });
  host.querySelectorAll('[data-preset]').forEach(b => b.onclick = () => {
    spec = b.dataset.preset;
    host.querySelector('input[data-k="spec"]').value = spec;
    render();
  });
  render();
}
export const WIDGETS = {
  'workshop-home':workshopHome,
  'button-workshop':buttonWorkshop,
  'exti-workshop':extiWorkshop,
  'nvic-workshop':nvicWorkshop,
  'timer-workshop':timerWorkshop,
  'pwm-workshop':pwmWorkshop,
  'led-lesson': ledLesson,
  'pin-lab': pinLab,
  'exti-line': extiLine,
  'exti-count': extiCount,
  'debounce': debounceLab,
  'nvic': nvicLab,
  'cnt': cntLab,
  'pwm': pwmLab,
  'faq': faqList,
  'quiz': quizLab,
  'printf-lab': printfLab
};

export function mountWidgets(root) {
  root.querySelectorAll('[data-widget]').forEach(el => {
    const factory = WIDGETS[el.dataset.widget];
    if (factory) {
      try { factory(el); } catch (e) { el.innerHTML = '<p class="quiet">这个交互组件加载失败：' + esc(e.message) + '</p>'; }
    }
  });
}
