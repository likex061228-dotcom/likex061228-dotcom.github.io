// 当前板卡依据：用户提供的普中精灵1核心板/底板原理图与配套例程；其余芯片仅寄存器比较。
// 只录入教学需要的引脚与外设；"板载"角色指该开发板默认接线，未列出的按通用 IO 处理。
// 注意：STM32F407RCT6 并非 ST 的产品型号（F407 无 LQFP64 的 RC 组合），此处按最常见的 F407VET6 建模。

const F1_WARN = {
  PA13: 'SWD 调试口（SWDIO），当普通 IO 会失去在线调试',
  PA14: 'SWD 调试口（SWCLK），当普通 IO 会失去在线调试',
  PA15: '上电默认是 JTAG 的 JTDI，要当普通 IO 必须先关闭 JTAG',
  PB3: '上电默认是 JTAG 的 JTDO，要当普通 IO 必须先关闭 JTAG',
  PB4: '上电默认是 JTAG 的 NJTRST，要当普通 IO 必须先关闭 JTAG',
  PC14: '接 32.768 kHz 晶振（OSC32_IN），不宜当普通 IO',
  PC15: '接 32.768 kHz 晶振（OSC32_OUT），不宜当普通 IO',
  PD0: '接 HSE 晶振（OSC_IN），不宜当普通 IO',
  PD1: '接 HSE 晶振（OSC_OUT），不宜当普通 IO'
};

const F4_WARN = {
  PA13: 'SWD 调试口（SWDIO），当普通 IO 会失去在线调试',
  PA14: 'SWD 调试口（SWCLK），当普通 IO 会失去在线调试',
  PA15: '上电默认是 JTAG 的 JTDI，要当普通 IO 必须先关闭 JTAG',
  PB3: '上电默认是 JTAG 的 JTDO，要当普通 IO 必须先关闭 JTAG',
  PB4: '上电默认是 JTAG 的 NJTRST，要当普通 IO 必须先关闭 JTAG',
  PC14: '接 32.768 kHz 晶振（OSC32_IN），不宜当普通 IO',
  PC15: '接 32.768 kHz 晶振（OSC32_OUT），不宜当普通 IO',
  PH0: '接 HSE 晶振（OSC_IN），不宜当普通 IO',
  PH1: '接 HSE 晶振（OSC_OUT），不宜当普通 IO'
};

// F1 上模拟通道所在引脚不是 5V 容忍的，这是新人最容易烧板子的点之一
function f1FiveVoltTolerant(port, num) {
  if (port === 'A' && num <= 7) return false;
  if (port === 'B' && num <= 1) return false;
  if (port === 'C' && num <= 5) return false;
  return true;
}

function buildPins(ports, warnMap, extra) {
  const pins = [];
  for (const [port, max] of ports) {
    for (let num = 0; num <= max; num++) {
      const name = 'P' + port + num;
      pins.push({
        name, port, num,
        warn: warnMap[name] || '',
        fiveVolt: extra.fiveVolt ? extra.fiveVolt(port, num) : true,
        roles: (extra.roles && extra.roles[name]) || []
      });
    }
  }
  return pins;
}

const PUZHONG_ROLES = {
 PA0:['底板LED1'],PA1:['底板LED2'],PA2:['底板LED3'],PA3:['底板LED4'],PA4:['底板LED5'],PA5:['底板LED6'],PA6:['底板LED7'],PA7:['底板LED8 / TIM3_CH2'],
 PA9:['CH340 USART1_TX'],PA10:['CH340 USART1_RX'],PA11:['核心板USB_D-'],PA12:['KEY4 / USB_D+'],PA13:['KEY3 / SWDIO'],PA14:['KEY2 / SWCLK'],PA15:['KEY1 / JTAG'],PC13:['核心板D2 / LED0']
};

const F407_ROLES = {
  PA0: ['WK_UP（常见板）'], PA9: ['USART1_TX'], PA10: ['USART1_RX'],
  PA13: ['SWD'], PA14: ['SWD'],
  PC13: ['常见板载 LED']
};

export const CHIPS = {
  f103rc: {
    key: 'f103rc',
    family: 'F1',
    name: 'STM32F103RCT6',
    board: '通用F103RCT6（仅寄存器比较）',
    pkg: 'LQFP64',
    flashKB: 256, ramKB: 48, maxMHz: 72,
    clock: { hse: 8000000, sysclk: 72000000, apb1: 36000000, apb2: 72000000, timApb1: 72000000, timApb2: 72000000 },
    registerModel: 'F1',
    demo: { ledPin: 'PC0', ledActiveLow: true, keyPin: 'PC8', keyActiveLow: true },
    pins: buildPins([['A', 15], ['B', 15], ['C', 15], ['D', 2]], F1_WARN, {
      roles: {}, fiveVolt: f1FiveVoltTolerant
    }),
    note: '此项仅用于64脚F103寄存器对比；当前实际课程板为普中精灵1 C8T6。PC0/PC8为通用示例，非本课程板接线。'
  },
  f103c8: {
    key: 'f103c8',
    family: 'F1',
    name: 'STM32F103C8T6',
    board: '普中精灵1（核心板＋底板）',
    pkg: 'LQFP48',
    flashKB: 64, ramKB: 20, maxMHz: 72,
    clock: { hse: 8000000, sysclk: 72000000, apb1: 36000000, apb2: 72000000, timApb1: 72000000, timApb2: 72000000 },
    registerModel: 'F1',
    demo: { ledPin: 'PC13', ledActiveLow: true, keyPin: 'PA12', keyActiveLow: true },
    pins: buildPins([['A', 15], ['B', 15], ['C', 15]], F1_WARN, {
      roles: PUZHONG_ROLES, fiveVolt: f1FiveVoltTolerant
    }).filter(p=>p.port!=='C'||p.num>=13).map(p=>p.name==='PA12'?{...p,warn:'KEY4与核心板USB_D+共用；课程禁用USB设备功能并不接核心板USB接口'}:p),
    note: '核心板D2/PC13低电平点亮；底板LED1～8接PA0～7，核对J11供电连接。KEY4/PA12用于本课，保留SWD；不启用USB设备功能，不连接核心板USB接口。HSE晶振8MHz，72MHz是课程PLL配置条件。'
  },
  f407ve: {
    key: 'f407ve',
    family: 'F4',
    name: 'STM32F407VET6',
    board: '通用 F407 开发板（LQFP100）',
    pkg: 'LQFP100',
    flashKB: 512, ramKB: 192, maxMHz: 168,
    clock: { hse: 8000000, sysclk: 168000000, apb1: 42000000, apb2: 84000000, timApb1: 84000000, timApb2: 168000000 },
    registerModel: 'F4',
    demo: { ledPin: 'PB0', ledActiveLow: false, keyPin: 'PB1', keyActiveLow: false },
    pins: buildPins([['A', 15], ['B', 15], ['C', 15], ['D', 15], ['E', 15], ['H', 1]], F4_WARN, {
      roles: F407_ROLES, fiveVolt: (port, num) => !(port === 'H' && num <= 1)
    }),
    note: 'F407 的 GPIO 由 MODER/OTYPER/PUPDR 控制，和 F1 的 CRL/CRH 是两套寄存器模型——页面上可以对照看。'
  }
};

export const CHIP_LIST = Object.values(CHIPS);

export function getChip(key) {
  return CHIPS[key] || CHIPS.f103c8;
}

export function findPin(chip, name) {
  return chip.pins.find(pin => pin.name === name) || null;
}
