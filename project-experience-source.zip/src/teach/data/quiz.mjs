// 自检题库。数值题的答案由公式实时算出，参数改了也不会出现"答案写死"的错误。
import { pwm, fmtFreq } from '../model/timer.mjs';

const f103 = { clock: { timApb1: 72000000, timApb2: 72000000 } };
const t1 = pwm(f103, { psc: 71, arr: 999, ccr: 250 });
const t2 = pwm(f103, { psc: 719, arr: 1999, ccr: 1999 });
const t3 = pwm(f103, { psc: 0, arr: 999, ccr: 500 });

const pct = v => Math.round(v * 100) + '%';

export const QUIZ = [
  {
    id: 'q1', sec: '7.1',
    q: '把 LED 接成「正极经电阻到 3.3V、负极接 PA1」，PA1 要输出什么电平才亮？',
    opts: ['高电平', '低电平', '高阻态', '无所谓'], answer: 1,
    why: '这种接法叫低电平有效：引脚输出低电平，电流从 3.3V 经 LED 流进引脚，LED 才亮。'
  },
  {
    id: 'q2', sec: '7.1',
    q: '开漏输出（Open-Drain）与推挽输出最本质的区别是？',
    opts: ['开漏速度更快', '开漏只能主动拉低，高电平要靠外部上拉', '开漏不能输出方波', '开漏更省电'], answer: 1,
    why: '开漏只有一个下拉管：写 0 是低电平，写 1 是高阻（悬空）。要得到高电平必须外接上拉电阻。'
  },
  {
    id: 'q3', sec: '7.1',
    q: 'CubeMX 里把 PA5 配成 GPIO_Output，代码里也写了 HAL_GPIO_WritePin，但引脚一点反应都没有。最可能漏了什么？',
    opts: ['没开 GPIOA 的时钟', '没写 while(1)', '没配 NVIC', '没开 DMA'], answer: 0,
    why: '外设时钟不开，寄存器写入无效。__HAL_RCC_GPIOA_CLK_ENABLE() 或 CubeMX 生成的 MX_GPIO_Init 里的时钟使能必须有。'
  },
  {
    id: 'q4', sec: '7.2',
    q: '按键一端接 GND、另一端接 PA0，按下为低电平。PA0 应该配成？',
    opts: ['浮空输入', '输入 + 内部上拉', '输入 + 内部下拉', '推挽输出'], answer: 1,
    why: '上拉保证松开时读到稳定的高电平，按下时被按键拉到 GND 读到低电平。配下拉会导致松开为低、按下也是低，分不清。'
  },
  {
    id: 'q5', sec: '7.2',
    q: '浮空输入为什么读数会乱跳？',
    opts: ['芯片坏了', '引脚没有确定的电平，像天线一样拾取周围噪声', '时钟太快', '没有开中断'], answer: 1,
    why: '浮空输入的电压由外部电路决定；什么都没接时输入阻抗很高，很容易被干扰，读数随机。'
  },
  {
    id: 'q6', sec: '7.2',
    q: '定时器每 10ms 采样一次按键，要求连续 3 次一致才确认状态，理论最短消抖时间是多少？',
    opts: ['10ms', '20ms', '30ms', '3ms'], answer: 2,
    why: '需要 3 个采样点都一致，最坏情况下要等 3 个采样周期，即 30ms。'
  },
  {
    id: 'q7', sec: '7.2',
    q: '按键抖动大约持续 8ms，采样周期 10ms。下面说法正确的是？',
    opts: ['一定能完全避开抖动', '可能正好采到抖动中间值，所以还需要「连续多次一致」才确认', '抖动不会影响采样', '采样周期越长越好'], answer: 1,
    why: '采样周期大于抖动时间只是降低了命中概率，不能保证避开；所以软件消抖靠的是"连续多次一致"，而不是单次采样。'
  },
  {
    id: 'q8', sec: '7.3',
    q: '单击与长按的区分依据是？',
    opts: ['按下的力度', '按下持续的时间是否超过阈值', '按下的次数', '引脚电平高低'], answer: 1,
    why: '一般是记录按下到松开的时长：小于阈值算单击，大于阈值算长按；阈值要结合手感调，常见 500–1000ms。'
  },
  {
    id: 'q9', sec: '7.3',
    q: '为什么长按要在松开时才能最终确定？',
    opts: ['因为松开才有下降沿', '因为按下那一刻无法预知会按多久，只能先记时间戳，松开时再算差值', '因为中断只能下降沿触发', '因为消抖需要松开'], answer: 1,
    why: '按下时只能记录起始时间；持续时长要等松开才知道。也可以做到"按住到阈值就触发长按"，那是另一种交互设计。'
  },
  {
    id: 'q10', sec: '8.1',
    q: 'EXTI0 这条中断线，同一时刻能同时接 PA0 和 PB0 吗？',
    opts: ['能，两个都能触发', '不能，同一编号的 EXTI 线只能选一个端口', '能，但要设不同优先级', '取决于时钟'], answer: 1,
    why: 'EXTI 线按引脚编号分组：EXTI0 只能从 PA0/PB0/PC0… 里选一个，通过 AFIO（F1）或 SYSCFG（F4）的 EXTICR 选择。'
  },
  {
    id: 'q11', sec: '8.1',
    q: '按键配好了 EXTI，也写了中断服务函数，但按下没有任何反应。下面哪一项最可能？',
    opts: ['NVIC 里没有使能对应的中断通道', 'GPIO 速度设成了高速', '没用 DMA', '时钟频率太高'], answer: 0,
    why: 'EXTI 只是"信号到中断控制器"的一段；还要在 NVIC 里使能对应的 IRQn 并设优先级，CPU 才会跳进中断。'
  },
  {
    id: 'q12', sec: '8.2',
    q: '两个中断的抢占优先级相同、子优先级不同，它们会互相嵌套吗？',
    opts: ['会，子优先级高的能打断低的', '不会，抢占级别相同就不能打断，只能排队', '取决于中断源', '会，只要优先级数值不同就能嵌套'], answer: 1,
    why: '只有抢占优先级更高的中断才能打断正在执行的中断；抢占级别相同时，子优先级只决定同时挂起时的先后，不产生嵌套。'
  },
  {
    id: 'q13', sec: '9.1',
    q: `定时器时钟 72 MHz，PSC=${71}、ARR=${999}，溢出（更新）频率是？`,
    opts: [fmtFreq(t1.freqHz), fmtFreq(t1.freqHz / 2), fmtFreq(t1.freqHz * 2), fmtFreq(t1.freqHz / 10)], answer: 0,
    why: `f = 72MHz / ((PSC+1)×(ARR+1)) = 72MHz / (72×1000) = ${fmtFreq(t1.freqHz)}。`
  },
  {
    id: 'q14', sec: '9.2',
    q: `接着上一题，CCR=${250} 时 PWM 的占空比是？`,
    opts: [pct(t1.duty), '12.5%', pct(Math.min(1, t1.duty * 2)), pct(t1.duty / 10)], answer: 0,
    why: `duty = CCR / (ARR+1) = 250 / 1000 = ${pct(t1.duty)}。注意分母是 ARR+1，不是 ARR。`
  },
  {
    id: 'q15', sec: '9.2',
    q: `PSC=0、ARR=999、CCR=500 时，占空比是多少？`,
    opts: [pct(t3.duty), '500%', '0.5倍频率', pct(t3.duty / 2)], answer: 0,
    why: `duty = 500 / 1000 = ${pct(t3.duty)}；PSC 只影响频率，不影响占空比。`
  },
  {
    id: 'q16', sec: '9.3',
    q: '呼吸灯为什么通常用 PWM 调亮度，而不是直接把引脚电压调低？',
    opts: ['PWM 更省引脚', 'GPIO 只能输出高低电平，PWM 靠改变亮/灭时间比例来调平均亮度', '电压调低会烧 LED', 'PWM 频率更高'], answer: 1,
    why: '数字引脚只有 0/1。PWM 通过快速开关改变平均电流，人眼因视觉暂留看到的是变暗；效率也比线性调压高。'
  },
  {
    id: 'q17', sec: '常见坑',
    q: '在中断服务函数里调用 HAL_Delay(500) 会发生什么？',
    opts: ['正常延时 500ms', '整个系统被卡住，其他中断和主循环都被拖慢', '自动进入低功耗', '只影响当前中断'], answer: 1,
    why: 'HAL_Delay 依赖 SysTick 轮询，且中断里长时间阻塞会让同级和更低优先级中断都无法响应。中断里只做标记，处理放到主循环。'
  },
  {
    id: 'q18', sec: '常见坑',
    q: `PSC=719、ARR=1999 时，PWM 频率约是多少？（定时器时钟 72MHz）`,
    opts: [fmtFreq(t2.freqHz), fmtFreq(100000), fmtFreq(1000), fmtFreq(5000)], answer: 0,
    why: `f = 72MHz / (720×2000) = ${fmtFreq(t2.freqHz)}，正好是常见的 50Hz 舵机信号频率。`
  }
];

export const QUIZ_BY_ID = Object.fromEntries(QUIZ.map(q => [q.id, q]));

export function gradeQuiz(answers) {
  let correct = 0;
  const detail = QUIZ.map(q => {
    const picked = answers[q.id];
    const ok = picked === q.answer;
    if (ok) correct++;
    return { id: q.id, sec: q.sec, ok, picked, answer: q.answer };
  });
  return { correct, total: QUIZ.length, detail };
}
