// 常见问题库：按"现象 → 原因 → 检查顺序"组织，面向前 4 周的嵌入式新手。
export const FAQ_CATS = ['全部', 'CubeMX', 'Keil', '下载与硬件', '调试思路'];

export const FAQ = [
  {
    cat: 'CubeMX',
    q: '搜索不到我的芯片型号（比如 STM32F103C8T6）',
    symptom: 'New Project 里输入型号，列表空的。',
    cause: 'CubeMX 默认只带部分器件包，具体型号的 DFB 包需要单独下载。',
    steps: ['Help → Manage embedded software packages', '展开 STM32F1（或 F4），勾选对应系列并 Install', '装完重启 CubeMX 再搜', '离线环境可手动导入 .pack 文件']
  },
  {
    cat: 'CubeMX',
    q: 'Clock Configuration 一片红，改不动',
    symptom: '时钟树节点全是红色，或者填了 HCLK 又被弹回去。',
    cause: '时钟链路不满足约束：输入频率没填、PLL 倍频超范围、或没选外部晶振。',
    steps: ['先确认 RCC 里 HSE 选了 Crystal/Ceramic Resonator', '把 Input frequency 填成板子晶振真实值（精灵1原理图为8 MHz，不代表系统已运行72 MHz）', '在 HCLK 框里直接输入 72（F1）或 168（F4）后回车', '让工具自动算 PLL，仍红就逐级看哪个节点的范围提示']
  },
  {
    cat: 'CubeMX',
    q: '点 GENERATE CODE 报路径/工程错误',
    symptom: '提示 project path 无效，或生成到一半失败。',
    cause: '工程路径含中文、空格或超长；或目标目录已有同名但结构不同的工程。',
    steps: ['把工程放到纯英文短路径，如 D:/stm32/led01', '删除旧的生成目录重新生成', 'Project Manager 里确认 Toolchain 是 MDK-ARM', '仍失败时新建空工程再试，排除路径问题']
  },
  {
    cat: 'CubeMX',
    q: '下载一次后芯片再也连不上（SWD 锁死）',
    symptom: '第二次下载报 No target connected，之前明明好的。',
    cause: 'SYS 的 Debug 用了默认 No Debug，或者代码把 PA13/PA14 配成了普通 IO，SWD 被关掉。',
    steps: ['CubeMX → SYS → Debug 选 Serial Wire（下载口默认复用）', '已锁死时：按住复位键 → 点下载 → 看到进度再松手', '或用 BOOT0 拉高进串口下载，擦除后恢复', '以后每次新建工程都先检查这一项']
  },
  {
    cat: 'CubeMX',
    q: '引脚上出现黄色感叹号',
    symptom: 'Pinout 视图里某个引脚是黄色，配置了也不生效。',
    cause: '该引脚被别的外设占用，或复用功能与当前模式冲突。',
    steps: ['把鼠标悬停在引脚上看提示', '检查是否有其他外设（如 SPI/I2C/USART）占了同一引脚', '关掉冲突外设，或换一个引脚', '注意 PB3/PB4/PA15 默认是 JTAG，要当普通 IO 需关闭 JTAG']
  },
  {
    cat: 'CubeMX',
    q: '重新生成代码后，我自己写的代码没了',
    symptom: '改完配置再 GENERATE，主循环里的代码被清空。',
    cause: '手写代码写在了 USER CODE BEGIN/END 之外，被模板覆盖。',
    steps: ['业务代码只写在 /* USER CODE BEGIN n */ 与 /* USER CODE END n */ 之间', '自定义函数放到单独的 .c 文件，避免和生成文件混在一起', '每次生成前先 git 提交或备份']
  },
  {
    cat: 'Keil',
    q: '魔术棒里 Debug 没选下载器，点下载报 No Debug Unit',
    symptom: '下载/调试时提示找不到调试单元。',
    cause: 'Options for Target → Debug 里还是默认的 ULINK 或空。',
    steps: ['魔术棒 → Debug → Use 选 ST-Link Debugger（或 CMSIS-DAP）', '点 Settings，确认 Port 是 SW、能识别到芯片 IDCODE', 'Utilities 里勾 Use Debug Driver', '确定后重新编译下载']
  },
  {
    cat: 'Keil',
    q: 'No target connected / Could not connect to target',
    symptom: '下载器识别到了，但连不上芯片。',
    cause: '目标没供电、SWD 线接错、芯片被复位拉住、或 SWD 引脚被复用。',
    steps: ['先确认板子电源灯亮，3.3V 正常', '检查 SWDIO/SWCLK/GND 三根线是否接对、是否共地', '把下载器速度降到 1 MHz 以下再试', '按住复位键点下载，出现进度再松手', '仍不行就用串口下载擦除一次']
  },
  {
    cat: 'Keil',
    q: 'Flash Download failed - Target DLL has been cancelled',
    symptom: '开始下载瞬间失败。',
    cause: '常见的几类：芯片读保护、下载算法选错、时钟太快、目标在复位状态。',
    steps: ['Options → Debug → Settings → Flash Download，确认 Download Function 勾了 Erase Sectors + Program + Verify', '确认芯片型号对应的 Flash 算法已添加', '降低 SWD 速度', '用 STM32CubeProgrammer 连接并做一次全片擦除']
  },
  {
    cat: 'Keil',
    q: '编译 0 error，但下载后没反应',
    symptom: 'Build 成功，下载成功，板子毫无变化。',
    cause: '没按复位、没勾 Reset and Run、写错端口/引脚、或时钟没起来。',
    steps: ['魔术棒 → Utilities → 勾 Reset and Run', '手动按一次复位键', '调试器里看 GPIOC->ODR 有没有变', '确认 LED 的极性（多数板子低电平点亮）']
  },
  {
    cat: 'Keil',
    q: '中文注释变成乱码',
    symptom: '打开 .c 文件，中文注释是方块或乱码。',
    cause: '文件编码与 Keil 的 Encoding 设置不一致。',
    steps: ['Edit → Configuration → Encoding 选 UTF-8', '或用记事本/VS Code 把文件转成 UTF-8 后另存', '团队协作时统一编码，避免来回转换']
  },
  {
    cat: 'Keil',
    q: '提示找不到 xxx.h',
    symptom: 'fatal error: stm32f1xx_hal.h: No such file or directory',
    cause: '头文件路径没加进工程。',
    steps: ['魔术棒 → C/C++ → Include Paths', '把 Drivers/STM32F1xx_HAL_Driver/Inc、Drivers/CMSIS/... 等目录加进去', 'CubeMX 生成时一般会自动加，手动搬工程时要补']
  },
  {
    cat: 'Keil',
    q: '链接报 L6218E: Undefined symbol',
    symptom: '某个函数未定义。',
    cause: '对应的 .c 没加进工程，或函数名拼错。',
    steps: ['在左侧工程树里确认该 .c 文件存在且被勾选参与编译', '检查函数声明与定义是否一致', 'HAL 的回调函数是弱定义，名字必须完全一致（如 HAL_GPIO_EXTI_Callback）']
  },
  {
    cat: 'Keil',
    q: '进调试后没停在 main',
    symptom: '点 Debug 之后停在启动文件或汇编里。',
    cause: '程序跑飞、HardFault，或启动文件/向量表问题。',
    steps: ['先在 main 第一行打断点再启动调试', '看 Call Stack + Locals 判断是不是 HardFault', '检查时钟配置与中断优先级是否越界', '确认下载的是刚编译的版本']
  },
  {
    cat: 'Keil',
    q: '断点是灰色打不上',
    symptom: '行号左侧点不出红色断点。',
    cause: '优化等级过高，代码被优化掉或行号对不上。',
    steps: ['魔术棒 → C/C++ → Optimization 改成 Level 0 (-O0) 调试', '确认该文件参与编译', '发布时再改回优化等级']
  },
  {
    cat: '下载与硬件',
    q: '精灵1的USB接口能直接当ST-Link使用吗',
    symptom: '设备管理器里没有 ST-Link，Keil 也找不到。',
    cause: '底板USB连接CH340串口，核心板USB连接STM32的PA11/PA12，两者都不是ST-Link。',
    steps: ['使用外接ST-Link时接核心板SWD并共地，CubeMX保留Serial Wire', '底板CH340是串口ISP，不会变成Keil的ST-Link；按资料设置BOOT及串口下载流程', 'KEY4/PA12课不连接核心板USB口，不配置占用SWD的KEY2/3', '核对数据线、目标供电和选择的下载方式，不关闭SWD来解决连接问题']
  },
  {
    cat: '下载与硬件',
    q: '程序下载成功但一上电就跑飞',
    symptom: '复位后行为异常，重新下载又正常。',
    cause: 'BOOT0 电平不对，芯片从系统存储器启动；或供电不稳。',
    steps: ['确认 BOOT0 接地（从 Flash 启动）', '量 3.3V 是否稳定', '检查是否有大电流外设拖垮电源', '必要时加复位电容']
  },
  {
    cat: '下载与硬件',
    q: '杜邦线接的按键时好时坏',
    symptom: '有时能读到按下，有时读不到。',
    cause: '接触不良、线太长、或没共地。',
    steps: ['换短一点的杜邦线，插紧', '确认开发板和外部模块共地', '用万用表通断档量按下前后通断', '能焊就焊，别依赖面包板']
  },
  {
    cat: '下载与硬件',
    q: '外部模块 5V 供电，直接接到 GPIO 上可以吗',
    symptom: '担心烧引脚，或已经出现异常。',
    cause: '多数 F1 引脚是 5V 容忍（FT），但模拟输入引脚不是。',
    steps: ['查数据手册的 pin definition 表看是否标 FT', 'F1 的 PA0–PA7、PB0/PB1、PC0–PC5 通常不是 5V 容忍', '不确定就加电平转换或分压', '永远先共地再接信号']
  },
  {
    cat: '调试思路',
    q: '灯不亮，从哪开始查',
    symptom: '程序看起来没问题，就是没现象。',
    cause: '可能卡在电源、时钟、引脚配置、代码执行任意一环。',
    steps: ['一查电源：板子电源灯亮不亮，3.3V 有没有', '二查时钟：调试器里看 RCC 相关寄存器，或先在 main 打个断点确认能停住', '三查引脚：调试器 Peripherals → GPIO 看 ODR/IDR 位', '四查极性：对照原理图，低电平还是高电平点亮', '五查下载：确认下载的是最新编译结果']
  },
  {
    cat: '调试思路',
    q: '中断进不去，怎么定位',
    symptom: '写了回调，但从来没执行。',
    cause: '中断链路上任意一环没打通：外设使能、EXTI 线、NVIC、清标志。',
    steps: ['确认外设本身在工作（比如定时器计数在动）', '确认 NVIC 里对应 IRQ 已使能（CubeMX 的 NVIC 标签）', 'EXTI 要确认线映射到正确端口', '在中断入口打断点，看是否进得去', '进去一次就停 → 检查有没有清标志']
  },
  {
    cat: '调试思路',
    q: '串口打印乱码',
    symptom: '串口助手收到一堆乱码。',
    cause: '波特率不匹配，或系统时钟配置和代码里假设的不一致。',
    steps: ['确认串口助手波特率与代码一致（常见 115200）', '确认 CubeMX 里 USART 的时钟源与波特率计算正常', '检查是否是 USB-TTL 的 TX/RX 接反', '先发一个固定字符串测试，排除业务代码问题']
  },
  {
    cat: '调试思路',
    q: '改了参数但现象完全没变',
    symptom: '调了 PSC/ARR 或引脚，波形/亮度纹丝不动。',
    cause: '没重新生成/编译/下载，或改的是另一路通道。',
    steps: ['确认 Keil 里编译并下载成功（看 Build Output 与下载进度）', '按一次复位', '确认改的是当前使用的定时器/通道', '在调试器里直接看寄存器值是否变化']
  },
  {
    cat: 'CubeMX',
    q: 'GPIO 表格里的 User Label 有什么用',
    symptom: '不填也能用，不知道要不要填。',
    cause: 'User Label 会生成宏定义，方便代码里读。',
    steps: ['填 CORE_LED、KEY4 这类名字', '生成后可用 CORE_LED_Pin / CORE_LED_GPIO_Port 宏', '比直接写 GPIO_PIN_0 更不容易写错']
  }
];
