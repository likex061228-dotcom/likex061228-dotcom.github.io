// Pure teaching models: these simulate signals and register behavior, not firmware.
import { simulateDebounce } from './debounce.mjs';
import { edgeTimes } from './edge.mjs';
import { PRIORITY_GROUPS, simulateNvic } from './nvic.mjs';

function bounded(name, value, min, max, integer = false) {
  if (!Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value))) {
    throw new RangeError(`${name} must be ${integer ? 'an integer' : 'finite'} in ${min}..${max}`);
  }
  return value;
}

// A click/long classification is emitted on stable release, never while held.
export function runButton({ pressMs = 260, bounceMs = 9, sampleMs = 10, need = 3, longMs = 800, seed = 7 } = {}) {
  bounded('pressMs', pressMs, 1, 10000);
  bounded('bounceMs', bounceMs, 0, Math.min(100, pressMs));
  bounded('sampleMs', sampleMs, 0.1, 1000);
  bounded('need', need, 1, 100, true);
  bounded('longMs', longMs, 1, 10000);
  bounded('seed', seed, 0, 0xffffffff, true);
  // Leave enough released time for a complete stable-release observation.
  return simulateDebounce({ pressMs, bounceMs, sampleMs, need, longMs, seed,
    releaseGapMs: Math.max(420, sampleMs * (need + 1)) });
}

export function extiSequence({ edge = 'falling', filter = false, bounceMs = 9, pressMs = 260 } = {}) {
  if (!['falling', 'rising', 'both'].includes(edge)) throw new RangeError('edge must be falling, rising, or both');
  if (typeof filter !== 'boolean') throw new RangeError('filter must be boolean');
  const sim = runButton({ bounceMs, pressMs });
  // This is an ideal software-debounced teaching input, not an EXTI hardware filter.
  const points = filter ? sim.samples.map(({ t, stable }) => ({ t, v: stable })) : sim.raw;
  return { points, edges: edgeTimes(points, edge), total: sim.total };
}

export function advanceExti(state = {}, { type, time = 0 } = {}) {
  bounded('time', time, 0, 1e9);
  if (!['edge', 'service', 'clear', 'sync'].includes(type)) throw new RangeError('Unknown EXTI action');
  const next = { pending: state.pending ?? false, callbacks: state.callbacks ?? 0,
    coalesced: state.coalesced ?? 0, enabled: state.enabled ?? true, unmasked: state.unmasked ?? true,
    nvicPending: state.nvicPending ?? false, services: state.services ?? 0 };
  for (const key of ['pending', 'enabled', 'unmasked', 'nvicPending']) {
    if (typeof next[key] !== 'boolean') throw new RangeError(`${key} must be boolean`);
  }
  for (const key of ['callbacks', 'coalesced', 'services']) bounded(key, next[key], 0, Number.MAX_SAFE_INTEGER - 1, true);
  // Sequential two-flag teaching model, excluding active time and entry latency.
  // PR and NVIC pending are separate latched bits, not event queues. NVIC enable
  // controls entry; IMR controls the request into NVIC, not an already latched bit.
  if (next.pending && next.unmasked) next.nvicPending = true;
  if (type === 'edge') {
    if (next.pending) next.coalesced++;
    next.pending = true;
    if (next.unmasked) next.nvicPending = true;
  } else if (type === 'service' && next.enabled && next.nvicPending) {
    next.services++;
    next.nvicPending = false;
    // HAL only calls the callback if its EXTI source flag is still set.
    if (next.pending) {
      next.pending = false;
      next.callbacks++;
    }
  } else if (type === 'clear') next.pending = false;
  return next;
}

export function counterState({ timerHz = 72000000, psc = 71, arr = 999, counts = 0, ccr = 250, polarity = 'high' } = {}) {
  bounded('timerHz', timerHz, 1, 168000000);
  bounded('psc', psc, 0, 65535, true);
  bounded('arr', arr, 0, 65535, true);
  bounded('counts', counts, 0, 1e9, true);
  bounded('ccr', ccr, 0, 65535, true);
  if (!['high', 'low'].includes(polarity)) throw new RangeError('polarity must be high or low');
  const periodCounts = arr + 1;
  const cnt = counts % periodCounts;
  const tickUs = 1e6 * (psc + 1) / timerHz;
  const activeDuty = Math.min(ccr, periodCounts) / periodCounts;
  const highDuty = polarity === 'high' ? activeDuty : 1 - activeDuty;
  // Upcounting PWM mode 1: active exactly while CNT < CCR.
  const active = cnt < ccr;
  // litDuty is low-active LED logical on-time proportion, not calibrated brightness.
  return { cnt, updates: Math.floor(counts / periodCounts), tickUs,
    periodUs: tickUs * periodCounts, frequencyHz: timerHz / ((psc + 1) * periodCounts),
    highDuty, litDuty: 1 - highDuty, pinHigh: polarity === 'high' ? active : !active, periodCounts };
}

export function nvicGrouped(tasks, groupId = 'g2') {
  const group = PRIORITY_GROUPS.find(g => g.id === groupId);
  if (!group) throw new RangeError('groupId must be g0, g1, g2, g3, or g4');
  if (!Array.isArray(tasks)) throw new RangeError('tasks must be an array');
  for (const task of tasks) {
    bounded('preempt', task?.preempt, 0, 2 ** group.preemptBits - 1, true);
    bounded('sub', task?.sub, 0, 2 ** group.subBits - 1, true);
  }
  return { ...simulateNvic(tasks), group: { preemptBits: group.preemptBits, subBits: group.subBits } };
}
