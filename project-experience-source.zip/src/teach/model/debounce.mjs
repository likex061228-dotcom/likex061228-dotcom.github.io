// 按键与软件消抖模型：输入是"物理按键事件"，输出是采样序列与识别结果。
// 约定：按键一端接 GND、MCU 内部上拉 → 松开时读到 1，按下读到 0（低电平有效）。

function lcg(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

// 构造带抖动的一段原始电平：1=松开，0=按下
function buildRaw({ pressAt, pressMs, releaseGapMs, bounceMs, seed }) {
  const rand = lcg(seed);
  const pts = [];
  const start = pressAt;
  const end = start + pressMs;
  pts.push({ t: 0, v: 1 });
  if (start > 0) pts.push({ t: start - 0.001, v: 1 });
  // 按下抖动：在 bounceMs 内随机翻转，最后落到 0
  const steps = Math.max(2, Math.round(bounceMs / 1.5));
  for (let i = 0; i < steps; i++) {
    pts.push({ t: start + (bounceMs * i) / steps, v: rand() < 0.5 ? 0 : 1 });
  }
  pts.push({ t: start + bounceMs, v: 0 });
  pts.push({ t: Math.max(start + bounceMs, end - 0.001), v: 0 });
  // 松开抖动
  for (let i = 0; i < steps; i++) {
    pts.push({ t: end + (bounceMs * i) / steps, v: rand() < 0.5 ? 0 : 1 });
  }
  pts.push({ t: end + bounceMs, v: 1 });
  pts.push({ t: end + bounceMs + releaseGapMs, v: 1 });
  return pts.sort((a, b) => a.t - b.t);
}

function sampleAt(points, t) {
  let v = points[0].v;
  for (const p of points) {
    if (p.t <= t) v = p.v; else break;
  }
  return v;
}

export function simulateDebounce(options = {}) {
  const {
    pressAt = 120,
    pressMs = 260,
    releaseGapMs = 420,
    bounceMs = 9,
    sampleMs = 10,
    need = 3,
    longMs = 800,
    seed = 7
  } = options;

  const points = buildRaw({ pressAt, pressMs, releaseGapMs, bounceMs, seed });
  const total = pressAt + pressMs + bounceMs + releaseGapMs + 40;
  const samples = [];
  let candidate = sampleAt(points, 0);
  let count = 1;
  let stable = candidate;
  let pressStart = null;
  const events = [];

  for (let t = 0; t <= total; t += sampleMs) {
    const raw = sampleAt(points, t);
    if (raw === candidate) count++; else { candidate = raw; count = 1; }
    const before = stable;
    if (count >= need && candidate !== stable) {
      stable = candidate;
      if (stable === 0 && before === 1) {
        pressStart = t;
        events.push({ t, type: 'press' });
      } else if (stable === 1 && before === 0) {
        const held = pressStart === null ? 0 : t - pressStart;
        const type = held >= longMs ? 'long' : 'click';
        events.push({ t, type: 'release', held });
        events.push({ t, type, held });
        pressStart = null;
      }
    }
    samples.push({ t, raw, stable });
  }

  const click = events.find(e => e.type === 'click');
  const long = events.find(e => e.type === 'long');
  return {
    samples, events, total, raw: points, pressAt,
    verdict: long ? '长按' : click ? '单击' : '没识别到完整按键',
    heldMs: click ? click.held : long ? long.held : 0,
    theoryMs: need * sampleMs,
    params: { sampleMs, need, longMs, bounceMs, pressMs, releaseGapMs, pressAt }
  };
}
