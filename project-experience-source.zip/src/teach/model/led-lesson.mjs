// Discrete teaching circuit: VDD -> resistor -> LED -> PC0. No analog voltages/currents.
export const DEFAULT_LED = Object.freeze({clock:true,mode:'output-pp',level:'high',pullup:false,external:'none'});
export function evaluateLed(c){
 if(!c||typeof c.clock!=='boolean'||typeof c.pullup!=='boolean'||!['output-pp','output-od','input'].includes(c.mode)||!['high','low'].includes(c.level)||!['none','high','low'].includes(c.external))throw new Error('不支持的课程电路配置');
 if(!c.clock)return{applied:false,drive:'Z',pad:'UNKNOWN',led:'unknown',odr:null,currentPath:false,reason:'GPIOC时钟未开启，本次初始化与写入步骤不应用；未根据复位/历史状态推断引脚。'};
 const odr=c.level==='high'?1:0;
 const drive=c.mode==='input'||(c.mode==='output-od'&&odr===1)?'Z':odr?'HIGH':'LOW';
 const external=c.external==='none'?'Z':c.external.toUpperCase();
 const conflict=drive!=='Z'&&external!=='Z'&&drive!==external;
 const pad=conflict?'CONFLICT':drive!=='Z'?drive:external!=='Z'?external:c.pullup?'HIGH':'UNKNOWN';
 const led=pad==='LOW'?'on':pad==='HIGH'?'off':'unknown';
 const reason=conflict?'相反的强驱动发生冲突，不能用逻辑值代替电路求解；不要在实物上这样连接。':pad==='UNKNOWN'?'输出级已释放。LED支路不当作可靠的逻辑上拉；本模型不计算漏电、阈值或微亮。':pad==='LOW'?'PC0吸收电流：VDD → 限流电阻 → LED → PC0 → GND。':drive==='HIGH'?'PC0主动输出高电平，LED支路没有点亮所需的压差。':'外部上拉使释放的引脚为高；LED不点亮。';
 return{applied:true,drive,pad,led,odr,currentPath:led==='on',reason};
}
export const FAULTS=[
 {id:'clock',name:'初始化没有生效',config:{...DEFAULT_LED,clock:false,level:'low'},check:'clock',evidence:'初始化代码缺少 __HAL_RCC_GPIOC_CLK_ENABLE()。只修改输出值不能补上外设时钟。',repaired:{...DEFAULT_LED,level:'low'}},
 {id:'mode',name:'写了0，灯仍没有确定状态',config:{...DEFAULT_LED,mode:'input',level:'low'},check:'mode',evidence:'CRL[3:0]=0100，MODE=00，PC0是浮空输入；ODR为0不代表输出级在拉低。',repaired:{...DEFAULT_LED,level:'low'}},
 {id:'polarity',name:'程序写1，灯没有亮',config:{...DEFAULT_LED,level:'high'},check:'path',evidence:'教学接法的LED负极接PC0。输出高时没有点亮压差，应输出低让电流流入引脚。',repaired:{...DEFAULT_LED,level:'low'}}
];
export function diagnoseFault(id,check){const fault=FAULTS.find(f=>f.id===id);if(!fault)throw new Error('未知练习');return{correct:check===fault.check,evidence:check===fault.check?fault.evidence:'这个检查还不能解释当前故障。对照初始化代码、CRL的MODE位和LED接法，再选一个依据。'};}
