// 定时器与 PWM 纯模型。所有结果都可由手册公式复算：
//   f_PWM  = f_TIM / ((PSC+1) * (ARR+1))
//   duty   = CCR / (ARR+1)          （PWM 模式 1，CCR<=ARR 时）
// 定时器的计数时钟不一定等于 APB 时钟：F1/F4 在 APB 预分频≠1 时，定时器时钟是 APB 时钟的 2 倍。
// 这里直接使用芯片数据里的 timApb1 / timApb2，避免新人在这里算错。

export function timerClock(chip, bus = 'APB1') {
  return bus === 'APB2' ? chip.clock.timApb2 : chip.clock.timApb1;
}

export function pwm(chip, { psc, arr, ccr, bus = 'APB1' }) {
  const clk = timerClock(chip, bus);
  const p = Math.max(0, Math.round(psc));
  const a = Math.max(0, Math.round(arr));
  const c = Math.max(0, Math.round(ccr));
  const prescaler = p + 1;
  const periodTicks = a + 1;
  const freq = clk / (prescaler * periodTicks);
  const duty = periodTicks <= 1 ? (c >= 1 ? 1 : 0) : Math.min(c, periodTicks) / periodTicks;
  return {
    clockHz: clk,
    freqHz: freq,
    periodUs: 1e6 / freq,
    duty,
    dutyPercent: duty * 100,
    tickUs: (1e6 * prescaler) / clk,
    periodTicks,
    prescaler,
    overflow: c > a,
    interruptHz: freq
  };
}

// 呼吸灯不需要改电压，只需要改占空比；这里把占空比换算成 0–100 的亮度百分比
export function brightness(duty) {
  return Math.round(Math.max(0, Math.min(1, duty)) * 100);
}

export function fmtFreq(hz) {
  if (hz >= 1000) return (hz / 1000).toFixed(hz >= 10000 ? 1 : 3).replace(/\.?0+$/, '') + ' kHz';
  return hz.toFixed(2).replace(/\.?0+$/, '') + ' Hz';
}

export function fmtUs(us) {
  if (us >= 1000) return (us / 1000).toFixed(3).replace(/\.?0+$/, '') + ' ms';
  return us.toFixed(2).replace(/\.?0+$/, '') + ' µs';
}
