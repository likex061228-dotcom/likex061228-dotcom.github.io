// printf 单个占位符的格式化模型（教学用，覆盖常用子集）。
// 支持：%[-][0][宽度][.精度]{d i u x X f c s %}；与 C 的行为对齐：默认右对齐、零填充只对数字、left 时忽略零填充。

const SPEC = /^%(-)?(0)?(\d+)?(?:\.(\d+))?([diuxXfcs%])$/;

export function parseSpec(spec) {
  const m = SPEC.exec(String(spec).trim());
  if (!m) return null;
  return {
    left: m[1] === '-',
    zero: m[2] === '0',
    width: m[3] ? Number(m[3]) : 0,
    precision: m[4] !== undefined ? Number(m[4]) : null,
    conv: m[5]
  };
}

function pad(text, spec) {
  if (!spec.width || text.length >= spec.width) return text;
  const fill = spec.zero && !spec.left && 'difu'.includes(spec.conv) ? '0' : ' ';
  const need = spec.width - text.length;
  if (spec.left) return text + ' '.repeat(need);
  if (fill === '0' && /^[+-]/.test(text)) return text[0] + '0'.repeat(need) + text.slice(1);
  return fill.repeat(need) + text;
}

export function formatOne(specText, rawValue) {
  const spec = parseSpec(specText);
  if (!spec) {
    return { ok: false, error: '只支持 %d %i %u %x %X %f %c %s %% 这几种，格式形如 %8.3f、%-5d、%05d。' };
  }
  const conv = spec.conv;
  if (conv === '%') return { ok: true, output: pad('%', spec), note: '输出一个百分号本身' };

  const value = String(rawValue ?? '');
  let body;
  try {
    if (conv === 's') {
      body = value;
    } else if (conv === 'c') {
      const code = Number(value);
      body = Number.isFinite(code) && value.trim() !== '' ? String.fromCharCode(code) : value.charAt(0);
    } else if (conv === 'f') {
      const n = Number(value);
      if (!Number.isFinite(n)) throw new Error('不是数字');
      body = n.toFixed(spec.precision === null ? 6 : spec.precision);
    } else if (conv === 'x' || conv === 'X') {
      const n = Math.trunc(Number(value));
      if (!Number.isFinite(n)) throw new Error('不是数字');
      body = (n >>> 0).toString(16);
      if (conv === 'X') body = body.toUpperCase();
    } else {
      const n = Math.trunc(Number(value));
      if (!Number.isFinite(n)) throw new Error('不是数字');
      body = String(n);
    }
  } catch (e) {
    return { ok: false, error: '这个值不能按该占位符输出：' + e.message };
  }

  const output = pad(body, spec);
  const parts = [];
  if (spec.width) parts.push('总宽 ' + spec.width);
  if (spec.left) parts.push('左对齐');
  if (spec.zero) parts.push('零填充');
  if (spec.precision !== null) parts.push((conv === 'f' ? '保留 ' : '至少 ') + spec.precision + (conv === 'f' ? ' 位小数' : ' 个字符'));
  return { ok: true, output, note: parts.length ? parts.join(' · ') : '没有宽度和精度修饰' };
}

export const FORMAT_PRESETS = ['%d', '%5d', '%-5d', '%05d', '%8.3f', '%.2f', '%x', '%c', '%s', '%%'];
