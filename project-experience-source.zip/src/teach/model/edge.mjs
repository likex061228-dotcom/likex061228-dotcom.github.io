// 边沿检测：用于 EXTI 章节。抖动会让一次按下产生多次边沿，这正是"按一下进好几次中断"的原因。
import { simulateDebounce } from './debounce.mjs';

export function countEdges(points, type = 'falling') {
  let count = 0;
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1].v, b = points[i].v;
    if (type === 'falling' && a === 1 && b === 0) count++;
    if (type === 'rising' && a === 0 && b === 1) count++;
    if (type === 'both' && a !== b) count++;
  }
  return count;
}

export function edgeTimes(points, type = 'falling') {
  const out = [];
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1].v, b = points[i].v;
    if ((type === 'falling' && a === 1 && b === 0) || (type === 'rising' && a === 0 && b === 1) || (type === 'both' && a !== b)) {
      out.push(points[i].t);
    }
  }
  return out;
}

export function simulateExti({ bounceMs = 9, pressMs = 260, edge = 'falling', debounce = false, sampleMs = 10, need = 3, seed = 7 }) {
  const sim = simulateDebounce({ bounceMs, pressMs, sampleMs, need, seed, pressAt: 140, releaseGapMs: 420 });
  const source = debounce ? sim.samples.map(s => ({ t: s.t, v: s.stable })) : sim.raw;
  return {
    raw: sim.raw,
    stable: sim.samples.map(s => ({ t: s.t, v: s.stable })),
    isrCount: countEdges(source, edge),
    isrTimes: edgeTimes(source, edge),
    edge,
    debounce,
    total: sim.total
  };
}
