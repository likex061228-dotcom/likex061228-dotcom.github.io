// NVIC 抢占模型：按 Cortex-M 的规则算出中断执行时间轴。
// 规则：抢占优先级更高的可以打断正在执行的；抢占优先级相同时不嵌套，
// 挂起中断按子优先级、IRQ 编号仲裁；未提供 IRQ 时按 id 确定顺序（教学约定，并非硬件 FIFO）。

export const PRIORITY_GROUPS = [
  { id: 'g4', label: '4 位全部给抢占（0 位子优先级）', preemptBits: 4, subBits: 0 },
  { id: 'g3', label: '3 位抢占 + 1 位子优先级', preemptBits: 3, subBits: 1 },
  { id: 'g2', label: '2 位抢占 + 2 位子优先级', preemptBits: 2, subBits: 2 },
  { id: 'g1', label: '1 位抢占 + 3 位子优先级', preemptBits: 1, subBits: 3 },
  { id: 'g0', label: '0 位抢占 + 4 位子优先级（完全不平抢）', preemptBits: 0, subBits: 4 }
];

export function normalizePriority(raw, group) {
  const max = Math.pow(2, group.preemptBits) - 1;
  const p = Math.max(0, Math.min(max, Math.round(raw)));
  return p;
}

// tasks: [{id,name,preempt,sub,arrive,duration}]
export function simulateNvic(tasks) {
  // 教学模型最多 1000 个单次中断，时间以非负整数刻度表示，总时间不得超过 1e9。
  // 不模拟入口/退出开销、尾链或同一 IRQ 重入；输入须有唯一字符串 id。
  if (!Array.isArray(tasks) || tasks.length > 1000) throw new RangeError('Expected at most 1000 tasks');
  const ids = new Set();
  let total = 0, latest = 0;
  for (const task of tasks) {
    if (!task || typeof task.id !== 'string' || !task.id || ids.has(task.id)
      || typeof task.name !== 'string'
      || !Number.isSafeInteger(task.arrive) || task.arrive < 0
      || !Number.isSafeInteger(task.duration) || task.duration <= 0
      || !Number.isInteger(task.preempt) || task.preempt < 0 || task.preempt > 15
      || !Number.isInteger(task.sub) || task.sub < 0 || task.sub > 15
      || (task.irq !== undefined && (!Number.isInteger(task.irq) || task.irq < 0 || task.irq > 239))) {
      throw new RangeError('Invalid interrupt task');
    }
    ids.add(task.id);
    total += task.duration;
    latest = Math.max(latest, task.arrive);
  }
  if (latest + total > 1e9) throw new RangeError('Simulation time exceeds 1e9');
  const compare = (a, b) => a.preempt - b.preempt || a.sub - b.sub
    || (a.irq ?? Infinity) - (b.irq ?? Infinity)
    || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  const pending = tasks.map(task => ({ ...task, remaining: task.duration }))
    .sort((a, b) => a.arrive - b.arrive || compare(a, b));
  const timeline = [], events = [], queue = [], suspended = [];
  let current = null, next = 0, t = 0, segmentStart = 0;
  const start = task => {
    current = task;
    segmentStart = t;
    events.push({ t, type: 'start', name: task.name });
  };
  while (next < pending.length || queue.length || suspended.length || current) {
    if (!current && !queue.length && !suspended.length) t = pending[next].arrive;
    // 先汇集同一时刻全部到达，再仲裁，避免零时长的假抢占。
    while (next < pending.length && pending[next].arrive <= t) {
      const incoming = pending[next++];
      queue.push(incoming);
      events.push({ t, type: 'queue', name: incoming.name });
    }
    queue.sort(compare);
    if (!current) {
      const resume = suspended[suspended.length - 1];
      // 已激活的处理程序不能被相同抢占级的挂起中断打断。
      start(resume && (!queue.length || resume.preempt <= queue[0].preempt)
        ? suspended.pop() : queue.shift());
    } else if (queue.length && queue[0].preempt < current.preempt) {
      timeline.push({ id: current.id, name: current.name, start: segmentStart, end: t, preempted: true });
      events.push({ t, type: 'preempt', name: current.name, by: queue[0].name });
      suspended.push(current);
      start(queue.shift());
    }
    const finishAt = t + current.remaining;
    const nextArrival = next < pending.length ? pending[next].arrive : Infinity;
    if (nextArrival < finishAt) {
      current.remaining -= nextArrival - t;
      t = nextArrival;
    } else {
      timeline.push({ id: current.id, name: current.name, start: segmentStart, end: finishAt, preempted: false });
      events.push({ t: finishAt, type: 'finish', name: current.name });
      t = finishAt;
      current = null;
    }
  }

  const latency = tasks.map(task => {
    const segs = timeline.filter(seg => seg.id === task.id);
    const first = segs[0];
    const last = segs[segs.length - 1];
    return {
      id: task.id,
      name: task.name,
      latency: first ? first.start - task.arrive : null,
      completion: last ? last.end : null,
      preempted: segs.filter(s => s.preempted).length
    };
  });

  return {
    timeline,
    events,
    latency,
    end: t,
    preemptions: events.filter(e => e.type === 'preempt').length
  };
}

// 教学用固定场景：三个中断同时或先后到达
export function scenario({ preempt = [2, 1, 0], sub = [0, 0, 0] } = {}) {
  return [
    { id: 'tim', name: 'TIM2 更新中断', preempt: preempt[0], sub: sub[0], arrive: 0, duration: 6 },
    { id: 'exti', name: 'EXTI0 按键中断', preempt: preempt[1], sub: sub[1], arrive: 2, duration: 4 },
    { id: 'usart', name: 'USART1 接收中断', preempt: preempt[2], sub: sub[2], arrive: 3, duration: 3 }
  ];
}
