// NVIC 抢占模型：按 Cortex-M 的规则算出中断执行时间轴。
// 规则：抢占优先级更高的可以打断正在执行的；抢占优先级相同时不嵌套，
// 只按子优先级排队（子优先级相同则先到先执行）。

export const PRIORITY_GROUPS = [
  { id: 'g4', label: '4 位全部给抢占（0 位子优先级）', preemptBits: 4, subBits: 0 },
  { id: 'g3', label: '3 位抢占 + 1 位子优先级', preemptBits: 3, subBits: 1 },
  { id: 'g2', label: '2 位抢占 + 2 位子优先级', preemptBits: 2, subBits: 2 },
  { id: 'g1', label: '1 位抢占 + 3 位子优先级', preemptBits: 1, subBits: 3 },
  { id: 'g0', label: '0 位抢占 + 4 位子优先级（完全不平抢）', preemptBits: 0, subBits: 4 }
];

export function normalizePriority(raw, group) {
  const max = Math.pow(2, group.preemptBits) - 1;
  const p = Math.max(0, Math.min(max, Math.round(raw)));
  return p;
}

// tasks: [{id,name,preempt,sub,arrive,duration}]
export function simulateNvic(tasks) {
  const pending = [...tasks].sort((a, b) => a.arrive - b.arrive || b.preempt - a.preempt);
  const timeline = [];
  const queue = [];
  let current = null;
  let next = 0;
  let t = 0;
  const events = [];
  let guard = 0;

  while ((next < pending.length || queue.length || current) && guard++ < 500) {
    const nextArrival = next < pending.length ? pending[next].arrive : Infinity;

    if (!current) {
      if (queue.length) {
        queue.sort((a, b) => a.preempt - b.preempt || a.sub - b.sub || a.arrive - b.arrive);
        current = queue.shift();
        t = Math.max(t, current.arrive);
        events.push({ t, type: 'start', name: current.name });
        continue;
      }
      if (next < pending.length) {
        t = Math.max(t, pending[next].arrive);
        current = { ...pending[next], remaining: pending[next].duration };
        events.push({ t, type: 'start', name: current.name });
        next++;
        continue;
      }
      break;
    }

    const finishAt = t + current.remaining;
    if (nextArrival < finishAt) {
      const incoming = pending[next];
      if (incoming.preempt < current.preempt) {
        timeline.push({ id: current.id, name: current.name, start: t, end: nextArrival, preempted: true });
        events.push({ t: nextArrival, type: 'preempt', name: current.name, by: incoming.name });
        current.remaining -= nextArrival - t;
        queue.push(current);
        current = { ...incoming, remaining: incoming.duration };
        t = nextArrival;
        next++;
        events.push({ t, type: 'start', name: current.name });
      } else {
        queue.push({ ...incoming });
        next++;
        events.push({ t: incoming.arrive, type: 'queue', name: incoming.name });
        // 循环会重新计算 finishAt：没有新到达就继续执行到完成
        continue;
      }
    } else {
      timeline.push({ id: current.id, name: current.name, start: t, end: finishAt, preempted: false });
      events.push({ t: finishAt, type: 'finish', name: current.name });
      t = finishAt;
      current = null;
    }
  }

  const latency = tasks.map(task => {
    const segs = timeline.filter(seg => seg.id === task.id);
    const first = segs[0];
    const last = segs[segs.length - 1];
    return {
      id: task.id,
      name: task.name,
      latency: first ? first.start - task.arrive : null,
      completion: last ? last.end : null,
      preempted: segs.filter(s => s.preempted).length
    };
  });

  return {
    timeline,
    events,
    latency,
    end: t,
    preemptions: events.filter(e => e.type === 'preempt').length
  };
}

// 教学用固定场景：三个中断同时或先后到达
export function scenario({ preempt = [2, 1, 0], sub = [0, 0, 0] } = {}) {
  return [
    { id: 'tim', name: 'TIM2 更新中断', preempt: preempt[0], sub: sub[0], arrive: 0, duration: 6 },
    { id: 'exti', name: 'EXTI0 按键中断', preempt: preempt[1], sub: sub[1], arrive: 2, duration: 4 },
    { id: 'usart', name: 'USART1 接收中断', preempt: preempt[2], sub: sub[2], arrive: 3, duration: 3 }
  ];
}
