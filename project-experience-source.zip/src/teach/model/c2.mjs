// C 语言第二课的纯模型：排序步骤、递归调用栈、字符串表示。全部可单测。

const clone = a => a.slice();

/* ---------------- 排序步骤 ---------------- */
export function bubbleSteps(input) {
  const a = clone(input), steps = [];
  let comparisons = 0, swaps = 0;
  const n = a.length;
  steps.push({ arr: clone(a), highlight: [], kind: 'start', note: '开始：相邻两个比较，大的往后换' });
  for (let i = 0; i < n - 1; i++) {
    let swapped = false;
    for (let j = 0; j < n - 1 - i; j++) {
      comparisons++;
      steps.push({ arr: clone(a), highlight: [j, j + 1], kind: 'compare', note: `比较 a[${j}]=${a[j]} 与 a[${j + 1}]=${a[j + 1]}` });
      if (a[j] > a[j + 1]) {
        [a[j], a[j + 1]] = [a[j + 1], a[j]];
        swaps++;
        swapped = true;
        steps.push({ arr: clone(a), highlight: [j, j + 1], kind: 'swap', note: `交换，把较大的 ${a[j + 1]} 往右移` });
      }
    }
    steps.push({ arr: clone(a), highlight: [], kind: 'round', note: `第 ${i + 1} 轮结束：末尾 ${i + 1} 个已就位`, sortedTail: i + 1 });
    if (!swapped) { steps.push({ arr: clone(a), highlight: [], kind: 'early', note: '本轮没有发生交换，提前结束' }); break; }
  }
  return { steps, result: clone(a), comparisons, swaps };
}

export function selectionSteps(input) {
  const a = clone(input), steps = [];
  let comparisons = 0, swaps = 0;
  const n = a.length;
  steps.push({ arr: clone(a), highlight: [], kind: 'start', note: '开始：每轮找最小值，放到前面' });
  for (let i = 0; i < n - 1; i++) {
    let minIdx = i;
    for (let j = i + 1; j < n; j++) {
      comparisons++;
      steps.push({ arr: clone(a), highlight: [minIdx, j], kind: 'compare', note: `a[${j}]=${a[j]} 与当前最小 a[${minIdx}]=${a[minIdx]} 比较` });
      if (a[j] < a[minIdx]) minIdx = j;
    }
    if (minIdx !== i) {
      [a[i], a[minIdx]] = [a[minIdx], a[i]];
      swaps++;
      steps.push({ arr: clone(a), highlight: [i, minIdx], kind: 'swap', note: `把最小值 ${a[i]} 换到第 ${i} 位` });
    }
    steps.push({ arr: clone(a), highlight: [], kind: 'round', note: `第 ${i + 1} 轮结束：前 ${i + 1} 个已就位`, sortedHead: i + 1 });
  }
  return { steps, result: clone(a), comparisons, swaps };
}

export function insertionSteps(input) {
  const a = clone(input), steps = [];
  let comparisons = 0, shifts = 0;
  const n = a.length;
  steps.push({ arr: clone(a), highlight: [], kind: 'start', note: '开始：把左边看成已排好，右边逐个插入' });
  for (let i = 1; i < n; i++) {
    const key = a[i];
    let j = i - 1;
    steps.push({ arr: clone(a), highlight: [i], kind: 'pick', note: `取出 a[${i}]=${key}，准备插入左边` });
    while (j >= 0) {
      comparisons++;
      steps.push({ arr: clone(a), highlight: [j, j + 1], kind: 'compare', note: `a[${j}]=${a[j]} 与待插入值 ${key} 比较` });
      if (a[j] <= key) break;
      a[j + 1] = a[j];
      shifts++;
      steps.push({ arr: clone(a), highlight: [j, j + 1], kind: 'shift', note: `${a[j]} 比 ${key} 大，往后挪一位` });
      j--;
    }
    a[j + 1] = key;
    steps.push({ arr: clone(a), highlight: [j + 1], kind: 'place', note: `把 ${key} 放到第 ${j + 1} 位` });
  }
  return { steps, result: clone(a), comparisons, shifts };
}

/* ---------------- 递归调用栈 ---------------- */
export function factTrace(n) {
  const steps = [];
  let result = 1;
  const stack = [];
  const snap = () => stack.map(f => ({ arg: f.arg, value: f.value }));

  function rec(k) {
    stack.push({ arg: k, value: null });
    steps.push({ stack: snap(), note: `调用 fact(${k})，等待返回` });
    if (k === 0) {
      stack[stack.length - 1].value = 1;
      steps.push({ stack: snap(), note: '到达终止条件：fact(0) = 1' });
      const v = 1;
      stack.pop();
      return v;
    }
    const sub = rec(k - 1);
    const v = sub * k;
    stack[stack.length - 1].value = v;
    steps.push({ stack: snap(), note: `fact(${k}) = ${sub} × ${k} = ${v}` });
    if (k === n) result = v;
    stack.pop();
    return v;
  }
  rec(n);
  steps.push({ stack: [], note: '全部返回，fact(' + n + ') = ' + result });
  return { steps, result, depth: n + 1 };
}

/* ---------------- 字符串 ---------------- */
export function stringCells(text) {
  const chars = Array.from(String(text));
  return [
    ...chars.map((ch, i) => ({ index: i, ch, terminator: false })),
    { index: chars.length, ch: '\\0', terminator: true }
  ];
}

export function manualStrlen(text) {
  let n = 0;
  while (n < String(text).length) n++;
  return n;
}

export function compareStrings(a, b) {
  const x = String(a), y = String(b);
  const len = Math.min(x.length, y.length);
  for (let i = 0; i < len; i++) {
    if (x.charCodeAt(i) !== y.charCodeAt(i)) return x.charCodeAt(i) - y.charCodeAt(i);
  }
  return x.length - y.length;
}

/* ---------------- 数组基本信息 ---------------- */
export function arrayFacts(values, typeBytes = 4) {
  return {
    length: values.length,
    totalBytes: values.length * typeBytes,
    lastIndex: values.length - 1,
    sizeofArray: values.length * typeBytes,
    sizeofElement: typeBytes,
    pointerBytes: 8
  };
}
