// C 语言第二课的纯模型：排序步骤（带行号与变量）、递归调用栈、字符串遍历。全部可单测。

const clone = a => a.slice();

const BUBBLE_CODE = [
  'for (int i = 0; i < n - 1; i++) {',
  '    for (int j = 0; j < n - 1 - i; j++) {',
  '        if (a[j] > a[j + 1]) {',
  '            int t = a[j];',
  '            a[j] = a[j + 1];',
  '            a[j + 1] = t;',
  '        }',
  '    }',
  '}'
];

const SELECTION_CODE = [
  'for (int i = 0; i < n - 1; i++) {',
  '    int min = i;',
  '    for (int j = i + 1; j < n; j++) {',
  '        if (a[j] < a[min]) {',
  '            min = j;',
  '        }',
  '    }',
  '    if (min != i) {',
  '        int t = a[i]; a[i] = a[min]; a[min] = t;',
  '    }',
  '}'
];

const INSERTION_CODE = [
  'for (int i = 1; i < n; i++) {',
  '    int key = a[i];',
  '    int j = i - 1;',
  '    while (j >= 0 && a[j] > key) {',
  '        a[j + 1] = a[j];',
  '        j--;',
  '    }',
  '    a[j + 1] = key;',
  '}'
];

/* ---------------- 排序步骤 ---------------- */
export function bubbleSteps(input) {
  const a = clone(input), steps = [];
  let comparisons = 0, swaps = 0;
  const n = a.length;
  const push = (line, vars, note, kind = 'line', highlight = []) =>
    steps.push({ arr: clone(a), highlight, kind, line, vars, note });

  push(0, { n, i: '—', j: '—' }, '开始：i 从 0 到 n-2，每轮把最大值送到末尾');
  for (let i = 0; i < n - 1; i++) {
    push(0, { n, i, j: '—' }, `外层第 ${i + 1} 轮：还没排序的部分是 a[0..${n - 1 - i}]`);
    let swapped = false;
    for (let j = 0; j < n - 1 - i; j++) {
      comparisons++;
      push(2, { n, i, j, 'a[j]': a[j], 'a[j+1]': a[j + 1] }, `比较 a[${j}]=${a[j]} 与 a[${j + 1}]=${a[j + 1]}`, 'compare', [j, j + 1]);
      if (a[j] > a[j + 1]) {
        const left = a[j];
        push(3, { n, i, j, t: left }, `前一个更大：先保存到临时变量 t = ${left}`, 'temp', [j, j + 1]);
        a[j] = a[j + 1];
        push(4, { n, i, j, t: left, 'a[j]': a[j] }, `a[${j}] = ${a[j]}（覆盖原来的 ${left}）`, 'swap', [j, j + 1]);
        a[j + 1] = left;
        swaps++;
        swapped = true;
        push(5, { n, i, j, t: left, 'a[j+1]': a[j + 1] }, `a[${j + 1}] = t = ${left}，完成交换`, 'swap', [j, j + 1]);
      }
    }
    push(0, { n, i, j: '—' }, `第 ${i + 1} 轮结束：a[${n - i - 1}] 已就位`, 'round');
    if (!swapped) { push(0, { n, i, j: '—' }, '本轮一次交换都没有，数组已有序，提前结束', 'early'); break; }
  }
  push(8, { n, i: '—', j: '—' }, '排序完成');
  return { steps, result: clone(a), comparisons, swaps, code: BUBBLE_CODE };
}

export function selectionSteps(input) {
  const a = clone(input), steps = [];
  let comparisons = 0, swaps = 0;
  const n = a.length;
  const push = (line, vars, note, kind = 'line', highlight = []) =>
    steps.push({ arr: clone(a), highlight, kind, line, vars, note });

  push(0, { n, i: '—', min: '—' }, '开始：每轮从未排序部分找最小值');
  for (let i = 0; i < n - 1; i++) {
    let minIdx = i;
    push(1, { n, i, min: i }, `假设本轮最小值是 a[${i}]=${a[i]}`);
    for (let j = i + 1; j < n; j++) {
      comparisons++;
      push(3, { n, i, j, min: minIdx, 'a[j]': a[j], 'a[min]': a[minIdx] }, `比较 a[${j}]=${a[j]} 与 a[${minIdx}]=${a[minIdx]}`, 'compare', [minIdx, j]);
      if (a[j] < a[minIdx]) {
        minIdx = j;
        push(4, { n, i, j, min: minIdx }, `更小，记下 min = ${minIdx}`, 'mark', [minIdx]);
      }
    }
    if (minIdx !== i) {
      const left = a[i];
      push(8, { n, i, min: minIdx, t: left }, `最小值在 a[${minIdx}]，与本轮起点交换`, 'temp', [i, minIdx]);
      a[i] = a[minIdx];
      a[minIdx] = left;
      swaps++;
      push(8, { n, i, min: minIdx }, `交换后 a[${i}]=${a[i]}`, 'swap', [i, minIdx]);
    }
    push(0, { n, i, min: minIdx }, `第 ${i + 1} 轮结束：前 ${i + 1} 个已就位`, 'round');
  }
  push(10, { n, i: '—', min: '—' }, '排序完成');
  return { steps, result: clone(a), comparisons, swaps, code: SELECTION_CODE };
}

export function insertionSteps(input) {
  const a = clone(input), steps = [];
  let comparisons = 0, shifts = 0;
  const n = a.length;
  const push = (line, vars, note, kind = 'line', highlight = []) =>
    steps.push({ arr: clone(a), highlight, kind, line, vars, note });

  push(0, { n, i: '—', key: '—', j: '—' }, '开始：把左边看成已排好，右边元素逐个插入');
  for (let i = 1; i < n; i++) {
    const key = a[i];
    push(1, { n, i, key, j: '—' }, `取出 a[${i}] = ${key}，准备插入左边`);
    let j = i - 1;
    push(2, { n, i, key, j }, `从 j = ${j} 开始往前比较`);
    while (j >= 0) {
      comparisons++;
      push(3, { n, i, key, j, 'a[j]': a[j] }, `比较 a[${j}]=${a[j]} 与 key=${key}`, 'compare', [j]);
      if (a[j] <= key) break;
      a[j + 1] = a[j];
      shifts++;
      push(4, { n, i, key, j }, `${a[j]} > ${key}：把 a[${j}] 往后挪到 a[${j + 1}]`, 'shift', [j, j + 1]);
      j--;
      push(5, { n, i, key, j }, `j 减到 ${j}`);
    }
    a[j + 1] = key;
    push(7, { n, i, key, j }, `找到位置：把 ${key} 放进 a[${j + 1}]`, 'place', [j + 1]);
  }
  push(8, { n, i: '—', key: '—', j: '—' }, '排序完成');
  return { steps, result: clone(a), comparisons, shifts, code: INSERTION_CODE };
}

/* ---------------- 递归调用栈 ---------------- */
const FACT_CODE = [
  'int fact(int n) {',
  '    if (n == 0) return 1;      /* 终止条件 */',
  '    return fact(n - 1) * n;    /* 递归关系 */',
  '}'
];

export function factTrace(n) {
  const steps = [];
  let result = 1;
  const stack = [];
  const snap = () => stack.map(f => ({ arg: f.arg, value: f.value }));

  function rec(k) {
    stack.push({ arg: k, value: null });
    steps.push({ line: 0, stack: snap(), note: `调用 fact(${k})，压入一层栈` });
    if (k === 0) {
      stack[stack.length - 1].value = 1;
      steps.push({ line: 1, stack: snap(), note: 'n == 0，终止条件命中：返回 1' });
      stack.pop();
      return 1;
    }
    const sub = rec(k - 1);
    const v = sub * k;
    stack[stack.length - 1].value = v;
    steps.push({ line: 2, stack: snap(), note: `收到 fact(${k - 1}) = ${sub}，乘 k=${k} 得到 ${v}` });
    if (k === n) result = v;
    stack.pop();
    return v;
  }
  rec(n);
  steps.push({ line: 3, stack: [], note: `全部返回，fact(${n}) = ${result}` });
  return { steps, result, depth: n + 1, code: FACT_CODE };
}

/* ---------------- 字符串 ---------------- */
const STRLEN_CODE = [
  'int str_len(const char *s) {',
  '    int len = 0;',
  '    while (s[len] != \'\\0\') {',
  '        len++;',
  '    }',
  '    return len;',
  '}'
];

export function strlenTrace(text) {
  const chars = Array.from(String(text));
  const steps = [{ line: 1, len: 0, note: 'len 初始化为 0', done: false }];
  let len = 0;
  while (len < chars.length) {
    steps.push({ line: 2, len, ch: chars[len], note: `检查 s[${len}] = '${chars[len]}'，不是 '\\0'`, done: false });
    len++;
    steps.push({ line: 3, len, note: `len++ → ${len}`, done: false });
  }
  steps.push({ line: 2, len, ch: '\\0', note: `检查 s[${len}] = '\\0'，循环结束`, done: false });
  steps.push({ line: 5, len, note: `返回 ${len}（不包含终止符）`, done: true });
  return { steps, length: len, code: STRLEN_CODE };
}

export function stringCells(text) {
  const chars = Array.from(String(text));
  return [
    ...chars.map((ch, i) => ({ index: i, ch, terminator: false })),
    { index: chars.length, ch: '\\0', terminator: true }
  ];
}

export function manualStrlen(text) {
  return Array.from(String(text)).length;
}

export function compareStrings(a, b) {
  const x = String(a), y = String(b);
  const len = Math.min(x.length, y.length);
  for (let i = 0; i < len; i++) {
    if (x.charCodeAt(i) !== y.charCodeAt(i)) return x.charCodeAt(i) - y.charCodeAt(i);
  }
  return x.length - y.length;
}

/* ---------------- 数组基本信息 ---------------- */
export function arrayFacts(values, typeBytes = 4) {
  return {
    length: values.length,
    totalBytes: values.length * typeBytes,
    lastIndex: values.length - 1,
    sizeofArray: values.length * typeBytes,
    sizeofElement: typeBytes,
    pointerBytes: 8
  };
}
