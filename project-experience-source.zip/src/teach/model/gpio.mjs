// GPIO 纯模型：配置 → 寄存器位 → 引脚电平。不依赖 DOM，可直接单测。
// F1 用 CRL/CRH（每脚 4 位：CNF[1:0] + MODE[1:0]）；F4 用 MODER/PUPDR/OTYPER/OSPEEDR（每脚 2/1/2/2 位）。

export const MODES = [
  { id: 'output-pp', label: '推挽输出', hal: 'GPIO_MODE_OUTPUT_PP' },
  { id: 'output-od', label: '开漏输出', hal: 'GPIO_MODE_OUTPUT_OD' },
  { id: 'input', label: '输入', hal: 'GPIO_MODE_INPUT' },
  { id: 'analog', label: '模拟输入', hal: 'GPIO_MODE_ANALOG' },
  { id: 'af-pp', label: '复用推挽', hal: 'GPIO_MODE_AF_PP' }
];

export const PULLS = [
  { id: 'none', label: '无上下拉', hal: 'GPIO_NOPULL' },
  { id: 'up', label: '上拉', hal: 'GPIO_PULLUP' },
  { id: 'down', label: '下拉', hal: 'GPIO_PULLDOWN' }
];

export const SPEEDS = [
  { id: 'low', label: '低速', hal: 'GPIO_SPEED_FREQ_LOW', f1Mode: 0b10, f4Code: 0b00, mhz: 2 },
  { id: 'medium', label: '中速', hal: 'GPIO_SPEED_FREQ_MEDIUM', f1Mode: 0b01, f4Code: 0b01, mhz: 10 },
  { id: 'high', label: '高速', hal: 'GPIO_SPEED_FREQ_HIGH', f1Mode: 0b11, f4Code: 0b10, mhz: 50 }
];

export const DEFAULT_CONFIG = { mode: 'output-pp', pull: 'none', speed: 'low', level: 'high' };

const byId = (list, id) => list.find(item => item.id === id) || list[0];
export const modeOf = id => byId(MODES, id);
export const pullOf = id => byId(PULLS, id);
export const speedOf = id => byId(SPEEDS, id);

// F1：CNF[1:0] + MODE[1:0]，输入时 MODE=00
export function f1Nibble(cfg) {
  const mode = modeOf(cfg.mode), speed = speedOf(cfg.speed);
  if (cfg.mode === 'input') {
    const cnf = cfg.pull === 'none' ? 0b01 : 0b10;   // 01 浮空输入，10 上下拉输入（上/下由 ODR 决定）
    return { cnf, modeBits: 0b00, nibble: (cnf << 2) | 0b00 };
  }
  if (cfg.mode === 'analog') return { cnf: 0b00, modeBits: 0b00, nibble: 0b0000 };
  const cnf = cfg.mode === 'output-pp' ? 0b00 : cfg.mode === 'output-od' ? 0b01 : 0b10;
  return { cnf, modeBits: speed.f1Mode, nibble: (cnf << 2) | speed.f1Mode };
}

// F4：MODER / OTYPER / OSPEEDR / PUPDR
export function f4Bits(cfg) {
  const moder = cfg.mode === 'input' ? 0b00 : cfg.mode === 'analog' ? 0b11 : cfg.mode === 'af-pp' ? 0b10 : 0b01;
  const otyper = cfg.mode === 'output-od' ? 1 : 0;
  const ospeedr = speedOf(cfg.speed).f4Code;
  const pupdr = cfg.mode === 'input' ? (cfg.pull === 'up' ? 0b01 : cfg.pull === 'down' ? 0b10 : 0b00) : 0b00;
  return { moder, otyper, ospeedr, pupdr };
}

const hex = (value, width = 8) => '0x' + (value >>> 0).toString(16).toUpperCase().padStart(width, '0');
const bin = (value, width) => value.toString(2).padStart(width, '0');

export function pinIndex(pinName) {
  return Number(pinName.replace(/^P[A-Z]/, ''));
}

// 生成寄存器视图：只显示与所选引脚相关的位，其余位按 0 显示，并明确说明
export function registers(chip, pinName, cfg) {
  const num = pinIndex(pinName), port = pinName[1];
  if (chip.registerModel === 'F1') {
    const { nibble, cnf, modeBits } = f1Nibble(cfg);
    const isLow = num < 8;
    const shifted = nibble << (4 * (num % 8));
    const odrBit = cfg.mode === 'input' ? Number(cfg.pull === 'up')
      : Number((cfg.mode === 'output-pp' || cfg.mode === 'output-od') && cfg.level === 'high');
    return {
      model: 'F1 · CRL/CRH',
      rows: [
        {
          name: 'GPIO' + port + '->' + (isLow ? 'CRL' : 'CRH'),
          value: hex(shifted),
          bits: bin(nibble, 4),
          fieldAt: (num % 8) * 4,
          fieldWidth: 4,
          formula: 'CNF=' + bin(cnf, 2) + ' MODE=' + bin(modeBits, 2) + ' → 0b' + bin(nibble, 4)
        },
        {
          name: 'GPIO' + port + '->ODR',
          value: hex(odrBit << num),
          bits: String(odrBit),
          fieldAt: num,
          fieldWidth: 1,
          formula: cfg.mode === 'input'
            ? '输入模式下 ODR 选择上拉(1)/下拉(0)：' + (odrBit ? '上拉' : '下拉/浮空')
            : 'ODR 为输出锁存值：开漏写 1 表示释放引脚；复用模式由外设驱动'
        }
      ]
    };
  }
  const { moder, otyper, ospeedr, pupdr } = f4Bits(cfg);
  const at = num * 2;
  return {
    model: 'F4 · MODER/PUPDR',
    rows: [
      { name: 'GPIO' + port + '->MODER', value: hex(moder << at), bits: bin(moder, 2), fieldAt: at, fieldWidth: 2, formula: '00 输入 / 01 输出 / 10 复用 / 11 模拟' },
      { name: 'GPIO' + port + '->OTYPER', value: hex(otyper << num), bits: String(otyper), fieldAt: num, fieldWidth: 1, formula: '0 推挽 / 1 开漏' },
      { name: 'GPIO' + port + '->OSPEEDR', value: hex(ospeedr << at), bits: bin(ospeedr, 2), fieldAt: at, fieldWidth: 2, formula: '输出速度档位' },
      { name: 'GPIO' + port + '->PUPDR', value: hex(pupdr << at), bits: bin(pupdr, 2), fieldAt: at, fieldWidth: 2, formula: '00 无 / 01 上拉 / 10 下拉' }
    ]
  };
}

// 引脚最终电平：输出由 ODR 决定；输入取决于外部电路与上下拉
export function pinLevel(cfg, inputDriven) {
  if (cfg.mode === 'analog') return 'ANALOG';
  if (cfg.mode === 'af-pp') return 'AF';
  if (cfg.mode === 'input') {
    if (inputDriven === 'strong') return 'EXTERNAL';
    if (cfg.pull === 'up') return 'HIGH';
    if (cfg.pull === 'down') return 'LOW';
    return 'FLOATING';
  }
  if (cfg.mode === 'output-od' && cfg.level === 'high') return 'FLOATING';
  return cfg.level === 'high' ? 'HIGH' : 'LOW';
}

export function ledOn(chip, level) {
  if (level === 'HIGH') return !chip.demo.ledActiveLow;
  if (level === 'LOW') return chip.demo.ledActiveLow;
  return false;
}

// 新人最容易踩的坑，直接给在配置面板旁边
export function warnings(chip, pin, cfg) {
  const list = [];
  if (pin && pin.warn) list.push(pin.warn);
  if (cfg.mode === 'output-od' && cfg.level === 'high') {
    list.push('开漏输出写 1 是高阻状态，没有外部上拉电阻时引脚不会真正变高');
  }
  if (cfg.mode === 'input' && cfg.pull === 'none') {
    list.push('浮空输入：按键没按下时电压不确定，读数会乱跳；按键一般配内部上拉+按下接 GND');
  }
  if (cfg.mode === 'analog' && cfg.pull !== 'none') {
    list.push('模拟输入不需要上下拉，配置里应选无上下拉');
  }
  if (!pin) list.push('先在上方引脚墙里点一个引脚');
  return list;
}

// 生成可复制的 HAL 初始化片段
export function halCode(chip, pinName, cfg) {
  const port = pinName[1], num = pinIndex(pinName);
  const mode = modeOf(cfg.mode), pull = pullOf(cfg.pull), speed = speedOf(cfg.speed);
  const lines = [
    '/* 1. 先开时钟，不开时钟后面写什么都无效 */',
    `__HAL_RCC_GPIO${port}_CLK_ENABLE();`,
    '',
    '/* 2. 填参数并初始化 */',
    'GPIO_InitTypeDef gpio = {0};',
    `gpio.Pin   = GPIO_PIN_${num};`,
    `gpio.Mode  = ${mode.hal};`,
    `gpio.Pull  = ${pull.hal};`,
    `gpio.Speed = ${speed.hal};`,
    `HAL_GPIO_Init(GPIO${port}, &gpio);`
  ];
  if (cfg.mode === 'output-pp' || cfg.mode === 'output-od') {
    lines.push('', '/* 3. 输出电平：SET 为高，RESET 为低 */', `HAL_GPIO_WritePin(GPIO${port}, GPIO_PIN_${num}, ${cfg.level === 'high' ? 'GPIO_PIN_SET' : 'GPIO_PIN_RESET'});`);
  }
  if (cfg.mode === 'input') {
    lines.push('', '/* 3. 读输入电平 */', `uint8_t level = HAL_GPIO_ReadPin(GPIO${port}, GPIO_PIN_${num});`);
  }
  return lines.join('\n');
}
