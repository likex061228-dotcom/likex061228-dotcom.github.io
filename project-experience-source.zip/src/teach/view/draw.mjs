// 画布渲染：只负责把模型结果画出来，不碰 DOM 结构，方便单独调样式。
const COLORS = {
  bg: '#0c171b',
  panel: '#101f24',
  grid: '#20343a',
  raw: '#7aa2a6',
  stable: '#acdfc4',
  sample: '#d9bf98',
  press: '#d9bf98',
  done: '#8fd4b0',
  text: '#8ba99b',
  dim: '#5c7670'
};

export function fitCanvas(canvas, height) {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = Math.max(320, canvas.clientWidth || 640);
  canvas.width = Math.round(w * dpr);
  canvas.height = Math.round(height * dpr);
  canvas.style.height = height + 'px';
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, w, h: height };
}

function panel(ctx, x, y, w, h) {
  ctx.fillStyle = COLORS.panel;
  ctx.fillRect(x, y, w, h);
  ctx.strokeStyle = COLORS.grid;
  ctx.lineWidth = 1;
  ctx.strokeRect(x + 0.5, y + 0.5, w - 1, h - 1);
}

function stepPath(ctx, points, yFn, xFn, color, width) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  points.forEach((p, i) => {
    const px = xFn(p.t), py = yFn(p.v);
    if (i === 0) ctx.moveTo(px, py);
    else { ctx.lineTo(px, yFn(points[i - 1].v)); ctx.lineTo(px, py); }
  });
  ctx.stroke();
}

export function drawDebounceCanvas(canvas, sim) {
  const { ctx, w } = fitCanvas(canvas, 264);
  const padL = 88, padR = 18;
  const rawTop = 38, rawH = 60, stTop = 150, stH = 60;
  const innerW = w - padL - padR;
  const x = t => padL + (t / sim.total) * innerW;
  const yRaw = v => rawTop + 8 + (1 - v) * (rawH - 16);
  const ySt = v => stTop + 8 + (1 - v) * (stH - 16);

  ctx.clearRect(0, 0, w, 264);
  ctx.fillStyle = COLORS.bg;
  ctx.fillRect(0, 0, w, 264);
  panel(ctx, padL, rawTop, innerW, rawH);
  panel(ctx, padL, stTop, innerW, stH);

  // 竖向时间网格
  ctx.strokeStyle = COLORS.grid;
  ctx.lineWidth = 1;
  for (let t = 0; t <= sim.total; t += 100) {
    ctx.beginPath();
    ctx.moveTo(x(t), rawTop);
    ctx.lineTo(x(t), rawTop + rawH);
    ctx.moveTo(x(t), stTop);
    ctx.lineTo(x(t), stTop + stH);
    ctx.stroke();
  }

  // 原始电平 + 采样点
  stepPath(ctx, sim.raw, yRaw, x, COLORS.raw, 1.4);
  sim.samples.forEach(s => {
    ctx.fillStyle = COLORS.sample;
    ctx.beginPath();
    ctx.arc(x(s.t), yRaw(s.raw) + (s.raw ? -8 : 8), 1.9, 0, Math.PI * 2);
    ctx.fill();
  });

  // 消抖后的稳定电平
  stepPath(ctx, sim.samples.map(s => ({ t: s.t, v: s.stable })), ySt, x, COLORS.stable, 2.4);

  // 事件线
  const press = sim.events.find(e => e.type === 'press');
  const done = sim.events.find(e => e.type === 'click' || e.type === 'long');
  const marks = [];
  if (press) marks.push({ t: press.t, text: '确认按下', color: COLORS.press });
  if (done) marks.push({ t: done.t, text: done.type === 'click' ? '确认松开 · 单击' : '确认松开 · 长按', color: COLORS.done });
  ctx.setLineDash([4, 4]);
  marks.forEach(m => {
    ctx.strokeStyle = m.color;
    ctx.beginPath();
    ctx.moveTo(x(m.t), rawTop - 8);
    ctx.lineTo(x(m.t), stTop + stH + 8);
    ctx.stroke();
  });
  ctx.setLineDash([]);

  // 事件标签：位置太近时上下错开，避免叠字
  let lastX = -1e9, row = 0;
  marks.forEach(m => {
    const px = x(m.t);
    if (px - lastX < 96) row = 1 - row; else row = 0;
    lastX = px;
    ctx.fillStyle = m.color;
    ctx.font = '11px Consolas, monospace';
    ctx.textAlign = px > w - 150 ? 'right' : 'left';
    ctx.fillText(m.text, px + (px > w - 150 ? -6 : 6), 238 + row * 15);
  });
  ctx.textAlign = 'left';

  // 左侧说明
  ctx.fillStyle = COLORS.text;
  ctx.font = '11px Consolas, monospace';
  ctx.fillText('原始电平', 8, rawTop + 16);
  ctx.fillStyle = COLORS.dim;
  ctx.fillText('1 松开 / 0 按下', 8, rawTop + 32);
  ctx.fillStyle = COLORS.text;
  ctx.fillText('消抖后', 8, stTop + 16);
  ctx.fillStyle = COLORS.dim;
  ctx.fillText(`${sim.params.sampleMs}ms 采样`, 8, stTop + 32);

  // 采样图例
  ctx.fillStyle = COLORS.sample;
  ctx.beginPath(); ctx.arc(padL + 8, 20, 2.4, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = COLORS.dim;
  ctx.fillText('采样点', padL + 16, 24);
  ctx.fillStyle = COLORS.dim;
  ctx.fillText('时间 / ms', w - 74, 24);
}

export function drawPwmCanvas(canvas, r) {
  const { ctx, w } = fitCanvas(canvas, 244);
  const padL = 54, padR = 18, top = 54, bot = 190;
  const innerW = w - padL - padR;
  const y = v => bot - 8 - v * (bot - top - 16);

  ctx.clearRect(0, 0, w, 244);
  ctx.fillStyle = COLORS.bg;
  ctx.fillRect(0, 0, w, 244);
  panel(ctx, padL, top, innerW, bot - top);

  // 高电平区域底色
  const cycles = 3;
  const period = innerW / cycles;
  ctx.fillStyle = 'rgba(172,223,196,0.10)';
  for (let i = 0; i < cycles; i++) {
    const x0 = padL + i * period;
    ctx.fillRect(x0, top, period * r.duty, bot - top);
  }

  // 波形
  ctx.beginPath();
  ctx.strokeStyle = COLORS.stable;
  ctx.lineWidth = 2;
  for (let i = 0; i < cycles; i++) {
    const x0 = padL + i * period;
    const xh = x0 + period * r.duty;
    ctx.moveTo(x0, y(0));
    ctx.lineTo(x0, y(1));
    ctx.lineTo(xh, y(1));
    ctx.lineTo(xh, y(0));
    ctx.lineTo(x0 + period, y(0));
  }
  ctx.stroke();

  // Y 轴刻度
  ctx.fillStyle = COLORS.dim;
  ctx.font = '10px Consolas, monospace';
  ctx.textAlign = 'right';
  ctx.fillText('3.3 V', padL - 8, y(1) + 4);
  ctx.fillText('0 V', padL - 8, y(0) + 4);
  ctx.textAlign = 'left';

  // CCR 时刻
  ctx.strokeStyle = COLORS.sample;
  ctx.setLineDash([3, 3]);
  ctx.beginPath();
  const xc = padL + period * r.duty;
  ctx.moveTo(xc, top - 8);
  ctx.lineTo(xc, bot + 8);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = COLORS.sample;
  ctx.fillText('CCR', xc + 4, bot + 20);

  // 周期标注
  ctx.strokeStyle = COLORS.grid;
  ctx.beginPath();
  ctx.moveTo(padL, bot + 34);
  ctx.lineTo(padL + period, bot + 34);
  ctx.stroke();
  ctx.fillStyle = COLORS.dim;
  ctx.fillText('1 个周期 T', padL + 6, bot + 30);

  // 顶部读数
  ctx.font = '11px Consolas, monospace';
  ctx.fillStyle = COLORS.text;
  ctx.fillText(`T = ${(r.periodUs / 1000).toFixed(r.periodUs < 1000 ? 3 : 2)} ms`, padL, 24);
  ctx.fillText(`占空比 ${(r.duty * 100).toFixed(1)}%`, padL + 150, 24);
  ctx.fillText(`f = ${r.freqHz >= 1000 ? (r.freqHz / 1000).toFixed(3).replace(/\.?0+$/, '') + ' kHz' : r.freqHz.toFixed(1) + ' Hz'}`, padL + 300, 24);
}
