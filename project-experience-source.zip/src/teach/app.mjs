import { CHAPTERS, FLAT, findSection } from './content/chapters.mjs';
import { mountWidgets } from './widgets/index.mjs';

const VISIT_KEY = 'Like_x.teach.visited.v1';
const side = document.getElementById('docs-side');
const doc = document.getElementById('doc');
const toc = document.getElementById('docs-toc');
const pager = document.getElementById('doc-pager');
const progressEl = document.getElementById('doc-progress');
const crumbs = document.getElementById('doc-crumbs');

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const visited = new Set();
try {
  const raw = JSON.parse(localStorage.getItem(VISIT_KEY) || '[]');
  if (Array.isArray(raw)) raw.forEach(x => visited.add(x));
} catch { /* 存储损坏按空进度处理 */ }
const saveVisited = () => { try { localStorage.setItem(VISIT_KEY, JSON.stringify([...visited])); } catch { /* 忽略 */ } };

let filterText = '';

function routeFromHash() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [chapterId, sectionId] = raw.split('/');
  const found = findSection(chapterId, sectionId);
  if (found) return { chapter: found.chapter, section: found.section };
  const first = CHAPTERS.find(c => c.id === FLAT[0].chapterId);
  return { chapter: first, section: first.sections[0] };
}

function renderSidebar(current) {
  const kw = filterText.trim().toLowerCase();
  const visitedCount = [...visited].filter(k => FLAT.some(f => f.chapterId + '/' + f.id === k)).length;
  side.innerHTML = `
    <div class="side-search"><input type="search" placeholder="搜索章节或小节…" value="${esc(filterText)}" aria-label="搜索章节"></div>
    <div class="side-progress"><span>阅读进度</span><b>${visitedCount} / ${FLAT.length}</b></div>
    <nav class="side-nav">
      ${[...new Set(CHAPTERS.map(c => c.group))].map(group => {
        const chapters = CHAPTERS.filter(c => c.group === group);
        const blocks = chapters.map(ch => {
          const sections = ch.sections.filter(s => !kw || (s.title + ch.title).toLowerCase().includes(kw));
          if (kw && !sections.length) return '';
          const active = ch.id === current.chapter.id;
          return `<div class="side-chapter ${active ? 'active' : ''}">
            <a class="side-chapter-link" href="#/${ch.id}/${ch.sections[0].id}" title="${esc(ch.title)}">${esc(ch.title.split('：')[0])}</a>
            ${(active || kw) ? `<ol class="side-sections">
              ${sections.map(s => `<li class="${s.id === current.section.id ? 'active' : ''}">
                <a href="#/${ch.id}/${s.id}"><span class="dot ${visited.has(ch.id + '/' + s.id) ? 'done' : ''}"></span>${esc(s.title)}</a>
              </li>`).join('')}
            </ol>` : ''}
          </div>`;
        }).join('');
        if (!blocks.trim()) return '';
        return `<div class="side-group">
          <div class="side-group-title">${esc(group)}</div>
          ${blocks}
        </div>`;
      }).join('')}
    </nav>`;
  side.querySelector('input').oninput = e => {
    filterText = e.target.value;
    const pos = e.target.selectionStart;
    renderSidebar(current);
    const input = side.querySelector('input');
    input.focus();
    input.setSelectionRange(pos, pos);
  };
  progressEl.textContent = `已读 ${visitedCount}/${FLAT.length}`;
}

function renderContent(current) {
  const idx = FLAT.findIndex(f => f.chapterId === current.chapter.id && f.id === current.section.id);
  const prev = FLAT[idx - 1], next = FLAT[idx + 1];

  crumbs.innerHTML = `<a href="index.html">作品集</a><span>/</span><span>${esc(current.chapter.group)}</span><span>/</span><b>${esc(current.section.title)}</b>`;

  doc.querySelectorAll('[data-widget]').forEach(el => { if (typeof el._cleanup === 'function') el._cleanup(); });
  doc.innerHTML = `
    <header class="doc-head">
      <div class="eyebrow">${esc(current.chapter.group)} · ${esc(current.chapter.title.split('：')[0])}</div>
      <h1>${esc(current.section.title)}</h1>
      <p class="doc-kicker">${esc(current.chapter.kicker)}</p>
    </header>
    <div class="doc-body">${current.section.html}</div>`;

  mountWidgets(doc);

  toc.innerHTML = `<div class="toc-title">本章目录</div>
    <ol>${current.chapter.sections.map(s => `<li class="${s.id === current.section.id ? 'active' : ''}"><a href="#/${current.chapter.id}/${s.id}">${esc(s.title)}</a></li>`).join('')}</ol>`;

  pager.innerHTML = `
    ${prev ? `<a class="pager prev" href="#/${prev.chapterId}/${prev.id}"><small>上一节</small><span>${esc(prev.title)}</span></a>` : '<span></span>'}
    ${next ? `<a class="pager next" href="#/${next.chapterId}/${next.id}"><small>下一节</small><span>${esc(next.title)}</span></a>` : '<span></span>'}`;

  visited.add(current.chapter.id + '/' + current.section.id);
  saveVisited();
}

function render() {
  const current = routeFromHash();
  renderSidebar(current);
  renderContent(current);
  document.title = current.section.title + ' · 嵌入式教学台 · Like_x';
  document.querySelector('.docs-shell').classList.remove('side-open');
  window.scrollTo({ top: 0, behavior: 'auto' });
}

window.addEventListener('hashchange', render);

document.getElementById('side-toggle').onclick = () => {
  document.querySelector('.docs-shell').classList.toggle('side-open');
};

if (!location.hash) {
  history.replaceState(null, '', '#/' + FLAT[0].chapterId + '/' + FLAT[0].id);
}
render();
