import { CHIPS, CHIP_LIST, getChip, findPin } from './data/chips.mjs';
import * as G from './model/gpio.mjs';
import { simulateDebounce } from './model/debounce.mjs';
import { pwm, brightness, fmtFreq, fmtUs } from './model/timer.mjs';
import { QUIZ, gradeQuiz } from './data/quiz.mjs';
import { drawDebounceCanvas, drawPwmCanvas } from './view/draw.mjs';

const STORE_KEY = 'Like_x.teach.progress.v1';
const app = document.getElementById('app');

const state = {
  chip: 'f103rc',
  pin: 'PC0',
  cfg: { ...G.DEFAULT_CONFIG },
  deb: { pressMs: 260, bounceMs: 9, sampleMs: 10, need: 3, longMs: 800 },
  pwm: { psc: 71, arr: 999, ccr: 250 },
  answers: {}
};

function loadProgress() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORE_KEY) || 'null');
    if (!raw || typeof raw !== 'object') return;
    if (raw.chip && CHIPS[raw.chip]) state.chip = raw.chip;
    if (raw.answers && typeof raw.answers === 'object') {
      for (const [k, v] of Object.entries(raw.answers)) if (Number.isInteger(v)) state.answers[k] = v;
    }
  } catch { /* 存储损坏时按新进度开始，不覆盖任何内容 */ }
}
function saveProgress() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify({ chip: state.chip, answers: state.answers })); } catch { /* 忽略 */ }
}

const chip = () => getChip(state.chip);
const pin = () => findPin(chip(), state.pin);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function defaultCfgFor(pinName) {
  const c = chip();
  if (pinName === c.demo.ledPin) return { ...G.DEFAULT_CONFIG, mode: 'output-pp', level: c.demo.ledActiveLow ? 'low' : 'high' };
  if (pinName === c.demo.keyPin) return { ...G.DEFAULT_CONFIG, mode: 'input', pull: 'up' };
  return { ...G.DEFAULT_CONFIG };
}

function pinSummary() {
  const c = chip(), p = pin();
  if (!p) return '未选择引脚';
  const level = G.pinLevel(state.cfg, 'none');
  const on = G.ledOn(c, level);
  const levelText = { HIGH: '高电平', LOW: '低电平', FLOATING: '高阻/浮空', ANALOG: '模拟', AF: '复用功能', EXTERNAL: '外部决定' }[level] || level;
  const ledText = p.name === c.demo.ledPin ? (on ? ' · LED 点亮' : ' · LED 熄灭') : '';
  return `${p.name} → ${levelText}${ledText}`;
}

function renderChipBar() {
  return `<div class="teach-chipbar">
    <div class="teach-chips">
      ${CHIP_LIST.map(c => `<button type="button" data-act="chip" data-chip="${c.key}" class="${c.key === state.chip ? 'on' : ''}" aria-pressed="${c.key === state.chip}">
        <strong>${esc(c.name)}</strong><small>${esc(c.pkg)} · ${c.flashKB}KB Flash · ${c.maxMHz}MHz</small>
      </button>`).join('')}
    </div>
    <p class="quiet">${esc(chip().board)}。${esc(chip().note)}</p>
  </div>`;
}

function renderPinWall() {
  const c = chip();
  const ports = [...new Set(c.pins.map(p => p.port))];
  return `<div class="teach-card" id="pinwall">
    <div class="card-head"><div><div class="eyebrow">01 / PIN WALL</div><h2>引脚墙</h2></div>
      <p class="quiet">点一个引脚看它怎么配。带虚线的引脚有占用或复用提醒；红色小点是该引脚的板载角色。</p></div>
    <div class="pinwall">
      ${ports.map(port => {
        const pins = c.pins.filter(p => p.port === port);
        return `<div class="pin-row"><span class="pin-port">P${port}</span><div class="pin-cells">
          ${pins.map(p => `<button type="button" class="pin ${p.name === state.pin ? 'on' : ''} ${p.warn ? 'warn' : ''}" data-act="pin" data-pin="${p.name}" title="${esc(p.warn || p.roles.join(' / ') || '通用 IO')}">
            <span>${p.num}</span>${p.roles.length ? '<i></i>' : ''}
          </button>`).join('')}
        </div></div>`;
      }).join('')}
    </div>
  </div>`;
}

function renderInspector() {
  const p = pin();
  if (!p) return '';
  const c = chip();
  const cfg = state.cfg;
  const isOutput = cfg.mode === 'output-pp' || cfg.mode === 'output-od';
  const warn = G.warnings(c, p, cfg);
  const level = G.pinLevel(cfg, 'none');
  const on = G.ledOn(c, level);
  const regs = G.registers(c, p.name, cfg);
  const code = G.halCode(c, p.name, cfg);
  const roles = p.roles.length ? p.roles.join(' / ') : '通用 IO';

  return `<div class="teach-card" id="inspector">
    <div class="card-head"><div><div class="eyebrow">02 / CONFIG → CODE → REGISTER</div><h2>${esc(p.name)} · ${esc(roles)}</h2></div>
      <p class="quiet">同一次配置的三个视角：CubeMX 里选了什么、生成的 HAL 代码长什么样、寄存器哪几位变了。</p></div>

    <div class="cfg-row">
      <label>模式<select data-act="cfg" data-key="mode">
        ${G.MODES.map(m => `<option value="${m.id}" ${m.id === cfg.mode ? 'selected' : ''}>${m.label} · ${m.hal}</option>`).join('')}
      </select></label>
      <label>上下拉<select data-act="cfg" data-key="pull">
        ${G.PULLS.map(m => `<option value="${m.id}" ${m.id === cfg.pull ? 'selected' : ''}>${m.label} · ${m.hal}</option>`).join('')}
      </select></label>
      <label>速度<select data-act="cfg" data-key="speed" ${isOutput ? '' : 'disabled'}>
        ${G.SPEEDS.map(m => `<option value="${m.id}" ${m.id === cfg.speed ? 'selected' : ''}>${m.label} · ${m.hal}</option>`).join('')}
      </select></label>
      <div class="level-toggle ${isOutput ? '' : 'off'}">
        <span>输出电平</span>
        <button type="button" data-act="level" data-level="high" class="${cfg.level === 'high' ? 'on' : ''}" ${isOutput ? '' : 'disabled'}>高</button>
        <button type="button" data-act="level" data-level="low" class="${cfg.level === 'low' ? 'on' : ''}" ${isOutput ? '' : 'disabled'}>低</button>
      </div>
      <div class="led-demo">
        <div class="led ${on ? 'lit' : ''}"></div>
        <div><small>引脚状态</small><strong>${esc(pinSummary())}</strong></div>
      </div>
    </div>

    ${warn.length ? `<ul class="warn-list">${warn.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : ''}

    <div class="triple">
      <div class="triple-col">
        <h3>① 配置摘要</h3>
        <dl class="kv">
          <div><dt>模式</dt><dd>${esc(G.modeOf(cfg.mode).label)}</dd></div>
          <div><dt>上下拉</dt><dd>${esc(G.pullOf(cfg.pull).label)}</dd></div>
          <div><dt>速度</dt><dd>${esc(G.speedOf(cfg.speed).label)}（约 ${G.speedOf(cfg.speed).mhz} MHz）</dd></div>
          <div><dt>电平</dt><dd>${isOutput ? (cfg.level === 'high' ? '高' : '低') : '由外部电路决定'}</dd></div>
        </dl>
      </div>
      <div class="triple-col">
        <h3>② 生成的 HAL 代码</h3>
        <pre class="code"><code>${code.split('\n').map(line => line.trim().startsWith('/*') ? `<span class="cm">${esc(line)}</span>` : esc(line)).join('\n')}</code></pre>
      </div>
      <div class="triple-col">
        <h3>③ 寄存器（只显示这个引脚的位）</h3>
        <p class="quiet">${esc(regs.model)}。加粗的是所选引脚占用的位，其余位按 0 显示。</p>
        <div class="reg-list">
          ${regs.rows.map(r => {
            return `<div class="reg">
              <div class="reg-head"><code>${esc(r.name)}</code><b>${esc(r.value)}</b></div>
              <div class="reg-bits">${binWithHighlight(r, 32)}</div>
              <p>${esc(r.formula)}</p>
            </div>`;
          }).join('')}
        </div>
      </div>
    </div>
  </div>`;
}

// 32 位二进制，把该引脚占用的位加粗
function binWithHighlight(row, width) {
  const total = width;
  const start = total - 1 - (row.fieldAt + row.fieldWidth - 1); // 从左往右的下标
  const value = parseInt(row.value, 16);
  let out = '';
  for (let i = 0; i < total; i++) {
    const bit = (value >> (total - 1 - i)) & 1;
    if (i >= start && i < start + row.fieldWidth) out += `<b>${bit}</b>`;
    else out += bit;
  }
  return `<code>${out}</code>`;
}

function renderDebounce() {
  return `<div class="teach-card" id="debounce">
    <div class="card-head"><div><div class="eyebrow">03 / GPIO INPUT · 7.2–7.3</div><h2>按键、抖动与消抖</h2></div>
      <p class="quiet">上排是引脚真实电平（含机械抖动），下排是定时器每 ${state.deb.sampleMs} ms 采样一次、连续 ${state.deb.need} 次一致后才确认的状态。</p></div>
    <div class="deb-grid">
      <div class="deb-canvas-wrap"><canvas id="deb-canvas" aria-label="按键抖动与消抖波形"></canvas></div>
      <div class="deb-controls">
        <label>按下时长 <output>${state.deb.pressMs} ms</output><input type="range" min="60" max="1400" step="10" value="${state.deb.pressMs}" data-act="deb" data-key="pressMs"></label>
        <label>抖动时长 <output>${state.deb.bounceMs} ms</output><input type="range" min="0" max="30" step="1" value="${state.deb.bounceMs}" data-act="deb" data-key="bounceMs"></label>
        <label>采样周期 <output>${state.deb.sampleMs} ms</output><input type="range" min="1" max="30" step="1" value="${state.deb.sampleMs}" data-act="deb" data-key="sampleMs"></label>
        <label>连续一致次数 <output>${state.deb.need} 次</output><input type="range" min="1" max="8" step="1" value="${state.deb.need}" data-act="deb" data-key="need"></label>
        <label>长按阈值 <output>${state.deb.longMs} ms</output><input type="range" min="300" max="1500" step="50" value="${state.deb.longMs}" data-act="deb" data-key="longMs"></label>
      </div>
    </div>
    <div class="deb-result" id="deb-result"></div>
  </div>`;
}

function renderPwm() {
  return `<div class="teach-card" id="pwm">
    <div class="card-head"><div><div class="eyebrow">04 / TIMER &amp; PWM · 9.1–9.3</div><h2>定时器与 PWM 调光</h2></div>
      <p class="quiet">f = 定时器时钟 / ((PSC+1) × (ARR+1))，占空比 = CCR / (ARR+1)。拖动滑杆，波形、频率和亮度一起变。</p></div>
    <div class="pwm-grid">
      <div class="pwm-canvas-wrap"><canvas id="pwm-canvas" aria-label="PWM 波形"></canvas></div>
      <div class="pwm-controls">
        <label>PSC <output>${state.pwm.psc}</output><input type="range" min="0" max="999" step="1" value="${state.pwm.psc}" data-act="pwm" data-key="psc"></label>
        <label>ARR <output>${state.pwm.arr}</output><input type="range" min="9" max="4999" step="10" value="${state.pwm.arr}" data-act="pwm" data-key="arr"></label>
        <label>CCR <output>${state.pwm.ccr}</output><input type="range" min="0" max="4999" step="10" value="${state.pwm.ccr}" data-act="pwm" data-key="ccr"></label>
        <div class="pwm-led"><div class="led big" id="pwm-led"></div><span id="pwm-brightness"></span></div>
      </div>
    </div>
    <div class="pwm-readout" id="pwm-readout"></div>
  </div>`;
}

function renderQuiz() {
  const { correct, total } = gradeQuiz(state.answers);
  const answered = Object.keys(state.answers).length;
  return `<div class="teach-card" id="quiz">
    <div class="card-head"><div><div class="eyebrow">05 / SELF CHECK</div><h2>自检题库</h2></div>
      <p class="quiet">覆盖 7.1–9.3 和几个高频坑。选完立刻判分并给解释；答错不会锁住，可以改。</p></div>
    <div class="quiz-score">已作答 ${answered} / ${total} · 正确 ${correct} · 进度 ${Math.round((answered / total) * 100)}%
      <button type="button" class="button" data-act="quiz-reset">清空作答</button></div>
    <div class="quiz-list">
      ${QUIZ.map((q, i) => {
        const picked = state.answers[q.id];
        const answeredQ = Number.isInteger(picked);
        return `<article class="quiz-item ${answeredQ ? (picked === q.answer ? 'ok' : 'bad') : ''}">
          <header><span class="sec">${esc(q.sec)}</span><h3>${i + 1}. ${esc(q.q)}</h3></header>
          <div class="quiz-opts">
            ${q.opts.map((opt, k) => `<button type="button" data-act="quiz" data-q="${q.id}" data-k="${k}"
              class="${answeredQ && picked === k ? 'picked' : ''} ${answeredQ && k === q.answer ? 'right' : ''}">${esc(opt)}</button>`).join('')}
          </div>
          ${answeredQ ? `<p class="quiz-why ${picked === q.answer ? 'ok' : 'bad'}">${picked === q.answer ? '✓ 正确。' : '✗ 再想想。'} ${esc(q.why)}</p>` : ''}
        </article>`;
      }).join('')}
    </div>
  </div>`;
}

function renderFooter() {
  return `<div class="teach-boundary">
    <strong>这个工具是什么：</strong>用 STM32F103RCT6 / F103C8T6 / F407VET6 的真实寄存器规则和定时器公式，解释“配置 → 代码 → 寄存器 → 引脚/波形”的因果关系。
    <strong>它不是什么：</strong>不执行固件、不仿真模拟精度、不代替上板调试；实际行为以芯片数据手册、参考手册和你板子的原理图为准。
    板上 LED/按键的接线取自正点原子 NANO STM32F1 V2.0 的《IO 引脚分配表》与 Blue Pill 原理图；其他板子请以原理图为准。
  </div>`;
}

function renderAll() {
  app.innerHTML = renderChipBar() + renderPinWall() + renderInspector() + renderDebounce() + renderPwm() + renderQuiz() + renderFooter();
  drawDebounce();
  drawPwm();
}

/* ---------- 画布 ---------- */
function drawDebounce() {
  const canvas = document.getElementById('deb-canvas');
  if (!canvas) return;
  const sim = simulateDebounce({ ...state.deb, pressAt: 140, releaseGapMs: 420, seed: 7 });
  drawDebounceCanvas(canvas, sim);
  const el = document.getElementById('deb-result');
  if (!el) return;
  const verdictColor = sim.verdict === '没识别到完整按键' ? '#efa78e' : '#acdfc4';
  const explain = sim.verdict === '长按'
    ? '确认后的按下时长 ≥ 长按阈值，判为长按。'
    : sim.verdict === '单击'
      ? '确认后的按下时长小于长按阈值，判为单击。'
      : '按下太短或抖动太强，连续一致次数还没攒够就松开了——这正是新手按键「没反应」的常见原因。';
  el.innerHTML = `<div><small>识别结果</small><strong style="color:${verdictColor}">${sim.verdict}</strong></div>
    <div><small>确认后的按下时长</small><strong>${Math.round(sim.heldMs)} ms</strong></div>
    <div><small>理论最短确认时间</small><strong>${sim.theoryMs} ms（${state.deb.need} × ${state.deb.sampleMs} ms）</strong></div>
    <div><small>说明</small><p>${explain}</p></div>`;
}

function drawPwm() {
  const canvas = document.getElementById('pwm-canvas');
  if (!canvas) return;
  const c = chip();
  const r = pwm(c, state.pwm);
  drawPwmCanvas(canvas, r);

  const b = brightness(r.duty) / 100;
  const led = document.getElementById('pwm-led');
  if (led) {
    led.style.background = `rgba(255,216,121,${(0.1 + 0.9 * b).toFixed(3)})`;
    led.style.borderColor = `rgba(255,216,121,${(0.25 + 0.75 * b).toFixed(3)})`;
    led.style.boxShadow = b > 0.02 ? `0 0 ${Math.round(6 + 18 * b)}px ${Math.round(1 + 4 * b)}px rgba(255,216,121,${(0.15 + 0.45 * b).toFixed(3)})` : 'none';
  }
  const out = document.getElementById('pwm-brightness');
  if (out) out.textContent = `亮度 ${brightness(r.duty)}% · 定时器时钟 ${(r.clockHz / 1e6).toFixed(0)} MHz`;

  const read = document.getElementById('pwm-readout');
  if (read) {
    read.innerHTML = `
      <div><small>频率</small><strong>${fmtFreq(r.freqHz)}</strong><span>${r.freqHz.toFixed(2)} Hz</span></div>
      <div><small>周期</small><strong>${fmtUs(r.periodUs)}</strong><span>ARR+1 = ${r.periodTicks} 个计数</span></div>
      <div><small>占空比</small><strong>${(r.duty * 100).toFixed(1)}%</strong><span>CCR ${state.pwm.ccr} / ${r.periodTicks}</span></div>
      <div><small>单计数时间</small><strong>${fmtUs(r.tickUs)}</strong><span>(PSC+1) = ${r.prescaler}</span></div>
      ${r.overflow ? '<div class="warn-inline">CCR 大于 ARR：输出会一直是高电平（100%），这是常见笔误。</div>' : ''}`;
  }
}

/* ---------- 交互 ---------- */
app.addEventListener('click', e => {
  const t = e.target.closest('[data-act]');
  if (!t) return;
  const act = t.dataset.act;
  if (act === 'chip') {
    state.chip = t.dataset.chip;
    state.pin = chip().demo.ledPin;
    state.cfg = defaultCfgFor(state.pin);
    saveProgress(); renderAll(); return;
  }
  if (act === 'pin') {
    state.pin = t.dataset.pin;
    state.cfg = defaultCfgFor(state.pin);
    renderAll(); return;
  }
  if (act === 'level') {
    state.cfg.level = t.dataset.level;
    renderAll(); return;
  }
  if (act === 'quiz') {
    state.answers[t.dataset.q] = Number(t.dataset.k);
    saveProgress(); renderAll(); return;
  }
  if (act === 'quiz-reset') {
    state.answers = {};
    saveProgress(); renderAll(); return;
  }
});

app.addEventListener('change', e => {
  const t = e.target.closest('[data-act]');
  if (!t) return;
  if (t.dataset.act === 'cfg') {
    state.cfg[t.dataset.key] = t.value;
    renderAll();
  }
});

app.addEventListener('input', e => {
  const t = e.target.closest('[data-act]');
  if (!t) return;
  const key = t.dataset.key;
  const value = Number(t.value);
  if (t.dataset.act === 'deb') {
    state.deb[key] = value;
    const out = t.parentElement.querySelector('output');
    if (out) out.textContent = key === 'need' ? value + ' 次' : value + ' ms';
    drawDebounce();
  }
  if (t.dataset.act === 'pwm') {
    state.pwm[key] = value;
    const out = t.parentElement.querySelector('output');
    if (out) out.textContent = value;
    drawPwm();
  }
});

let resizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { drawDebounce(); drawPwm(); }, 120);
});

loadProgress();
if (!findPin(chip(), state.pin)) state.pin = chip().demo.ledPin;
state.cfg = defaultCfgFor(state.pin);
renderAll();
