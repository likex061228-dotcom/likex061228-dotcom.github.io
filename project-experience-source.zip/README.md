# Like_x · Interactive project experience

This source package builds the three interactive project pages and the project experiment library. The project behavior engine computes the displayed state; Three.js renders it. This is not MCU firmware execution, electrical simulation, full 3D vehicle dynamics, or a calibrated digital twin.

## Reproduce

Use Node.js22+. In this extracted folder:

```
npm ci --ignore-scripts
npm test
npm run build
python -m http.server 8765 --directory dist
```

Open http://localhost:8765/studio.html or project.html?project=matrix. The public support files are bundled here. To reproduce the whole portfolio including its original project source archives and independent MuJoCo workspace, use the existing repository https://github.com/likex061228-dotcom/likex061228-dotcom.github.io and overlay the generated files. Those large archives/native-engine assets are separate downloads, not duplicated in this package.

## Responsibilities

- src/project-app.mjs: project feature selection, held controls, optional debugging, local experiment continuation and exports.
- src/project-view.mjs: real orbit/tilt/scene placement interactions and rendering from the same project state.
- src/project-contract.mjs: bounded version2 checkpoints, deterministic bead initialization and board gravity transform consistent with Three EulerXYZ.
- src/project-geometry.mjs: fixed-pivot pipe and constant-length illustrative crank/connecting rod.
- src/charts.mjs: actual trace and A/B reference plotting.
- src/library.mjs: studio saved-experiment list, per-record delete with inline confirmation and remaining-capacity text.
- src/library-store.mjs: pure validation, parsing, deletion and summary helpers for the 20-record local library (no DOM, unit tested).
- src/teach/: docs-style teaching bench (9 chapters / 32 sections). content/chapters.mjs holds the Chinese lesson text; widgets/index.mjs mounts the interactive labs (pin inspector, debounce, EXTI edge counting, NVIC timeline, counter animation, PWM); data/faq.mjs is the symptom-to-cause troubleshooting bank; data/chips.mjs holds board pin maps for STM32F103RCT6 (ALIENTEK NANO), F103C8T6 (Blue Pill) and F407VET6; model/gpio.mjs maps CubeMX-style settings to CRL/CRH (F1) or MODER/PUPDR (F4) bits; model/debounce.mjs simulates sampling debounce and click/long-press classification; model/timer.mjs computes PWM frequency and duty; data/quiz.mjs generates a self-check bank whose numeric answers are computed from the same formulas. It never executes firmware.
- public/sim-engine.js: source-informed planar car behavior, legacy balance and LED models. public/sim-tasks.js: course and task checks.
- tests/: car state machine, contact events, actual velocity-derived acceleration, checkpoint/replay validation, combined tilt using Three quaternion math, mechanism geometry, and saved-library parsing/deletion.

## Scope and limitations

All parameters and records stay in the browser unless explicitly exported. Checkpoints transfer current model state; trace history is separate. A/B traces use each retained20s window aligned at its own first sample; this is stated next to the comparison. Seeds make initial LED layouts reproducible. Camera observation does not change physical inputs; board manipulation does.

Car behavior represents timed source-level actions; the redundant pre-turn scan is abstracted. Sound inputs are qualitative directional values, not acoustic pressure or original INMP441 firmware sampling. Sound does not include path planning. Balance mechanics and the linked 3D assembly remain an illustrative behavior model with assumed dimensions and gains. LED positions are occupancy/display state; animated jump height illustrates a virtual state, not moving physical LEDs. Arbitrary requirements-to-model AI is not implemented.

## Third-party notices

Three.js0.186.1: MIT license, retained in licenses/THREE-LICENSE.txt. https://github.com/mrdoob/three.js

Build tool esbuild0.28.2: MIT, upstream package retains license. Model/backend and visualization roles are separate. No assets or personal content copied from reference portfolios.

## Teaching lesson update (2026-10-21)

The teaching page now starts with one complete NANO F1 PC0 LED lesson, followed by existing reference chapters. GPIO/NVIC correctness regressions and discrete LED-circuit tests are included (62 total tests across project and teaching suites). The lesson uses symbolic logic, not analog current/voltage or firmware execution. `src/teach/content/gpio-lesson.mjs` holds the lesson; `model/led-lesson.mjs` computes states and `widgets/led-lesson.mjs` renders the exercise. Browser-local checks represent completed operations, not mastery. Teaching static styles are in public/teach.css and public/teach-lesson.css.
