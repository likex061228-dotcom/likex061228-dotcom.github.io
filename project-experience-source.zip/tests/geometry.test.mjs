import test from 'node:test';import assert from 'node:assert/strict';
import {linkage} from '../src/project-geometry.mjs';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
test('fixed-end pipe and planar crank/coupler lengths remain constant through operating range',()=>{
 for(const a of [-.1,-.05,0,.05,.1]){const g=linkage(a);assert.deepEqual(g.fixed,{x:-.125,z:.25});assert.ok(Math.abs(distance(g.fixed,g.end)-.25)<1e-12);assert.ok(Math.abs(distance(g.motor,g.pin)-.03)<1e-12);assert.ok(Math.abs(distance(g.pin,g.end)-.075)<1e-12);}
});
