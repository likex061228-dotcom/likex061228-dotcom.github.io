import test from 'node:test';
import assert from 'node:assert/strict';
import {LIBRARY_KEY,LIBRARY_LIMIT,LIBRARY_EMPTY,isRecord,parseRecords,withoutRecord,summary} from '../src/library-store.mjs';

const record=(id,slug='balance',name='实验 '+id)=>({id,name,slug,date:'2026-10-21T10:00:00.000Z',experiment:{version:2,project:slug}});

test('library key and limit match the published storage contract',()=>{
  assert.equal(LIBRARY_KEY,'Like_x.project.experiments.v2');
  assert.equal(LIBRARY_LIMIT,20);
});

test('records are accepted only with id, name, supported slug and experiment payload',()=>{
  assert.ok(isRecord(record('a')));
  assert.ok(!isRecord(null),'rejects null');
  assert.ok(!isRecord(record('b','workflow')),'rejects unsupported project');
  assert.ok(!isRecord({...record('c'),name:5}),'rejects non-string name');
  assert.ok(!isRecord({...record('d'),experiment:null}),'rejects missing payload');
});

test('parsing tolerates junk entries but never exceeds the stored limit',()=>{
  const rows=[record('a'),null,{id:'bad'},record('b','smartcar'),record('c','matrix','点阵')];
  const parsed=parseRecords(JSON.stringify(rows));
  assert.deepEqual(parsed.map(item=>item.id),['a','b','c']);
  assert.equal(parseRecords('').length,0,'empty storage reads as an empty list');
  const many=Array.from({length:LIBRARY_LIMIT+5},(_,i)=>record('r'+i));
  assert.equal(parseRecords(JSON.stringify(many)).length,LIBRARY_LIMIT);
});

test('corrupt or non-array storage raises instead of silently wiping records',()=>{
  assert.throws(()=>parseRecords('{oops'),/保存格式无效/);
  assert.throws(()=>parseRecords('"text"'),/保存格式无效/);
});

test('deleting removes exactly one record and leaves the rest in order',()=>{
  const rows=[record('a'),record('b'),record('c')];
  assert.deepEqual(withoutRecord(rows,'b').map(item=>item.id),['a','c']);
  assert.deepEqual(withoutRecord(rows,'missing').map(item=>item.id),['a','b','c']);
  assert.deepEqual(withoutRecord(null,'a'),[]);
});

test('summary states capacity honestly',()=>{
  assert.equal(summary([]),LIBRARY_EMPTY);
  assert.match(summary([record('a'),record('b')]),/2 \/ 20/);
});
