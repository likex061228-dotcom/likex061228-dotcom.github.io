import test from 'node:test';
import assert from 'node:assert/strict';
import { CHIPS, getChip, findPin } from '../src/teach/data/chips.mjs';
import * as G from '../src/teach/model/gpio.mjs';
import { simulateDebounce } from '../src/teach/model/debounce.mjs';
import { pwm, brightness } from '../src/teach/model/timer.mjs';
import { QUIZ, gradeQuiz } from '../src/teach/data/quiz.mjs';

test('三颗芯片都带引脚表与演示引脚', () => {
  const keys = Object.keys(CHIPS);
  assert.deepEqual(keys.sort(), ['f103c8', 'f103rc', 'f407ve']);
  for (const key of keys) {
    const chip = CHIPS[key];
    assert.ok(chip.pins.length > 20, key + ' 引脚数量');
    assert.ok(findPin(chip, chip.demo.ledPin), key + ' 演示 LED 引脚存在');
    assert.ok(findPin(chip, chip.demo.keyPin), key + ' 演示按键引脚存在');
  }
  assert.deepEqual(findPin(CHIPS.f103c8, 'PC13').roles, ['核心板D2 / LED0']);
  assert.match(findPin(CHIPS.f103rc, 'PA13').warn, /SWD/);
  assert.match(findPin(CHIPS.f407ve, 'PH0').warn, /HSE/);
});

test('F1 的 CRL/CRH 四位编码与手册一致', () => {
  const base = { ...G.DEFAULT_CONFIG };
  assert.equal(G.f1Nibble({ ...base, mode: 'output-pp', speed: 'low' }).nibble, 0b0010);
  assert.equal(G.f1Nibble({ ...base, mode: 'output-pp', speed: 'medium' }).nibble, 0b0001);
  assert.equal(G.f1Nibble({ ...base, mode: 'output-pp', speed: 'high' }).nibble, 0b0011);
  assert.equal(G.f1Nibble({ ...base, mode: 'output-od', speed: 'low' }).nibble, 0b0110);
  assert.equal(G.f1Nibble({ ...base, mode: 'af-pp', speed: 'low' }).nibble, 0b1010);
  assert.equal(G.f1Nibble({ ...base, mode: 'input', pull: 'none' }).nibble, 0b0100);
  assert.equal(G.f1Nibble({ ...base, mode: 'analog' }).nibble, 0b0000);
});

test('F1 上拉与下拉共用同一个 CRL 编码，区别在 ODR 位', () => {
  const chip = getChip('f103rc');
  const base = { ...G.DEFAULT_CONFIG, mode: 'input' };
  const up = G.registers(chip, 'PA0', { ...base, pull: 'up' });
  const down = G.registers(chip, 'PA0', { ...base, pull: 'down' });
  assert.equal(up.rows[0].value, down.rows[0].value, 'CRL 编码相同');
  assert.equal(up.rows[1].value, '0x00000001', '上拉时 ODR0=1');
  assert.equal(down.rows[1].value, '0x00000000', '下拉时 ODR0=0');
});

test('F1 按引脚编号选择 CRL 或 CRH', () => {
  const chip = getChip('f103rc');
  const cfg = { ...G.DEFAULT_CONFIG, mode: 'output-pp', speed: 'low' };
  assert.equal(G.registers(chip, 'PC0', cfg).rows[0].name, 'GPIOC->CRL');
  assert.equal(G.registers(chip, 'PC8', cfg).rows[0].name, 'GPIOC->CRH');
  assert.equal(G.registers(chip, 'PC8', cfg).rows[0].fieldAt, 0);
  assert.equal(G.registers(chip, 'PC7', cfg).rows[0].fieldAt, 28);
});

test('F4 的 MODER/PUPDR 编码与手册一致', () => {
  const chip = getChip('f407ve');
  const out = G.registers(chip, 'PB0', { ...G.DEFAULT_CONFIG, mode: 'output-pp', speed: 'low' });
  assert.equal(out.rows[0].value, '0x00000001', 'MODER0=01 输出');
  const inn = G.registers(chip, 'PB0', { ...G.DEFAULT_CONFIG, mode: 'input', pull: 'up' });
  assert.equal(inn.rows[0].value, '0x00000000', 'MODER0=00 输入');
  assert.equal(inn.rows[3].value, '0x00000001', 'PUPDR0=01 上拉');
  const pc13 = G.registers(chip, 'PC13', { ...G.DEFAULT_CONFIG, mode: 'output-pp' });
  assert.equal(pc13.rows[0].fieldAt, 26);
});

test('开漏写 1 是高阻，低电平有效 LED 由低电平点亮', () => {
  const chip = getChip('f103rc');
  assert.equal(G.pinLevel({ ...G.DEFAULT_CONFIG, mode: 'output-od', level: 'high' }, 'none'), 'FLOATING');
  assert.equal(G.ledOn(chip, G.pinLevel({ ...G.DEFAULT_CONFIG, mode: 'output-pp', level: 'low' }, 'none')), true);
  assert.equal(G.ledOn(chip, G.pinLevel({ ...G.DEFAULT_CONFIG, mode: 'output-pp', level: 'high' }, 'none')), false);
  const f4 = getChip('f407ve');
  assert.equal(G.ledOn(f4, 'HIGH'), true, 'F407 演示板 LED 是高电平有效');
});

test('生成的 HAL 代码包含开时钟、模式与写电平', () => {
  const code = G.halCode(getChip('f103rc'), 'PA1', { ...G.DEFAULT_CONFIG, mode: 'output-pp', level: 'low' });
  assert.match(code, /__HAL_RCC_GPIOA_CLK_ENABLE\(\)/);
  assert.match(code, /GPIO_PIN_1/);
  assert.match(code, /GPIO_MODE_OUTPUT_PP/);
  assert.match(code, /GPIO_PIN_RESET/);
});

test('消抖：260ms 按下判为单击，900ms 判为长按', () => {
  const click = simulateDebounce({ pressMs: 260 });
  assert.equal(click.verdict, '单击');
  assert.ok(click.heldMs >= 260 && click.heldMs <= 300, '按下时长约等于设置值：' + click.heldMs);
  const long = simulateDebounce({ pressMs: 900 });
  assert.equal(long.verdict, '长按');
  const types = long.events.map(e => e.type);
  assert.deepEqual(types, ['press', 'release', 'long']);
});

test('消抖：抖动很强且按下很短时不会误判成单击', () => {
  const sim = simulateDebounce({ pressMs: 5, bounceMs: 20, sampleMs: 10, need: 4 });
  assert.notEqual(sim.verdict, '单击');
  assert.equal(sim.theoryMs, 40);
});

test('定时器公式：72MHz、PSC=71、ARR=999 → 1kHz', () => {
  const chip = getChip('f103rc');
  const r = pwm(chip, { psc: 71, arr: 999, ccr: 250 });
  assert.equal(r.freqHz, 1000);
  assert.equal(r.duty, 0.25);
  assert.equal(r.periodTicks, 1000);
  assert.equal(r.prescaler, 72);
  assert.equal(brightness(r.duty), 25);
});

test('定时器边界：ARR=0 与 CCR>ARR', () => {
  const chip = getChip('f103rc');
  const a = pwm(chip, { psc: 71, arr: 0, ccr: 1 });
  assert.equal(a.freqHz, 1000000);
  assert.equal(a.duty, 1);
  const b = pwm(chip, { psc: 71, arr: 999, ccr: 1500 });
  assert.equal(b.duty, 1);
  assert.equal(b.overflow, true);
});

test('F4 的定时器时钟按 APB1/APB2 取值', () => {
  const chip = getChip('f407ve');
  assert.equal(pwm(chip, { psc: 83, arr: 999, ccr: 500, bus: 'APB1' }).freqHz, 1000);
  assert.equal(pwm(chip, { psc: 167, arr: 999, ccr: 500, bus: 'APB2' }).freqHz, 1000);
});

test('题库数值题的正确答案与模型计算一致', () => {
  const q13 = QUIZ.find(q => q.id === 'q13');
  const expected = pwm({ clock: { timApb1: 72000000 } }, { psc: 71, arr: 999, ccr: 0 }).freqHz;
  assert.match(q13.opts[q13.answer], new RegExp(expected >= 1000 ? '1 kHz' : String(expected)));
  for (const q of QUIZ) {
    assert.ok(q.opts.length >= 3, q.id + ' 选项数量');
    assert.ok(q.answer >= 0 && q.answer < q.opts.length, q.id + ' 答案下标合法');
    assert.ok(new Set(q.opts).size === q.opts.length, q.id + ' 选项不重复');
  }
});

test('判分统计正确数与作答明细', () => {
  const answers = { q1: 1, q2: 0, q3: 0 };
  const r = gradeQuiz(answers);
  assert.equal(r.total, QUIZ.length);
  assert.equal(r.correct, 2);
  assert.equal(r.detail.find(d => d.id === 'q2').ok, false);
});
