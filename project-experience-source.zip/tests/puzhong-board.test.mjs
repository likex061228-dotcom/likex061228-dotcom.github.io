import test from 'node:test';
import assert from 'node:assert/strict';
import {getChip,findPin} from '../src/teach/data/chips.mjs';
import {registers,DEFAULT_CONFIG} from '../src/teach/model/gpio.mjs';
test('精灵1板卡引脚、封装与寄存器位置一致',()=>{
 const c=getChip('f103c8');assert.match(c.board,/普中/);assert.equal(c.demo.keyPin,'PA12');assert.equal(c.demo.ledPin,'PC13');
 assert.equal(findPin(c,'PC8'),null);assert.equal(c.pins.length,35);
 assert.match(findPin(c,'PA7').roles.join(' '),/LED8/);assert.match(findPin(c,'PA12').warn,/USB/);
 const led=registers(c,'PC13',{...DEFAULT_CONFIG,level:'high'});assert.ok(led.rows.some(r=>r.name==='GPIOC->CRH'&&r.value==='0x00200000'));assert.ok(led.rows.some(r=>r.name==='GPIOC->ODR'&&r.value==='0x00002000'));
 const key=registers(c,'PA12',{...DEFAULT_CONFIG,mode:'input',pull:'up'});assert.ok(key.rows.some(r=>r.name==='GPIOA->CRH'&&r.value==='0x00080000'));assert.ok(key.rows.some(r=>r.name==='GPIOA->ODR'&&r.value==='0x00001000'));
});
