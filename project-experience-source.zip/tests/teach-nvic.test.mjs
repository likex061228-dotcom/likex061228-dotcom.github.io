import test from 'node:test';
import assert from 'node:assert/strict';
import { simulateNvic, scenario, PRIORITY_GROUPS } from '../src/teach/model/nvic.mjs';
import { countEdges, simulateExti } from '../src/teach/model/edge.mjs';

test('数值越小的抢占优先级越高：后来的高优先级中断会打断正在执行的', () => {
  // TIM2 抢占=2（最低）先到；EXTI0 抢占=1 后到 → 打断；USART1 抢占=0 再到 → 再打断
  const r = simulateNvic(scenario({ preempt: [2, 1, 0] }));
  assert.equal(r.preemptions, 2);
  const names = r.timeline.map(s => s.name);
  assert.deepEqual(names, ['TIM2 更新中断', 'EXTI0 按键中断', 'USART1 接收中断', 'EXTI0 按键中断', 'TIM2 更新中断']);
});

test('数值更小的抢占优先级可以打断正在执行的中断', () => {
  // TIM 抢占优先级 0（最高），EXTI 抢占 1，USART 抢占 2
  const r = simulateNvic(scenario({ preempt: [0, 1, 2] }));
  // 先到的是 TIM，不会被打断；换成 EXTI 先到、TIM 后到会怎样：
  const tasks = [
    { id: 'a', name: 'EXTI0 按键中断', preempt: 1, sub: 0, arrive: 0, duration: 10 },
    { id: 'b', name: 'TIM2 更新中断', preempt: 0, sub: 0, arrive: 2, duration: 3 }
  ];
  const r2 = simulateNvic(tasks);
  assert.equal(r2.preemptions, 1);
  const segs = r2.timeline;
  assert.equal(segs[0].name, 'EXTI0 按键中断');
  assert.equal(segs[0].end, 2, '被打断的时刻');
  assert.equal(segs[1].name, 'TIM2 更新中断');
  assert.equal(segs[1].start, 2);
  assert.equal(segs[1].end, 5);
  assert.equal(segs[2].name, 'EXTI0 按键中断');
  assert.equal(segs[2].start, 5, '高优先级结束后继续');
});

test('抢占优先级相同时不嵌套，按子优先级排队', () => {
  const tasks = [
    { id: 'a', name: 'A', preempt: 0, sub: 2, arrive: 0, duration: 5 },
    { id: 'b', name: 'B', preempt: 0, sub: 1, arrive: 1, duration: 2 },
    { id: 'c', name: 'C', preempt: 0, sub: 3, arrive: 2, duration: 2 }
  ];
  const r = simulateNvic(tasks);
  const order = r.timeline.map(s => s.name);
  assert.deepEqual(order, ['A', 'B', 'C'], 'A 不被抢占，B 子优先级更高先执行，C 最后');
  assert.equal(r.preemptions, 0);
});

test('相同抢占与子优先级时先到先执行', () => {
  const tasks = [
    { id: 'a', name: 'A', preempt: 1, sub: 0, arrive: 0, duration: 3 },
    { id: 'b', name: 'B', preempt: 1, sub: 0, arrive: 1, duration: 3 }
  ];
  const r = simulateNvic(tasks);
  assert.deepEqual(r.timeline.map(s => s.name), ['A', 'B']);
});

test('优先级分组只影响可用的位数', () => {
  const g = PRIORITY_GROUPS.find(x => x.id === 'g4');
  assert.equal(g.preemptBits, 4);
  assert.equal(g.subBits, 0);
  const g0 = PRIORITY_GROUPS.find(x => x.id === 'g0');
  assert.equal(g0.preemptBits, 0, '全给子优先级时完全不抢占');
  const r = simulateNvic([
    { id: 'a', name: 'A', preempt: 0, sub: 1, arrive: 0, duration: 5 },
    { id: 'b', name: 'B', preempt: 0, sub: 0, arrive: 1, duration: 2 }
  ]);
  assert.equal(r.preemptions, 0);
});

test('EXTI：不消抖时一次按键会触发多次边沿，消抖后只剩一次', () => {
  const raw = simulateExti({ bounceMs: 12, pressMs: 300, edge: 'falling', debounce: false });
  const stable = simulateExti({ bounceMs: 12, pressMs: 300, edge: 'falling', debounce: true });
  assert.ok(raw.isrCount >= 2, '抖动应产生多次下降沿：' + raw.isrCount);
  assert.equal(stable.isrCount, 1, '消抖后只应有一次下降沿');
});

test('上升沿与下降沿计数对称', () => {
  const pts = [{ t: 0, v: 1 }, { t: 1, v: 0 }, { t: 2, v: 1 }, { t: 3, v: 0 }];
  assert.equal(countEdges(pts, 'falling'), 2);
  assert.equal(countEdges(pts, 'rising'), 1);
  assert.equal(countEdges(pts, 'both'), 3);
});
