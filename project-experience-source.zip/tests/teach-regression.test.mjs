import test from 'node:test';
import assert from 'node:assert/strict';
import { registers, DEFAULT_CONFIG } from '../src/teach/model/gpio.mjs';
import { getChip } from '../src/teach/data/chips.mjs';
import { simulateNvic, scenario } from '../src/teach/model/nvic.mjs';

const task = (id, preempt, arrive, duration, sub = 0, irq) => ({ id, name: id, preempt, sub, arrive, duration, ...(irq === undefined ? {} : { irq }) });
function check(tasks, result) {
  let end = 0;
  for (const seg of result.timeline) {
    assert.ok(Number.isFinite(seg.start) && Number.isFinite(seg.end));
    assert.ok(seg.start >= end && seg.end > seg.start);
    end = seg.end;
  }
  for (const t of tasks) {
    const segments = result.timeline.filter(s => s.id === t.id);
    assert.equal(segments.reduce((sum, s) => sum + s.end - s.start, 0), t.duration);
    assert.equal(result.latency.find(l => l.id === t.id).latency, segments[0].start - t.arrive);
  }
  assert.equal(result.end, end);
  assert.ok(result.events.every((e, i, all) => Number.isFinite(e.t) && (!i || e.t >= all[i - 1].t)));
}
test('GPIO output latch follows requested high/low and top register fields are unsigned', () => {
  for (const mode of ['output-pp', 'output-od']) {
    for (const level of ['high', 'low']) {
      const r = registers(getChip('f103rc'), 'PC0', { ...DEFAULT_CONFIG, mode, level });
      assert.equal(r.rows[1].value, level === 'high' ? '0x00000001' : '0x00000000');
    }
  }
  assert.equal(registers(getChip('f103rc'), 'PC7', { ...DEFAULT_CONFIG, mode: 'af-pp', speed: 'high' }).rows[0].value, '0xB0000000');
  assert.equal(registers(getChip('f407ve'), 'PC15', { ...DEFAULT_CONFIG, mode: 'analog' }).rows[0].value, '0xC0000000');
});
test('queued interrupts preserve finite durations and exact waiting time', () => {
  const tasks = [task('a', 0, 0, 5), task('b', 1, 1, 2), task('c', 2, 2, 3)];
  const r = simulateNvic(tasks);
  check(tasks, r);
  assert.deepEqual(r.latency.map(l => l.latency), [0, 4, 5]);
});
test('simultaneous arrivals arbitrate before starting or preempting', () => {
  for (const tasks of [[task('a', 2, 0, 6), task('b', 1, 0, 2), task('c', 0, 0, 1)], [task('a', 2, 0, 6), task('b', 1, 2, 2), task('c', 0, 2, 1)]]) {
    const r = simulateNvic(tasks);
    check(tasks, r);
    assert.equal(r.preemptions, tasks[1].arrive === 0 ? 0 : 1);
  }
});
test('nested interruptions resume active lower handlers before equal-priority pending handlers', () => {
  const tasks = [task('a', 2, 0, 6), task('b', 1, 2, 4), task('c', 0, 3, 3), task('d', 1, 4, 1, 0)];
  const r = simulateNvic(tasks);
  check(tasks, r);
  assert.deepEqual(r.timeline.map(s => s.id), ['a', 'b', 'c', 'b', 'd', 'a']);
  const original = scenario();
  check(original, simulateNvic(original));
});
test('pending equal priorities use IRQ number, with deterministic id fallback', () => {
  for (const tasks of [[task('z', 1, 0, 1, 0, 2), task('a', 1, 0, 1, 0, 9)], [task('z', 1, 0, 1), task('a', 1, 0, 1)]]) {
    const r = simulateNvic(tasks);
    check(tasks, r);
    assert.equal(r.timeline[0].id, tasks[0].irq === undefined ? 'a' : 'z');
  }
});
test('invalid or unbounded simulation inputs are rejected', () => {
  for (const changes of [{ arrive: NaN }, { arrive: Infinity }, { arrive: -1 }, { arrive: 0.1 }, { duration: 0 }, { duration: -1 }, { duration: 0.1 }, { duration: Infinity }, { duration: 1e100 }, { preempt: 16 }, { preempt: 0.5 }, { sub: -1 }, { irq: NaN }]) {
    assert.throws(() => simulateNvic([{ ...task('a', 0, 0, 1), ...changes }]));
  }
  assert.throws(() => simulateNvic([task('a', 0, 0, 1), task('a', 1, 0, 1)]));
  assert.throws(() => simulateNvic(Array.from({ length: 1001 }, (_, i) => task(String(i), 0, 0, 1))));
  assert.deepEqual(simulateNvic([]).timeline, []);
});
