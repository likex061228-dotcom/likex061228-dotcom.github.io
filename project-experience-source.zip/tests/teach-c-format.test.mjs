import test from 'node:test';
import assert from 'node:assert/strict';
import { formatOne, parseSpec, FORMAT_PRESETS } from '../src/teach/model/format.mjs';

const out = (spec, value) => {
  const r = formatOne(spec, value);
  assert.ok(r.ok, spec + ' 应该能格式化：' + r.error);
  return r.output;
};

test('整数：默认、宽度、左对齐、零填充', () => {
  assert.equal(out('%d', 42), '42');
  assert.equal(out('%5d', 42), '   42');
  assert.equal(out('%-5d', 42), '42   ');
  assert.equal(out('%05d', 42), '00042');
  assert.equal(out('%3d', 12345), '12345', '超出宽度不截断');
});

test('负数的零填充把符号放在最前', () => {
  assert.equal(out('%05d', -42), '-0042');
  assert.equal(out('%-5d', -42), '-42  ');
});

test('浮点：默认 6 位、精度与宽度组合', () => {
  assert.equal(out('%f', 1.2), '1.200000');
  assert.equal(out('%.2f', 3.14159), '3.14');
  assert.equal(out('%8.3f', 3.14159), '   3.142');
  assert.equal(out('%-8.3f', 3.14159), '3.142   ');
});

test('十六进制、字符、字符串与百分号', () => {
  assert.equal(out('%x', 255), 'ff');
  assert.equal(out('%X', 255), 'FF');
  assert.equal(out('%c', 65), 'A');
  assert.equal(out('%c', 'z'), 'z');
  assert.equal(out('%s', 'abc'), 'abc');
  assert.equal(out('%%', ''), '%');
});

test('非法格式与非法值给出可读错误', () => {
  assert.equal(formatOne('%7.2f', 1).ok, true, 'scanf 的限制不影响 printf');
  assert.equal(formatOne('%q', 1).ok, false);
  assert.equal(formatOne('d', 1).ok, false);
  assert.equal(formatOne('%d', 'abc').ok, false);
});

test('解析出的修饰符与 C 语义一致', () => {
  assert.deepEqual(parseSpec('%-8.3f'), { left: true, zero: false, width: 8, precision: 3, conv: 'f' });
  assert.deepEqual(parseSpec('%05d'), { left: false, zero: true, width: 5, precision: null, conv: 'd' });
  assert.equal(parseSpec('hello'), null);
  for (const p of FORMAT_PRESETS) assert.ok(parseSpec(p), p + ' 应该是合法预设');
});
