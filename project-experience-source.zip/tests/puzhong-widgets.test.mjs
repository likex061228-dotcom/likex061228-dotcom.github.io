import test from 'node:test';
import assert from 'node:assert/strict';
import {getChip} from '../src/teach/data/chips.mjs';
import {registers} from '../src/teach/model/gpio.mjs';
import {FAULTS,evaluateLed} from '../src/teach/model/led-lesson.mjs';
import {counterState} from '../src/teach/model/workshop.mjs';
test('PC13 lesson fault identifies CRH field, and repaired output lights D2',()=>{
 const f=FAULTS.find(f=>f.id==='mode');assert.match(f.evidence,/CRH\[23:20\]/);assert.match(f.evidence,/PC13/);
 assert.equal(evaluateLed(f.repaired).led,'on');
 const r=registers(getChip('f103c8'),'PC13',{mode:'output-pp',speed:'low',pull:'none',level:'high'});
 assert.ok(r.rows.some(x=>x.name==='GPIOC->CRH'&&x.value==='0x00200000'));
 assert.ok(r.rows.some(x=>x.name==='GPIOC->ODR'&&x.value==='0x00002000'));
});
test('low-polarity PWM mode1 makes LED8 on for CCR/period, high reverses it',()=>{
 for(const ccr of [0,250,750,1000]){
  const c={timerHz:72000000,psc:71,arr:999,ccr,polarity:'low'};
  const a=counterState(c);assert.equal(a.litDuty,ccr/1000);
  assert.equal(counterState({...c,counts:0}).pinHigh,ccr===0);
  assert.equal(counterState({...c,polarity:'high'}).highDuty,ccr/1000);
 }
});

import {extiWorkshop} from '../src/teach/widgets/signal-workshops.mjs';
import {pwmWorkshop} from '../src/teach/widgets/timer-workshops.mjs';
import {mcuCodeviz} from '../src/teach/widgets/mcu-codeviz.mjs';
// Minimal DOM adapter exercises real event handlers without running animations.
function hostStub(dataset={}){
 const nodes=new Map();
 const host={dataset,innerHTML:'',textContent:'',style:{},classList:{add(){}},setAttribute(){},querySelector(selector){
  if(!nodes.has(selector))nodes.set(selector,hostStub());return nodes.get(selector);
 },querySelectorAll(){return[];}};
 return host;
}
function withBrowserStubs(run){
 const original={document:globalThis.document,localStorage:globalThis.localStorage,cancelAnimationFrame:globalThis.cancelAnimationFrame};
 globalThis.document={addEventListener(){},removeEventListener(){}};
 globalThis.localStorage={getItem(){return null;},setItem(){}};globalThis.cancelAnimationFrame=()=>{};
 try{run();}finally{for(const [k,v]of Object.entries(original))if(v===undefined)delete globalThis[k];else globalThis[k]=v;}
}
test('mounted EXTI workshop routes PA12 through line12 and services one callback',()=>withBrowserStubs(()=>{
 const h=hostStub();extiWorkshop(h);
 assert.match(h.innerHTML,/GPIOA → PA12/);assert.match(h.querySelector('.ws-code-host').innerHTML,/EXTI15_10_IRQHandler/);
 h.querySelector('[data-edge]').onclick();assert.equal(h.querySelector('[data-service]').disabled,false);
 h.querySelector('[data-service]').onclick();assert.match(h.querySelector('.ws-results').innerHTML,/已执行回调<\/dt><dd>1 /);
 assert.match(h.querySelector('.ws-code-host').innerHTML,/GPIO_PIN_12/);
}));
test('mounted PWM workshop defaults to CH2 Low and displays 75 percent high, 25 percent LED',()=>withBrowserStubs(()=>{
 const h=hostStub();pwmWorkshop(h);
 const code=h.querySelector('.ws-code-host').innerHTML;
 assert.match(code,/TIM_CHANNEL_2/);assert.match(code,/TIM_OCPOLARITY_LOW/);
 assert.match(h.querySelector('.ws-results').innerHTML,/引脚高电平<\/dt><dd>75 /);
 assert.match(h.querySelector('.ws-results').innerHTML,/低有效LED导通<\/dt><dd>25 /);
 h.querySelector('[data-step]').onclick();assert.match(h.querySelector('.ws-code-host').innerHTML,/CCR2/);h._cleanup();
}));
test('code visualizer writes bit13 and initializes CRH; input uses GPIOA bit12',()=>withBrowserStubs(()=>{
 const out=hostStub({mode:'output'});mcuCodeviz(out);
 for(let i=0;i<7;i++)out.querySelector('[data-act="next"]').onclick();
 assert.match(out.innerHTML,/GPIOC-&gt;CRH/);assert.match(out.innerHTML,/0x00200000/);assert.match(out.innerHTML,/GPIO_PIN_13/);
 const input=hostStub({mode:'input'});mcuCodeviz(input);
 for(let i=0;i<6;i++)input.querySelector('[data-act="next"]').onclick();
 assert.match(input.innerHTML,/GPIOA-&gt;ODR/);assert.match(input.innerHTML,/0x00001000/);assert.match(input.innerHTML,/HAL_GPIO_ReadPin\(GPIOA, GPIO_PIN_12\)/);
}));
