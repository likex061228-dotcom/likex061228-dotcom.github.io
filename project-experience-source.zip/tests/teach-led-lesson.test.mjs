import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateLed, diagnoseFault, FAULTS } from '../src/teach/model/led-lesson.mjs';
const base={clock:true,mode:'output-pp',level:'low',pullup:false,external:'none'};
test('low-active LED follows resolved pad, not output word',()=>{
 assert.deepEqual(['low','high'].map(level=>evaluateLed({...base,level}).led),['on','off']);
 assert.equal(evaluateLed({...base,level:'high'}).odr,1);
});
test('open drain release needs a separate pull-up to determine HIGH',()=>{
 const released=evaluateLed({...base,mode:'output-od',level:'high'});
 assert.equal(released.drive,'Z');assert.equal(released.pad,'UNKNOWN');assert.equal(released.led,'unknown');
 const pulled=evaluateLed({...base,mode:'output-od',level:'high',pullup:true});
 assert.equal(pulled.pad,'HIGH');assert.equal(pulled.led,'off');
 assert.equal(evaluateLed({...base,mode:'output-od'}).led,'on');
});
test('input mode cannot light the LED by writing a latch alone',()=>{
 const r=evaluateLed({...base,mode:'input'});assert.equal(r.drive,'Z');assert.equal(r.pad,'UNKNOWN');assert.equal(r.led,'unknown');
});
test('external strong drive can override release, opposing strong outputs are conflicts',()=>{
 assert.equal(evaluateLed({...base,mode:'input',external:'low'}).led,'on');
 assert.equal(evaluateLed({...base,external:'high'}).pad,'CONFLICT');
 assert.equal(evaluateLed({...base,level:'high',external:'low'}).led,'unknown');
});
test('disabled GPIO clock blocks this initialization exercise without inventing a pad result',()=>{
 const r=evaluateLed({...base,clock:false});assert.equal(r.applied,false);assert.equal(r.pad,'UNKNOWN');assert.equal(r.led,'unknown');assert.equal(r.odr,null);
});
test('invalid teaching states are rejected',()=>{
 assert.throws(()=>evaluateLed({...base,level:'middle'}));assert.throws(()=>evaluateLed({...base,mode:'af'}));
});
test('diagnosis uses a selected observation and repair reaches requested lit output',()=>{
 for(const f of FAULTS){assert.equal(diagnoseFault(f.id,'guess').correct,false);assert.equal(diagnoseFault(f.id,f.check).correct,true);assert.equal(evaluateLed(f.repaired).led,'on');}
});
