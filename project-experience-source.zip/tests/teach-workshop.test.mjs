import test from 'node:test';
import assert from 'node:assert/strict';
import { runButton, extiSequence, advanceExti, counterState, nvicGrouped } from '../src/teach/model/workshop.mjs';

test('button deterministic, classifies at release and filters short pulses', () => {
  const a = runButton();
  assert.deepEqual(a, runButton());
  assert.equal(a.verdict, '单击');
  assert.equal(a.events.find(e => e.type === 'click').t, a.events.find(e => e.type === 'release').t);
  assert.equal(runButton({ pressMs: 4, bounceMs: 0 }).events.length, 0);
  for (const sampleMs of [0, -1, NaN, Infinity]) assert.throws(() => runButton({ sampleMs }), RangeError);
});

test('EXTI sequence filtering and single pending bit', () => {
  assert.equal(extiSequence({ filter: true, edge: 'both' }).edges.length, 2);
  assert.ok(extiSequence({ edge: 'both' }).edges.length > 2);
  const initial = { pending: false, callbacks: 0, coalesced: 0, enabled: false, unmasked: true };
  let s = advanceExti(initial, { type: 'edge', time: 0 });
  s = advanceExti(s, { type: 'edge', time: 1 });
  assert.equal(s.coalesced, 1);
  assert.equal(advanceExti(s, { type: 'service', time: 2 }).callbacks, 0);
  s = advanceExti({ ...s, enabled: true }, { type: 'service', time: 3 });
  assert.equal(s.callbacks, 1); assert.equal(s.pending, false);
  assert.equal(initial.pending, false);
  const masked = advanceExti({ ...initial, enabled: true, unmasked: false }, { type: 'edge', time: 0 });
  assert.equal(masked.pending, true);
  assert.equal(advanceExti(masked, { type: 'service', time: 1 }).callbacks, 0);
  const delivered = advanceExti({ ...masked, unmasked: true }, { type: 'service', time: 2 });
  assert.equal(delivered.callbacks, 1);
  assert.equal(delivered.pending, false);
  assert.equal(advanceExti({ ...initial, pending: true }, { type: 'clear', time: 0 }).pending, false);
});

test('EXTI request and NVIC pending are distinct latched flags', () => {
  const initial = { pending: false, enabled: true, unmasked: true };
  const edge = advanceExti(initial, { type: 'edge' });
  assert.equal(edge.nvicPending, true);
  const maskedAfter = advanceExti({ ...edge, unmasked: false }, { type: 'service' });
  assert.equal(maskedAfter.services, 1);
  assert.equal(maskedAfter.callbacks, 1);
  const cleared = advanceExti(edge, { type: 'clear' });
  assert.equal(cleared.pending, false);
  assert.equal(cleared.nvicPending, true);
  const emptyEntry = advanceExti(cleared, { type: 'service' });
  assert.equal(emptyEntry.services, 1);
  assert.equal(emptyEntry.callbacks, 0);
  assert.equal(emptyEntry.nvicPending, false);
  const maskedBefore = advanceExti({ ...initial, unmasked: false }, { type: 'edge' });
  assert.equal(maskedBefore.pending, true);
  assert.equal(maskedBefore.nvicPending, false);
  assert.equal(advanceExti({ ...maskedBefore, unmasked: true }, { type: 'sync' }).nvicPending, true);
  const disabled = advanceExti({ ...initial, enabled: false }, { type: 'edge' });
  assert.equal(disabled.nvicPending, true);
  assert.equal(advanceExti(disabled, { type: 'service' }).services, 0);
});

test('timer overflow and PWM boundaries/polarities', () => {
  assert.equal(counterState({ counts: 999 }).cnt, 999);
  assert.equal(counterState({ counts: 1000 }).cnt, 0);
  assert.equal(counterState({ counts: 3123 }).updates, 3);
  assert.equal(counterState({ counts: 3123 }).cnt, 123);
  assert.equal(counterState().frequencyHz, 1000);
  assert.equal(counterState().tickUs, 1);
  assert.equal(counterState({ ccr: 0 }).highDuty, 0);
  assert.equal(counterState({ ccr: 1000 }).highDuty, 1);
  assert.equal(counterState({ ccr: 1000, polarity: 'low' }).highDuty, 0);
  assert.equal(counterState({ counts: 249 }).pinHigh, true);
  assert.equal(counterState({ counts: 250 }).pinHigh, false);
  assert.equal(counterState().litDuty, .75);
  assert.equal(counterState({ arr: 65535, ccr: 65535 }).highDuty, 65535 / 65536);
  assert.throws(() => counterState({ arr: 65535, ccr: 65536 }), RangeError);
  assert.throws(() => counterState({ counts: .5 }), RangeError);
  for (const timerHz of [0, Number.MIN_VALUE]) assert.throws(() => counterState({ timerHz }), RangeError);
  for (const value of Object.values(counterState({ timerHz: 1, psc: 65535, arr: 65535, counts: 1e9 }))) {
    if (typeof value === 'number') assert.ok(Number.isFinite(value));
  }
});

test('NVIC group enforces bit ranges and preserves duration/IRQ ordering', () => {
  const tasks = [
    { id: 'b', name: 'B', preempt: 0, sub: 0, irq: 9, arrive: 0, duration: 4 },
    { id: 'a', name: 'A', preempt: 0, sub: 0, irq: 2, arrive: 0, duration: 2 }
  ];
  const s = nvicGrouped(tasks);
  assert.deepEqual(s.group, { preemptBits: 2, subBits: 2 });
  assert.equal(s.timeline[0].id, 'a');
  assert.equal(s.timeline.reduce((n, x) => n + x.end - x.start, 0), 6);
  assert.equal(s.preemptions, 0);
  assert.throws(() => nvicGrouped([{ ...tasks[0], preempt: 4 }]), /0.*3/);
  assert.throws(() => nvicGrouped([{ ...tasks[0], sub: 1 }], 'g4'), RangeError);
  assert.throws(() => nvicGrouped(tasks, 'invalid'), RangeError);
});
