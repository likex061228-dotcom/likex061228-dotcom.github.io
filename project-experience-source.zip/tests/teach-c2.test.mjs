import test from 'node:test';
import assert from 'node:assert/strict';
import { bubbleSteps, selectionSteps, insertionSteps, factTrace, stringCells, manualStrlen, compareStrings, arrayFacts } from '../src/teach/model/c2.mjs';

const cases = [
  [6, 3, 2, 7, 5],
  [1],
  [2, 2, 1],
  [5, 4, 3, 2, 1],
  [1, 2, 3, 4, 5]
];

test('三种排序都得到正确结果，且不修改输入', () => {
  for (const input of cases) {
    const copy = input.slice();
    for (const fn of [bubbleSteps, selectionSteps, insertionSteps]) {
      const r = fn(input);
      assert.deepEqual(r.result, [...input].sort((a, b) => a - b), fn.name + ' 结果');
      assert.deepEqual(input, copy, fn.name + ' 不应修改原数组');
      assert.ok(r.steps.length > 0);
    }
  }
});

test('冒泡排序的每一步数组长度不变，最后一步等于结果', () => {
  const r = bubbleSteps([6, 3, 2, 7, 5]);
  for (const s of r.steps) assert.equal(s.arr.length, 5);
  assert.deepEqual(r.steps[r.steps.length - 1].arr, r.result);
  assert.ok(r.comparisons >= 4);
});

test('已有序数组：冒泡会提前结束，比较次数少于逆序', () => {
  const sorted = bubbleSteps([1, 2, 3, 4, 5]);
  const reversed = bubbleSteps([5, 4, 3, 2, 1]);
  assert.ok(sorted.comparisons < reversed.comparisons);
  assert.ok(sorted.steps.some(s => s.kind === 'early'));
});

test('选择排序的交换次数不超过 n-1，插入排序的 shifting 次数合理', () => {
  const sel = selectionSteps([5, 4, 3, 2, 1]);
  assert.ok(sel.swaps <= 4);
  const ins = insertionSteps([5, 4, 3, 2, 1]);
  assert.equal(ins.result.join(','), '1,2,3,4,5');
  assert.ok(ins.shifts >= 4);
});

test('阶乘递归：结果正确，栈深度与步骤单调', () => {
  const r = factTrace(5);
  assert.equal(r.result, 120);
  assert.equal(r.depth, 6);
  const maxDepth = Math.max(...r.steps.map(s => s.stack.length));
  assert.equal(maxDepth, 6, '最深时有 fact(5)…fact(0) 六层');
  assert.ok(r.steps[r.steps.length - 1].stack.length === 0, '结束时应全部返回');
  assert.ok(r.steps.some(s => s.note.includes('fact(0) = 1')));
  assert.equal(factTrace(0).result, 1);
});

test('字符串：字符单元以 \\0 结尾，长度不包含终止符', () => {
  const cells = stringCells('hello');
  assert.equal(cells.length, 6);
  assert.equal(cells[5].terminator, true);
  assert.equal(cells[5].ch, '\\0');
  assert.equal(manualStrlen('hello'), 5);
  assert.equal(manualStrlen(''), 0);
});

test('字符串比较与 C 的 strcmp 语义一致', () => {
  assert.ok(compareStrings('abc', 'abd') < 0);
  assert.ok(compareStrings('abd', 'abc') > 0);
  assert.equal(compareStrings('abc', 'abc'), 0);
  assert.ok(compareStrings('ab', 'abc') < 0, '前缀更短时更小');
});

test('数组元信息：sizeof 与下标', () => {
  const f = arrayFacts([1, 2, 3, 4, 5]);
  assert.equal(f.length, 5);
  assert.equal(f.lastIndex, 4);
  assert.equal(f.sizeofArray, 20);
  assert.equal(f.sizeofElement, 4);
});
