#ifndef __APP_MAIN_H
#define __APP_MAIN_H
#include "main.h"
void App_Init(void);
void App_Loop(void);
/* Optional debugger-triggered demonstration; no external button needed. */
void App_ApplyPattern(uint8_t req);
#endif
