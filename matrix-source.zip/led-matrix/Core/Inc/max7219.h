/**
 ******************************************************************************
 * @file    max7219.h
 * @brief   4 片 MAX7219 级联驱动 8×32 单色点阵
 * @note    帧缓冲布局： buf[col * MATRIX_ROWS + row]
 *            col = 0..31  左 → 右
 *            row = 0..7   上 → 下
 *            bit0 = 最上面一行（MAX7219 的 DIG0），bit7 = 最下面一行
 *          该布局的好处：一个 uint8_t 正好是「一片 MAX7219 的一列」，
 *          刷新时直接顺序发给菊花链即可，无需任何位重排。
 ******************************************************************************
 */
#ifndef __MAX7219_H
#define __MAX7219_H

#include "main.h"
#include "config.h"

/* ---- MAX7219 寄存器 ---- */
#define MAX7219_REG_NOOP        (0x00U)
#define MAX7219_REG_DIGIT0      (0x01U)
#define MAX7219_REG_DECODE      (0x09U)
#define MAX7219_REG_INTENSITY   (0x0AU)
#define MAX7219_REG_SCANLIMIT   (0x0BU)
#define MAX7219_REG_SHUTDOWN    (0x0CU)
#define MAX7219_REG_DISPTEST    (0x0FU)

/** 帧缓冲：驱动内部维护，应用层只读/只经 API 修改 */
extern uint8_t LED_Buf[MATRIX_COLS * MATRIX_ROWS];

/* --------------------------------------------------------------------------
 *  初始化 / 刷新
 * ------------------------------------------------------------------------ */

/**
 * @brief  上电初始化 4 片 MAX7219
 * @note   关闭译码、8 行扫描、正常模式、设定亮度；末尾清屏。
 */
void MAX7219_Init(void);

/**
 * @brief  把帧缓冲推到点阵
 * @note   逐行发送，每个寄存器一次片选发 4 字节（4 片同一寄存器），
 *         8 行 × 1 次片选 = 8 次片选即可刷完整屏。
 */
void LED_Refresh(void);

/** @brief 强制下次 LED_Refresh() 全量重发（初始化/异常恢复后调用） */
void LED_Invalidate(void);

/**
 * @brief  直接给全部 4 片写同一个寄存器（绕过影子寄存器优化）
 * @param  addr  寄存器地址，如 0x0C = SHUTDOWN、0x0F = DISPLAY TEST
 * @param  value 寄存器值
 * @note   排障专用：诊断时可以反复发送，不受 LED_Refresh() 的
 *         「画面没变就不发」优化影响。正常业务代码不要用它。
 */
void MAX7219_WriteReg(uint8_t addr, uint8_t value);

/* --------------------------------------------------------------------------
 *  帧缓冲操作（只改内存，不碰硬件；改完调用 LED_Refresh()）
 * ------------------------------------------------------------------------ */

/** 清空帧缓冲 */
void LED_Clear(void);

/** 整屏点亮（自检用） */
void LED_FillAll(void);

/**
 * @brief  设置/清除一个像素
 * @param  col 列 0..31
 * @param  row 行 0..7
 * @param  on  1=点亮, 0=熄灭
 */
void LED_SetPixel(uint8_t col, uint8_t row, uint8_t on);

/** @brief 读取一个像素（越界返回 0） */
uint8_t LED_GetPixel(uint8_t col, uint8_t row);

/** @brief 点亮/熄灭一整行（col_mask 的 bit n 对应列 n） */
void LED_SetRowMask(uint8_t row, uint32_t col_mask);

/** @brief 点亮/熄灭一整列 */
void LED_SetCol(uint8_t col, uint8_t value);

/* --------------------------------------------------------------------------
 *  灰度缓冲（用于「弹跳拖影」的视觉效果，可选）
 * ------------------------------------------------------------------------ */

/**
 * @brief  把灰度缓冲按阈值二值化写入帧缓冲
 * @param  gray  灰度缓冲，长度 MATRIX_COLS*MATRIX_ROWS，每格 0..255
 * @param  thr   阈值，>= thr 点亮
 */
void LED_GrayToBuf(const uint8_t *gray, uint8_t thr);

#endif /* __MAX7219_H */
