#ifndef MOTION_H
#define MOTION_H
#include <stdint.h>
typedef enum { MOTION_NONE, MOTION_TAP, MOTION_SHAKE } MotionEvent;
typedef struct {
    float baseline,peak,strength;
    uint32_t started,last_event,boot,high_started;
    uint8_t active,shake_sent,have_event,high_active;
} MotionState;
void Motion_Init(MotionState *s,uint32_t now);
MotionEvent Motion_Update(MotionState *s,float magnitude,uint32_t now);
void Motion_Gravity(float ax,float ay,float az,float *gx,float *gy);
typedef struct {
    uint32_t inverted_since,held_ms,released_at;
    uint8_t phase;
} FlipState;
void Flip_Init(FlipState *s);
/* One event only after face-down hold >=1.5s followed by face-up return. */
uint8_t Flip_Update(FlipState *s,float az,uint32_t now);
#endif
