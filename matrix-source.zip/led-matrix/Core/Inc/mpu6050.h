/**
 ******************************************************************************
 * @file    mpu6050.h
 * @brief   MPU6050 六轴姿态传感器（软件 I2C：SCL=PB6, SDA=PB7）
 * @note    为什么用软件 I2C：
 *          1) 接口就是普通 GPIO，接线任意、不受硬件 I2C 复用限制；
 *          2) 单个从机、速率要求低（每帧只读 14 字节），完全够用；
 *          3) 出问题时用示波器/逻辑分析仪抓 PB6/PB7 即可，便于赛场排障。
 ******************************************************************************
 */
#ifndef __MPU6050_H
#define __MPU6050_H

#include "main.h"
#include <stdint.h>

/* ---- 从机地址（AD0 接地 = 0x68，接 VCC = 0x69） ---- */
#define MPU6050_ADDR_7BIT   (0x68U)

/* ---- 对外暴露的传感器数据结构 ---- */
typedef struct {
    int16_t Accel_X_RAW;
    int16_t Accel_Y_RAW;
    int16_t Accel_Z_RAW;
    int16_t Gyro_X_RAW;
    int16_t Gyro_Y_RAW;
    int16_t Gyro_Z_RAW;

    float Ax, Ay, Az;              /* 单位 g      */
    float Gx, Gy, Gz;              /* 单位 度/秒  */
    float Temperature;             /* 单位 ℃      */

    /* 卡尔曼融合后的姿态角（度） */
    float AngleRoll;               /* 绕传感器 X 轴 */
    float AnglePitch;
    float AngleYaw;                /* 仅陀螺积分，会缓慢漂移，本工程不用 */

    /* 上电零偏（校准后写入） */
    float GyroBiasX, GyroBiasY, GyroBiasZ;

    /* 派生量：便于主逻辑直接使用 */
    float AccMag;                  /* 加速度矢量模值 (g)，1.0 = 静止 */
    float VertAcc;                 /* AccMag - 1.0，竖直抖动强度     */
} MPU6050_t;

/* 兼容旧工程命名 */
typedef MPU6050_t MPU6050_Data_t;

/* --------------------------------------------------------------------------
 *  API
 * ------------------------------------------------------------------------ */

/**
 * @brief  初始化 MPU6050（配置软件 I2C 引脚 + 唤醒 + 量程设置）
 * @return 0 = 成功；1 = 未检测到器件（WHO_AM_I 不符或 I2C 无应答）
 */
uint8_t MPU6050_Init(void);

/**
 * @brief  上电零偏校准：静止平放，采 MPU_CALIB_SAMPLES 点求均值
 * @return 0=校准成功；1=有效样本不足90%。校准期间保持静止。
 */
uint8_t MPU6050_Calibrate(void);

/**
 * @brief  读一次全部数据（加速度 + 角速度 + 温度），并做姿态解算
 * @param  d  输出结构体
 * @return 0=成功；1=总线或数据错误，不可使用旧帧做动作识别。
 */
uint8_t MPU6050_Read_All(MPU6050_t *d);
uint32_t MPU6050_RandomSeed(void);
uint8_t MPU6050_Address(void);

/** @brief 直接读 WHO_AM_I（用于排障） */
uint8_t MPU6050_WhoAmI(void);

/** @brief 低层寄存器读写（排障用） */
uint8_t MPU6050_WriteReg(uint8_t reg, uint8_t data);
uint8_t MPU6050_ReadRegs(uint8_t reg, uint8_t *buf, uint8_t len);

/* 全局实例在 app_main.c 定义。 */
extern MPU6050_t mpu;

#endif /* __MPU6050_H */
