#ifndef HOURGLASS_H
#define HOURGLASS_H
#include <stdint.h>
void Hourglass_Init(void);
void Hourglass_Update(float gx,float gy,float dt);
void Hourglass_Render(void);
uint8_t Hourglass_LeftCount(void);
uint8_t Hourglass_Validate(void);
uint8_t Hourglass_IsVertical(void);
#endif
