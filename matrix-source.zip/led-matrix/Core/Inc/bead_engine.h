#ifndef __BEAD_ENGINE_H
#define __BEAD_ENGINE_H
#include "main.h"
#include "config.h"
#define BEAD_TOTAL (MATRIX_COLS*BEADS_PER_COLUMN)
typedef enum {
    BEAD_MODE_IDLE,BEAD_MODE_TILT,BEAD_MODE_SHAKE,BEAD_MODE_TAP,
    BEAD_MODE_GATHER,BEAD_MODE_SCATTER
} BeadMode_t;
/* Every column starts with two distinct cells. Seed rand from sensor entropy first. */
void Bead_Init(void);
void Bead_InitRandom(void);
/* gx/gy: normalized downhill direction; dt in seconds. Positions never overlap. */
void Bead_Update(float gx,float gy,float dt);
void Bead_UpdateVertical(float dt);
void Bead_Shake(float strength);
/* Adds a new impulse to 16..40 randomly chosen beads without replacement. */
void Bead_Tap(float strength);
void Bead_StartGather(void);
void Bead_StartScatter(void);
void Bead_Tick(uint32_t now);
/* Moves airborne bodies against gravity and preserves exactly 64 bright cells. */
void Bead_Render(void);
BeadMode_t Bead_GetMode(void);
float Bead_GetMaxHeight(void);
#ifdef BEAD_DEBUG
float Bead_DebugHeight(uint8_t index);
#endif
#endif
