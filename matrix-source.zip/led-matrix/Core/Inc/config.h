#ifndef __CONFIG_H
#define __CONFIG_H
#include <stdint.h>
#define MATRIX_COLS 32U
#define MATRIX_ROWS 8U
#define MATRIX_CHIPS 4U
/* First pair goes to the farthest MAX7219. DIN-nearest is logical left block. */
#define MATRIX_CHIP_ORDER {3,2,1,0}
#define MATRIX_BRIGHTNESS 2U
/* Per-chip display transform, for FC-16 modules adjust after the row/column test.
   0=none, 1=90 clockwise, 2=180, 3=270 clockwise. */
#define MATRIX_ROTATION 0U
#define MATRIX_MIRROR_X 0U
#define MATRIX_MIRROR_Y 0U
/* Sensor board X/Y may be swapped by assembly. 0=MPU X, 1=MPU Y. */
#define GRAV_X_AXIS 1U
#define GRAV_Y_AXIS 0U
#define GRAV_X_SIGN (-1)
#define GRAV_Y_SIGN (+1)
#define TILT_DEADZONE_DEG 4.0f
#define TILT_FULLSCALE_DEG 18.0f
#define TILT_SPEED_MAX 24.0f
#define EDGE_FLOW_INTERVAL_S 0.025f
#define EDGE_FLOW_STUCK_S 0.06f
#define EDGE_FLOW_SLIDE_S 0.16f
#define HOURGLASS_STEP_S 0.035f
#define HOURGLASS_NECK_S 0.09f
#define BEADS_PER_COLUMN 2U
#define SHAKE_KICK 20.0f
#define TAP_KICK 18.0f
#define TAP_COUNT_MIN 16U
#define TAP_COUNT_MAX 40U
#define VERT_GRAVITY 30.0f
#define VERT_BOUNCE 0.32f
#define VERT_MAX_H 6.0f
#define VERT_SETTLE_V 1.5f
#define SELFTEST_ROW_MS 120U
#define SELFTEST_COL_MS 40U
#define SELFTEST_CELL_MS 22U
#define SELFTEST_FLASH_MS 220U
#define MPU_CALIB_SAMPLES 256U
#define MPU_LPF_ALPHA 0.12f
#define MAIN_LOOP_MS 5U
#define DISPLAY_PERIOD_MS 16U
#define MOTION_SHAKE_THRESHOLD 0.45f
#define MOTION_TAP_THRESHOLD 0.30f
#define MOTION_SHAKE_HOLD_MS 30U
#define MOTION_COOLDOWN_MS 180U
#endif
