/**
 ******************************************************************************
 * @file    max7219.c
 * @brief   4 片 MAX7219 级联驱动 8×32 单色点阵（SPI1 硬件 + PA4 软件片选）
 *
 *  原理说明
 *  --------
 *  4 片 MAX7219 串成一条 64bit 的移位寄存器：
 *
 *        STM32_MOSI ──▶ [CH1] ──▶ [CH2] ──▶ [CH3] ──▶ [CH4]
 *         (PA7/DIN)      第1片      第2片      第3片      第4片
 *                        列0..7    列8..15    列16..23   列24..31
 *
 *  数据流里「最先发出的 2 字节」会被推到最远的 CH4，
 *  因此发送顺序必须是 CH4, CH3, CH2, CH1（离 DIN 最远的先发）。
 *  具体顺序由 config.h 的 MATRIX_CHIP_ORDER 决定，现场可一行改掉。
 *
 *  时序：CS 拉低 → 连续 64bit（8 字节）→ CS 拉高，锁存生效。
 ******************************************************************************
 */

#include "max7219.h"
#include "spi.h"
#include <string.h>

/* ==========================================================================
 *  帧缓冲与影子寄存器
 * ========================================================================== */

uint8_t LED_Buf[MATRIX_COLS * MATRIX_ROWS];

/**
 * @brief 影子：上一次真正发到硬件上的数据
 * @note  按「逻辑列块」组织： led_sent[blk * MATRIX_ROWS + row]
 *        blk = 0..3 对应列块 0..3（列 0..7 / 8..15 / 16..23 / 24..31）
 *        一个字节的 bit n 对应列块内第 n 列（即整个点阵的第 blk*8+n 列），
 *        bit 置 1 = 该列在 row 行点亮。
 */
static uint8_t led_sent[MATRIX_CHIPS * MATRIX_ROWS];
/** 0 = 影子内容无效，下次必须全量重发 */
static uint8_t led_shadow_valid = 0U;

/** 菊花链片序：下标 = 发送次序，值 = 逻辑列块号（见 config.h） */
static const uint8_t chip_order[MATRIX_CHIPS] = MATRIX_CHIP_ORDER;

/* ==========================================================================
 *  底层收发
 * ========================================================================== */

/**
 * @brief  片选拉低 → 发送 count 字节 → 片选拉高
 * @note   全程只操作一次 CS，保证整串数据被完整地移进菊花链后再锁存。
 */
static uint8_t max7219_write(const uint8_t *buf, uint16_t count)
{
    LED_CS_LOW();
    HAL_StatusTypeDef status=HAL_SPI_Transmit(&hspi1, (uint8_t *)buf, count, 10U);
    LED_CS_HIGH();
    return (uint8_t)(status==HAL_OK);
}

/**
 * @brief  给全部 4 片写入「同一寄存器、各自不同的数据」
 * @param  addr  寄存器地址（例如 0x01 = DIG0，即最上面一行）
 * @param  data  逻辑列块数据，长度 MATRIX_CHIPS，data[blk] 发给列块 blk
 * @note   发送次序按 chip_order 展开，保证离 DIN 最远的芯片最后收到。
 */
static uint8_t max7219_write_all(uint8_t addr, const uint8_t *data)
{
    uint8_t frame[MATRIX_CHIPS * 2U];
    uint8_t i;

    for (i = 0U; i < MATRIX_CHIPS; i++) {
        frame[i * 2U + 0U] = addr;
        frame[i * 2U + 1U] = data[chip_order[i]];
    }
    return max7219_write(frame, (uint16_t)(MATRIX_CHIPS * 2U));
}

/** 便捷包装：4 片写同样的数据 */
static void max7219_bcast(uint8_t addr, uint8_t value)
{
    const uint8_t v[MATRIX_CHIPS] = { value, value, value, value };
    max7219_write_all(addr, v);
}

/* ==========================================================================
 *  初始化
 * ========================================================================== */

void MAX7219_Init(void)
{
    uint8_t row;
    const uint8_t zeros[MATRIX_CHIPS] = { 0U, 0U, 0U, 0U };
    const uint8_t seven[MATRIX_CHIPS] = { 7U, 7U, 7U, 7U };

    /* --- 复位到已知状态 --- */
    max7219_bcast(MAX7219_REG_DISPTEST, 0x00U);   /* 关测试模式 */
    max7219_bcast(MAX7219_REG_SHUTDOWN, 0x00U);   /* 先关断，配置期间不显示 */

    /* --- 寄存器配置（4 片完全一致，广播即可） --- */
    max7219_write_all(MAX7219_REG_DECODE,    zeros);            /* 不译码 */
    max7219_write_all(MAX7219_REG_SCANLIMIT, seven);            /* 扫描 8 行 */
    max7219_bcast(MAX7219_REG_INTENSITY, MATRIX_BRIGHTNESS);    /* 亮度 */
    max7219_bcast(MAX7219_REG_DISPTEST,  0x00U);                /* 正常显示 */
    max7219_bcast(MAX7219_REG_SHUTDOWN,  0x01U);                /* 进入工作 */

    LED_Clear();
    for (row = 0U; row < MATRIX_ROWS; row++) {
        (void)max7219_write_all((uint8_t)(MAX7219_REG_DIGIT0 + row), zeros);
    }
    led_shadow_valid = 0U;
    LED_Refresh();
}

void LED_Invalidate(void)
{
    led_shadow_valid = 0U;
}

void MAX7219_WriteReg(uint8_t addr, uint8_t value)
{
    max7219_bcast(addr, value);
}

/* ==========================================================================
 *  刷新
 * ========================================================================== */

void LED_Refresh(void)
{
    uint8_t row,blk,k;
    uint8_t next[MATRIX_CHIPS*MATRIX_ROWS]={0};
    for(blk=0;blk<MATRIX_CHIPS;blk++) for(row=0;row<MATRIX_ROWS;row++) {
        for(k=0;k<8;k++) {
            uint8_t x=k,y=row,r;
            if(!(LED_Buf[(blk*8U+k)*MATRIX_ROWS+row]&1U)) continue;
            for(r=0;r<MATRIX_ROTATION;r++) { uint8_t old=x; x=(uint8_t)(7U-y); y=old; }
            if(MATRIX_MIRROR_X) x=(uint8_t)(7U-x);
            if(MATRIX_MIRROR_Y) y=(uint8_t)(7U-y);
            next[blk*MATRIX_ROWS+y] |= (uint8_t)(1U<<x);
        }
    }
    if(led_shadow_valid && memcmp(next,led_sent,sizeof next)==0) return;
    for(row=0;row<MATRIX_ROWS;row++) {
        uint8_t line[MATRIX_CHIPS];
        for(blk=0;blk<MATRIX_CHIPS;blk++) line[blk]=next[blk*MATRIX_ROWS+row];
        if(!max7219_write_all((uint8_t)(MAX7219_REG_DIGIT0+row),line)) {
            led_shadow_valid=0; return;
        }
    }
    memcpy(led_sent,next,sizeof next);
    led_shadow_valid=1;
}

/* ==========================================================================
 *  帧缓冲操作
 * ========================================================================== */

void LED_Clear(void)
{
    uint16_t i;
    for (i = 0U; i < (uint16_t)(MATRIX_COLS * MATRIX_ROWS); i++) {
        LED_Buf[i] = 0U;
    }
}

void LED_FillAll(void)
{
    uint16_t i;
    for (i = 0U; i < (uint16_t)(MATRIX_COLS * MATRIX_ROWS); i++) {
        LED_Buf[i] = 1U;
    }
}

void LED_SetPixel(uint8_t col, uint8_t row, uint8_t on)
{
    if ((col >= MATRIX_COLS) || (row >= MATRIX_ROWS)) {
        return;
    }
    LED_Buf[(uint16_t)col * MATRIX_ROWS + row] = on ? 1U : 0U;
}

uint8_t LED_GetPixel(uint8_t col, uint8_t row)
{
    if ((col >= MATRIX_COLS) || (row >= MATRIX_ROWS)) {
        return 0U;
    }
    return LED_Buf[(uint16_t)col * MATRIX_ROWS + row];
}

void LED_SetRowMask(uint8_t row, uint32_t col_mask)
{
    uint8_t col;
    if (row >= MATRIX_ROWS) {
        return;
    }
    for (col = 0U; col < MATRIX_COLS; col++) {
        LED_Buf[(uint16_t)col * MATRIX_ROWS + row] =
            (uint8_t)((col_mask >> col) & 0x01U);
    }
}

void LED_SetCol(uint8_t col, uint8_t value)
{
    uint8_t row;
    uint8_t v = value ? 0xFFU : 0x00U;
    if (col >= MATRIX_COLS) {
        return;
    }
    for (row = 0U; row < MATRIX_ROWS; row++) {
        LED_Buf[(uint16_t)col * MATRIX_ROWS + row] = (uint8_t)((v >> row) & 0x01U);
    }
}

void LED_GrayToBuf(const uint8_t *gray, uint8_t thr)
{
    uint16_t i;
    for (i = 0U; i < (uint16_t)(MATRIX_COLS * MATRIX_ROWS); i++) {
        LED_Buf[i] = (gray[i] >= thr) ? 1U : 0U;
    }
}
