/* C题: occupancy-conserving grid motion with independent ballistic jumps. */
#include "bead_engine.h"
#include "max7219.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct { int x,y; float px,py,h,vh,stuck; } Bead;
static Bead beads[BEAD_TOTAL];
static BeadMode_t mode;
static uint32_t end_ms;
static float max_h;
static float jump_x=0.0f,jump_y=-1.0f;
static uint8_t occupied[MATRIX_COLS*MATRIX_ROWS];
static float flow_time;
static unsigned flow_cursor;
/* Reserve only the few cells of one finite surface slide, then release them.
   This prevents the original one-cell retreat / immediate refill / retreat. */
static uint8_t slide_reserved[MATRIX_COLS*MATRIX_ROWS];
static int slide_inner[4],slide_outer[4],slide_length,slide_pos;
static unsigned slide_carrier;
static float slide_time,slide_rest,slide_gx,slide_gy;
static void slide_cancel(void) {
    slide_length=0;slide_time=0;
    memset(slide_reserved,0,sizeof slide_reserved);
}
static float random01(void) { return (float)(rand() & 32767)/32767.0f; }
static float clamp(float x,float a,float b) { return x<a?a:(x>b?b:x); }
static int slot(int x,int y) { return x*(int)MATRIX_ROWS+y; }
static int move_cell(Bead *b,int x,int y) {
    if(x<0 || x>31 || y<0 || y>7 || occupied[slot(x,y)]) return 0;
    occupied[slot(b->x,b->y)]=0;
    b->x=x; b->y=y; occupied[slot(x,y)]=1;
    return 1;
}
static int move_to(Bead *b,int x,int y) {
    if(x<0 || x>31 || y<0 || y>7 ||
       slide_reserved[slot(b->x,b->y)] || slide_reserved[slot(x,y)]) return 0;
    return move_cell(b,x,y);
}
static int find_bead(int cell) {
    unsigned i;
    for(i=0;i<BEAD_TOTAL;i++) if(slot(beads[i].x,beads[i].y)==cell) return (int)i;
    return -1;
}
static int surface_cell(int horizontal,int lane,int sign) {
    int depth=horizontal?32:8,d,front=-1;
    if(lane<0 || lane>=(horizontal?8:32)) return -1;
    for(d=sign>0?0:depth-1;d>=0 && d<depth;d+=sign) {
        int cell=horizontal?slot(d,lane):slot(lane,d);
        if(occupied[cell]) {front=cell;break;}
    }
    if(front<0) return -1;
    /* No unstable hole may hide behind this surface cell. */
    for(;d>=0 && d<depth;d+=sign)
        if(!occupied[horizontal?slot(d,lane):slot(lane,d)]) return -1;
    return front;
}
static int flow_move(Bead *b,int x,int y,float gx,float gy) {
    /* Diagonal piles remain in the low corner even during a small ripple. */
    if(fabsf(gx)>0.1f && fabsf(gy)>0.1f) {
        int width=(int)((BEAD_TOTAL+7U)/8U+4U);
        int height=BEAD_TOTAL>36U?8:6;
        if((gx>0 && x<32-width)||(gx<0 && x>=width)||
           (gy>0 && y<8-height)||(gy<0 && y>=height)) return 0;
    }
    return move_to(b,x,y);
}
static int slide_start(unsigned index,int side,float gx,float gy) {
    Bead *b=&beads[index];
    int horizontal=fabsf(gx)>=fabsf(gy),sign=(horizontal?gx:gy)>0?1:-1;
    int lane=horizontal?b->y:b->x,k,count=0;
    int inner[4],outer[4];
    inner[0]=surface_cell(horizontal,lane,sign);
    if(inner[0]!=slot(b->x,b->y)) return 0;
    for(k=1;k<=3;k++) {
        int cell=surface_cell(horizontal,lane+side*k,sign),x,y,px,py;
        if(cell<0) break;
        x=cell/8;y=cell%8;
        if(horizontal) x-=sign;else y-=sign;
        if(x<0 || x>31 || y<0 || y>7 || occupied[slot(x,y)]) break;
        if(fabsf(gx)>0.1f && fabsf(gy)>0.1f) {
            int width=(int)((BEAD_TOTAL+7U)/8U+4U);
            if((gx>0 && x<32-width)||(gx<0 && x>=width)) break;
        }
        px=(k==1?inner[0]:outer[k-1])/8;
        py=(k==1?inner[0]:outer[k-1])%8;
        if(abs(x-px)>1 || abs(y-py)>1) break;
        if(abs(cell/8-inner[k-1]/8)>1 || abs(cell%8-inner[k-1]%8)>1) break;
        inner[k]=cell;outer[k]=slot(x,y);count=k;
    }
    if(count<2) return 0;
    if(!flow_move(b,outer[1]/8,outer[1]%8,gx,gy)) return 0;
    for(k=0;k<=count;k++) {
        slide_inner[k]=inner[k];slide_reserved[inner[k]]=1;
        if(k) {slide_outer[k]=outer[k];slide_reserved[outer[k]]=1;}
    }
    slide_length=count;slide_pos=1;slide_carrier=index;
    slide_time=0;slide_gx=gx;slide_gy=gy;
    b->px=b->py=b->stuck=0;
    return 1;
}
static void edge_flow(float gx,float gy,float dt) {
    unsigned n;
    float strength=fmaxf(fabsf(gx),fabsf(gy));
    if(strength<0.05f || (mode!=BEAD_MODE_IDLE && mode!=BEAD_MODE_TILT)) {
        slide_cancel();flow_time=0;return;
    }
    if(slide_length) {
        int next,gap=slide_inner[slide_pos-1],follower;
        slide_time+=dt*strength;
        if(slide_time<EDGE_FLOW_SLIDE_S) return;
        slide_time-=EDGE_FLOW_SLIDE_S;
        follower=find_bead(slide_inner[slide_pos]);
        next=slide_pos<slide_length?slide_outer[slide_pos+1]:slide_inner[slide_pos];
        if(follower<0 || !move_cell(&beads[follower],gap/8,gap%8) ||
           !move_cell(&beads[slide_carrier],next/8,next%8)) {
            slide_cancel();slide_rest=EDGE_FLOW_SLIDE_S;return;
        }
        beads[follower].px=beads[follower].py=beads[follower].stuck=0;
        if(slide_pos==slide_length) {slide_cancel();slide_rest=EDGE_FLOW_SLIDE_S;}
        else slide_pos++;
        return;
    }
    if(slide_rest>0) {slide_rest-=dt*strength;return;}
    flow_time+=dt*strength;
    if(flow_time<EDGE_FLOW_INTERVAL_S) return;
    flow_time=0;
    for(n=0;n<BEAD_TOTAL;n++) {
        unsigned index=(flow_cursor+n)%BEAD_TOTAL;
        Bead *b=&beads[index];
        int horizontal=fabsf(gx)>=fabsf(gy),side;
        if(b->stuck<EDGE_FLOW_STUCK_S || b->h>0.25f) continue;
        if(horizontal && ((gx>0 && b->x<32-(int)((BEAD_TOTAL+7U)/8U)) ||
                          (gx<0 && b->x>=(int)((BEAD_TOTAL+7U)/8U)))) continue;
        if(!horizontal && ((gy>0 && b->y<8-(int)((BEAD_TOTAL+31U)/32U)) ||
                           (gy<0 && b->y>=(int)((BEAD_TOTAL+31U)/32U)))) continue;
        side=horizontal?(fabsf(gy)>0.1f?(gy>0?1:-1):((rand()&1)?1:-1)):
                        (fabsf(gx)>0.1f?(gx>0?1:-1):((rand()&1)?1:-1));
        if(slide_start(index,side,gx,gy) || slide_start(index,-side,gx,gy)) {
            flow_cursor=(index+1U)%BEAD_TOTAL;return;
        }
    }
}
void Bead_InitRandom(void) {
    unsigned i;
    memset(occupied,0,sizeof occupied);
    for(i=0;i<BEAD_TOTAL;i++) {
        int x=(int)(i/BEADS_PER_COLUMN),y;
        do { y=rand()%8; } while(occupied[slot(x,y)]);
        beads[i].x=x; beads[i].y=y;
        beads[i].px=beads[i].py=beads[i].h=beads[i].vh=0;
        beads[i].stuck=0;
        occupied[slot(x,y)]=1;
    }
    max_h=0; mode=BEAD_MODE_IDLE; end_ms=0;
    jump_x=0; jump_y=-1;
    flow_time=0;flow_cursor=0;slide_rest=0;slide_cancel();
}
void Bead_Init(void) { Bead_InitRandom(); }
void Bead_Update(float gx,float gy,float dt) {
    unsigned order[BEAD_TOTAL],i,j;
    float scores[BEAD_TOTAL];
    if(dt<=0) return;
    dt=clamp(dt,0,0.05f);
    gx=clamp(gx,-1,1); gy=clamp(gy,-1,1);
    if(slide_length) {
        float norm=sqrtf((gx*gx+gy*gy)*(slide_gx*slide_gx+slide_gy*slide_gy));
        if(fmaxf(fabsf(gx),fabsf(gy))<0.05f || gx*slide_gx+gy*slide_gy<0.8f*norm ||
           (mode!=BEAD_MODE_IDLE && mode!=BEAD_MODE_TILT)) {slide_cancel();slide_rest=0;}
    }
    if(fabsf(gx)+fabsf(gy)>0.05f) {
        float n=sqrtf(gx*gx+gy*gy);
        jump_x=-gx/n; jump_y=-gy/n;
    }
    /* Downhill beads move first so the pile remains compact. */
    for(i=0;i<BEAD_TOTAL;i++) { order[i]=i; scores[i]=(float)beads[i].x*gx+(float)beads[i].y*gy; }
    for(i=1;i<BEAD_TOTAL;i++) {
        unsigned v=order[i]; float score=scores[v];
        j=i;
        while(j && scores[order[j-1]]<score) {
            order[j]=order[j-1]; --j;
        }
        order[j]=v;
    }
    for(i=0;i<BEAD_TOTAL;i++) {
        Bead *b=&beads[order[i]];
        float xg=gx,yg=gy;
        int sx=0,sy=0,oldx=b->x,oldy=b->y;
        if(mode==BEAD_MODE_GATHER) {
            xg=b->x<14?1.0f:(b->x>17?-1.0f:0.0f);
            yg=b->y<2?1.0f:(b->y>5?-1.0f:0.0f);
        } else if(mode==BEAD_MODE_SCATTER) {
            xg=b->x<16?-1.0f:1.0f; yg=b->y<4?-1.0f:1.0f;
        }
        if(fabsf(xg)<0.01f) b->px=0;
        if(fabsf(yg)<0.01f) b->py=0;
        b->px+=fabsf(xg)*TILT_SPEED_MAX*dt;
        b->py+=fabsf(yg)*TILT_SPEED_MAX*dt;
        if(b->px>=1) { sx=xg>0?1:-1; b->px-=1; }
        if(b->py>=1) { sy=yg>0?1:-1; b->py-=1; }
        if(sx && sy && move_to(b,b->x+sx,b->y+sy)) { b->stuck=0;continue; }
        /* Random tie breaking avoids a fixed diagonal packing bias. */
        if((rand()&1)!=0) {
            if(sx) (void)move_to(b,b->x+sx,b->y);
            if(sy) (void)move_to(b,b->x,b->y+sy);
        } else {
            if(sy) (void)move_to(b,b->x,b->y+sy);
            if(sx) (void)move_to(b,b->x+sx,b->y);
        }
        /* A blocked bead can roll diagonally downhill under single-axis gravity.
           This releases full columns/rows when the device changes orientation. */
        if(b->x==oldx && b->y==oldy && sx && !sy && fabsf(yg)<0.01f) {
            int side=(rand()&1)?1:-1;
            if(!move_to(b,b->x+sx,b->y+side)) (void)move_to(b,b->x+sx,b->y-side);
        }
        if(b->x==oldx && b->y==oldy && sy && !sx && fabsf(xg)<0.01f) {
            int side=(rand()&1)?1:-1;
            if(!move_to(b,b->x+side,b->y+sy)) (void)move_to(b,b->x-side,b->y+sy);
        }
        /* Slide along an equal-potential diagonal to fill a compact corner,
           only when it reduces distance to the low corner (no oscillation). */
        if(b->x==oldx && b->y==oldy && sx && sy) {
            float cx=sx>0?31.0f:0.0f,cy=sy>0?7.0f:0.0f;
            float dx=(float)b->x-cx,dy=(float)b->y-cy;
            if(fabsf(xg)>=fabsf(yg) &&
               (dx+(float)sx)*(dx+(float)sx)+(dy-(float)sy)*(dy-(float)sy)<dx*dx+dy*dy)
                (void)move_to(b,b->x+sx,b->y-sy);
            else if(fabsf(yg)>=fabsf(xg) &&
               (dx-(float)sx)*(dx-(float)sx)+(dy+(float)sy)*(dy+(float)sy)<dx*dx+dy*dy)
                (void)move_to(b,b->x-sx,b->y+sy);
        }
        if(b->x==oldx && b->y==oldy) b->stuck+=dt;
        else b->stuck=0;
    }
    edge_flow(gx,gy,dt);
    if(mode==BEAD_MODE_IDLE || mode==BEAD_MODE_TILT)
        mode=(fabsf(gx)+fabsf(gy)>0.01f)?BEAD_MODE_TILT:BEAD_MODE_IDLE;
}
void Bead_UpdateVertical(float dt) {
    unsigned i; max_h=0;
    dt=clamp(dt,0,0.05f);
    for(i=0;i<BEAD_TOTAL;i++) {
        Bead *b=&beads[i];
        if(b->h>0 || b->vh>0) {
            b->vh-=VERT_GRAVITY*dt; b->h+=b->vh*dt;
            if(b->h<=0) {
                b->h=0; b->vh=b->vh < -VERT_SETTLE_V ? -b->vh*VERT_BOUNCE:0;
            }
            if(b->h>VERT_MAX_H) { b->h=VERT_MAX_H; if(b->vh>0) b->vh=0; }
        }
        if(b->h>max_h) max_h=b->h;
    }
}
void Bead_Shake(float strength) {
    unsigned i; float s=clamp(fabsf(strength),0.8f,1.5f);
    slide_cancel();slide_rest=0;flow_time=0;
    /* Repeated sensor events must not relaunch airborne grains at the ceiling.
       Each grain completes its own fall before the next kick. */
    for(i=0;i<BEAD_TOTAL;i++) if(beads[i].h<0.25f) {
        beads[i].h=0;
        beads[i].vh=SHAKE_KICK*s*(0.7f+0.6f*random01());
    }
    mode=BEAD_MODE_SHAKE; end_ms=HAL_GetTick()+350;
}
void Bead_Tap(float strength) {
    unsigned ids[BEAD_TOTAL],i,count=TAP_COUNT_MIN+(unsigned)rand()%(TAP_COUNT_MAX-TAP_COUNT_MIN+1U);
    float s=clamp(fabsf(strength),0.8f,1.5f);
    slide_cancel();slide_rest=0;flow_time=0;
    for(i=0;i<BEAD_TOTAL;i++) ids[i]=i;
    /* A visible random subset jumps; the resting group provides contrast. */
    for(i=0;i<count;i++) {
        unsigned j=i+(unsigned)rand()%(BEAD_TOTAL-i),v=ids[j];
        ids[j]=ids[i]; ids[i]=v;
        beads[v].vh=TAP_KICK*s*(0.8f+0.5f*random01());
    }
    mode=BEAD_MODE_TAP; end_ms=HAL_GetTick()+350;
}
void Bead_StartGather(void) { mode=BEAD_MODE_GATHER; end_ms=HAL_GetTick()+1800; }
void Bead_StartScatter(void) { Bead_Shake(1); mode=BEAD_MODE_SCATTER; end_ms=HAL_GetTick()+700; }
void Bead_Tick(uint32_t now) {
    if(mode>=BEAD_MODE_SHAKE && (int32_t)(now-end_ms)>=0) mode=BEAD_MODE_IDLE;
}
BeadMode_t Bead_GetMode(void) { return mode; }
float Bead_GetMaxHeight(void) { return max_h; }
#ifdef BEAD_DEBUG
float Bead_DebugHeight(uint8_t i) { return i<BEAD_TOTAL?beads[i].h:0; }
#endif
void Bead_Render(void) {
    unsigned i;
    uint8_t used[MATRIX_COLS*MATRIX_ROWS]={0};
    LED_Clear();
    /* Reserve resting beads first: a jumping bead may not displace one. */
    for(i=0;i<BEAD_TOTAL;i++) if(beads[i].h<0.25f) {
        used[slot(beads[i].x,beads[i].y)]=1;
        LED_SetPixel((uint8_t)beads[i].x,(uint8_t)beads[i].y,1);
    }
    for(i=0;i<BEAD_TOTAL;i++) {
        if(beads[i].h<0.25f) continue;
        float tx=clamp((float)beads[i].x+jump_x*beads[i].h,0,31);
        float ty=clamp((float)beads[i].y+jump_y*beads[i].h,0,7);
        int x=(int)(tx+0.5f),y=(int)(ty+0.5f),best=slot(x,y);
        if(used[best]) {
            int c,r; float distance=1e9f;
            for(c=0;c<32;c++) for(r=0;r<8;r++) if(!used[slot(c,r)]) {
                float dx=(float)c-tx,dy=(float)r-ty,d=dx*dx+dy*dy;
                if(d<distance) { distance=d; best=slot(c,r); }
            }
        }
        used[best]=1;
        LED_SetPixel((uint8_t)(best/8),(uint8_t)(best%8),1);
    }
}
