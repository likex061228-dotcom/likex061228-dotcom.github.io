/* Application kept outside CubeMX-generated files. */
#include "app_main.h"
#include "max7219.h"
#include "mpu6050.h"
#include "bead_engine.h"
#include "app_ui.h"
#include "motion.h"
#include "hourglass.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
MPU6050_t mpu;
static MotionState motion;
static FlipState flip;
static uint8_t hourglass_mode;
static uint8_t status_active;
static float face_up_sign=1.0f;
static uint32_t status_until;
static uint8_t sensor_ready,failures;
static uint32_t last_sample,last_display,last_retry;

static uint8_t sensor_start(void) {
    memset(&mpu,0,sizeof mpu);
    if(MPU6050_Init() || MPU6050_Calibrate() || MPU6050_Read_All(&mpu)) return 0;
    srand((unsigned int)MPU6050_RandomSeed());
    Bead_InitRandom();
    Motion_Init(&motion,HAL_GetTick());
    Flip_Init(&flip);
    hourglass_mode=0;status_until=0;status_active=0;
    face_up_sign=mpu.Az<0?-1.0f:1.0f;
    failures=0;
    return 1;
}
void App_Init(void) {
    MAX7219_Init();
    /* All 256 cells are checked even with a disconnected sensor. */
    UI_SelfTest();
    sensor_ready=sensor_start();
    if(sensor_ready) Bead_Render(); else UI_ShowSensorError();
    LED_Refresh();
    last_sample=last_display=last_retry=HAL_GetTick();
}
void App_Loop(void) {
    uint32_t now=HAL_GetTick();
    float gx,gy,dt;
    MotionEvent event;
    if(!sensor_ready) {
        if((uint32_t)(now-last_retry)>=1000U) {
            last_retry=now;
            sensor_ready=sensor_start();
            last_sample=last_display=HAL_GetTick();
        }
        if(sensor_ready) Bead_Render();
        else if((now/500U)&1U) UI_ShowSensorError();
        else LED_Clear();
        LED_Refresh();
        HAL_Delay(5U); return;
    }
    if((uint32_t)(now-last_sample)<MAIN_LOOP_MS) { HAL_Delay(1U); return; }
    dt=(float)(uint32_t)(now-last_sample)*0.001f;
    last_sample=now;
    if(dt>0.05f) dt=0.05f;
    if(MPU6050_Read_All(&mpu)) {
        if(++failures>=20U) { sensor_ready=0; last_retry=now; UI_ShowSensorError(); }
        /* Keep the last good frame, never classify stale sensor data. */
        HAL_Delay(1U); return;
    }
    failures=0;
    Motion_Gravity(mpu.Ax,mpu.Ay,mpu.Az,&gx,&gy);
    if(Flip_Update(&flip,mpu.Az*face_up_sign,now)) {
        hourglass_mode=(uint8_t)!hourglass_mode;
        if(hourglass_mode) Hourglass_Init(); else Bead_InitRandom();
        status_until=now+600U;
        status_active=1;
    }
    event=Motion_Update(&motion,mpu.AccMag,now);
    if(hourglass_mode) {
        Hourglass_Update(gx,gy,dt);
    } else {
        /* Set jump direction before applying the event. */
        Bead_Tick(now);
        Bead_Update(gx,gy,dt);
        switch(event) {
        case MOTION_SHAKE: Bead_Shake(motion.strength); break;
        case MOTION_TAP: Bead_Tap(motion.strength); break;
        default: break;
        }
        Bead_UpdateVertical(dt);
    }
    if((uint32_t)(now-last_display)>=DISPLAY_PERIOD_MS) {
        last_display=now;
        if(status_active && (int32_t)(status_until-now)>0) {
            LED_Clear();UI_DrawChar(13,0,hourglass_mode?'H':'B',1);
        } else {
            status_active=0;
            if(hourglass_mode) Hourglass_Render(); else Bead_Render();
        }
        LED_Refresh();
    }
}
void App_ApplyPattern(uint8_t req) {
    if(req==1) Bead_StartGather();
    else if(req==2) Bead_StartScatter();
    else if(req==3) Bead_InitRandom();
}
