/* MPU6050: software I2C, checked configuration, gyro calibration and gravity filter. */

#include "mpu6050.h"
#include "config.h"
#include <math.h>

/* ==========================================================================
 *  寄存器地址
 * ========================================================================== */
#define REG_SMPLRT_DIV      0x19U
#define REG_CONFIG          0x1AU
#define REG_GYRO_CONFIG     0x1BU
#define REG_ACCEL_CONFIG    0x1CU
#define REG_ACCEL_XOUT_H    0x3BU
#define REG_TEMP_OUT_H      0x41U
#define REG_GYRO_XOUT_H     0x43U
#define REG_PWR_MGMT_1      0x6BU
#define REG_PWR_MGMT_2      0x6CU
#define REG_WHO_AM_I        0x75U

#define WHO_AM_I_VALUE      0x68U

/* 量程对应的灵敏度（与下方配置必须一致） */
#define ACCEL_LSB_PER_G     4096.0f     /* ±8g */
#define GYRO_LSB_PER_DPS    65.5f       /* ±500°/s */
#define RAD_TO_DEG          57.29577951308232f

/* ==========================================================================
 *  软件 I2C 底层
 * ========================================================================== */

#define I2C_PORT            GPIOB
#define I2C_SCL_PIN         GPIO_PIN_6
#define I2C_SDA_PIN         GPIO_PIN_7

#define SCL_H()   scl_high()
#define SCL_L()   HAL_GPIO_WritePin(I2C_PORT, I2C_SCL_PIN, GPIO_PIN_RESET)
#define SDA_H()   HAL_GPIO_WritePin(I2C_PORT, I2C_SDA_PIN, GPIO_PIN_SET)
#define SDA_L()   HAL_GPIO_WritePin(I2C_PORT, I2C_SDA_PIN, GPIO_PIN_RESET)
#define SDA_IN()  HAL_GPIO_ReadPin(I2C_PORT, I2C_SDA_PIN)

/** 总线忙等待上限，超时即认为从机没接好 */
#define I2C_TIMEOUT_LOOPS   4000U

static uint8_t i2c_init_done = 0U;
static uint8_t address = 0x68U;
static uint8_t bus_error = 0U;
static uint8_t first_sample = 1U;
static float ax_f,ay_f,az_f;
static uint32_t entropy = 2166136261U;
uint32_t MPU6050_RandomSeed(void) { return entropy; }
uint8_t MPU6050_Address(void) { return address; }
static void entropy_add(uint32_t v) { entropy=(entropy^v)*16777619U; }
static void scl_high(void) {
    uint32_t guard=I2C_TIMEOUT_LOOPS;
    HAL_GPIO_WritePin(I2C_PORT,I2C_SCL_PIN,GPIO_PIN_SET);
    while(HAL_GPIO_ReadPin(I2C_PORT,I2C_SCL_PIN)==GPIO_PIN_RESET && guard) --guard;
    if(!guard) bus_error=1U;
}

/** 粗延时：72MHz 下约 1.1us/次调用，软件 I2C 用 ~100kHz 足够稳 */
static void i2c_delay(void)
{
    volatile uint32_t i;
    for (i = 0U; i < 14U; i++) {
        __NOP();
    }
}

/**
 * @brief  把 SCL/SDA 配成开漏 + 上拉
 * @note   开漏是 I2C 的硬性要求（只能拉低，靠上拉拉高）；
 *         若误配成推挽，一端输出高、一端输出低会直接短路。
 */
static void i2c_gpio_init(void)
{
    GPIO_InitTypeDef gpio = {0};

    __HAL_RCC_GPIOB_CLK_ENABLE();

    gpio.Pin   = I2C_SCL_PIN | I2C_SDA_PIN;
    gpio.Mode  = GPIO_MODE_OUTPUT_OD;
    gpio.Pull  = GPIO_PULLUP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_WritePin(I2C_PORT,I2C_SCL_PIN|I2C_SDA_PIN,GPIO_PIN_SET);
    HAL_GPIO_Init(I2C_PORT, &gpio);

    SCL_H();
    SDA_H();
    i2c_init_done = 1U;
}

/** 释放总线：如果从机把 SDA 拉死，发 9 个时钟让它松手 */
static void i2c_bus_recover(void)
{
    uint8_t i;
    SDA_H();
    for (i = 0U; i < 9U; i++) {
        SCL_L(); i2c_delay();
        SCL_H(); i2c_delay();
    }
    /* 补一个 STOP */
    SDA_L(); i2c_delay();
    SCL_H(); i2c_delay();
    SDA_H(); i2c_delay();
}

static void i2c_start(void)
{
    SDA_H(); SCL_H(); i2c_delay();
    if(SDA_IN()==GPIO_PIN_RESET) bus_error=1U;
    SDA_L(); i2c_delay();       /* SCL 高时 SDA 下降沿 = START */
    SCL_L(); i2c_delay();
}

static void i2c_stop(void)
{
    SDA_L(); i2c_delay();
    SCL_H(); i2c_delay();
    SDA_H(); i2c_delay();       /* SCL 高时 SDA 上升沿 = STOP */
}

/** @return 0 = 收到 ACK，1 = NACK / 超时 */
static uint8_t i2c_write_byte(uint8_t data)
{
    uint8_t i;
    uint32_t guard;

    for (i = 0U; i < 8U; i++) {
        if (data & 0x80U) {
            SDA_H();
        } else {
            SDA_L();
        }
        data = (uint8_t)(data << 1);
        i2c_delay();
        SCL_H(); i2c_delay();
        SCL_L(); i2c_delay();
    }

    /* 第 9 个时钟读 ACK */
    SDA_H();                    /* 释放 SDA，交给从机 */
    i2c_delay();
    SCL_H(); i2c_delay();

    guard = I2C_TIMEOUT_LOOPS;
    while ((SDA_IN() != GPIO_PIN_RESET) && (guard > 0U)) {
        guard--;
    }

    SCL_L(); i2c_delay();
    return (guard == 0U) ? 1U : 0U;
}

static uint8_t i2c_read_byte(uint8_t ack)
{
    uint8_t i;
    uint8_t data = 0U;

    SDA_H();                    /* 主机释放 SDA */
    for (i = 0U; i < 8U; i++) {
        data = (uint8_t)(data << 1);
        i2c_delay();
        SCL_H(); i2c_delay();
        if (SDA_IN() == GPIO_PIN_SET) {
            data |= 0x01U;
        }
        SCL_L(); i2c_delay();
    }

    /* 第 9 个时钟发 ACK(0) / NACK(1) */
    if (ack) {
        SDA_H();
    } else {
        SDA_L();
    }
    i2c_delay();
    SCL_H(); i2c_delay();
    SCL_L(); i2c_delay();
    SDA_H();

    return data;
}

/* ==========================================================================
 *  寄存器读写
 * ========================================================================== */

uint8_t MPU6050_WriteReg(uint8_t reg, uint8_t data)
{
    uint8_t err = 0U;

    if (!i2c_init_done) {
        i2c_gpio_init();
    }

    bus_error=0U;
    i2c_start();
    if (i2c_write_byte((uint8_t)(address << 1))) { err = 1U; }
    else if (i2c_write_byte(reg))                           { err = 1U; }
    else if (i2c_write_byte(data))                          { err = 1U; }
    i2c_stop();

    return (uint8_t)(err || bus_error);
}

uint8_t MPU6050_ReadRegs(uint8_t reg, uint8_t *buf, uint8_t len)
{
    uint8_t i;
    uint8_t err = 0U;

    if (!i2c_init_done) {
        i2c_gpio_init();
    }

    bus_error=0U;
    i2c_start();
    if (i2c_write_byte((uint8_t)(address << 1))) { err = 1U; }
    else if (i2c_write_byte(reg))                           { err = 1U; }

    if (err == 0U) {
        i2c_start();            /* Repeated START */
        if (i2c_write_byte((uint8_t)((address << 1) | 0x01U))) {
            err = 1U;
        }
    }

    if (err == 0U) {
        for (i = 0U; i < len; i++) {
            buf[i] = i2c_read_byte((uint8_t)((i == (uint8_t)(len - 1U)) ? 1U : 0U));
        }
    }

    i2c_stop();
    return (uint8_t)(err || bus_error);
}

uint8_t MPU6050_WhoAmI(void)
{
    uint8_t id = 0U;
    if (MPU6050_ReadRegs(REG_WHO_AM_I, &id, 1U)) {
        return 0U;
    }
    return id;
}

/* ==========================================================================
 *  卡尔曼滤波（1 维，每轴独立）
 * ========================================================================== */

typedef struct {
    float Q_angle;
    float Q_bias;
    float R_measure;
    float angle;
    float bias;
    float P[2][2];
} Kalman_t;

static Kalman_t kal_roll;
static Kalman_t kal_pitch;

static void kalman_init(Kalman_t *kf)
{
    kf->Q_angle   = 0.001f;
    kf->Q_bias    = 0.003f;
    kf->R_measure = 0.03f;
    kf->angle     = 0.0f;
    kf->bias      = 0.0f;
    kf->P[0][0]   = 0.0f;
    kf->P[0][1]   = 0.0f;
    kf->P[1][0]   = 0.0f;
    kf->P[1][1]   = 0.0f;
}

/**
 * @brief  一维卡尔曼：陀螺积分做预测，加速度计角度做观测
 * @param  kf       滤波器状态
 * @param  newAngle 加速度计解算出的角度（度）
 * @param  newRate  陀螺角速度（度/秒）
 * @param  dt       采样间隔（秒）
 */
static float kalman_update(Kalman_t *kf, float newAngle, float newRate, float dt)
{
    float S;
    float K0, K1;
    float y;
    float P00_temp, P01_temp;

    /* --- 预测 --- */
    kf->angle += dt * (newRate - kf->bias);

    kf->P[0][0] += dt * (dt * kf->P[1][1] - kf->P[0][1] - kf->P[1][0] + kf->Q_angle);
    kf->P[0][1] -= dt * kf->P[1][1];
    kf->P[1][0] -= dt * kf->P[1][1];
    kf->P[1][1] += kf->Q_bias * dt;

    /* --- 更新 --- */
    S  = kf->P[0][0] + kf->R_measure;
    K0 = kf->P[0][0] / S;
    K1 = kf->P[1][0] / S;

    y = newAngle - kf->angle;
    kf->angle += K0 * y;
    kf->bias  += K1 * y;

    P00_temp = kf->P[0][0];
    P01_temp = kf->P[0][1];

    kf->P[0][0] -= K0 * P00_temp;
    kf->P[0][1] -= K0 * P01_temp;
    kf->P[1][0] -= K1 * P00_temp;
    kf->P[1][1] -= K1 * P01_temp;

    return kf->angle;
}

/* ==========================================================================
 *  低通滤波（对原始加速度做一次，减小抖动）
 * ========================================================================== */

static float lpf(float prev, float now)
{
    return prev + MPU_LPF_ALPHA * (now - prev);
}

/* ==========================================================================
 *  初始化 / 校准 / 读取
 * ========================================================================== */

/** 全局实例（定义在 main.c，这里只引用） */
extern MPU6050_t mpu;
static uint32_t last_tick_ms = 0U;

uint8_t MPU6050_Init(void)
{
    uint8_t id;

    i2c_gpio_init();
    i2c_bus_recover();
    HAL_Delay(50U);             /* 等 MPU6050 上电稳定 */

    address=0x68U;
    id = MPU6050_WhoAmI();
    if(id!=WHO_AM_I_VALUE) { address=0x69U; id=MPU6050_WhoAmI(); }
    if (id != WHO_AM_I_VALUE) {
        return 1U;              /* 没接好 / 地址不对（AD0 接高时为 0x69） */
    }

    /* 复位 → 唤醒 → 选时钟源 */
    if(MPU6050_WriteReg(REG_PWR_MGMT_1, 0x80U)) return 1U;
    HAL_Delay(100U);
    if(MPU6050_WriteReg(REG_PWR_MGMT_1,0x01U) ||
       MPU6050_WriteReg(REG_PWR_MGMT_2,0x00U)) return 1U;
    HAL_Delay(20U);
    /* 200 Hz, ~94 Hz accelerometer bandwidth, +/-8g and +/-500 dps. */
    if(MPU6050_WriteReg(REG_SMPLRT_DIV,0x04U) ||
       MPU6050_WriteReg(REG_CONFIG,0x02U) ||
       MPU6050_WriteReg(REG_GYRO_CONFIG,0x08U) ||
       MPU6050_WriteReg(REG_ACCEL_CONFIG,0x10U)) return 1U;
    {
        uint8_t actual;
        if(MPU6050_ReadRegs(REG_ACCEL_CONFIG,&actual,1U) || (actual&0x18U)!=0x10U)
            return 1U;
    }
    first_sample=1U;

    kalman_init(&kal_roll);
    kalman_init(&kal_pitch);

    last_tick_ms = HAL_GetTick();
    return 0U;
}

uint8_t MPU6050_Calibrate(void)
{
    uint32_t i;
    uint32_t n = 0U;
    float sx = 0.0f, sy = 0.0f, sz = 0.0f;
    uint8_t raw[6];

    for (i = 0U; i < MPU_CALIB_SAMPLES; i++) {
        if (MPU6050_ReadRegs(REG_GYRO_XOUT_H, raw, 6U) == 0U) {
            sx += (float)(int16_t)(((uint16_t)raw[0] << 8) | raw[1]);
            sy += (float)(int16_t)(((uint16_t)raw[2] << 8) | raw[3]);
            sz += (float)(int16_t)(((uint16_t)raw[4] << 8) | raw[5]);
            entropy_add((uint32_t)raw[0] | ((uint32_t)raw[1]<<8) | ((uint32_t)raw[3]<<16) | ((uint32_t)raw[5]<<24));
            entropy_add(SysTick->VAL);
            n++;
        }
        HAL_Delay(5U);
    }

    /* 只对「成功读到的样本」求平均；n 为 0 时保留 0 零偏，不影响后续运行 */
    if (n > 0U) {
        mpu.GyroBiasX = sx / (float)n / GYRO_LSB_PER_DPS;
        mpu.GyroBiasY = sy / (float)n / GYRO_LSB_PER_DPS;
        mpu.GyroBiasZ = sz / (float)n / GYRO_LSB_PER_DPS;
    }

    last_tick_ms = HAL_GetTick();
    return (uint8_t)(n < MPU_CALIB_SAMPLES*9U/10U);
}

uint8_t MPU6050_Read_All(MPU6050_t *d)
{
    uint8_t buf[14];
    int16_t raw_temp;
    uint32_t now_ms;
    float dt;
    float ax, ay, az;
    float gx, gy, gz;
    float roll_acc, pitch_acc;


    if (MPU6050_ReadRegs(REG_ACCEL_XOUT_H, buf, 14U) != 0U) {
        return 1U;              /* Caller must not process stale data. */
    }
    {
        uint8_t i,nonzero=0U;
        for(i=0;i<14U;i++) nonzero|=buf[i];
        if(!nonzero) return 1U;
    }

    d->Accel_X_RAW = (int16_t)(((uint16_t)buf[0]  << 8) | buf[1]);
    d->Accel_Y_RAW = (int16_t)(((uint16_t)buf[2]  << 8) | buf[3]);
    d->Accel_Z_RAW = (int16_t)(((uint16_t)buf[4]  << 8) | buf[5]);
    raw_temp       = (int16_t)(((uint16_t)buf[6]  << 8) | buf[7]);
    d->Gyro_X_RAW  = (int16_t)(((uint16_t)buf[8]  << 8) | buf[9]);
    d->Gyro_Y_RAW  = (int16_t)(((uint16_t)buf[10] << 8) | buf[11]);
    d->Gyro_Z_RAW  = (int16_t)(((uint16_t)buf[12] << 8) | buf[13]);

    d->Temperature = (float)raw_temp / 340.0f + 36.53f;

    /* --- 换算物理量，并扣掉上电校准得到的零偏 --- */
    ax = (float)d->Accel_X_RAW / ACCEL_LSB_PER_G;
    ay = (float)d->Accel_Y_RAW / ACCEL_LSB_PER_G;
    az = (float)d->Accel_Z_RAW / ACCEL_LSB_PER_G;

    gx = (float)d->Gyro_X_RAW / GYRO_LSB_PER_DPS - d->GyroBiasX;
    gy = (float)d->Gyro_Y_RAW / GYRO_LSB_PER_DPS - d->GyroBiasY;
    gz = (float)d->Gyro_Z_RAW / GYRO_LSB_PER_DPS - d->GyroBiasZ;

    if (first_sample) {
        ax_f=ax; ay_f=ay; az_f=az;
        kal_roll.angle=atan2f(ay,az)*RAD_TO_DEG;
        kal_pitch.angle=atan2f(-ax,sqrtf(ay*ay+az*az))*RAD_TO_DEG;
        first_sample=0U;
    }
    d->AccMag=sqrtf(ax*ax+ay*ay+az*az);
    /* Preserve gravity direction during impulsive acceleration. */
    if(d->AccMag>0.70f && d->AccMag<1.30f) {
        ax_f=lpf(ax_f,ax); ay_f=lpf(ay_f,ay); az_f=lpf(az_f,az);
    }
    d->Ax=ax_f; d->Ay=ay_f; d->Az=az_f;

    d->Gx = gx;
    d->Gy = gy;
    d->Gz = gz;

    /* --- 姿态解算 --- */
    now_ms = HAL_GetTick();
    dt = (float)(now_ms - last_tick_ms) / 1000.0f;
    last_tick_ms = now_ms;
    if (dt <= 0.0f)   { dt = 0.001f; }
    if (dt > 0.05f)   { dt = 0.05f; }     /* 限幅，防止长时间阻塞后积分炸掉 */

    /* 加速度计直接解算角度 */
    roll_acc  = atan2f(d->Ay, d->Az) * RAD_TO_DEG;
    pitch_acc = atan2f(-d->Ax, sqrtf(d->Ay * d->Ay + d->Az * d->Az)) * RAD_TO_DEG;

    d->AngleRoll  = kalman_update(&kal_roll,  roll_acc,  gx, dt);
    d->AnglePitch = kalman_update(&kal_pitch, pitch_acc, gy, dt);

    /* 偏航：只做陀螺积分，会漂移，本工程仅用于可选的「旋转」彩蛋 */
    d->AngleYaw += gz * dt;

    /* --- 派生量：摇动 / 轻弹检测用 --- */
    d->AccMag = sqrtf(ax * ax + ay * ay + az * az);   /* 用未滤波值，保留冲击细节 */
    d->VertAcc = d->AccMag - 1.0f;
    return 0U;
}
