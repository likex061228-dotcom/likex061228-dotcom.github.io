/* Fixed long-axis hourglass; reversing the device reverses the flow. */
#include "hourglass.h"
#include "bead_engine.h"
#include "max7219.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
typedef struct { uint8_t x,y; } Grain;
static Grain grains[BEAD_TOTAL];
static uint8_t cells[256];
static float step_time,neck_time;
static int top(int x) {
    int edge=x<16?x:31-x;
    return edge<=6?1:(edge<=11?2:3);
}
static int allowed(int x,int y) {
    return x>=1 && x<=30 && y>=top(x) && y<=7-top(x);
}
static int move(Grain *g,int x,int y) {
    int crossing=(g->x==15 && x==16)||(g->x==16 && x==15);
    if(!allowed(x,y) || cells[x*8+y]) return 0;
    if(crossing && neck_time<HOURGLASS_NECK_S) return 0;
    cells[g->x*8+g->y]=0;g->x=(uint8_t)x;g->y=(uint8_t)y;cells[x*8+y]=1;
    if(crossing) neck_time=0;
    return 1;
}
void Hourglass_Init(void) {
    unsigned i;
    memset(cells,0,sizeof cells);
    for(i=0;i<BEAD_TOTAL;i++) {
        int x,y;
        do {x=1+rand()%15;if(i>=BEAD_TOTAL/2U) x=31-x;y=rand()%8;}
        while(!allowed(x,y) || cells[x*8+y]);
        grains[i].x=(uint8_t)x;grains[i].y=(uint8_t)y;cells[x*8+y]=1;
    }
    step_time=neck_time=0;
}
void Hourglass_Update(float gx,float gy,float dt) {
    unsigned order[BEAD_TOTAL],i,j;
    int direction=gx>0?1:-1;
    float strength=fabsf(gx);
    (void)gy; /* Only the fixed long axis drives this mode. */
    if(dt<=0 || strength<0.08f) {step_time=0;return;}
    if(dt>0.05f) dt=0.05f;
    if(strength>1) strength=1;
    neck_time+=dt;if(neck_time>HOURGLASS_NECK_S) neck_time=HOURGLASS_NECK_S;
    step_time+=dt*strength;
    if(step_time<HOURGLASS_STEP_S) return;
    step_time-=HOURGLASS_STEP_S;
    for(i=0;i<BEAD_TOTAL;i++) order[i]=i;
    for(i=1;i<BEAD_TOTAL;i++) {
        unsigned v=order[i];j=i;
        while(j && direction*(int)grains[order[j-1]].x<direction*(int)grains[v].x) {
            order[j]=order[j-1];--j;
        }
        order[j]=v;
    }
    for(i=0;i<BEAD_TOTAL;i++) {
        Grain *g=&grains[order[i]];
        int x=g->x,y=g->y,nx=x+direction,side=y<4?1:-1;
        if(move(g,nx,y)) continue;
        if(move(g,nx,y+side)) continue;
        if(move(g,nx,y-side)) continue;
        if(direction>0?x>=26:x<=5) {
            int outward=y<4?-1:1;
            if(move(g,x,y+outward)) continue;
        }
        if((y<3 || y>4) && (direction>0?(x>=6 && x<=14):(x>=17 && x<=25)))
            (void)move(g,x,y+side);
    }
}
void Hourglass_Render(void) {
    unsigned i;int x,y;
    LED_Clear();
    for(x=1;x<=30;x++) {
        LED_SetPixel((uint8_t)x,(uint8_t)(top(x)-1),1);
        LED_SetPixel((uint8_t)x,(uint8_t)(8-top(x)),1);
    }
    for(y=0;y<8;y++) {LED_SetPixel(0,(uint8_t)y,1);LED_SetPixel(31,(uint8_t)y,1);}
    for(i=0;i<BEAD_TOTAL;i++) LED_SetPixel(grains[i].x,grains[i].y,1);
}
uint8_t Hourglass_LeftCount(void) {
    unsigned i;uint8_t n=0;
    for(i=0;i<BEAD_TOTAL;i++) if(grains[i].x<=15) ++n;
    return n;
}
uint8_t Hourglass_IsVertical(void) {return 0;}
uint8_t Hourglass_Validate(void) {
    unsigned i;uint8_t seen[256]={0};
    for(i=0;i<BEAD_TOTAL;i++) {
        int x=grains[i].x,y=grains[i].y;
        if(!allowed(x,y) || seen[x*8+y]) return 0;
        seen[x*8+y]=1;
    }
    return 1;
}
