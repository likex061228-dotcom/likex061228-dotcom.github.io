#include "motion.h"
#include "config.h"
#include <math.h>
#include <string.h>
void Motion_Init(MotionState *s,uint32_t now) {
    memset(s,0,sizeof(*s)); s->baseline=1.0f; s->boot=now;
}
MotionEvent Motion_Update(MotionState *s,float magnitude,uint32_t now) {
    float deviation=fabsf(magnitude-s->baseline);
    MotionEvent event=MOTION_NONE;
    if((uint32_t)(now-s->boot)<150U) return MOTION_NONE;
    if(deviation<0.15f) s->baseline+=0.01f*(magnitude-s->baseline);
    if(deviation>MOTION_SHAKE_THRESHOLD) {
        if(!s->high_active) {s->high_active=1;s->high_started=now;}
    } else s->high_active=0;
    if(deviation>fminf(MOTION_SHAKE_THRESHOLD,MOTION_TAP_THRESHOLD)) {
        if(!s->active) { s->active=1; s->started=now; s->peak=deviation; s->shake_sent=0; }
        if(deviation>s->peak) s->peak=deviation;
        if(s->high_active &&
           (uint32_t)(now-s->high_started)>=MOTION_SHAKE_HOLD_MS && !s->shake_sent) {
            event=MOTION_SHAKE; s->shake_sent=1;
        }
        /* Continue kicking under sustained shaking, at most every 180 ms. */
        if(s->high_active && s->shake_sent && (uint32_t)(now-s->last_event)>=MOTION_COOLDOWN_MS) event=MOTION_SHAKE;
    } else if(s->active) {
        if(!s->shake_sent && s->peak>MOTION_TAP_THRESHOLD) event=MOTION_TAP;
        s->active=0;
    }
    if(event!=MOTION_NONE) {
        if(s->have_event && (uint32_t)(now-s->last_event)<MOTION_COOLDOWN_MS) return MOTION_NONE;
        s->have_event=1; s->last_event=now; s->strength=s->peak;
    }
    return event;
}

static float gravity_axis(float value) {
    float dead=sinf(TILT_DEADZONE_DEG*0.01745329252f);
    float full=sinf(TILT_FULLSCALE_DEG*0.01745329252f);
    float g=(fabsf(value)-dead)/(full-dead);
    if(g<0) g=0;
    if(g>1) g=1;
    return value<0?-g:g;
}
void Motion_Gravity(float ax,float ay,float az,float *gx,float *gy) {
    float n=sqrtf(ax*ax+ay*ay+az*az),x,y;
    if(n<0.1f) { *gx=0; *gy=0; return; }
    x=(GRAV_X_AXIS==0U?ax:ay)/n;
    y=(GRAV_Y_AXIS==0U?ax:ay)/n;
    *gx=gravity_axis(x)*(float)GRAV_X_SIGN;
    *gy=gravity_axis(y)*(float)GRAV_Y_SIGN;
    n=sqrtf((*gx)*(*gx)+(*gy)*(*gy));
    if(n>1) { *gx/=n; *gy/=n; }
}
void Flip_Init(FlipState *s) { memset(s,0,sizeof(*s)); }
uint8_t Flip_Update(FlipState *s,float az,uint32_t now) {
    if(s->phase==2 && (uint32_t)(now-s->released_at)>2000U) {
        s->phase=0;return 0;
    }
    if(s->phase==0 && az < -0.8f) {
        s->phase=1;s->inverted_since=now;
    } else if(s->phase==1 && az > -0.6f) {
        s->held_ms=(uint32_t)(now-s->inverted_since);s->released_at=now;s->phase=2;
    } else if(s->phase==2 && az < -0.8f) {
        s->phase=1;s->inverted_since=now;
    }
    if(s->phase==2 && az>0.8f) {
        s->phase=0;
        return (uint8_t)(s->held_ms>=1500U);
    }
    return 0;
}
