/**
 ******************************************************************************
 * @file    app_ui.c
 * @brief   点阵显示辅助实现：自检动画 + 5×7 字库 + 装饰图案
 ******************************************************************************
 */

#include "app_ui.h"
#include "max7219.h"

/* ==========================================================================
 *  字符取模方向
 *  ------------------------------------------------------------------------
 *  5×7 字库，每个字符 5 列；某列的 bit0 = 最上面一行，bit6 = 最下面一行。
 *  与 LED_Buf[col*8+row] 的 bit 顺序天然一致，无需翻转。
 * ========================================================================== */

typedef struct {
    char    ch;
    uint8_t col[5];
} Glyph_t;

static const Glyph_t font5x7[] = {
    { ' ', { 0x00, 0x00, 0x00, 0x00, 0x00 } },
    { '-', { 0x08, 0x08, 0x08, 0x08, 0x08 } },
    { '.', { 0x00, 0x60, 0x60, 0x00, 0x00 } },
    { ':', { 0x00, 0x36, 0x36, 0x00, 0x00 } },
    { '/', { 0x20, 0x10, 0x08, 0x04, 0x02 } },

    { '0', { 0x3E, 0x51, 0x49, 0x45, 0x3E } },
    { '1', { 0x00, 0x42, 0x7F, 0x40, 0x00 } },
    { '2', { 0x42, 0x61, 0x51, 0x49, 0x46 } },
    { '3', { 0x21, 0x41, 0x45, 0x4B, 0x31 } },
    { '4', { 0x18, 0x14, 0x12, 0x7F, 0x10 } },
    { '5', { 0x27, 0x45, 0x45, 0x45, 0x39 } },
    { '6', { 0x3C, 0x4A, 0x49, 0x49, 0x30 } },
    { '7', { 0x01, 0x71, 0x09, 0x05, 0x03 } },
    { '8', { 0x36, 0x49, 0x49, 0x49, 0x36 } },
    { '9', { 0x06, 0x49, 0x49, 0x29, 0x1E } },

    { 'A', { 0x7E, 0x11, 0x11, 0x11, 0x7E } },
    { 'B', { 0x7F, 0x49, 0x49, 0x49, 0x36 } },
    { 'C', { 0x3E, 0x41, 0x41, 0x41, 0x22 } },
    { 'D', { 0x7F, 0x41, 0x41, 0x22, 0x1C } },
    { 'E', { 0x7F, 0x49, 0x49, 0x49, 0x41 } },
    { 'F', { 0x7F, 0x09, 0x09, 0x09, 0x01 } },
    { 'G', { 0x3E, 0x41, 0x49, 0x49, 0x7A } },
    { 'H', { 0x7F, 0x08, 0x08, 0x08, 0x7F } },
    { 'I', { 0x00, 0x41, 0x7F, 0x41, 0x00 } },
    { 'J', { 0x20, 0x40, 0x41, 0x3F, 0x01 } },
    { 'K', { 0x7F, 0x08, 0x14, 0x22, 0x41 } },
    { 'L', { 0x7F, 0x40, 0x40, 0x40, 0x40 } },
    { 'M', { 0x7F, 0x02, 0x0C, 0x02, 0x7F } },
    { 'N', { 0x7F, 0x04, 0x08, 0x10, 0x7F } },
    { 'O', { 0x3E, 0x41, 0x41, 0x41, 0x3E } },
    { 'P', { 0x7F, 0x09, 0x09, 0x09, 0x06 } },
    { 'Q', { 0x3E, 0x41, 0x51, 0x21, 0x5E } },
    { 'R', { 0x7F, 0x09, 0x19, 0x29, 0x46 } },
    { 'S', { 0x46, 0x49, 0x49, 0x49, 0x31 } },
    { 'T', { 0x01, 0x01, 0x7F, 0x01, 0x01 } },
    { 'U', { 0x3F, 0x40, 0x40, 0x40, 0x3F } },
    { 'V', { 0x1F, 0x20, 0x40, 0x20, 0x1F } },
    { 'W', { 0x3F, 0x40, 0x38, 0x40, 0x3F } },
    { 'X', { 0x63, 0x14, 0x08, 0x14, 0x63 } },
    { 'Y', { 0x07, 0x08, 0x70, 0x08, 0x07 } },
    { 'Z', { 0x61, 0x51, 0x49, 0x45, 0x43 } },
};

#define FONT_ROWS       (7U)
#define FONT_WIDTH      (5U)
#define FONT_SPACING    (1U)

static const Glyph_t *font_find(char ch)
{
    uint8_t i;
    char c = ch;

    if ((c >= 'a') && (c <= 'z')) {
        c = (char)(c - 'a' + 'A');      /* 小写按大写显示 */
    }

    for (i = 0U; i < (uint8_t)(sizeof(font5x7) / sizeof(font5x7[0])); i++) {
        if (font5x7[i].ch == c) {
            return &font5x7[i];
        }
    }
    return NULL;
}

uint8_t UI_DrawChar(uint8_t col, uint8_t row, char ch, uint8_t on)
{
    const Glyph_t *g = font_find(ch);
    uint8_t k, r;

    if (g == NULL) {
        return 0U;
    }

    /* on = 0 时只计算宽度不落笔，便于上层做「先量宽度再定位」 */
    if (on == 0U) {
        return (uint8_t)(FONT_WIDTH + FONT_SPACING);
    }

    for (k = 0U; k < FONT_WIDTH; k++) {
        uint8_t bits = g->col[k];
        for (r = 0U; r < FONT_ROWS; r++) {
            if ((bits >> r) & 0x01U) {
                LED_SetPixel((uint8_t)(col + k), (uint8_t)(row + r), 1U);
            }
        }
    }

    return (uint8_t)(FONT_WIDTH + FONT_SPACING);
}

uint8_t UI_DrawString(uint8_t col, uint8_t row, const char *s, uint8_t on)
{
    uint8_t c = col;

    while ((*s != '\0') && (c < MATRIX_COLS)) {
        uint8_t w = UI_DrawChar(c, row, *s, on);
        if (w == 0U) {
            w = (uint8_t)(FONT_WIDTH + FONT_SPACING);
        }
        c = (uint8_t)(c + w);
        s++;
    }
    return c;
}

/* ==========================================================================
 *  自检动画（要求 2）
 * ========================================================================== */

static void selftest_flash(uint8_t times)
{
    uint8_t i;
    for (i = 0U; i < times; i++) {
        LED_FillAll();
        LED_Refresh();
        HAL_Delay(SELFTEST_FLASH_MS);

        LED_Clear();
        LED_Refresh();
        HAL_Delay(SELFTEST_FLASH_MS / 2U);
    }
}

void UI_SelfTest(void)
{
    uint8_t row;
    uint8_t col;
    uint32_t mask;

    /* ---------- 阶段 1：整屏快闪，确认没有坏点 ---------- */
    selftest_flash(2U);

    /* ---------- 阶段 2：逐行点亮（上 → 下），确认 8 行驱动 ---------- */
    for (row = 0U; row < MATRIX_ROWS; row++) {
        LED_Clear();
        mask = 0xFFFFFFFFUL;                /* 32 列全亮 */
        LED_SetRowMask(row, mask);
        LED_Refresh();
        HAL_Delay(SELFTEST_ROW_MS);
    }

    /* ---------- 阶段 3：逐列点亮（左 → 右），确认 4 片级联顺序 ---------- */
    for (col = 0U; col < MATRIX_COLS; col++) {
        LED_Clear();
        LED_SetCol(col, 1U);
        LED_Refresh();
        HAL_Delay(SELFTEST_COL_MS);
    }

    /* ---------- 阶段 4：所有单元顺序闪烁（跑马灯）---------- */
    LED_Clear();
    for (col = 0U; col < MATRIX_COLS; col++) {
        for (row = 0U; row < MATRIX_ROWS; row++) {
            LED_SetPixel(col, row, 1U);
            LED_Refresh();
            HAL_Delay(SELFTEST_CELL_MS/2U);
            LED_SetPixel(col,row,0U);
            LED_Refresh();
            HAL_Delay(SELFTEST_CELL_MS-SELFTEST_CELL_MS/2U);
        }
    }

    /* ---------- 收尾：全亮 → 全灭，提示自检结束 ---------- */
    selftest_flash(1U);
}

void UI_BlinkAll(uint8_t times, uint16_t on_ms, uint16_t off_ms)
{
    uint8_t i;
    for (i = 0U; i < times; i++) {
        LED_FillAll();
        LED_Refresh();
        HAL_Delay(on_ms);
        LED_Clear();
        LED_Refresh();
        HAL_Delay(off_ms);
    }
}

/* ==========================================================================
 *  故障提示
 * ========================================================================== */

/** 传感器故障图标：8×8，外框 + 中间感叹号 */
static const uint8_t icon_sensor_error[8] = {
    0xFF, 0x81, 0xBD, 0xA5, 0xA5, 0xBD, 0x81, 0xFF
};

/** 笑脸图标：8×8（正常状态用） */
static const uint8_t icon_smile[8] = {
    0x3C, 0x42, 0xA5, 0x81, 0xA5, 0x99, 0x42, 0x3C
};

void UI_ShowIcon(const uint8_t icon[8])
{
    uint8_t r;

    LED_Clear();
    for (r = 0U; r < 8U; r++) {
        uint8_t bits = icon[r];
        uint8_t c;
        for (c = 0U; c < 8U; c++) {
            /* 图标第 r 行第 c 位 → 点阵第 (12 + c) 列、第 r 行（居中） */
            if ((bits >> (7U - c)) & 0x01U) {
                LED_SetPixel((uint8_t)(12U + c), r, 1U);
            }
        }
    }
    LED_Refresh();
}

void UI_ShowSensorError(void)
{
    UI_ShowIcon(icon_sensor_error);
}

/* ==========================================================================
 *  装饰图案（要求 8）
 * ========================================================================== */

/** 32 点正弦表，幅度 3 格，居中在第 4 行附近 */
static const int8_t sine_lut[32] = {
     0,  1,  1,  2,  2,  3,  3,  3,  3,  3,  3,  2,  2,  1,  1,  0,
     0, -1, -1, -2, -2, -3, -3, -3, -3, -3, -3, -2, -2, -1, -1,  0
};

void UI_DrawSineWave(uint16_t phase)
{
    uint8_t col;

    for (col = 0U; col < MATRIX_COLS; col++) {
        int16_t idx = (int16_t)((col + phase) & 0x1FU);
        int16_t y = (int16_t)((MATRIX_ROWS / 2) + sine_lut[idx]);
        if ((y >= 0) && (y < (int16_t)MATRIX_ROWS)) {
            LED_SetPixel(col, (uint8_t)y, 1U);
        }
    }
}

void UI_DrawProgressBar(uint8_t percent, uint8_t row)
{
    uint8_t col;
    uint8_t lit;

    if (percent > 100U) { percent = 100U; }
    lit = (uint8_t)(((uint32_t)percent * MATRIX_COLS) / 100U);

    if (row >= MATRIX_ROWS) { return; }

    for (col = 0U; col < MATRIX_COLS; col++) {
        LED_SetPixel(col, row, (uint8_t)((col < lit) ? 1U : 0U));
    }
}

/** 正常状态笑脸（上电成功后短暂显示，作为「系统就绪」提示） */
void UI_ShowSensorOk(void)
{
    UI_ShowIcon(icon_smile);
}
