# 点阵滚动与重力互动

作者：Like_x

## 概述
STM32F103C8T6、MPU6050 与四片 MAX7219 组成 8×32 LED 点阵。当前版本包含重力滚动、光点堆积、摇动弹跳、轻弹和沙漏模式。

历史工程名 chang_OLED 沿用至今；当前主工程的显示硬件是 MAX7219 LED 点阵，不能将其描述为 OLED 屏。

## 代码入口
- Core/Src/app_main.c：应用入口与主循环。
- Core/Src/bead_engine.c：光点运动与堆积。
- Core/Src/motion.c、mpu6050.c：运动处理与姿态采集。
- Core/Src/hourglass.c：沙漏模式。
- Core/Src/max7219.c：点阵显示驱动。
- MDK-ARM/chang_OLED.uvprojx：Keil 工程。

默认珠盘使用64颗光点；倾斜滚动、摇动弹跳。倒扣保持并及时翻回可切换固定横向沙漏，重复动作返回珠盘。沙漏是趣味视觉效果，不是校准计时器。

## 连接
MAX7219：CS=PA4，CLK=PA5，DIN=PA7。MPU6050：SCL=PB6，SDA=PB7。以 Core 与 .ioc 实际配置为准；确认模块供电和电平兼容并共地。

本次仅整理公开源码，未重新编译、下载或测试硬件。未包含历史备份、测试录像、桌面截图和私人日志。Drivers 中的上游许可继续适用。
