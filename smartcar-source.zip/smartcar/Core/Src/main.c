/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Smart Car - BT Remote + Auto Avoid + Sound Locate (INMP441)
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include "core_cm3.h"  // DWT
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum {
	
	
    DIR_STOP = 0,
    DIR_FORWARD = 1,
    DIR_BACKWARD = 2,
    DIR_LEFT = 3,
    DIR_RIGHT = 4,
    DIR_SPIN_LEFT = 5,
    DIR_SPIN_RIGHT = 6
} CarDirection;

typedef enum {
    SPEED_LOW = 0,
    SPEED_MEDIUM = 1,
    SPEED_HIGH = 2,
    SPEED_MAX = 3
} SpeedLevel;

typedef enum {
    MODE_MANUAL = 0,
    MODE_AVOID = 1,
    MODE_SOUND = 2
} ControlMode;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PWM_MIN          0
#define PWM_MAX          1000
#define SPEED_LOW_PWM    300
#define SPEED_MEDIUM_PWM 600
#define SPEED_HIGH_PWM   800
#define SPEED_MAX_PWM    1000

// BT commands
#define CMD_FORWARD      'F'
#define CMD_BACKWARD     'B'
#define CMD_LEFT         'L'
#define CMD_RIGHT        'R'
#define CMD_STOP         'S'
#define CMD_SPIN_LEFT    'G'
#define CMD_SPIN_RIGHT   'H'
#define CMD_SPEED_LOW    '1'
#define CMD_SPEED_MED    '2'
#define CMD_SPEED_HIGH   '3'
#define CMD_SPEED_MAX    '4'
#define CMD_INFO         'I'
#define CMD_HELP         '?'
#define CMD_TEST         'T'
#define CMD_AUTO_MODE    'A'
#define CMD_MANUAL_MODE  'M'
#define CMD_SOUND_MODE   'E'
#define CMD_SERVO_LEFT   'U'
#define CMD_SERVO_RIGHT  'D'
#define CMD_ULTRASONIC   'C'
#define CMD_DEBUG        'X'

// Avoidance params
#define OBSTACLE_DISTANCE 30
#define DEAD_END_THRESHOLD 20
#define TURN_BASE_TIME     400
#define BACKUP_TIME        400
#define SPIN_TIME          600

// Ultrasonic
#define MAX_VALID_DISTANCE 400
#define MIN_VALID_DISTANCE 5
#define SAMPLE_COUNT       5

// Sound locate params
#define SOUND_SAMPLE_MS    50
#define SOUND_THRESHOLD    50
#define SOUND_TURN_TIME    300

#define RX_BUFFER_SIZE   32
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
// Right motor direction (AIN1=PA4, AIN2=PA5)
#define MOTOR_RIGHT_FORWARD() \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);   \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET)

#define MOTOR_RIGHT_BACKWARD() \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET); \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET)

#define MOTOR_RIGHT_STOP() \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET); \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET)

// Left motor direction (BIN1=PA6, BIN2=PA7)
#define MOTOR_LEFT_FORWARD() \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET); \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET)

#define MOTOR_LEFT_BACKWARD() \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);   \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET)

#define MOTOR_LEFT_STOP() \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET); \
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET)

// Mic SD pin read
#define READ_LEFT_MIC()   HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1)
#define READ_RIGHT_MIC()  HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3)
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
CarDirection currentDirection = DIR_STOP;
SpeedLevel currentSpeed = SPEED_MEDIUM;
uint16_t currentPWMValue = SPEED_MEDIUM_PWM;
uint32_t systemUptime = 0;
ControlMode controlMode = MODE_MANUAL;

// Avoidance state machine
static uint8_t avoidStep = 0;

// BT receive
volatile uint8_t rxData = 0;
volatile uint8_t rxDataReady = 0;

// Ultrasonic (DWT timing)
volatile uint32_t echoStartTime = 0;
volatile uint32_t echoEndTime = 0;
volatile uint8_t echoFlag = 0;
volatile uint8_t echoRisingFlag = 0;

// Sound locate
uint32_t leftMicAcc = 0;
uint32_t rightMicAcc = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
// Motor
void Motor_Init(void);
void Motor_SetSpeed(uint16_t speed);
void Motor_SetDirection(CarDirection direction);
void Motor_Stop(void);
void Motor_Forward(void);
void Motor_Backward(void);
void Motor_TurnLeft(void);
void Motor_TurnRight(void);
void Motor_SpinLeft(void);
void Motor_SpinRight(void);

// BT
void Bluetooth_SendString(const char* str);
void Bluetooth_SendInfo(void);
void Bluetooth_SendHelp(void);
void Process_Bluetooth_Command(char cmd);
void Motor_Test_Sequence(void);

// Servo (TIM3: PSC=71, ARR=19999, 1MHz count -> 50Hz)
void Servo_SetAngle(uint8_t angle);

// Ultrasonic (DWT microsecond timing)
void DWT_Init(void);
uint32_t DWT_GetMicros(void);
void Ultrasonic_Init(void);
void Ultrasonic_Trigger(void);
uint32_t Ultrasonic_GetDistance(void);
uint32_t Ultrasonic_GetDistanceFiltered(void);

// Mic
void Mic_Init(void);
void Mic_Sample(uint32_t duration_ms);
int8_t Mic_GetDirection(void);

// Auto modes
void Auto_Avoid_Obstacle(void);
void Auto_Sound_Localize(void);

// System
void System_Init(void);
void System_Tick(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//=============================================================================
// Motor Control
//=============================================================================
void Motor_Init(void) {
    Motor_Stop();
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, 0);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, 0);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
    Motor_SetSpeed(SPEED_MEDIUM_PWM);
}

void Motor_SetSpeed(uint16_t speed) {
    if (speed > PWM_MAX) speed = PWM_MAX;
    if (speed < PWM_MIN) speed = PWM_MIN;
    currentPWMValue = speed;
    if (currentDirection != DIR_STOP) {
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, speed);
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, speed);
    }
    if (speed == SPEED_LOW_PWM) currentSpeed = SPEED_LOW;
    else if (speed == SPEED_MEDIUM_PWM) currentSpeed = SPEED_MEDIUM;
    else if (speed == SPEED_HIGH_PWM) currentSpeed = SPEED_HIGH;
    else if (speed == SPEED_MAX_PWM) currentSpeed = SPEED_MAX;
}

void Motor_SetDirection(CarDirection direction) {
    if (currentDirection != DIR_STOP) {
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, 0);
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, 0);
        HAL_Delay(5);
    }
    currentDirection = direction;
    switch (direction) {
    case DIR_STOP:      Motor_Stop(); break;
    case DIR_FORWARD:   Motor_Forward(); break;
    case DIR_BACKWARD:  Motor_Backward(); break;
    case DIR_LEFT:      Motor_TurnLeft(); break;
    case DIR_RIGHT:     Motor_TurnRight(); break;
    case DIR_SPIN_LEFT: Motor_SpinLeft(); break;
    case DIR_SPIN_RIGHT:Motor_SpinRight(); break;
    }
    if (direction != DIR_STOP) {
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3, currentPWMValue);
        __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4, currentPWMValue);
    }
}

void Motor_Stop(void) {
    MOTOR_RIGHT_STOP();
    MOTOR_LEFT_STOP();
}

void Motor_Forward(void) {
    MOTOR_RIGHT_FORWARD();
    MOTOR_LEFT_FORWARD();
}

void Motor_Backward(void) {
    MOTOR_RIGHT_BACKWARD();
    MOTOR_LEFT_BACKWARD();
}

void Motor_TurnLeft(void) {
    MOTOR_RIGHT_FORWARD();
    MOTOR_LEFT_STOP();
}

void Motor_TurnRight(void) {
    MOTOR_RIGHT_STOP();
    MOTOR_LEFT_FORWARD();
}

void Motor_SpinLeft(void) {
    MOTOR_RIGHT_FORWARD();
    MOTOR_LEFT_BACKWARD();
}

void Motor_SpinRight(void) {
    MOTOR_RIGHT_BACKWARD();
    MOTOR_LEFT_FORWARD();
}

//=============================================================================
// Bluetooth
//=============================================================================
void Bluetooth_SendString(const char* str) {
    if (str != NULL) {
        HAL_UART_Transmit(&huart1, (uint8_t*)str, strlen(str), 1000);
    }
}

void Bluetooth_SendInfo(void) {
    char info[128];
    Bluetooth_SendString("\r\n========== System Status ==========\r\n");
    sprintf(info, "Uptime: %u ms\r\n", (unsigned int)systemUptime);
    Bluetooth_SendString(info);
    sprintf(info, "Direction: ");
    Bluetooth_SendString(info);
    switch (currentDirection) {
    case DIR_STOP: Bluetooth_SendString("STOP"); break;
    case DIR_FORWARD: Bluetooth_SendString("FORWARD"); break;
    case DIR_BACKWARD: Bluetooth_SendString("BACKWARD"); break;
    case DIR_LEFT: Bluetooth_SendString("LEFT"); break;
    case DIR_RIGHT: Bluetooth_SendString("RIGHT"); break;
    case DIR_SPIN_LEFT: Bluetooth_SendString("SPIN LEFT"); break;
    case DIR_SPIN_RIGHT: Bluetooth_SendString("SPIN RIGHT"); break;
    }
    sprintf(info, "\r\nSpeed: %d%% (PWM: %d)\r\n", currentPWMValue * 100 / PWM_MAX, currentPWMValue);
    Bluetooth_SendString(info);
    sprintf(info, "Speed Level: ");
    Bluetooth_SendString(info);
    switch (currentSpeed) {
    case SPEED_LOW: Bluetooth_SendString("LOW"); break;
    case SPEED_MEDIUM: Bluetooth_SendString("MEDIUM"); break;
    case SPEED_HIGH: Bluetooth_SendString("HIGH"); break;
    case SPEED_MAX: Bluetooth_SendString("MAX"); break;
    }
    sprintf(info, "\r\nMode: ");
    Bluetooth_SendString(info);
    switch (controlMode) {
    case MODE_MANUAL: Bluetooth_SendString("Manual(BT)"); break;
    case MODE_AVOID:  Bluetooth_SendString("Auto Avoid"); break;
    case MODE_SOUND:  Bluetooth_SendString("Sound Locate"); break;
    }
    Bluetooth_SendString("\r\n===================================\r\n");
}

void Bluetooth_SendHelp(void) {
    const char* help =
        "\r\n========== Commands ==========\r\n"
        "Movement (tap to toggle):\r\n"
        "  F - Forward       B - Backward\r\n"
        "  L - Left          R - Right\r\n"
        "  G - Spin Left     H - Spin Right\r\n"
        "  S - Stop\r\n"
        "Speed:\r\n"
        "  1 - Low(30%)      2 - Medium(60%)\r\n"
        "  3 - High(80%)     4 - Max(100%)\r\n"
        "Mode:\r\n"
        "  M - Manual         A - Auto Avoid\r\n"
        "  E - Sound Locate\r\n"
        "System:\r\n"
        "  I - Status         ? - Help\r\n"
        "  T - Motor Test\r\n"
        "  U - Servo Left(150) D - Servo Right(30)\r\n"
        "  C - Distance       X - Debug\r\n"
        "===============================\r\n";
    Bluetooth_SendString((char*)help);
}

void Motor_Test_Sequence(void) {
    Bluetooth_SendString("\r\nMotor Test Start...\r\n");
    Motor_SetDirection(DIR_FORWARD); HAL_Delay(1000); Motor_Stop(); HAL_Delay(500);
    Motor_SetDirection(DIR_BACKWARD); HAL_Delay(1000); Motor_Stop(); HAL_Delay(500);
    Motor_SetDirection(DIR_LEFT); HAL_Delay(1000); Motor_Stop(); HAL_Delay(500);
    Motor_SetDirection(DIR_RIGHT); HAL_Delay(1000); Motor_Stop(); HAL_Delay(500);
    Motor_SetDirection(DIR_SPIN_LEFT); HAL_Delay(1000); Motor_Stop(); HAL_Delay(500);
    Motor_SetDirection(DIR_SPIN_RIGHT); HAL_Delay(1000); Motor_Stop();
    Bluetooth_SendString("Motor Test Done\r\n");
}

//=============================================================================
// Servo (1MHz count: PSC=71, ARR=19999)
//=============================================================================
void Servo_SetAngle(uint8_t angle) {
    if (angle < 30) angle = 30;
    if (angle > 150) angle = 150;
    // 1MHz => 1us/count. 0.5ms=500, 2.5ms=2500
    uint16_t pulse = 500 + (angle * 2000) / 180;
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3, pulse);
    HAL_Delay(20);
}

//=============================================================================
// Ultrasonic (DWT microsecond timing)
//=============================================================================
void DWT_Init(void) {
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}

uint32_t DWT_GetMicros(void) {
    return DWT->CYCCNT / (HAL_RCC_GetHCLKFreq() / 1000000);
}

void Ultrasonic_Init(void) {
    echoFlag = 0;
    echoRisingFlag = 0;
}

void Ultrasonic_Trigger(void) {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
}

uint32_t Ultrasonic_GetDistance(void) {
    uint32_t timeout;
    uint32_t duration;

    echoFlag = 0;
    echoRisingFlag = 0;
    Ultrasonic_Trigger();

    timeout = DWT_GetMicros() + 100000;
    while (!echoRisingFlag) {
        if (DWT_GetMicros() > timeout) return 0;
    }

    timeout = DWT_GetMicros() + 100000;
    while (!echoFlag) {
        if (DWT_GetMicros() > timeout) return 0;
    }

    duration = echoEndTime - echoStartTime;
    return duration / 58;  // 340m/s => cm
}

uint32_t Ultrasonic_GetDistanceFiltered(void) {
    uint32_t samples[SAMPLE_COUNT];
    uint8_t validCount = 0;
    uint32_t temp;

    for (uint8_t i = 0; i < SAMPLE_COUNT; i++) {
        uint32_t d = Ultrasonic_GetDistance();
        if (d > MIN_VALID_DISTANCE && d < MAX_VALID_DISTANCE) {
            samples[validCount++] = d;
        }
        HAL_Delay(15);
    }

    if (validCount == 0) return 999;

    for (uint8_t i = 0; i < validCount - 1; i++) {
        for (uint8_t j = i + 1; j < validCount; j++) {
            if (samples[i] > samples[j]) {
                temp = samples[i];
                samples[i] = samples[j];
                samples[j] = temp;
            }
        }
    }
    return samples[validCount / 2];
}

//=============================================================================
// Mic (INMP441)
//=============================================================================
void Mic_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = { 0 };
    GPIO_InitStruct.Pin = GPIO_PIN_1;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_3;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    // PB12 as input (WS signal routing)
    GPIO_InitStruct.Pin = GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    // Start TIM4_CH2 PWM (1MHz SCK)
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);
    // Start TIM1_CH1 PWM (16kHz WS)
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
}

void Mic_Sample(uint32_t duration_ms) {
    uint32_t start = HAL_GetTick();
    leftMicAcc = 0;
    rightMicAcc = 0;

    // ~100kHz sample rate (10us interval)
    while (HAL_GetTick() - start < duration_ms) {
        leftMicAcc += READ_LEFT_MIC();
        rightMicAcc += READ_RIGHT_MIC();
        for (volatile int i = 0; i < 200; i++);
    }
}

int8_t Mic_GetDirection(void) {
    Mic_Sample(SOUND_SAMPLE_MS);

    if (leftMicAcc > rightMicAcc + SOUND_THRESHOLD) {
        return -1;
    } else if (rightMicAcc > leftMicAcc + SOUND_THRESHOLD) {
        return 1;
    } else {
        return 0;
    }
}

//=============================================================================
// Auto Avoid
//=============================================================================
void Auto_Avoid_Obstacle(void) {
    uint32_t frontDist, leftDist, rightDist;
    uint32_t currentTime = HAL_GetTick();
    static uint32_t lastActionTime = 0;

    if (currentTime - lastActionTime < 100) return;
    lastActionTime = currentTime;

    switch (avoidStep) {
    case 0:
        Servo_SetAngle(90);
        HAL_Delay(50);
        frontDist = Ultrasonic_GetDistanceFiltered();
        if (frontDist > OBSTACLE_DISTANCE) {
            Motor_SetDirection(DIR_FORWARD);
        } else {
            Motor_Stop();
            avoidStep = 1;
            HAL_Delay(100);
        }
        break;

    case 1:
        Servo_SetAngle(150); HAL_Delay(150);
        leftDist = Ultrasonic_GetDistanceFiltered();
        Servo_SetAngle(30);  HAL_Delay(150);
        rightDist = Ultrasonic_GetDistanceFiltered();
        Servo_SetAngle(90);  HAL_Delay(50);

        if (leftDist > rightDist && leftDist > DEAD_END_THRESHOLD) {
            avoidStep = 2;
        } else if (rightDist > leftDist && rightDist > DEAD_END_THRESHOLD) {
            avoidStep = 2;
        } else {
            avoidStep = 3;
        }
        break;

    case 2:
        Servo_SetAngle(150); HAL_Delay(100);
        leftDist = Ultrasonic_GetDistanceFiltered();
        Servo_SetAngle(30);  HAL_Delay(100);
        rightDist = Ultrasonic_GetDistanceFiltered();
        Servo_SetAngle(90);  HAL_Delay(50);

        if (leftDist > rightDist && leftDist > DEAD_END_THRESHOLD) {
            Motor_SetDirection(DIR_LEFT);
            HAL_Delay(TURN_BASE_TIME);
        } else if (rightDist > leftDist && rightDist > DEAD_END_THRESHOLD) {
            Motor_SetDirection(DIR_RIGHT);
            HAL_Delay(TURN_BASE_TIME);
        } else {
            avoidStep = 3;
            break;
        }
        Motor_Stop();
        avoidStep = 0;
        break;

    case 3:
        Motor_SetDirection(DIR_BACKWARD);
        HAL_Delay(BACKUP_TIME);
        Motor_Stop();
        HAL_Delay(100);
        Motor_SetDirection(DIR_SPIN_RIGHT);
        HAL_Delay(SPIN_TIME);
        Motor_Stop();
        avoidStep = 0;
        break;

    default:
        avoidStep = 0;
        break;
    }
}

//=============================================================================
// Sound Locate Mode
//=============================================================================
void Auto_Sound_Localize(void) {
    int8_t dir = Mic_GetDirection();
    char msg[32];

    sprintf(msg, "L:%u R:%u Dir:%d\r\n", (unsigned int)leftMicAcc, (unsigned int)rightMicAcc, dir);
    Bluetooth_SendString(msg);

    if (dir == -1) {
        Motor_SetDirection(DIR_SPIN_LEFT);
        HAL_Delay(SOUND_TURN_TIME);
        Motor_Stop();
    } else if (dir == 1) {
        Motor_SetDirection(DIR_SPIN_RIGHT);
        HAL_Delay(SOUND_TURN_TIME);
        Motor_Stop();
    } else {
        Motor_SetDirection(DIR_FORWARD);
        HAL_Delay(300);
        Motor_Stop();
    }
}

//=============================================================================
// BT Command Processing
//=============================================================================
void Process_Bluetooth_Command(char cmd) {
    char response[64];

    // Lowercase letters = immediate stop (for apps that send lowercase on release)
    if (cmd >= 'a' && cmd <= 'z') {
        if (controlMode == MODE_MANUAL) {
            if (currentDirection != DIR_STOP) Motor_SetDirection(DIR_STOP);
        }
        return;
    }

    switch (cmd) {
    case CMD_FORWARD:
        if (controlMode == MODE_MANUAL) Motor_SetDirection(DIR_FORWARD);
        break;
    case CMD_BACKWARD:
        if (controlMode == MODE_MANUAL) Motor_SetDirection(DIR_BACKWARD);
        break;
    case CMD_LEFT:
        if (controlMode == MODE_MANUAL) Motor_SetDirection(DIR_LEFT);
        break;
    case CMD_RIGHT:
        if (controlMode == MODE_MANUAL) Motor_SetDirection(DIR_RIGHT);
        break;
    case CMD_STOP:
        if (controlMode == MODE_MANUAL) Motor_SetDirection(DIR_STOP);
        break;
    case CMD_SPIN_LEFT:
        if (controlMode == MODE_MANUAL) Motor_SetDirection(DIR_SPIN_LEFT);
        break;
    case CMD_SPIN_RIGHT:
        if (controlMode == MODE_MANUAL) Motor_SetDirection(DIR_SPIN_RIGHT);
        break;

    case CMD_SPEED_LOW:
        Motor_SetSpeed(SPEED_LOW_PWM);
        Bluetooth_SendString("Speed: LOW (30%)\r\n");
        break;
    case CMD_SPEED_MED:
        Motor_SetSpeed(SPEED_MEDIUM_PWM);
        Bluetooth_SendString("Speed: MEDIUM (60%)\r\n");
        break;
    case CMD_SPEED_HIGH:
        Motor_SetSpeed(SPEED_HIGH_PWM);
        Bluetooth_SendString("Speed: HIGH (80%)\r\n");
        break;
    case CMD_SPEED_MAX:
        Motor_SetSpeed(SPEED_MAX_PWM);
        Bluetooth_SendString("Speed: MAX (100%)\r\n");
        break;

    case CMD_INFO:
        Bluetooth_SendInfo();
        break;
    case CMD_HELP:
        Bluetooth_SendHelp();
        break;
    case CMD_TEST:
        Motor_Test_Sequence();
        break;

    case CMD_MANUAL_MODE:
        controlMode = MODE_MANUAL;
        Motor_Stop();
        avoidStep = 0;
        Bluetooth_SendString("Mode: Manual(BT)\r\n");
        break;
    case CMD_AUTO_MODE:
        controlMode = MODE_AVOID;
        Motor_Stop();
        avoidStep = 0;
        Bluetooth_SendString("Mode: Auto Avoid\r\n");
        break;
    case CMD_SOUND_MODE:
        controlMode = MODE_SOUND;
        Motor_Stop();
        Bluetooth_SendString("Mode: Sound Locate\r\n");
        break;

    case CMD_SERVO_LEFT:
        Servo_SetAngle(150);
        Bluetooth_SendString("Servo: 150 deg\r\n");
        break;
    case CMD_SERVO_RIGHT:
        Servo_SetAngle(30);
        Bluetooth_SendString("Servo: 30 deg\r\n");
        break;

    case CMD_ULTRASONIC:
    {
        uint32_t dist = Ultrasonic_GetDistanceFiltered();
        sprintf(response, "Distance(filtered): %u cm\r\n", (unsigned int)dist);
        Bluetooth_SendString(response);
    }
    break;

    case CMD_DEBUG:
    {
        uint32_t dist = Ultrasonic_GetDistanceFiltered();
        sprintf(response, "Front distance: %u cm\r\n", (unsigned int)dist);
        Bluetooth_SendString(response);
    }
    break;

    case '\r':
    case '\n':
        break;
    default:
        sprintf(response, "Unknown command: %c\r\n", cmd);
        Bluetooth_SendString(response);
        Bluetooth_SendHelp();
        break;
    }
}

//=============================================================================
// System Init & Tick
//=============================================================================
void System_Init(void) {
    Motor_Init();
    controlMode = MODE_MANUAL;
    avoidStep = 0;

    Bluetooth_SendString("\r\n******************************\r\n");
    Bluetooth_SendString("*  STM32 Smart Car Control   *\r\n");
    Bluetooth_SendString("*  BT + Avoid + Sound Locate *\r\n");
    Bluetooth_SendString("******************************\r\n");
    Bluetooth_SendHelp();

    // Servo init
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
    Servo_SetAngle(90);

    // Ultrasonic init (DWT)
    DWT_Init();
    Ultrasonic_Init();

    // Mic init
    Mic_Init();

    HAL_Delay(2000);
    Bluetooth_SendString("System ready. Type '?' for help\r\n");
}

void System_Tick(void) {
    static uint32_t lastTick = 0;
    uint32_t now = HAL_GetTick();
    if (now - lastTick >= 100) {
        systemUptime += 100;
        lastTick = now;
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
    }
}

//=============================================================================
// Callbacks
//=============================================================================
void HAL_UART_RxCpltCallback(UART_HandleTypeDef* huart) {
    if (huart->Instance == USART1) {
        rxDataReady = 1;
        HAL_UART_Receive_IT(&huart1, (uint8_t*)&rxData, 1);
    }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    if (GPIO_Pin == GPIO_PIN_9) {
        if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9) == GPIO_PIN_SET) {
            echoStartTime = DWT_GetMicros();
            echoRisingFlag = 1;
        } else {
            echoEndTime = DWT_GetMicros();
            echoFlag = 1;
        }
    }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
    System_Init();
    HAL_UART_Receive_IT(&huart1, (uint8_t*)&rxData, 1);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    while (1) {
        // Process BT commands
        if (rxDataReady) {
            rxDataReady = 0;
            Process_Bluetooth_Command((char)rxData);
        }

        // Auto modes
        if (controlMode == MODE_AVOID) {
            Auto_Avoid_Obstacle();
        }
        else if (controlMode == MODE_SOUND) {
            Auto_Sound_Localize();
        }

        // System tick
        System_Tick();

        // Delay to avoid over-looping
        HAL_Delay(10);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void Error_Handler(void) {
    while (1) {
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
        HAL_Delay(100);
    }
}
/* USER CODE END 4 */
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */